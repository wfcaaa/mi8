#!/usr/bin/perl

#=============================================================================#
#
# Script : coverageExtractor.pl
#
# This script extracts the code coverage from index.html for a component.
#
#-----------------------------------------------------------------------------#

use strict;

{
  # index.html is provided as input
  my $inputFile = shift(@ARGV);
  open(INFILE, $inputFile) or die $!;

  my $componentName = shift(@ARGV);
  my $baseComponentName = (split "/",$componentName)[-1];
  my $coveredLineFinal = 0;
  my $totalLineFinal = 0;
  my $found = 0;

  # Read index.html to extract code coverage
  while(<INFILE>){


    if ((/Main\//) && (/index\.html"/)){

      # Ignore if some other component
      if( (/\/Main\/index\.html"/) && (!/$baseComponentName/) ){
        next;
      }

      my $nextLine;
      my $lineCounter;
      for($lineCounter = 0; $lineCounter < 5; $lineCounter += 1){
          $nextLine = <INFILE>;
      }
      # Extract covered lines and total lines for "Main"
      if ($nextLine =~ />\s*(\d*\s?\/\s?\d*)/){
        (my $coveredLine, my $totalLine) = split("/", $1);
        chomp($coveredLine);
        chomp($totalLine);

        $coveredLineFinal = $coveredLineFinal + $coveredLine;
        $totalLineFinal = $totalLineFinal + $totalLine;
      }
    }

    if ((/src\//) && (/\/index\.html"/)){
      my $nextLine;
      my $lineCounter;
      for($lineCounter = 0; $lineCounter < 5; $lineCounter += 1){
          $nextLine = <INFILE>;
      }
      # Extract covered lines and total lines for "src"
      if ($nextLine =~ />\s*(\d*\s?\/\s?\d*)/){
        (my $coveredLine, my $totalLine) = split("/", $1);
        chomp($coveredLine);
        chomp($totalLine);
        $coveredLineFinal = $coveredLineFinal + $coveredLine;
        $totalLineFinal = $totalLineFinal + $totalLine;
      }
    }
  }
  close(INFILE);

  # Calculate % coverage
  if(0 != $totalLineFinal){
    my $avgCov = (($coveredLineFinal / $totalLineFinal) * 100);
    print sprintf("%.2f", $avgCov);
  }
}
