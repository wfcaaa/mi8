#!/bin/sh
ME=$(basename $0)
HERE=$(dirname $(readlink -f $0))
PASS=0
IS_CLEAN_UP_SUCCEED=999
function cleanup
{
  echo "---------------------------------"
  echo "|          clean up             |"
  echo "---------------------------------"

  IS_CLEAN_UP_SUCCEED=1
  $XOC_SYSTEM/bin/killPH 
#1>/dev/null
  judge_execution $? killPH
 
  $XOC_SYSTEM/bin/killTcct 
#1>/dev/null
  judge_execution $? killTcct

  /opt/hp93000/soc/prod_env/lbin/kill_smarTest -f 
#1>/dev/null
  judge_execution $? kill_smarTest
 
  rm -rf $XOC_SYSTEM/log/* 

  if [[ $IS_CLEAN_UP_SUCCEED -ne 1 ]]
  then
    leave 1
  fi
}

function judge_execution
{
  if [[ $1 -ne 0 ]]
  then
    echo "*****$2 error*****"
    IS_CLEAN_UP_SUCCEED=0
  else
    echo "*****$2 successfully*****"
  fi
}

function build_runner
{
  echo "---------------------------------"
  echo "|    build the test cases       |"
  echo "---------------------------------"
  cd cases && 
  make clean && 
  make

  status=$?

  cd ..

  if [[ $status -ne 0 ]]
  then
    leave 1
  fi
}

function backup_logs
{
  echo "---------------------------------"
  echo "|       backup the logs         |"
  echo "---------------------------------"

  rm -rf testbed/logs/bak 1>/dev/null
  mkdir -p testbed/logs/bak/ 1>/dev/null

  if [[ -d testbed/logs/latest/ ]]
  then
    cp -rf testbed/logs/latest/* testbed/logs/bak/ 1>/dev/null
  else
    mkdir testbed/logs/latest/ 1>/dev/null
    mkdir testbed/logs/bak/ 1>/dev/null
  fi
}

function copy_workspaces
{
  echo "---------------------------------"
  echo "|    copy the workspaces        |"
  echo "---------------------------------"

  rm -rf testbed/workspaces && 
  cp -rf -L testbed/workspace_templates testbed/workspaces

  status=$?

  if [[ $status -ne 0 ]]
  then
    leave 1
  fi

}

function compile_workspace
{
  echo "---------------------------------"
  echo "|    compile the workspaces        |"
  echo "---------------------------------"
  FILE=testbed/workspaces
  
  for dir in $FILE/*/
  do
      dir=${dir%*/}
      workspace=$FILE/${dir##*/}
      if [ -e $workspace/projects.map ]
      then
	echo "---------------------------------"
	echo "|    compile the workspaces $workspace  |"
	echo "---------------------------------"
	$HERE/doTplc.sh $workspace /tmp/.tplc_$USER
      fi
      
      status=$?
      if [[ $status -ne 0 ]]
      then
	leave 1
      fi
  done
  
}


function list_cases
{
  echo "---------------------------------"
  echo "|     list the test cases       |"
  echo "---------------------------------"
  ./cases/runner --gtest_list_tests | tee testbed/logs/test.list
}

function execute_cases
{
  if [[ -n $1 ]]
  then 
    echo "---------------------------------"
    echo "|    execute the test cases $1   |"
    echo "---------------------------------"
    $XOC_SYSTEM/bin/run ./cases/runner --gtest_filter=$1* --gtest_output=xml:testbed/logs/latest/test_logs.xml 
  else
    # First list all cases in a file, and then parse all cases in a array
    # Then iterate the the test cases execution, with this approach, even one case crashes, the test can continue
    input=testbed/logs/test.list
    i=0
    while IFS= read -r line
    do
      if [[ "$line" == *. ]]; then
        testSuites[$i]=$line
	#suite=$line
        #else
	#testSuites[$i]=$suite`echo $line`
	i=$(($i+1))
      fi
    done < "$input"

    for suite in "${testSuites[@]}"
    do
      execute_cases $suite || continue
    done
  fi
  PASS=`expr $PASS + $?`  
}

function savelog
{
  echo "---------------------------------"
  echo "|      save log files            |"
  echo "---------------------------------"
  cp -rf $XOC_SYSTEM/log/* testbed/logs/latest/
}

function leave
{
  echo ">>>>>>>>> Leaving " $PWD
  echo ""
  echo ""
  exit $1
}

function enter()
{
  echo ""
  echo ""
  echo ">>>>>Entering " $PWD
  echo "`tput setaf 2`================================"
  echo "     Testing Module $(basename $PWD) "
  echo "================================`tput sgr0`"
  export XOC_TEST_MODULE=$PWD
  export XOC_TEST_WORKSPACES=$PWD/testbed/workspaces

  if [[ -z $XOC_SYSTEM ]]
  then
    echo "ERROR: run set_environment.ksh before running the integration tests!"
    exit 1;
  fi

  if [[ -e "$PWD/preRun.sh" ]]
  then
     $PWD/preRun.sh
  fi
}

export XOC_TEST_MODULE=$PWD
export XOC_TEST_BED=$PWD/testbed

#enter the tests
enter

#clean up
cleanup

#copy the workspaces
copy_workspaces 

#compile the workspace
compile_workspace

#build the test runner
build_runner

#copy the logs to bak directory
backup_logs

#list the test cases
list_cases

#execute the test cases, user can specify a single test case in this way: ./run_tests.sh TestCaseName,
#If not specified, all test cases will be executed
execute_cases $1

#save test execution logs
savelog

#clean up again
cleanup

#leave the tests
leave $PASS;

