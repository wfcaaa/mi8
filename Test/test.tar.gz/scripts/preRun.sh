#!/bin/sh
#untar all devices in the resoure folder
DEVICE_DIR=testbed/devices
DEVICE_UNTAR=$DEVICE_DIR/untar/
rm -rf $DEVICE_UNTAR
mkdir $DEVICE_UNTAR
FILES=$DEVICE_DIR/*.gz
for f in $FILES
do
  echo "extract device $f ..."
  tar -xzf $f -C $DEVICE_UNTAR
  DEVICE_DIR=`basename $f .tar.gz`
  if [ -e $DEVICE_UNTAR/$DEVICE_DIR/build.xml ]
  then
    pwd=$PWD
    cd $DEVICE_UNTAR/$DEVICE_DIR/
    echo "build the device ..."
    ant clean;ant
    cd $pwd
  fi
done

#Here copy the libedl.so to be libinternaledl.so, so later can run test cases which test custom formatter
#The test case normally an existed fomatter run with latest libedl, so this can test the compatiblity issue
#Rename the libedl to libinternaledl so that can pass the formatter link validation
EDLDIR=/tmp/edllib
rm ${EDLDIR}/* -f
mkdir ${EDLDIR} -p
cp ${XOC_SYSTEM}/lib/libedl.so ${EDLDIR}/libinternaledl.so