/**
 * Copyright by Advantest, 2019
 *
 * @author  zoyiyu
 * @date    Sep 10, 2019
 */

#include "AbstractUtilityTest.hpp"

class TestStartSmartest : public AbstractUtilityTest {
protected:
  static string START_SMARTEST_TOOL;
  static string TEST_PRODUCTION_CONFIG_1;
  static string TEST_PRODUCTION_CONFIG_2;
  static string TEST_PRODUCTION_CONFIG_3;
};

string TestStartSmartest::START_SMARTEST_TOOL = tcct_workspace
    + "/system/bin/start_smartest_services ";

string TestStartSmartest::TEST_PRODUCTION_CONFIG_1 = testHome
    + "/testbed/config/production_environment_config_1.xml";

string TestStartSmartest::TEST_PRODUCTION_CONFIG_2 = testHome
    + "/testbed/config/production_environment_config_2.xml";

string TestStartSmartest::TEST_PRODUCTION_CONFIG_3 = testHome
    + "/testbed/config/production_environment_config_3.xml";


/**
 * Test start smartest
 */
TEST_F(TestStartSmartest, startSmartest1)
{
  TRY_BEGIN

  // start smartest1
  string command = START_SMARTEST_TOOL + TEST_PRODUCTION_CONFIG_1 + " 5";
  system(command.c_str());

  // start smartest2
  command = START_SMARTEST_TOOL + TEST_PRODUCTION_CONFIG_1 + " 5";
  system(command.c_str());

  TRY_END_FAIL
}

TEST_F(TestStartSmartest, startSmartest2)
{
  TRY_BEGIN

  // start smartest1
  string command = START_SMARTEST_TOOL + TEST_PRODUCTION_CONFIG_1 + " 5";
  system(command.c_str());

  // start smartest2
  command = START_SMARTEST_TOOL + TEST_PRODUCTION_CONFIG_2 + " 5";
  system(command.c_str());

  TRY_END_FAIL
}

TEST_F(TestStartSmartest, startSmartest3)
{
  TRY_BEGIN

  // start smartest
  string command = START_SMARTEST_TOOL + TEST_PRODUCTION_CONFIG_3 + " 5";
  system(command.c_str());

  TRY_END_FAIL
}

TEST_F(TestStartSmartest, startSmartest4)
{
  TRY_BEGIN

  // start smartest
  string command = START_SMARTEST_TOOL;
  system(command.c_str());

  command = START_SMARTEST_TOOL + "\"\" 5";
  system(command.c_str());

  TRY_END_FAIL
}

