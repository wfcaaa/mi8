/**
 * Copyright by Advantest, 2021
 *
 * @author  zoyiyu
 * @date    Oct 18, 2021
 */

#include "AbstractUtilityTest.hpp"

class TestSetDiePosXYOfSite : public AbstractUtilityTest {
protected:
  string sessionId;
  vector<string> param_list;
  string comment_out;

  TestProgram &loadTestProgram()
  {
    //start a session
    TesterSession& testerSession = TestCell::getInstance().
                                   newTesterSession().
                                   setModelFile(modelFile).
                                   setWorkspace(ws[0]).
                                   start();
    sessionId = testerSession.getSessionId();

    // load testProgram
    return testerSession.testProgram().activate("TestProgramSample/src/tp/MyTestProgram4.prog").load();
  }

  void startPHSession(PHSession &phSession){
    string driverPath = sysPath + "/phcontrol/drivers/Generic_93K_Driver/GenericHandler/MCT/";
    string driverConfig = testHome + "/testbed/drivers/GenericHandler/MCT/config/MCT-FH1200-GPIB-4.cfg";
    phSession.setDriverPath(driverPath).setConfigPath(driverConfig).start().connect();
  }
};

extern "C" {
  int setDiePosXYOfSite(const string& sessionID, const vector<string>& param_list_input, string& comment_out);
}

/**
 * TestSet Die PosXY 
 */
TEST_F(TestSetDiePosXYOfSite, setDiePosXYOfSite)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  //start a PH session
  PHSession &phSession = TestCell::getInstance().newPHSession();
  startPHSession(phSession);


  MultiSiteLong x_coord;
  MultiSiteLong y_coord;
  x_coord.set(1, 1);
  x_coord.set(2, 2);
  x_coord.set(3, 3);
  x_coord.set(4, 4);
  y_coord.set(1, 1);
  y_coord.set(2, 2);
  y_coord.set(3, 3);
  y_coord.set(4, 4);
  tp.setTPVariable("STDF.X_COORD", x_coord);
  tp.setTPVariable("STDF.Y_COORD", y_coord);

  int rtn;
  param_list.push_back(phSession.getSessionId());
  param_list.push_back("1 2 4");
  rtn = setDiePosXYOfSite(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 0);

  // simulator with offline mode and return empty xy coordinate
  MultiSiteLong xcoord = tp.getTPVariableLong("STDF.X_COORD");
  MultiSiteLong ycoord = tp.getTPVariableLong("STDF.Y_COORD");

  EXPECT_TRUE(xcoord.get(1) == 0);
  EXPECT_TRUE(xcoord.get(2) == 0);
  EXPECT_TRUE(xcoord.get(3) == 0);
  EXPECT_TRUE(xcoord.get(4) == 0);
  EXPECT_TRUE(ycoord.get(1) == 0);
  EXPECT_TRUE(ycoord.get(2) == 0);
  EXPECT_TRUE(ycoord.get(3) == 0);
  EXPECT_TRUE(ycoord.get(4) == 0);

  phSession.stop();

  TRY_END_FAIL
}

