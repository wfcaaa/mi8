/**
 * Copyright by Advantest, 2019
 *
 * @author  zoyiyu
 * @date    Sep 10, 2019
 */

#include "AbstractUtilityTest.hpp"

class TestStartTCServices : public AbstractUtilityTest {
protected:
  static string START_TCCT_TOOL;
  static string KILL_TCCT_TOOL;
  static string START_TESTCELL_SESSION;
};

string TestStartTCServices::START_TCCT_TOOL = tcct_workspace
    + "/system/bin/tcct ";

string TestStartTCServices::KILL_TCCT_TOOL = tcct_workspace
    + "/system/bin/killTcct ";

string TestStartTCServices::START_TESTCELL_SESSION = tcct_workspace
    + "/system/bin/start_tc_services ";

/**
 * Test start TestCell session
 */
TEST_F(TestStartTCServices, startTestcellSession)
{
  TRY_BEGIN

  // start TCCT
  system(START_TCCT_TOOL.c_str());

  system(KILL_TCCT_TOOL.c_str());

  TRY_END_FAIL
}

TEST_F(TestStartTCServices, startTestcellSession2)
{
  TRY_BEGIN

  // start Testcell session alone
  system(START_TESTCELL_SESSION.c_str());

  TRY_END_FAIL
}
