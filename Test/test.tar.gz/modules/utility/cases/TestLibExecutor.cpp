/**
 * Copyright by Advantest, 2019
 *
 * @author  zoyiyu
 * @date    Sep 10, 2019
 */

#include "AbstractUtilityTest.hpp"
#include "util/Helper.hpp"

using namespace ::recipe::util;

class TestLibExecutor : public AbstractUtilityTest {
protected:
  static string START_TCCT_TOOL;
  static string EXECUTE_LIBRARY_TOOL;
  static string LIBRARY_PATH;
};

string TestLibExecutor::START_TCCT_TOOL = tcct_workspace
    + "/system/bin/tcct ";

string TestLibExecutor::EXECUTE_LIBRARY_TOOL = tcct_workspace
    + "/system/bin/LibExecutor ";

string TestLibExecutor::LIBRARY_PATH = tcct_workspace
    + "/system/lib/libpartIDIncrement.so";

/**
 * Test execute external library
 */
TEST_F(TestLibExecutor, executeExternalLibrary1)
{
  TRY_BEGIN

  // start exec library tool
  string command = EXECUTE_LIBRARY_TOOL;
  system(command.c_str());

  TRY_END_FAIL
}

TEST_F(TestLibExecutor, executeExternalLibrary2)
{
  TRY_BEGIN

  vector<string> functions;
  functions.push_back("autoIncrementPartID");

  TestCell &testCell = TestCell::getInstance();

  ::Helper::loadLibraryInSeparateProcess(LIBRARY_PATH, functions);

  TRY_END_FAIL
}

TEST_F(TestLibExecutor, executeExternalLibrary3)
{
  TRY_BEGIN

  vector<string> functions;
  functions.push_back("autoIncrementPartID");

  TestCell &testCell = TestCell::getInstance();

  ::Helper::loadLibraryInSeparateProcess(LIBRARY_PATH, functions);

  string sessionID = "sessionid_1";
  vector<string> sv;
  string comment;
  string out;
  ::Helper::callLibFunctionInSeparateProcess(sessionID, LIBRARY_PATH, functions[0], sv, comment, out);

  ::Helper::unloadLibraryInProcess(LIBRARY_PATH);

  TRY_END_FAIL
}

TEST_F(TestLibExecutor, executeExternalLibrary4)
{
  TRY_BEGIN

  vector<string> functions;
  functions.push_back("autoIncrementPartID");

  TestCell &testCell = TestCell::getInstance();

  ::Helper::loadLibraryInSeparateProcess(LIBRARY_PATH, functions);

  raise(SIGUSR1);

  TRY_END_FAIL
}
