/**
 * Copyright by Advantest, 2019
 *
 * @author  zoyiyu
 * @date    Sep 10, 2019
 */

#include "AbstractUtilityTest.hpp"

class TestPHSiteConfiguration : public AbstractUtilityTest {
protected:
  string sessionId;
  vector<string> param_list;
  string comment_out;

  void startPHSession(PHSession &phSession){
    string driverPath = sysPath + "/phcontrol/drivers/Generic_93K_Driver/GenericHandler/Multitest/";
    string driverConfig = testHome + "/testbed/drivers/GenericHandler/Multitest/config/MT9918-GPIB-4-offline.cfg";
    phSession.setDriverPath(driverPath).setConfigPath(driverConfig).start().connect();
  }
};

extern "C" {
  int setPHSiteMap(const string& sessionID, const vector<string>& param_list_input, string& comment_out);
  int setPHSiteMask(const string& sessionID, const vector<string>& param_list_input, string& comment_out);
  int setPHSiteIDs(const string& sessionID, const vector<string>& param_list_input, string& comment_out);
}

/**
 * Test PH site configuration
 */
TEST_F(TestPHSiteConfiguration, phConfiguration)
{
  TRY_BEGIN

  //start a PH session
  PHSession &phSession = TestCell::getInstance().newPHSession();
  startPHSession(phSession);

  int rtn;
  // site map [ 1 2 3 4 ]
  param_list.push_back(phSession.getSessionId());
  param_list.push_back("1 2 4");
  param_list.push_back("smartest_site_to_handler_site_map");
  rtn = setPHSiteMap(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 0);
  string site_map = phSession.getConfigParam("smartest_site_to_handler_site_map");
  EXPECT_TRUE(site_map == "[ 1 2 3 4 ]");
  vector<string>().swap(param_list);

  // site mask [ 1 1 0 1 ]
  param_list.push_back(phSession.getSessionId());
  param_list.push_back("1 2 4");
  param_list.push_back("handler_site_mask");
  rtn = setPHSiteMask(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 0);
  string site_mask = phSession.getConfigParam("handler_site_mask");
  EXPECT_TRUE(site_mask == "[ 1 1 0 1 ]");
  vector<string>().swap(param_list);

  // site IDs [ "1" "2" "3" "4" ]
  param_list.push_back(phSession.getSessionId());
  param_list.push_back("1 2 4");
  param_list.push_back("handler_site_ids");
  rtn = setPHSiteIDs(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 0);
  string site_ids = phSession.getConfigParam("handler_site_ids");
  EXPECT_TRUE(site_ids == "[ \"1\" \"2\" \"3\" \"4\" ]");
  vector<string>().swap(param_list);

  // site IDs [ "A" "B" "C" "D" ]
  param_list.push_back(phSession.getSessionId());
  param_list.push_back("1 2 4");
  param_list.push_back("handler_site_ids");
  param_list.push_back("true");
  rtn = setPHSiteIDs(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 0);
  site_ids = phSession.getConfigParam("handler_site_ids");
  EXPECT_TRUE(site_ids == "[ \"A\" \"B\" \"C\" \"D\" ]");
  vector<string>().swap(param_list);

  // invalid parameter
  rtn = setPHSiteMap(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 1);
  vector<string>().swap(param_list);

  param_list.push_back("");
  rtn = setPHSiteMap(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 1);
  vector<string>().swap(param_list);

  param_list.push_back(phSession.getSessionId());
  param_list.push_back("");
  param_list.push_back("");
  rtn = setPHSiteMask(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 1);
  vector<string>().swap(param_list);

  param_list.push_back(phSession.getSessionId());
  param_list.push_back("1 2 4");
  param_list.push_back("xxxx");
  rtn = setPHSiteMap(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 1);
  vector<string>().swap(param_list);

  param_list.push_back(phSession.getSessionId());
  param_list.push_back("1 2 4");
  param_list.push_back("xxxx");
  rtn = setPHSiteMask(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 1);
  vector<string>().swap(param_list);

  param_list.push_back(phSession.getSessionId());
  param_list.push_back("1 2 4");
  param_list.push_back("xxxx");
  rtn = setPHSiteIDs(sessionId, param_list, comment_out);
  EXPECT_TRUE(rtn == 1);
  vector<string>().swap(param_list);

  phSession.stop();

  TRY_END_FAIL
}

