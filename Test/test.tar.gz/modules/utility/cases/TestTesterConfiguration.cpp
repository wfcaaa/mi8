/**
 * Copyright by Advantest, 2019
 *
 * @author  zoyiyu
 * @date    Sep 10, 2019
 */

#include "AbstractUtilityTest.hpp"

class TestTesterConfiguration : public AbstractUtilityTest {
protected:
  string sessionId;
  vector<string> param_list;
  string comment_out;
  string output;

  TestProgram &loadTestProgram()
  {
    //start a session
    TesterSession& testerSession = TestCell::getInstance().
                                   newTesterSession().
                                   setModelFile(modelFile).
                                   setWorkspace(ws[0]).
                                   start();
    sessionId = testerSession.getSessionId();

    // load testProgram
    return testerSession.testProgram().activate("TestProgramSample/src/tp/MyTestProgram4.prog").load();
  }
};

extern "C" {
  int mask(const string& sessionID,
           const vector<string>& parm_list_input, string& coment_out, string& output);
}

extern "C" int setMultiSiteVariableWithSplitter(const string& sessionID,
                    const vector<string>& parm_list_input, string& comment_out, string& output);

/**
 * Test SITE_MASK_FOR_SITES
 */
TEST_F(TestTesterConfiguration, site_mask_for_sites_normal)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  // mask site 2,3
  param_list.push_back("0");
  param_list.push_back("1");
  param_list.push_back("1");
  param_list.push_back("0");
  mask(sessionId, param_list, comment_out, output);

  MultiSiteString siteMask = tp.getTCVariableString("SITE_MASK_FOR_SITES");

  EXPECT_TRUE(siteMask.get(1) == "0");
  EXPECT_TRUE(siteMask.get(2) == "1");
  EXPECT_TRUE(siteMask.get(3) == "1");
  EXPECT_TRUE(siteMask.get(4) == "0");

  TRY_END_FAIL
}

TEST_F(TestTesterConfiguration, site_mask_for_sites_pattern)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  // mask site 1,3
  param_list.push_back("1:1");
  param_list.push_back("3:1");
  param_list.push_back("*:0");
  mask(sessionId, param_list, comment_out, output);

  MultiSiteString siteMask = tp.getTCVariableString("SITE_MASK_FOR_SITES");

  EXPECT_TRUE(siteMask.get(1) == "1");
  EXPECT_TRUE(siteMask.get(2) == "0");
  EXPECT_TRUE(siteMask.get(3) == "1");
  EXPECT_TRUE(siteMask.get(4) == "0");

  TRY_END_FAIL
}

TEST_F(TestTesterConfiguration, site_mask_for_sites_invalid)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  // mask site 2,3
  param_list.push_back("1:2 3:2");
  param_list.push_back("*:3");
  int rtn = mask(sessionId, param_list, comment_out, output);

  EXPECT_TRUE(rtn == 1);

  TRY_END_FAIL
}

TEST_F(TestTesterConfiguration, set_tc_variable_with_splitter_normal)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  // variable name
  param_list.push_back("TC_VARIABLE");

  // variable string
  param_list.push_back("x::y::z::c");

  // splitter
  param_list.push_back("::");

  setMultiSiteVariableWithSplitter(sessionId, param_list, comment_out, output);

  MultiSiteString siteMask = tp.getTCVariableString("TC_VARIABLE");

  EXPECT_TRUE(siteMask.get(1) == "x");
  EXPECT_TRUE(siteMask.get(2) == "y");
  EXPECT_TRUE(siteMask.get(3) == "z");
  EXPECT_TRUE(siteMask.get(4) == "c");

  TRY_END_FAIL
}

TEST_F(TestTesterConfiguration, set_tc_variable_with_splitter_miss_variable)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  // variable name
  param_list.push_back("TC_VARIABLE");

  // variable string
  param_list.push_back("x::y::z");

  // splitter
  param_list.push_back("::");

  setMultiSiteVariableWithSplitter(sessionId, param_list, comment_out, output);

  MultiSiteString siteMask = tp.getTCVariableString("TC_VARIABLE");

  EXPECT_TRUE(siteMask.get(1) == "x");
  EXPECT_TRUE(siteMask.get(2) == "y");
  EXPECT_TRUE(siteMask.get(3) == "z");
  EXPECT_TRUE(siteMask.get(4) == "");

  TRY_END_FAIL
}

TEST_F(TestTesterConfiguration, set_tp_variable_with_splitter_normal)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  // variable name
  param_list.push_back("STDF.PART_ID");

  // variable string
  param_list.push_back("1::2::3::4");

  // splitter
  param_list.push_back("::");

  setMultiSiteVariableWithSplitter(sessionId, param_list, comment_out, output);

  MultiSiteString siteMask = tp.getTPVariableString("STDF.PART_ID");

  EXPECT_TRUE(siteMask.get(1) == "1");
  EXPECT_TRUE(siteMask.get(2) == "2");
  EXPECT_TRUE(siteMask.get(3) == "3");
  EXPECT_TRUE(siteMask.get(4) == "4");

  TRY_END_FAIL
}

TEST_F(TestTesterConfiguration, set_tp_variable_with_splitter_miss_variable)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  /*
   * Set variable value to 1,2,3,4
   */
  param_list.push_back("STDF.PART_ID");
  param_list.push_back("1::2::3::4");
  param_list.push_back("::");

  setMultiSiteVariableWithSplitter(sessionId, param_list, comment_out, output);

  MultiSiteString siteMask = tp.getTPVariableString("STDF.PART_ID");

  EXPECT_TRUE(siteMask.get(1) == "1");
  EXPECT_TRUE(siteMask.get(2) == "2");
  EXPECT_TRUE(siteMask.get(3) == "3");
  EXPECT_TRUE(siteMask.get(4) == "4");

  /*
   * change variable value of site one, from 1 to 5
   */
  param_list.clear();
  param_list.push_back("STDF.PART_ID");
  param_list.push_back("5");
  param_list.push_back("::");

  setMultiSiteVariableWithSplitter(sessionId, param_list, comment_out, output);

  siteMask = tp.getTPVariableString("STDF.PART_ID");

  cout << siteMask.get(1) << siteMask.get(2) << siteMask.get(3) << siteMask.get(4) << endl;

  EXPECT_TRUE(siteMask.get(1) == "5");
  EXPECT_TRUE(siteMask.get(2) == "2");
  EXPECT_TRUE(siteMask.get(3) == "3");
  EXPECT_TRUE(siteMask.get(4) == "4");

  TRY_END_FAIL
}

TEST_F(TestTesterConfiguration, set_tc_variable_with_splitter_invalid_parameter_amount)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  // variable name
  param_list.push_back("TC_VARIABLE");

  // variable string
  param_list.push_back("1::2::3::4");

  // splitter
  param_list.push_back("::");

  // the 4th parameter is invalid because the function only allows 3
  param_list.push_back("invalid parameter");

  int ret = setMultiSiteVariableWithSplitter(sessionId, param_list, comment_out, output);
  EXPECT_TRUE(ret == 1);
  EXPECT_TRUE(comment_out == "Expected amount of input parameters should be 3, but actual value is 4");


  TRY_END_FAIL
}

TEST_F(TestTesterConfiguration, set_variable_with_splitter_invalid_variable_type)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  // variable name
  param_list.push_back("INVALID.VARIABLE");

  // variable string
  param_list.push_back("1::2::3::4");

  // splitter
  param_list.push_back("::");

  int ret = setMultiSiteVariableWithSplitter(sessionId, param_list, comment_out, output);
  EXPECT_TRUE(comment_out == "Only support tp or tc variable, but actual variable is INVALID.VARIABLE");


  TRY_END_FAIL
}

















