/**
 * Copyright by Advantest, 2019
 *
 * @author  zoyiyu
 * @date    Sep 9, 2019
 */

#include "AbstractUtilityTest.hpp"

class TestPartIDIncrement : public AbstractUtilityTest {
protected:
  string sessionId;
  vector<string> param_list;
  string comment_out;
  string output;

  TestProgram &loadTestProgram()
  {
    //start a session
    TesterSession& testerSession = TestCell::getInstance().
                                   newTesterSession().
                                   setModelFile(modelFile).
                                   setWorkspace(ws[0]).
                                   start();
    sessionId = testerSession.getSessionId();

    // load testProgram
    return testerSession.testProgram().activate("TestProgramSample/src/tp/MyTestProgram4.prog").load();
  }
};

extern "C" {
  int autoIncrementPartID(const string& sessionID,
    const vector<string>& parm_list_input, string& coment_out, string& output);
}

/**
 * Test auto increment PART_ID
 */
TEST_F(TestPartIDIncrement, testAutoIncrementPartID)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  //increase PART_ID for 5 times
  for(int i = 0; i < 5; i++)
  {
    autoIncrementPartID(sessionId, param_list, comment_out, output);
  }

  MultiSiteString partID = tp.getTPVariableString("STDF.PART_ID");

  EXPECT_TRUE(partID.get(1) == "17");
  EXPECT_TRUE(partID.get(2) == "18");
  EXPECT_TRUE(partID.get(3) == "19");
  EXPECT_TRUE(partID.get(4) == "20");

  TRY_END_FAIL
}

/**
 * Test PART_ID set from TCCT GUI
 */
TEST_F(TestPartIDIncrement, testIncrementPartIDFromGUI)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  vector<long> enabledSites = {1,2,4};
  tp.testflow().setEnabledSites(enabledSites);

  string varName1 = "PH_ENABLE_SITES";
  string varName2 = "SITE_MASK_FOR_SITES";
  string varName3 = "PART_ID_SET_GUI";

  // enable all sites
  MultiSiteString values1("1");
  MultiSiteString values2("0");
  MultiSiteBoolean values3(true);

  tp.setTCVariable(varName1, values1);
  tp.setTCVariable(varName2, values2);
  tp.setTCVariable(varName3, values3);

  //increase PART_ID for 5 times for all sites 1,2,3,4
  for(int i = 0; i < 5; i++)
  {
    autoIncrementPartID(sessionId, param_list, comment_out, output);
  }

  MultiSiteString partID = tp.getTPVariableString("STDF.PART_ID");

  EXPECT_TRUE(partID.get(1) == "5");
  EXPECT_TRUE(partID.get(2) == "");
  EXPECT_TRUE(partID.get(3) == "");
  EXPECT_TRUE(partID.get(4) == "");

  TRY_END_FAIL
}


/**
 * Test PART_ID calculate from TC vars
 */
TEST_F(TestPartIDIncrement, testIncrementPartIDForTCVar)
{
  TRY_BEGIN

  //load testProgram
  TestProgram& tp = loadTestProgram();

  vector<long> enabledSites = {1,2,4};
  tp.testflow().setEnabledSites(enabledSites);

  string varName1 = "PH_ENABLE_SITES";
  string varName2 = "SITE_MASK_FOR_SITES";
  string varName3 = "PART_ID_SET_GUI";

  // enable sites 1,2,4
  MultiSiteString values1;
  values1.set(1, "1");
  values1.set(2, "2");
  values1.set(3, "4");

  // mask site 2,3
  MultiSiteString values2;
  values2.set(1, "0");
  values2.set(2, "1");
  values2.set(3, "1");
  values2.set(4, "0");

  MultiSiteBoolean values3(false);

  tp.setTCVariable(varName1, values1);
  tp.setTCVariable(varName2, values2);
  tp.setTCVariable(varName3, values3);

  //increase PART_ID for 5 times for final enable sites 1,4
  for(int i = 0; i < 5; i++)
  {
    autoIncrementPartID(sessionId, param_list, comment_out, output);
  }

  MultiSiteString partID = tp.getTPVariableString("STDF.PART_ID");

  EXPECT_TRUE(partID.get(1) == "9");
  EXPECT_TRUE(partID.get(2) == "");
  EXPECT_TRUE(partID.get(3) == "");
  EXPECT_TRUE(partID.get(4) == "10");

  TRY_END_FAIL
}
