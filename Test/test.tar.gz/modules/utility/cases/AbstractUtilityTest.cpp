/**
 * Copyright by Advantest, 2019
 *
 * @author  zoyiyu
 * @date    Sep 9, 2019
 */
#include "AbstractUtilityTest.hpp"
//static variable definition
string AbstractUtilityTest::sysPath = getenv("XOC_SYSTEM");
string AbstractUtilityTest::tcct_workspace = getenv("WORKSPACE");
string AbstractUtilityTest::testHome = getenv("XOC_TEST_MODULE");
string AbstractUtilityTest::wsHome = getenv("XOC_TEST_WORKSPACES");
string AbstractUtilityTest::modelFile =  testHome + "/testbed/models/model.dd1_updated";
vector<string> AbstractUtilityTest::ws = vector<string>();


AbstractUtilityTest::AbstractUtilityTest()
{
  // TODO Auto-generated constructor stub

}

AbstractUtilityTest::~AbstractUtilityTest()
{
  // TODO Auto-generated destructor stub
}

// Per-test-case set-up.
void AbstractUtilityTest::SetUpTestCase()
{
  if(access("/opt/hp93000/soc/prod_env/lbin/kill_smarTest", X_OK) != 0 ||
     access("/opt/hp93000/soc/prod_env/bin/HPSmarTest", X_OK) != 0 )
  {
    throw(runtime_error("kill_smarTest and HPSmarTest are not executable. SmarTest may not be installed!"));
  }

  ws.push_back(wsHome + "/ws");
}

// Per-test-case tear-down.
void AbstractUtilityTest::TearDownTestCase()
{
}

// Per-test set-up
void AbstractUtilityTest::SetUp()
{
  int ret = system("/opt/hp93000/soc/prod_env/lbin/kill_smarTest -f");

  if(ret == -1 || WEXITSTATUS(ret) != 0)
  {
    throw(runtime_error("Failed to execute /opt/hp93000/soc/prod_env/lbin/kill_smarTest"));
  }

  sleep(1);
}

// Per-test tear-down
void AbstractUtilityTest::TearDown()
{
}
