#!/bin/sh
#untar all devices in the resoure folder
DEVICE_DIR=testbed/devices
DEVICE_UNTAR=$DEVICE_DIR/untar/
rm -rf $DEVICE_UNTAR
mkdir $DEVICE_UNTAR
FILES=$DEVICE_DIR/*.gz
for f in $FILES
do
  echo "extract device $f ..."
  tar -xzf $f -C $DEVICE_UNTAR
  DEVICE_DIR=`basename $f .tar.gz`
  if [ -e $DEVICE_UNTAR/$DEVICE_DIR/build.xml ]
  then
    pwd=$PWD
    cd $DEVICE_UNTAR/$DEVICE_DIR/
    echo "build the device ..."
    ant clean;ant
    cd $pwd
  fi
done
