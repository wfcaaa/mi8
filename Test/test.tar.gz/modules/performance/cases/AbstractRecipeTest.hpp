/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#ifndef H51EABF7C_81FD_4FF1_81E0_2CE2E2E219A9
#define H51EABF7C_81FD_4FF1_81E0_2CE2E2E219A9
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include <exception>
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <pthread.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <ctype.h>
#include <stdlib.h>
#include <errno.h>
#include <fstream>
#include <unistd.h>
#include <pwd.h>
#include <mqueue.h>
#include "exception_handler.hpp"

using namespace xoc::tcapi;
using namespace std;

class AbstractRecipeTest : public testing::Test {
public:
  AbstractRecipeTest();
  virtual ~AbstractRecipeTest();

  static void SetUpTestCase();

  static void TearDownTestCase();

  // Per-test set-up
  virtual void SetUp();

  virtual void TearDown();

  void executeRecipe(const string& path,Recipe *executor=NULL);

  void executeRecipeNoException(const string& path,Recipe *executor=NULL);

  static string testHome;
  static string wsHome;
  static string recipesDir;
};
#endif /* H51EABF7C_81FD_4FF1_81E0_2CE2E2E219A9 */
