#include "AbstractRecipeTest.hpp"

int executeCustomCommand(const string & command);
string& trim(string &s);

class TestRecipeIndexTime : public AbstractRecipeTest {
protected:
  static string TEST_RECIPE_ELEMENT_HANDLER;
  static string TEST_RECIPE_ELEMENT_WAFER;
};


string TestRecipeIndexTime::TEST_RECIPE_ELEMENT_HANDLER = recipesDir + "test_indextime_Multitest_handler.xml";
string TestRecipeIndexTime::TEST_RECIPE_ELEMENT_WAFER = recipesDir + "test_indextime_Multitest_wafer.xml";

 TEST_F(TestRecipeIndexTime , testRecipeForHandlerIndexTime)
{
  executeRecipeNoException(TEST_RECIPE_ELEMENT_HANDLER);
  string datalogPath = TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "datalogPath").getCommon();
  string command = "python3 ./testbed/scripts/HandleIndexTime.py " + datalogPath;
  if(executeCustomCommand(command)==-1){
     FAIL() << "Failed with unknown exception" << endl; 
  }
}

 TEST_F(TestRecipeIndexTime , testRecipeForWaferIndexTime)
{
  executeRecipeNoException(TEST_RECIPE_ELEMENT_WAFER);
  string datalogPath = TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString("datalogPath").getCommon();
  string command = "python3 ./testbed/scripts/HandleIndexTime.py " + datalogPath;
  if(executeCustomCommand(command)==-1){
     FAIL() << "Failed with unknown exception" << endl; 
  }
}

int executeCustomCommand(const string & command)
{
  if (command.empty())
  {
    return -1;
  }

  stringstream msg;
  char line[1024] = "";
  FILE *fp = popen(command.c_str(), "r");
  if (fp != NULL)
  {
    msg << "Start executing custom command: " << command;
    cout << msg.str() << endl;
    msg.str("");
    while (fgets(line, sizeof(line)-1, fp) != NULL)
    {
      if(line[0]=='\n'){
	continue;
      }
      msg << line;
    }
    string str_msg=msg.str();
    cout << trim(str_msg)<<endl;
    if (str_msg.find("Index time is exceeded")!=string::npos){
      return -1;
    }

  }else {
    msg.str("");
    msg << "Cannot execute custom command! Please check command: " << command;
    cout << msg.str() << endl;
    return -1;
  }
  cout << "End executing custom command" << endl;
  return pclose(fp);
}


string& trim(string &s)
{
  if (s.empty()) {
    return s;
  }
  s.erase(s.find_last_not_of(" ") + 1);
  s.erase(s.find_last_not_of("	") + 1);
  s.erase(s.find_last_not_of("\n") + 1);

}  
