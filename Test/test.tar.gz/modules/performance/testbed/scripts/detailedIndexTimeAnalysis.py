#!/usr/bin/env python3
import collections
import csv
import datetime
import re
import sys

LOAD_DEVICE = 'load device'
key1 = 'Starting to load device...'
key2 = 'Loading device completed'

CALL_LIBRARY = 'call library'
key3 = 'Starting to execute library call "PartIDLib.autoIncrementPartID"'
key4 = 'Executing library function PartIDLib.autoIncrementPartID successfully'

EXECUTE_MAIN_FLOW = 'execute main flow'
key5 = 'Starting to execute "Main" flow...'
key6 = 'Executing "Main" flow completed'

BIN_DEVICE = 'bin device'
key7 = 'Starting to bin device...'
key8 = 'Binning device completed'

SET_TC_VARIABLE = 'setTCVariable TestCount'
key9 = 'TC variable: TestCount type is STRING'
key10 = 'Setting TC variable "TestCount" to '

LOOP_NUM = 'loop_num'
ITEM_NAME = 'item_name'
EXECUTE_TIME = 'execute_time(ms)'

'''
load slg file to map
'''


def load_recipe_slg(slg_path, key_list):
    map = collections.OrderedDict()
    try:
        with open(slg_path, 'r', encoding='utf-8') as f1:
            for num, value in enumerate(f1):
                for key in key_list:
                    if value.find(key) != -1:
                        map[num] = value
    except Exception as e:
        print("read csv error", e)
        return None
    return map


'''
calculate between  start & end key words
'''


def calculate_time(map, start_key, end_key, item_name):
    total_item_time = 0
    start_item_time = ''
    loop_num = 0
    output_list = []
    for key, value in map.items():
        if value.find(start_key) != -1:
            start_item_time = re.search('\d{2}:\d{2}:\d{2},\d{3}', value).group(0)
            loop_num += 1
        elif value.find(end_key) != -1:
            end_item_time = re.search('\d{2}:\d{2}:\d{2},\d{3}', value).group(0)
            if start_item_time is '':
                print('Previous starting time do not exist')
            else:
                row_list = []
                item_time_delta = time_differ(start_item_time, end_item_time)
                if loop_num > 1:
                    total_item_time += item_time_delta
                row_list.append(item_name)
                row_list.append(',')
                row_list.append(item_time_delta)
                row_list.append(',')
                row_list.append(loop_num)
                row_list.append('\n')
                output_list.append(row_list)
                start_item_time = -1
    avg_item_time = -1
    if loop_num == 0:
        print("No item " + item_name + " find in log")
        return output_list, avg_item_time
    elif loop_num == 1:
        print("Cannot do computing for the item " + item_name + " loop count must larger than 1")
        return output_list, avg_item_time
    # remove the first one
    avg_item_time = round(total_item_time / (len(output_list) - 1), 4)
    return output_list, avg_item_time


'''
compute time in millisecond
'''


def time_differ(time1, time2):
    time1_arr = list(map(int, re.split(':|,', time1)))
    time2_arr = list(map(int, re.split(':|,', time2)))
    delta_time = (time2_arr[3] - time1_arr[3]) \
                 + (time2_arr[2] - time1_arr[2]) * 1000 \
                 + (time2_arr[1] - time1_arr[1]) * 1000 * 60 \
                 + (time2_arr[0] - time1_arr[0]) * 1000 * 60 * 24
    return delta_time


def write_map_to_csv(write_path, map):
    try:
        with open(write_path, 'w', encoding='utf-8') as f2:
            for key in map:
                f2.write(map[key])
    except Exception as e:
        print("read csv error", e)
        return None
    return map


def write_result_collection_to_csv(write_path, result_collection):
    try:
        with open(write_path, 'w', encoding='utf-8') as f2:
            for item in result_collection:
                for row in item:
                    for ele in row:
                        if type(ele) != str:
                            ele = str(ele)
                        f2.write(ele)
    except Exception as e:
        print("write csv error", e)
        return None


def compute_detailed_index_time(slg_path,write_path):

    key_list = [key1, key2, key3, key4, key5, key6, key7, key8, key9, key10]
    slg_data = load_recipe_slg(slg_path, key_list)
    load_device_data = calculate_time(slg_data, key1, key2,
                                      LOAD_DEVICE)
    set_tc_variable = calculate_time(slg_data, key9, key10,
                                     SET_TC_VARIABLE)
    call_library_data = calculate_time(slg_data, key3, key4,
                                       CALL_LIBRARY)
    execute_main_flow = calculate_time(slg_data, key5, key6,
                                       EXECUTE_MAIN_FLOW)
    bin_device = calculate_time(slg_data, key7, key8,
                                BIN_DEVICE)
    print('load device average time cost: %s ms' % load_device_data[1])
    print('set TCVariable average time cost: %s ms' % set_tc_variable[1])
    print('call library average time cost: %s ms' % call_library_data[1])
    print('execute main flow time cost: %s ms' % execute_main_flow[1])
    print('bin device time cost: %s ms' % bin_device[1])

    result_collection = [[ITEM_NAME, ',', EXECUTE_TIME, ',', LOOP_NUM, '\n']]
    result_collection.append(load_device_data[0])
    result_collection.append(set_tc_variable[0])
    result_collection.append(call_library_data[0])
    result_collection.append(execute_main_flow[0])
    result_collection.append(bin_device[0])
    write_result_collection_to_csv(write_path, result_collection)


if __name__ == '__main__':
    slg_path = sys.argv[1]
    write_path = sys.argv[2]
    compute_detailed_index_time(slg_path,write_path)
