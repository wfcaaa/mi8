#!/usr/bin/env python3
import os
import csv
import sys
from detailedIndexTimeAnalysis import compute_detailed_index_time


def execute_cmd(cmd):
    cmd = os.path.expandvars(cmd)
    print("Start to execute command: " + cmd)
    result = os.popen(cmd).read()
    for line in result.split("\n"):
        print(line)


'''
keep 4 decimal place
'''


def base_average_index_time(csv_path):
    sum = 0
    with open(csv_path, 'r', encoding='utf-8') as file:
        reader = csv.reader(file)
        for index, line in enumerate(reader):
            # skip row 0 & row 1
            if index > 1:
                sum = sum + float(line[-1])
    # total number minus 2
    return round(sum / (reader.line_num - 2) * 1000, 4)


if __name__ == '__main__':
    script_path = os.path.dirname(os.path.realpath(__file__))
    recipe_datalog_path = sys.argv[1]
    print("The generated the EDL file is " + recipe_datalog_path)
    recipe_dump_path = recipe_datalog_path + '.edldump'
    # The CSV file saves the index time between EXECUTION_START_EVENT and EXECUTION_END_EVENT
    recipe_index_csv_path = recipe_datalog_path + '.indextime.csv'
    # Save the time cost on recipe operations
    recipe_operations_time= recipe_datalog_path + '.operation.csv'
  
    # The index time benchmark value, if the index time is longer than this value, then the test case fails
    #TODO need change the base index time to be reasonable one 
    base_index_time = 100  
    
    # Back up the TCA running log and later parse the operation time cost from it
    backup_slg_file = 'cp $XOC_SYSTEM/log/Recipe.slg $XOC_TEST_MODULE/testbed/logs'
    execute_cmd(backup_slg_file)
   
    # Covert the EDL file to ascii dump file
    convert_format = 'env -i /opt/hp93000/soc/system/bin/OfflineFormatter -e ' + recipe_datalog_path + ' ' + recipe_dump_path
    execute_cmd(convert_format)
   
    # Generate the index time CSV file
    generate_csv = script_path + '/indextimeFromEDL.RB ' + recipe_dump_path +' ' + recipe_index_csv_path   
    execute_cmd(generate_csv)

    compute_detailed_index_time(os.path.expandvars('$XOC_TEST_MODULE/testbed/logs/Recipe.slg'),recipe_operations_time)
    
    avg_index_time = base_average_index_time(recipe_index_csv_path)
    print('base index average time: %s ms' % base_index_time)
    print('current case index average time: %s ms' % avg_index_time)
    if avg_index_time > base_index_time:
        print("WARNING: Index time is exceeded")
        sys.exit(1)
        
