#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class exampleTest : public ::testing::Test
{

protected:

  // Per-test-case set-up.
  static void SetUpTestCase()
  {
   cout<< "Execute Setup for Test Case" << endl;
  }

  // Per-test-case tear-down.
  static void TearDownTestCase()
  {
    cout<< "Execute TestDown for Test Case" << endl; 
  }
 
  // Per-test set-up
  virtual void SetUp()
  {
     cout<< "Execute Setup for Test" << endl; 
  }

  // Per-test tear-down
  virtual void TearDown()
  {
      cout<< "Execute TearDwon for Test" << endl;
  }
};

TEST_F(exampleTest, testcase1)
{
  ASSERT_EQ(1, 1);
}

TEST_F(exampleTest, testcase2)
{
  ASSERT_EQ(1, 1);
}
