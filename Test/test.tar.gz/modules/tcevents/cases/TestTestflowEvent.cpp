/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestTestflowEvent : public AbstractTest {
};

class TestflowSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumeTestflowEvent(const TestflowEvent &event)
  {
    setEvent(event);
  }
};

TEST_F(TestTestflowEvent, testTestflowEvent)
{
  TRY_BEGIN
    aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram4.prog");
    aSession->testProgram().load();
    aSession->testProgram().bind();
    aSession->testProgram().run();
    TestflowSpecificMonitor monitor;
    startMonitor(monitor);
    aSession->testProgram().testflow().execute();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<TestflowEvent>());
      const TestflowEvent* vEvent = event1->getExtension<TestflowEvent>();
      EXPECT_TRUE(vEvent->getAction() == TestflowEvent::EXECUTE);
      EXPECT_TRUE(vEvent->getProgress() == TestProgramEvent::STARTED);
      EXPECT_TRUE(vEvent->getTestflowName() == "Main");
      EXPECT_TRUE(vEvent->getSessionId() == aSession->getSessionId());
      monitor.eventDone();
    }

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<TestflowEvent>());
      const TestflowEvent* vEvent = event1->getExtension<TestflowEvent>();
      EXPECT_TRUE(vEvent->getAction() == TestflowEvent::EXECUTE);
      EXPECT_TRUE(vEvent->getProgress() == TestProgramEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getTestflowName() == "Main");
      EXPECT_TRUE(vEvent->getSessionId() == aSession->getSessionId());
      EXPECT_TRUE(vEvent->getSites().size() == 1);
      EXPECT_TRUE(vEvent->getSites()[0] == 1);
      EXPECT_TRUE(vEvent->getSoftBins()[0].id == 0);
      EXPECT_TRUE(vEvent->getSoftBins()[0].name == "DEFAULT");
      EXPECT_TRUE(vEvent->getSoftBins()[0].resultType == FAIL);
      EXPECT_TRUE(vEvent->getSoftBins()[0].color == 2);
      EXPECT_TRUE(vEvent->getHardBins()[0].id == 0);
      EXPECT_TRUE(vEvent->getHardBins()[0].name == "DEFAULT");
      EXPECT_TRUE(vEvent->getHardBins()[0].resultType == FAIL);
      monitor.eventDone();
    }

    stopMonitor(monitor);
  TRY_END_FAIL
}

