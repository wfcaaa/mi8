/**
 * Copyright by Advantest, 2019
 *
 * @author  alexguo
 * @date    Nov 8, 2019
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestLicenseEvent : public AbstractTest {
};

class TestLicenseSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumeLicenseEvent(const LicenseEvent &event)
  {
    setEvent(event);
    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
  }
};

TEST_F(TestLicenseEvent, LicenseEvent)
{
  TRY_BEGIN

  map<string, string> envVariable;
  envVariable["XOC_PMON_DEBUG"] = "TRUE";
  TestLicenseSpecificMonitor monitor;
  TestLicenseEvent::startMonitor(monitor);

  // stop first to set the environment variable and then start
  aSession->stop();
  aSession->setEnvVariables(envVariable).start();
  {
    aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram.prog").load().bind().run();
    const Event* event = monitor.getNextEvent();
    EXPECT_TRUE(event->hasExtension<LicenseEvent>());
    const LicenseEvent* vEvent = event->getExtension<LicenseEvent>();
    EXPECT_EQ(LicenseEvent::LICENSE_CHECKED_OUT, vEvent->getAction());
    vector<LicenseInfo> licenseCol = vEvent->getCheckedOutLicenses();
    EXPECT_EQ(licenseCol.size(), 6);
    vEvent->getDurationTime();
    vEvent->getRemainingTime();

    monitor.eventDone();
  }

  TestLicenseEvent::stopMonitor(monitor);
  aSession->stop();
  TRY_END_FAIL
}



