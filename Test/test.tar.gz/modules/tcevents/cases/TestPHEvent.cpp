/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestPHEvent : public AbstractTest {
protected:
  PHSession &startPHSession()
  {
    string sysPath = getenv("XOC_SYSTEM");
    string testModulePath = getenv("XOC_TEST_MODULE");
    string driverPath = testModulePath + "/testbed/drivers/GenericProber/TEL";
    string driverConfig = testModulePath + "/testbed/drivers/GenericProber/TEL/config/P8-GPIB-Prober-4-die-offline.cfg";

    vector<PHSession*> allTS = TestCell::getInstance().getPHSessions();
    if(allTS.size() == 0)
    {
      //start a session
      return  TestCell::getInstance().
                        newPHSession().
                        setDriverPath(driverPath).
                        setDriverType(PHSession::GENERIC_93K_DRIVER).
                        setConfigPath(driverConfig).
                        start();
    }

    return *allTS[0];
  }
};

void cleanup()
{
    // Shut down all SmarTest sessions
    vector<TesterSession *> allSessions = TestCell::getInstance().getTesterSessions();
    for(unsigned int i = 0; i < allSessions.size(); i++ )
    {
      allSessions[i]->stop();
    }

    // Shut down all PH sessions
    vector<PHSession *> allPHSessions = TestCell::getInstance().getPHSessions();
    for(unsigned int i = 0; i < allPHSessions.size(); i++ )
    {
      allPHSessions[i]->stop();
    }
}

class PHSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumePHEvent(const PHEvent &event)
  {
    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
    setEvent(event);
  }

  void consumeSessionEvent(const SessionEvent &event)
  {
    setEvent(event);
  }
};

TEST_F(TestPHEvent, connectSession)
{
  TRY_BEGIN
    PHSpecificMonitor monitor;
    startMonitor(monitor);
    PHSession& aPHSession = startPHSession();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<SessionEvent>());
      const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
      EXPECT_EQ(vEvent->getAction(), SessionEvent::CREATE);
      EXPECT_EQ(vEvent->getProgress(), SessionEvent::COMPLETED);
      EXPECT_EQ(vEvent->getApplication(), SessionEvent::UNKNOWN);
      EXPECT_EQ(vEvent->isOnline(), false);
      EXPECT_TRUE(vEvent->getVersion().empty());
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<SessionEvent>());
      const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
      EXPECT_EQ(vEvent->getAction(), SessionEvent::STARTUP);
      EXPECT_EQ(vEvent->getProgress(), SessionEvent::STARTED);
      EXPECT_EQ(vEvent->getApplication(), SessionEvent::PH);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<SessionEvent>());
      const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
      EXPECT_EQ(vEvent->getAction(), SessionEvent::STARTUP);
      EXPECT_EQ(vEvent->getProgress(), SessionEvent::COMPLETED);
      EXPECT_EQ(vEvent->getApplication(), SessionEvent::PH);
      EXPECT_TRUE(vEvent->getModelFile() == "");
      monitor.eventDone();
    }


    aPHSession.connect();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::CONNECT);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      EXPECT_TRUE(vEvent->getType() == PHEvent::PH);
      EXPECT_TRUE(vEvent->getSessionId() == "PHControl_1");
      monitor.eventDone();
    }

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::CONNECT);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getType() == PHEvent::PH);
      EXPECT_TRUE(vEvent->getSessionId() == "PHControl_1");
      monitor.eventDone();
    }


    TestProgram &tp = aSession->testProgram();
    tp.activate("TestProgramSample/src/tp/MyTestProgram4.prog").load().bind().run();

    aPHSession.loadLot();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::LOAD_LOT);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::LOAD_LOT);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getLotId() == "dummy lot ID string");
      monitor.eventDone();
    }

    string lotId = string("lot_") + aPHSession.getIdentification("lot");
    tp.setTPVariable("STDF.LOT_ID", lotId);

    aPHSession.loadCassette();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::LOAD_CASSETTE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::LOAD_CASSETTE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getCassetteId() == "cassette_id_not_available");
      monitor.eventDone();
    }


    aPHSession.loadWafer();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::LOAD_WAFER);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::LOAD_WAFER);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getWaferId() == "dummy wafer ID string");
      monitor.eventDone();
    }

    string waferId = lotId + string("_wafer_") + aPHSession.getIdentification("wafer");
    tp.setTPVariable("STDF.WAFER_ID", waferId);

    aPHSession.loadDevice();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::LOAD_DEVICE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::LOAD_DEVICE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      EXPECT_EQ(vEvent->getTesterEnableSites().size(), 4);
      EXPECT_EQ(vEvent->getEquipmentEnableSites().size(), 4);
      vEvent->getXcoords();
      vEvent->getYcoords();
      monitor.eventDone();
    }

    MultiSiteLong diex, diey;
    diex.setCommon(-9999);
    diey.setCommon(-9999);
    // Query the x/y coordinate values from the PH session
    vector<PHDeviceId> deviceIds = aPHSession.getDeviceIds();

    // Assign the queried x/y coordinates to the variable
    for(unsigned int i = 0; i < deviceIds.size(); i++)
    {
      diex.set(deviceIds[i].site, deviceIds[i].xCoord);
      diey.set(deviceIds[i].site, deviceIds[i].yCoord);
    }

    // Set the x/y coordinate variable
    tp.setTPVariable("STDF.X_COORD", diex);
    tp.setTPVariable("STDF.Y_COORD", diey);

    // Run the test flow
    TestResults results = tp.testflow().setEnabledSites(aPHSession.getEnabledSites()).execute();

    // Bin the device
    aPHSession.setTestResults(results).binDevice();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::BIN_DEVICE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::BIN_DEVICE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      monitor.eventDone();
    }


    aPHSession.pause();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::PAUSE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::PAUSE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      monitor.eventDone();
    }

    aPHSession.resume();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::RESUME);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::RESUME);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      monitor.eventDone();
    }

    aPHSession.executeProtocolCommand("ID?",false);
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::EXECUTE_COMMAND);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      EXPECT_TRUE(vEvent->getProtocolCommand() == "ID?");
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::EXECUTE_COMMAND);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getProtocolCommand() == "ID?");
      EXPECT_TRUE(vEvent->getResult() == "");

      monitor.eventDone();
    }


    aPHSession.executeDriverFunction("ph_get_status","id?");
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::EXECUTE_DRIVER_FUNCTION);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      EXPECT_TRUE(vEvent->getDriverFunction() == "ph_get_status(id?)");
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::EXECUTE_DRIVER_FUNCTION);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getDriverFunction() == "ph_get_status(id?)");
      monitor.eventDone();
    }

    aPHSession.send("Dummy");
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::SEND);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::SEND);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      monitor.eventDone();
    }


    aPHSession.unloadWafer();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::UNLOAD_WAFER);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::UNLOAD_WAFER);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      monitor.eventDone();
    }


    // Unload the Casstte
    aPHSession.unloadCassette();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::UNLOAD_CASSETTE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::UNLOAD_CASSETTE);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      monitor.eventDone();
    }

    // Unload the lot
    aPHSession.unloadLot();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::UNLOAD_LOT);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<PHEvent>());
      const PHEvent* vEvent = event1->getExtension<PHEvent>();
      EXPECT_TRUE(vEvent->getAction() == PHEvent::UNLOAD_LOT);
      EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
      monitor.eventDone();
    }

    tp.stop();

  aPHSession.disconnect();
  {
    const Event * event1 = monitor.getNextEvent();
    EXPECT_TRUE(event1->hasExtension<PHEvent>());
    const PHEvent* vEvent = event1->getExtension<PHEvent>();
    EXPECT_TRUE(vEvent->getAction() == PHEvent::DISCONNECT);
    EXPECT_TRUE(vEvent->getProgress() == PHEvent::STARTED);
    EXPECT_TRUE(vEvent->getType() == PHEvent::PH);
    EXPECT_TRUE(vEvent->getSessionId() == "PHControl_1");
    monitor.eventDone();
  }

  {
    const Event * event1 = monitor.getNextEvent();
    EXPECT_TRUE(event1->hasExtension<PHEvent>());
    const PHEvent* vEvent = event1->getExtension<PHEvent>();
    EXPECT_TRUE(vEvent->getAction() == PHEvent::DISCONNECT);
    EXPECT_TRUE(vEvent->getProgress() == PHEvent::COMPLETED);
    EXPECT_TRUE(vEvent->getType() == PHEvent::PH);
    EXPECT_TRUE(vEvent->getSessionId() == "PHControl_1");
    monitor.eventDone();
  }

  aPHSession.stop();
  {
    const Event * event1 = monitor.getNextEvent();
    EXPECT_TRUE(event1->hasExtension<SessionEvent>());
    const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
    EXPECT_EQ(vEvent->getAction(), SessionEvent::TERMINATE);
    EXPECT_EQ(vEvent->getProgress(),SessionEvent::STARTED);
    EXPECT_EQ(vEvent->getApplication(),SessionEvent::PH);
    monitor.eventDone();
  }
  {
    const Event * event1 = monitor.getNextEvent();
    EXPECT_TRUE(event1->hasExtension<SessionEvent>());
    const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
    EXPECT_EQ(vEvent->getAction(), SessionEvent::TERMINATE);
    EXPECT_EQ(vEvent->getProgress(),SessionEvent::COMPLETED);
    EXPECT_EQ(vEvent->getApplication(),SessionEvent::UNKNOWN);
    monitor.eventDone();
  }


  cleanup();
  TRY_END_FAIL
}

