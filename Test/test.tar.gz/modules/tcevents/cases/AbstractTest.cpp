/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#include "AbstractTest.hpp"
#include "exception_handler.hpp"
//static variable definition
string AbstractTest::testHome = getenv("XOC_TEST_MODULE");
string AbstractTest::wsHome = getenv("XOC_TEST_WORKSPACES");
string AbstractTest::workspace = AbstractTest::wsHome + "/ws/";

TesterSession * AbstractTest::aSession = NULL;
AbstractTest::AbstractTest()
{
}

AbstractTest::~AbstractTest()
{
}

// Per-test-case set-up.
void AbstractTest::SetUpTestCase()
{
  if (access("/opt/hp93000/soc/prod_env/lbin/kill_smarTest", X_OK) != 0
      || access("/opt/hp93000/soc/prod_env/bin/HPSmarTest", X_OK) != 0) {
    throw(runtime_error(
        "kill_smarTest and HPSmarTest are not executable. SmarTest may not be installed!"));
  }
  string modelFile = AbstractTest::workspace + "/model.dd1_updated";

  //start a smt session
  map<string, string> envVariable;
  envVariable["XOC_PMON_DEBUG"] = "TRUE";
  aSession = &(TestCell::getInstance().newTesterSession().setModelFile(
      modelFile).setWorkspace(AbstractTest::workspace).setEnvVariables(envVariable).start());
}

// Per-test-case tear-down.
void AbstractTest::TearDownTestCase()
{
  int ret = system("/opt/hp93000/soc/prod_env/lbin/kill_smarTest -f");
  if (ret == -1 || WEXITSTATUS(ret) != 0) {
    throw(runtime_error(
        "Failed to execute /opt/hp93000/soc/prod_env/lbin/kill_smarTest"));
  }
}

// Per-test set-up
void AbstractTest::SetUp()
{
}

// Per-test tear-down
void AbstractTest::TearDown()
{
}
