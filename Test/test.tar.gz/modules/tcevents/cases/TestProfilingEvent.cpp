#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestProfilingEvent : public AbstractTest {
    public:
        static string RECIPE_NORMAL;

};

string TestProfilingEvent::RECIPE_NORMAL = workspace + "/" +"test_profiling.xml"; 



void executeRecipeEnableProfiling(const string& path,const TesterSession &session,const bool &enableProfiling)
{
    RecipeManager &manager = RecipeManager::getInstance();
    Recipe *pExecutor = &manager.newRecipe(path);
    pExecutor->attachToTesterSession(session);
    pExecutor->setEnableProfiling(enableProfiling);
    pExecutor->start();
    cout<<"Execute successfully"<<endl;
}


/**Test the edl datalog file have the key words "PERFORMANCE_TRANSACTION" **/

TEST_F(TestProfilingEvent,TestEdlFile)
{
    TRY_BEGIN

        executeRecipeEnableProfiling(RECIPE_NORMAL,*aSession,true);

    string value=
        TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString("datalogPath").getCommon();
    EXPECT_TRUE(!value.empty());
    string edl_src = value + ".edl";
    string edl_target = value + ".edltxt";
    string command = "";
    command = "/opt/hp93000/soc/system/bin/OfflineFormatter -e " + edl_src + " " + edl_target; 
    cout << command << endl;
    system(command.c_str());
    int offset;
    string line;
    string target="PERFORMANCE_TRANSACTION";
    ifstream filelxt;
    filelxt.open(edl_target.c_str());
    if(filelxt.is_open())
    {
        while(!filelxt.eof())
        {
            getline(filelxt,line);
            offset=line.find(target);
            EXPECT_TRUE(offset);
        }
        filelxt.close();
    }
    else
    {
        cout<<"Unable to open the file"<<endl;
    }

    TRY_END_FAIL
}


TEST_F(TestProfilingEvent, TestProfilingLog)
{
    TRY_BEGIN
        executeRecipeEnableProfiling(RECIPE_NORMAL,*aSession,true);
    string testModulePath = getenv("XOC_SYSTEM");
    string pfpath = testModulePath + "/log/profiling.slg";
    cout<<pfpath<<endl;
    ifstream filepf(pfpath.c_str(), std::ifstream::ate | std ::ifstream::binary);
    EXPECT_TRUE(filepf.tellg()>0);
    TRY_END_FAIL
}
