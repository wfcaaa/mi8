/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestWorkspaceEvent : public AbstractTest {
};

class WorkspaceSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumeWorkspaceEvent(const WorkspaceEvent &event)
  {
    setEvent(event);
    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
  }
};

TEST_F(TestWorkspaceEvent, testWorkspaceEvent)
{ TRY_BEGIN
  WorkspaceSpecificMonitor monitor;
  startMonitor(monitor);
  {
    aSession->setWorkspace(AbstractTest::wsHome + "/ws1/");
    const Event * event1 = monitor.getNextEvent();
    EXPECT_TRUE(event1->hasExtension<WorkspaceEvent>());
    const WorkspaceEvent* vEvent = event1->getExtension<WorkspaceEvent>();
    EXPECT_TRUE(vEvent->getAction() == WorkspaceEvent::SWITCH);
    EXPECT_TRUE(vEvent->getProgress() == TestProgramEvent::COMPLETED);
    EXPECT_TRUE((vEvent->getPath() + "/") == AbstractTest::wsHome + "/ws1/");
    monitor.eventDone();
  }
  stopMonitor(monitor);
  TRY_END_FAIL
}

