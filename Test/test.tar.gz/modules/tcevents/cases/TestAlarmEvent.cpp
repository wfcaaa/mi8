/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
#include <boost/algorithm/string.hpp>
#include <string>
class TestAlarmEvent : public AbstractTest {
};

class AlarmSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumeAlarmEvent(const AlarmEvent &event)
  {
    setEvent(event);
    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
  }
};

int i = 0;

TEST_F(TestAlarmEvent, FormatterDefect)
{
  TRY_BEGIN

  const string CUST_DATALOG_PATH = string(getenv("XOC_TEST_MODULE")) + "/testbed/cust_datalog.so";
  const string CUST_DATALOG_FILE = string(getenv("XOC_TEST_MODULE")) + "/testbed/cust_datalog.cus";
  AlarmSpecificMonitor monitor;
  TestAlarmEvent::startMonitor(monitor);

  TestProgram &tp = aSession->testProgram();
  tp.activate("TestProgramSample/src/tp/MyTestProgram4.prog").load().bind().run();

  DatalogFile& aDatalogFile = aSession->datalog().newDatalogFile(CUST_DATALOG_FILE);
  aDatalogFile.setFormatterType(DatalogFile::CUSTOM).setCustomFormatterPath(CUST_DATALOG_PATH).open();

  EXPECT_THROW(tp.testflow().execute(), TCException);
  {
    const Event* event = monitor.getNextEvent();
    EXPECT_TRUE(event->hasExtension<AlarmEvent>());
    const AlarmEvent* vEvent = event->getExtension<AlarmEvent>();
    EXPECT_EQ(vEvent->getName(), Alarm::FORMATTER_DEFECT);
    EXPECT_EQ(vEvent->getDisplayName(), "Formatter Defect");
    EXPECT_EQ(vEvent->getDescription().empty(), false);
    EXPECT_EQ(vEvent->getProgress(), Event::COMPLETED);
    EXPECT_EQ(vEvent->getType(), Event::ALARM);
    EXPECT_TRUE(vEvent->getSessionId().size() != 0);
    EXPECT_EQ(vEvent->getSites().size(), 0);

    monitor.eventDone();
  }
  
  aSession->clearAlarms();
  tp.stop();
  
  TestAlarmEvent::stopMonitor(monitor);
  TRY_END_FAIL
}

void TCCmdUtil(const string& str, vector<string>& resultsVec)
{
  resultsVec.clear();

  std::string results;
  FILE *fp = popen(str.c_str(), "r");
  if(fp != NULL)
  {
    char *aLine = NULL;
    size_t lineLen = 0;

    //read the output line by line
    while(getline(&aLine, &lineLen, fp) != -1)
    {
      results = std::string(aLine);
      boost::algorithm::trim(results);
      resultsVec.push_back(results);

      free(aLine);
      aLine = NULL;
    }
    pclose(fp);
  }
}

int getUseValue(string& str)
{
  vector<string> usageVec;
  boost::split(usageVec, str, boost::is_any_of(" "), boost::token_compress_on);

  if(usageVec.size() < 5)
  {
    return -2;
  }

  vector<string> tmpStr;
  boost::split(tmpStr, usageVec[4], boost::is_any_of("%"), boost::token_compress_on);

  if(tmpStr.size() == 0)
  {
    return -1;
  }

  return atoi(tmpStr[0].data());
}


void createFileWithSize(const int& size, const char* fileName)
{
  FILE* newFile = fopen(fileName, "w");
  char buffer[1024];
  memset(buffer, ' ', 1024);

  for(int i=0; i<1024*1024*size; i++)
  {
    fputs(buffer, newFile);
  }
}

bool isCreatFileSuccess(const int& filePercentage)
{
  string cmdDfTmp = "df -h /tmp";
  vector<string> resultVec;
  int use = 0;
  int nth = 0;
  int maxLimit = 999;

  char fileName[256];
  char buf[102] = {'\0'};

  while(use < filePercentage)
  {
    nth++;
    use = 0;
    sprintf(fileName, "/tmp/alarmLog%d", i++);

    createFileWithSize(1, fileName);

    TCCmdUtil(cmdDfTmp, resultVec);

    if(resultVec.size() == 0)
    {
      cout << "cmd result vector is empty." << endl;
      return false;
    }

    use = getUseValue(resultVec[1]);
    memset(buf, '#', use);
    printf("[%-101s][%%%d]\r", buf, use);
    fflush(stdout);

    switch(use)
    {
    case -1:
      cout << "cmd result vector is error." << endl;
      return false;
    case -2:
      cout << "cmd result single string is error." << endl;
      return false;
    default:
      break;
    }

    if(nth > maxLimit)
    {
     return false;
    }
  }

  if(nth == 0)
    return false;
  else
    return true;
}

bool isDiskMonitorAlartTestSuc(const AlarmEvent* vEvent, const Alarm::AlarmName& alarmName, const string& alarmStr)
{
  if
  (
    vEvent->getName() == alarmName             &&
    vEvent->getDisplayName() == alarmStr       &&
    vEvent->getDescription().empty() == false  &&
    vEvent->getProgress() == Event::COMPLETED  &&
    vEvent->getType() == Event::ALARM
  )
    return true;
  else
  {
    EXPECT_EQ(vEvent->getName(), alarmName);
    EXPECT_EQ(vEvent->getDisplayName(), alarmStr);
    EXPECT_EQ(vEvent->getDescription().empty(), false);
    EXPECT_EQ(vEvent->getProgress(), Event::COMPLETED);
    EXPECT_EQ(vEvent->getType(), Event::ALARM);

    return false;
  }
}

//test case for ID:REQ.10395.1 ID:REQ.10395.2
TEST_F(TestAlarmEvent, DiskMonitorAlarm)
{
  TRY_BEGIN

  bool isOK=false;

  if(isCreatFileSuccess(80))
  {
    AlarmSpecificMonitor monitor;
    TestAlarmEvent::startMonitor(monitor);
    createFileWithSize(1, "/tmp/alarmLog_80");
    const Event* event = monitor.getNextEvent();
    EXPECT_TRUE(event->hasExtension<AlarmEvent>());
    const AlarmEvent* vEvent = event->getExtension<AlarmEvent>();

    isOK = isDiskMonitorAlartTestSuc(vEvent, Alarm::DISK_SPACE_EXCEEDS_THRESHOLD, "Disk space threshold is exceeded");
    monitor.eventDone();

    TestAlarmEvent::stopMonitor(monitor);
    EXPECT_TRUE(isOK);
    if(!isOK)
    {
      goto endFlag;
    }
  }
  else
  {
    cout<<"test disk monitor alarm error with threshold: 80" << endl;
    EXPECT_TRUE(false);
  }

#if 0
  //Fatal alarm on disk monitor has been disabled, because it will cause many inconviences to customers.
  if(isCreatFileSuccess(99))
  {
    AlarmSpecificMonitor monitor;
    TestAlarmEvent::startMonitor(monitor);
    createFileWithSize(1, "/tmp/alarmLog_100");
    const Event* event = monitor.getNextEvent();
    EXPECT_TRUE(event->hasExtension<AlarmEvent>());
    const AlarmEvent* vEvent = event->getExtension<AlarmEvent>();

    EXPECT_TRUE(isDiskMonitorAlartTestSuc(vEvent, Alarm::RAN_OUT_OF_DISK_SPACE, "Ran out of disk space"));
    monitor.eventDone();

    TestAlarmEvent::stopMonitor(monitor);
  }
  else
  {
    cout<<"test disk monitor alarm error with threshold: 99" << endl;
    EXPECT_TRUE(false);
  }
#endif

endFlag:

  int ret = system("rm -rf /tmp/alarmLog*");
  if (ret == -1 || ret == 127 || WEXITSTATUS(ret) != 0)
  {
    cout << "delete tmp files" << endl;
    EXPECT_TRUE(false);
  }

  TRY_END_FAIL
}
