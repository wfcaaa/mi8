/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestVariableEvent : public AbstractTest {
};

class VariableSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumeVariableEvent(const VariableEvent &event)
  {
    setEvent(event);
    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
  }
};

TEST_F(TestVariableEvent, testVariableEvent)
{ TRY_BEGIN
  aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram4.prog");
  aSession->testProgram().load();

  VariableSpecificMonitor monitor;
  startMonitor(monitor);
  {
    aSession->testProgram().setTCVariable("test_key", "test_value");
    const Event * event1 = monitor.getNextEvent();
    EXPECT_TRUE(event1->hasExtension<VariableEvent>());
    const VariableEvent* vEvent = event1->getExtension<VariableEvent>();
    EXPECT_TRUE(vEvent->getAction() == VariableEvent::ADD);
    EXPECT_TRUE(vEvent->getProgress() == TestProgramEvent::COMPLETED);
    EXPECT_TRUE(vEvent->getVariableName() == "test_key");
    EXPECT_TRUE(vEvent->getCategory() == VariableEvent::TC);
    EXPECT_TRUE(vEvent->getSites().size() == 0);
    EXPECT_TRUE(vEvent->getValueType() == VariableEvent::STRING);
    EXPECT_TRUE(vEvent->getVariableStringValue().isCommon());
    EXPECT_TRUE(vEvent->getVariableStringValue().getCommon() == "test_value");
    monitor.eventDone();
  }

  {
    int value = 123;
    aSession->testProgram().setTCVariable("test_long_key", value);
    const Event * event1 = monitor.getNextEvent();
    EXPECT_TRUE(event1->hasExtension<VariableEvent>());
    const VariableEvent* vEvent = event1->getExtension<VariableEvent>();
    EXPECT_TRUE(vEvent->getAction() == VariableEvent::ADD);
    EXPECT_TRUE(vEvent->getProgress() == TestProgramEvent::COMPLETED);
    EXPECT_TRUE(vEvent->getVariableName() == "test_long_key");
    EXPECT_TRUE(vEvent->getCategory() == VariableEvent::TC);
    EXPECT_TRUE(vEvent->getSites().size() == 0);
    EXPECT_TRUE(vEvent->getValueType() == VariableEvent::LONG);
    EXPECT_TRUE(vEvent->getVariableLongValue().isCommon());
    EXPECT_TRUE(vEvent->getVariableLongValue().getCommon() == 123);
    monitor.eventDone();
  }

  {
      aSession->testProgram().setTCVariable("test_bool_key", true);
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<VariableEvent>());
      const VariableEvent* vEvent = event1->getExtension<VariableEvent>();
      EXPECT_TRUE(vEvent->getAction() == VariableEvent::ADD);
      EXPECT_TRUE(vEvent->getProgress() == TestProgramEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getVariableName() == "test_bool_key");
      EXPECT_TRUE(vEvent->getCategory() == VariableEvent::TC);
      EXPECT_TRUE(vEvent->getSites().size() == 0);
      EXPECT_TRUE(vEvent->getValueType() == VariableEvent::BOOL);
      EXPECT_TRUE(vEvent->getVariableBooleanValue().isCommon());
      EXPECT_TRUE(vEvent->getVariableBooleanValue().getCommon() == true);
      monitor.eventDone();
  }

  {
    long value = 123;
    aSession->testProgram().setTCVariable("test_long_key1", value);
    const Event * event1 = monitor.getNextEvent();
    EXPECT_TRUE(event1->hasExtension<VariableEvent>());
    const VariableEvent* vEvent = event1->getExtension<VariableEvent>();
    EXPECT_TRUE(vEvent->getAction() == VariableEvent::ADD);
    EXPECT_TRUE(vEvent->getProgress() == TestProgramEvent::COMPLETED);
    EXPECT_TRUE(vEvent->getVariableName() == "test_long_key1");
    EXPECT_TRUE(vEvent->getCategory() == VariableEvent::TC);
    EXPECT_TRUE(vEvent->getSites().size() == 0);
    EXPECT_TRUE(vEvent->getValueType() == VariableEvent::LONG);
    EXPECT_TRUE(vEvent->getVariableLongValue().isCommon());
    EXPECT_TRUE(vEvent->getVariableLongValue().getCommon() == 123);
    monitor.eventDone();
  }

  {
    MultiSiteString ms;
    ms.set(1, "test1");
    ms.set(2, "test2");
    ms.set(3, "test3");
    ms.set(4, "test4");
    aSession->testProgram().setTPVariable("variable1", ms);
    monitor.getNextEvent();
    const Event *event2 = monitor.getNextEvent();
    EXPECT_TRUE(event2->hasExtension<VariableEvent>());
    const VariableEvent* vEvent2 = event2->getExtension<VariableEvent>();
    EXPECT_TRUE(vEvent2->getAction() == VariableEvent::MODIFY);
    EXPECT_TRUE(vEvent2->getProgress() == TestProgramEvent::COMPLETED);
    EXPECT_TRUE(vEvent2->getVariableName() == "variable1");
    EXPECT_TRUE(vEvent2->getCategory() == VariableEvent::TP);
    EXPECT_TRUE(vEvent2->getValueType() == VariableEvent::STRING);
    EXPECT_TRUE(vEvent2->getSites().size() == 4);
    EXPECT_TRUE(vEvent2->getSites()[0] == 1);
    EXPECT_TRUE(vEvent2->getSites()[1] == 2);
    EXPECT_TRUE(vEvent2->getSites()[2] == 3);
    EXPECT_TRUE(vEvent2->getSites()[3] == 4);
    ms = vEvent2->getVariableStringValue();
    EXPECT_TRUE(ms.get(1) == "test1");
    EXPECT_TRUE(ms.get(2) == "test2");
    EXPECT_TRUE(ms.get(3) == "test3");
    EXPECT_TRUE(ms.get(4) == "test4");
    EXPECT_TRUE(!vEvent2->getVariableStringValue().isCommon());
    monitor.eventDone();
  }

  {
    MultiSiteLong ms;
    ms.set(1, 10);
    ms.set(2, 20);
    ms.set(3, 30);
    ms.set(4, 40);
    aSession->testProgram().setTCVariable("variable_tc_long", ms);
    monitor.getNextEvent();
    const Event *event2 = monitor.getNextEvent();
    EXPECT_TRUE(event2->hasExtension<VariableEvent>());
    const VariableEvent* vEvent2 = event2->getExtension<VariableEvent>();
    EXPECT_TRUE(vEvent2->getAction() == VariableEvent::ADD);
    EXPECT_TRUE(vEvent2->getProgress() == TestProgramEvent::COMPLETED);
    EXPECT_TRUE(vEvent2->getVariableName() == "variable_tc_long");
    EXPECT_TRUE(vEvent2->getCategory() == VariableEvent::TC);
    EXPECT_TRUE(vEvent2->getValueType() == VariableEvent::LONG);
    EXPECT_TRUE(vEvent2->getSites().size() == 4);
    EXPECT_TRUE(vEvent2->getSites()[0] == 1);
    EXPECT_TRUE(vEvent2->getSites()[1] == 2);
    EXPECT_TRUE(vEvent2->getSites()[2] == 3);
    EXPECT_TRUE(vEvent2->getSites()[3] == 4);
    ms = vEvent2->getVariableLongValue();
    EXPECT_TRUE(ms.get(1) == 10);
    EXPECT_TRUE(ms.get(2) == 20);
    EXPECT_TRUE(ms.get(3) == 30);
    EXPECT_TRUE(ms.get(4) == 40);
    EXPECT_TRUE(!vEvent2->getVariableLongValue().isCommon());
    monitor.eventDone();
  }

  {
    MultiSiteDouble ms;
    ms.set(1, 10.0);
    ms.set(2, 20.0);
    ms.set(3, 30.0);
    ms.set(4, 40.0);
    aSession->testProgram().setTCVariable("variable_tc_double", ms);
    monitor.getNextEvent();
    const Event *event2 = monitor.getNextEvent();
    EXPECT_TRUE(event2->hasExtension<VariableEvent>());
    const VariableEvent* vEvent2 = event2->getExtension<VariableEvent>();
    EXPECT_TRUE(vEvent2->getAction() == VariableEvent::ADD);
    EXPECT_TRUE(vEvent2->getProgress() == TestProgramEvent::COMPLETED);
    EXPECT_TRUE(vEvent2->getVariableName() == "variable_tc_double");
    EXPECT_TRUE(vEvent2->getCategory() == VariableEvent::TC);
    EXPECT_TRUE(vEvent2->getValueType() == VariableEvent::DOUBLE);
    EXPECT_TRUE(vEvent2->getSites().size() == 4);
    EXPECT_TRUE(vEvent2->getSites()[0] == 1);
    EXPECT_TRUE(vEvent2->getSites()[1] == 2);
    EXPECT_TRUE(vEvent2->getSites()[2] == 3);
    EXPECT_TRUE(vEvent2->getSites()[3] == 4);
    ms = vEvent2->getVariableDoubleValue();
    EXPECT_TRUE(ms.get(1) == 10.0);
    EXPECT_TRUE(ms.get(2) == 20.0);
    EXPECT_TRUE(ms.get(3) == 30.0);
    EXPECT_TRUE(ms.get(4) == 40.0);
    EXPECT_TRUE(!vEvent2->getVariableDoubleValue().isCommon());
    monitor.eventDone();
  }

  {
    MultiSiteBoolean ms;
    ms.set(1, false);
    ms.set(2, true);
    ms.set(3, false);
    ms.set(4, true);
    aSession->testProgram().setTCVariable("variable_tc_boolean", ms);
    monitor.getNextEvent();
    const Event *event2 = monitor.getNextEvent();
    EXPECT_TRUE(event2->hasExtension<VariableEvent>());
    const VariableEvent* vEvent2 = event2->getExtension<VariableEvent>();
    EXPECT_TRUE(vEvent2->getAction() == VariableEvent::ADD);
    EXPECT_TRUE(vEvent2->getProgress() == TestProgramEvent::COMPLETED);
    EXPECT_TRUE(vEvent2->getVariableName() == "variable_tc_boolean");
    EXPECT_TRUE(vEvent2->getCategory() == VariableEvent::TC);
    EXPECT_TRUE(vEvent2->getValueType() == VariableEvent::BOOL);
    EXPECT_TRUE(vEvent2->getSites().size() == 4);
    EXPECT_TRUE(vEvent2->getSites()[0] == 1);
    EXPECT_TRUE(vEvent2->getSites()[1] == 2);
    EXPECT_TRUE(vEvent2->getSites()[2] == 3);
    EXPECT_TRUE(vEvent2->getSites()[3] == 4);
    ms = vEvent2->getVariableBooleanValue();
    EXPECT_TRUE(ms.get(1) == false);
    EXPECT_TRUE(ms.get(2) == true);
    EXPECT_TRUE(ms.get(3) == false);
    EXPECT_TRUE(ms.get(4) == true);
    EXPECT_TRUE(!vEvent2->getVariableBooleanValue().isCommon());
    monitor.eventDone();
  }

  stopMonitor(monitor);
  TRY_END_FAIL
}

