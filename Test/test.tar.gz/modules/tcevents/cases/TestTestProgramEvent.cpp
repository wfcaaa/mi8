/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestTestProgramEvent : public AbstractTest {
};

class TestProgramSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumeTestProgramEvent(const TestProgramEvent &event)
  {
    setEvent(event);
    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
  }
};

void checkBasicInformation(const TestProgramEvent* testProgramEvent)
{
  EXPECT_TRUE(
      testProgramEvent->getTestProgramName() == "TestProgramSample/src/tp/MyTestProgram.prog");
  EXPECT_TRUE(
      testProgramEvent->getTestProgramPath() == AbstractTest::workspace + "TestProgramSample");
  EXPECT_TRUE((testProgramEvent->getWorkspacePath() + "/") == AbstractTest::workspace);
}

void checkTPBindEvent(TestProgramSpecificMonitor &monitor,
                      const string str)
{
  const Event * bindEvent = monitor.getNextEvent();
  EXPECT_TRUE(bindEvent->hasExtension<TestProgramEvent>());
  const TestProgramEvent* testProgramEvent = bindEvent->getExtension<TestProgramEvent>();
  vector<TestCellEventProperty> eventProperty = testProgramEvent->getProperties();

  int numCount = 0;
  int numLimit = 60;
  while (1)
  {
    if(eventProperty[0].value[0] != str)
    {
      monitor.eventDone();
      bindEvent = monitor.getNextEvent();
      EXPECT_TRUE(bindEvent->hasExtension<TestProgramEvent>());
      testProgramEvent = bindEvent->getExtension<TestProgramEvent>();
      eventProperty = testProgramEvent->getProperties();

      numCount++;
      sleep(1);
    }
    else
    {
      break;
    }

    if(numCount > numLimit)
    {
      cout << "Not get event" << str << endl;
      break;
    }
  }

  if(str == "TESTPROGRAM_BINDING_STARTED")
  {
    EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::BIND);
    EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::STARTED);
  }
  else if(str == "TESTPROGRAM_BINDING_COMPLETED")
  {
    EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::BIND);
    EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::COMPLETED);
    ASSERT_EQ(testProgramEvent->getSoftBins().size(), 1);
    ASSERT_EQ(testProgramEvent->getHardBins().size(), 1);
  }
  else
  {
    cout << "checkTPBindEvent out of range." << endl;
    EXPECT_TRUE(false);
  }

  monitor.eventDone();
}

TEST_F(TestTestProgramEvent, testActivateProgramEvent)
{
  TRY_BEGIN
  TestProgramSpecificMonitor monitor;
  TestTestProgramEvent::startMonitor(monitor);
  aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram.prog");

  const Event * activationStartEvent = monitor.getNextEvent();
  EXPECT_TRUE(activationStartEvent->hasExtension<TestProgramEvent>());
  const TestProgramEvent* testProgramEvent = activationStartEvent->getExtension<
      TestProgramEvent>();
  checkBasicInformation(testProgramEvent);
  EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::ACTIVATE);
  EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::STARTED);
  monitor.eventDone();

  const Event * activationCompletedEvent = monitor.getNextEvent();
  EXPECT_TRUE(activationCompletedEvent->hasExtension<TestProgramEvent>());
  testProgramEvent = activationCompletedEvent->getExtension<TestProgramEvent>();
  checkBasicInformation(testProgramEvent);
  EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::ACTIVATE);
  EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::COMPLETED);

  std::vector<long> sites = testProgramEvent->getAvailableSites();
  EXPECT_TRUE(sites.size() == 1);
  EXPECT_TRUE(sites[0] == 1);

  sites = testProgramEvent->getConfiguredSites();
  EXPECT_TRUE(sites.size() == 1);
  EXPECT_TRUE(sites[0] == 1);

  TestProgramEvent::SIGNAL_POGO_MAP aMap = testProgramEvent->getSignalToPogoMap();
  EXPECT_TRUE(aMap.size() == 1);

  monitor.eventDone();

  TestTestProgramEvent::stopMonitor(monitor);
  TRY_END_FAIL
}

TEST_F(TestTestProgramEvent, testLoadProgramEvent)
{
  TRY_BEGIN
  aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram.prog");
  TestProgramSpecificMonitor monitor;
  TestTestProgramEvent::startMonitor(monitor);
  aSession->testProgram().load();

  const Event * loadStartEvent = monitor.getNextEvent();
  EXPECT_TRUE(loadStartEvent->hasExtension<TestProgramEvent>());
  const TestProgramEvent* testProgramEvent = loadStartEvent->getExtension<
      TestProgramEvent>();
  EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::LOAD);
  EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::STARTED);
  monitor.eventDone();

  const Event * loadCompletedEvent = monitor.getNextEvent();
  EXPECT_TRUE(loadCompletedEvent->hasExtension<TestProgramEvent>());
  testProgramEvent = loadCompletedEvent->getExtension<TestProgramEvent>();
  EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::LOAD);
  EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::COMPLETED);
  ASSERT_EQ(testProgramEvent->getMainFlowPath(), "tf/MainFlow.flow");

  monitor.eventDone();

  TestTestProgramEvent::stopMonitor(monitor);
  TRY_END_FAIL
}

TEST_F(TestTestProgramEvent, testBindProgramEvent)
{
  TRY_BEGIN
  aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram.prog");
  aSession->testProgram().load();

  TestProgramSpecificMonitor monitor;
  TestTestProgramEvent::startMonitor(monitor);
  aSession->testProgram().bind();

  checkTPBindEvent(monitor, "TESTPROGRAM_BINDING_STARTED");
  checkTPBindEvent(monitor, "TESTPROGRAM_BINDING_COMPLETED");

  TestTestProgramEvent::stopMonitor(monitor);
  TRY_END_FAIL
}

TEST_F(TestTestProgramEvent, testStartProgramEvent)
{
  TRY_BEGIN
  aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram.prog");
  aSession->testProgram().load();
  aSession->testProgram().bind();

  TestProgramSpecificMonitor monitor;
  TestTestProgramEvent::startMonitor(monitor);
  aSession->testProgram().run();

  const Event * loadStartEvent = monitor.getNextEvent();
  EXPECT_TRUE(loadStartEvent->hasExtension<TestProgramEvent>());
  const TestProgramEvent* testProgramEvent = loadStartEvent->getExtension<
      TestProgramEvent>();
  EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::START);
  EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::STARTED);
  monitor.eventDone();

  const Event * loadCompletedEvent = monitor.getNextEvent();
  EXPECT_TRUE(loadCompletedEvent->hasExtension<TestProgramEvent>());
  testProgramEvent = loadCompletedEvent->getExtension<TestProgramEvent>();
  EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::START);
  EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::COMPLETED);
  monitor.eventDone();

  TestTestProgramEvent::stopMonitor(monitor);
  TRY_END_FAIL
}

TEST_F(TestTestProgramEvent, testStopProgramEvent)
{
  TRY_BEGIN
  aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram.prog");
  aSession->testProgram().load();
  aSession->testProgram().bind();
  aSession->testProgram().run();

  TestProgramSpecificMonitor monitor;
  TestTestProgramEvent::startMonitor(monitor);
  aSession->testProgram().stop();

  const Event * loadStartEvent = monitor.getNextEvent();
  EXPECT_TRUE(loadStartEvent->hasExtension<TestProgramEvent>());
  const TestProgramEvent* testProgramEvent = loadStartEvent->getExtension<
      TestProgramEvent>();
  EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::STOP);
  EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::STARTED);
  monitor.eventDone();

  const Event * loadCompletedEvent = monitor.getNextEvent();
  EXPECT_TRUE(loadCompletedEvent->hasExtension<TestProgramEvent>());
  testProgramEvent = loadCompletedEvent->getExtension<TestProgramEvent>();
  EXPECT_TRUE(testProgramEvent->getAction() == TestProgramEvent::STOP);
  EXPECT_TRUE(testProgramEvent->getProgress() == TestProgramEvent::COMPLETED);
  monitor.eventDone();

  TestTestProgramEvent::stopMonitor(monitor);
  TRY_END_FAIL
}

TEST_F(TestTestProgramEvent, testTerminateProgramEvent)
{
  TRY_BEGIN
  aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram.prog");
  aSession->testProgram().load();
  TestProgramSpecificMonitor monitor;
  TestTestProgramEvent::startMonitor(monitor);
  aSession->testProgram().terminate();

  {
    const Event * event = monitor.getNextEvent();
    EXPECT_TRUE(event->hasExtension<TestProgramEvent>());
    const TestProgramEvent* tpEvent = event->getExtension<TestProgramEvent>();
    EXPECT_TRUE(tpEvent->getAction() == TestProgramEvent::TERMINATE);
    EXPECT_TRUE(tpEvent->getProgress() == TestProgramEvent::STARTED);
    monitor.eventDone();
  }

  {
    const Event * event = monitor.getNextEvent();
    EXPECT_TRUE(event->hasExtension<TestProgramEvent>());
    const TestProgramEvent* tpEvent = event->getExtension<TestProgramEvent>();
    EXPECT_TRUE(tpEvent->getAction() == TestProgramEvent::TERMINATE);
    EXPECT_TRUE(tpEvent->getProgress() == TestProgramEvent::COMPLETED);
    monitor.eventDone();
  }

  TestTestProgramEvent::stopMonitor(monitor);
  TRY_END_FAIL
}

TEST_F(TestTestProgramEvent, testDeactiveProgramEvent)
{
  TRY_BEGIN
  aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram.prog");
  TestProgramSpecificMonitor monitor;
  TestTestProgramEvent::startMonitor(monitor);
  aSession->testProgram().deactivate();

  {
    const Event * event = monitor.getNextEvent();
    EXPECT_TRUE(event->hasExtension<TestProgramEvent>());
    const TestProgramEvent* tpEvent = event->getExtension<TestProgramEvent>();
    EXPECT_TRUE(tpEvent->getAction() == TestProgramEvent::DEACTIVATE);
    EXPECT_TRUE(tpEvent->getProgress() == TestProgramEvent::STARTED);
    monitor.eventDone();
  }

  {
    const Event * event = monitor.getNextEvent();
    EXPECT_TRUE(event->hasExtension<TestProgramEvent>());
    const TestProgramEvent* tpEvent = event->getExtension<TestProgramEvent>();
    EXPECT_TRUE(tpEvent->getAction() == TestProgramEvent::DEACTIVATE);
    EXPECT_TRUE(tpEvent->getProgress() == TestProgramEvent::COMPLETED);
    monitor.eventDone();
  }

  TestTestProgramEvent::stopMonitor(monitor);
  TRY_END_FAIL
}
