/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestTesterStatusEvent : public AbstractTest {
};

class TesterStatusSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumeTesterStatusEvent(const TesterStatusEvent &event)
  {
    setEvent(event);
    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
  }
};

TEST_F(TestTesterStatusEvent, TesterStatusEvent)
{
  TRY_BEGIN
  aSession->stop();
  TesterStatusSpecificMonitor monitor;
  TestTesterStatusEvent::startMonitor(monitor);

  map<string, string> envVariable;
  envVariable["XOC_PMON_DEBUG"] = "TRUE";
  (*aSession).setEnvVariables(envVariable).start();
  {
    const Event* event = monitor.getNextEvent();
    EXPECT_TRUE(event->hasExtension<TesterStatusEvent>());
    const TesterStatusEvent* vEvent = event->getExtension<TesterStatusEvent>();
    std::auto_ptr<HwConf> hwConfig = vEvent->getHwConfig();
    monitor.eventDone();
  }

  TestTesterStatusEvent::stopMonitor(monitor);
  (*aSession).stop();
  TRY_END_FAIL
}



