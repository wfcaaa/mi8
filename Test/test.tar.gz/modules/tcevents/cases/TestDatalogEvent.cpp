/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <iostream>
#include <fstream>
class TestDatalogEvent : public AbstractTest {
};

class DatalogSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumeDatalogEvent(const DatalogEvent &event)
  {
    setEvent(event);

    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
  }
};

TEST_F(TestDatalogEvent, testDatalogEvent)
{
  TRY_BEGIN
  DatalogSpecificMonitor monitor;
    startMonitor(monitor);
    {
      aSession->testProgram().activate("TestProgramSample/src/tp/MyTestProgram.prog");
      aSession->testProgram().load();
      aSession->testProgram().bind();
      aSession->testProgram().run();
      ofstream outputFile;

      const string TEXT_DATALOG_PATH = string(getenv("XOC_TEST_MODULE")) + "/testbed/test_datalog";
      outputFile.open(TEXT_DATALOG_PATH.c_str());
      outputFile.close();

      DatalogFile& file = aSession->datalog().newDatalogFile(TEXT_DATALOG_PATH);
      file.setFormatterType(DatalogFile::ASCII);
      file.open();
      string id;
      {
        const Event * event1 = monitor.getNextEvent();
        EXPECT_TRUE(event1->hasExtension<DatalogEvent>());
        const DatalogEvent* vEvent = event1->getExtension<DatalogEvent>();
        EXPECT_TRUE(vEvent->getAction() == DatalogEvent::OPEN);
        EXPECT_TRUE(vEvent->getProgress() == Event::COMPLETED);
        EXPECT_TRUE(vEvent->getDatalogPath() == TEXT_DATALOG_PATH);
        EXPECT_TRUE(vEvent->getDatalogType() == DatalogFile::ASCII);
        EXPECT_TRUE(!vEvent->getDatalogId().empty());
        id = vEvent->getDatalogId();
        monitor.eventDone();
      }
      aSession->testProgram().testflow().execute();
      file.flush();
      {
        const Event * event1 = monitor.getNextEvent();
        EXPECT_TRUE(event1->hasExtension<DatalogEvent>());
        const DatalogEvent* vEvent = event1->getExtension<DatalogEvent>();
        EXPECT_TRUE(vEvent->getAction() == DatalogEvent::FLUSH);
        EXPECT_TRUE(vEvent->getProgress() == Event::COMPLETED);
        EXPECT_TRUE(vEvent->getDatalogPath() == TEXT_DATALOG_PATH);
        EXPECT_TRUE(vEvent->getDatalogType() == DatalogFile::ASCII);
        EXPECT_TRUE(vEvent->getDatalogId() == id);
        monitor.eventDone();
      }

      file.pause();
      {
        const Event * event1 = monitor.getNextEvent();
        EXPECT_TRUE(event1->hasExtension<DatalogEvent>());
        const DatalogEvent* vEvent = event1->getExtension<DatalogEvent>();
        EXPECT_TRUE(vEvent->getAction() == DatalogEvent::PAUSE);
        EXPECT_TRUE(vEvent->getProgress() == Event::COMPLETED);
        EXPECT_TRUE(vEvent->getDatalogPath() == TEXT_DATALOG_PATH);
        EXPECT_TRUE(vEvent->getDatalogType() == DatalogFile::ASCII);
        EXPECT_TRUE(vEvent->getDatalogId() == id);
        monitor.eventDone();
      }

      file.resume();
      {
        const Event * event1 = monitor.getNextEvent();
        EXPECT_TRUE(event1->hasExtension<DatalogEvent>());
        const DatalogEvent* vEvent = event1->getExtension<DatalogEvent>();
        EXPECT_TRUE(vEvent->getAction() == DatalogEvent::RESUME);
        EXPECT_TRUE(vEvent->getProgress() == Event::COMPLETED);
        EXPECT_TRUE(vEvent->getDatalogPath() == TEXT_DATALOG_PATH);
        EXPECT_TRUE(vEvent->getDatalogType() == DatalogFile::ASCII);
        EXPECT_TRUE(vEvent->getDatalogId() == id);
        monitor.eventDone();
      }

      file.close();
      {
        const Event * event1 = monitor.getNextEvent();
        EXPECT_TRUE(event1->hasExtension<DatalogEvent>());
        const DatalogEvent* vEvent = event1->getExtension<DatalogEvent>();
        EXPECT_TRUE(vEvent->getAction() == DatalogEvent::CLOSE);
        EXPECT_TRUE(vEvent->getProgress() == Event::STARTED);
        EXPECT_TRUE(vEvent->getDatalogPath() == TEXT_DATALOG_PATH);
        EXPECT_TRUE(vEvent->getDatalogType() == DatalogFile::ASCII);
        EXPECT_TRUE(vEvent->getDatalogId() == id);
        monitor.eventDone();
      }
    }
    stopMonitor(monitor);
  TRY_END_FAIL
}

