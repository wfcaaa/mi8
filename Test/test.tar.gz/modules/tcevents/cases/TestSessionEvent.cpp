/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestSessionEvent : public AbstractTest {
};

class SessionSpecificMonitor : public AbstractTestSpecificMonitor {
public:
  void consumeSessionEvent(const SessionEvent &event)
  {
    setEvent(event);
    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
  }
};

TEST_F(TestSessionEvent, testSessionEvent)
{
  TRY_BEGIN
  SessionSpecificMonitor monitor;
    startMonitor(monitor);
    aSession->stop();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<SessionEvent>());
      const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
      EXPECT_TRUE(vEvent->getAction() == SessionEvent::TERMINATE);
      EXPECT_TRUE(vEvent->getProgress() == SessionEvent::STARTED);
      EXPECT_TRUE(vEvent->getApplication() == SessionEvent::SMARTEST);
      EXPECT_TRUE(!vEvent->isOnline());
      EXPECT_TRUE(!vEvent->getVersion().empty());
      EXPECT_TRUE(vEvent->getLoginUser() == getenv("USER"));
      monitor.eventDone();
    }

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<SessionEvent>());
      const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
      EXPECT_TRUE(vEvent->getAction() == SessionEvent::TERMINATE);
      EXPECT_TRUE(vEvent->getProgress() == SessionEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getApplication() == SessionEvent::UNKNOWN);
      monitor.eventDone();
    }

    aSession->start();
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<SessionEvent>());
      const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
      EXPECT_TRUE(vEvent->getAction() == SessionEvent::CREATE);
      EXPECT_TRUE(vEvent->getProgress() == SessionEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getApplication() == SessionEvent::UNKNOWN);
      monitor.eventDone();
    }

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<SessionEvent>());
      const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
      EXPECT_TRUE(vEvent->getAction() == SessionEvent::STARTUP);
      EXPECT_TRUE(vEvent->getProgress() == SessionEvent::STARTED);
      EXPECT_TRUE(vEvent->getApplication() == SessionEvent::SMARTEST);
      EXPECT_TRUE(!vEvent->isOnline());
      EXPECT_TRUE(!vEvent->getVersion().empty());
      EXPECT_TRUE(vEvent->getLoginUser() == getenv("USER"));
      monitor.eventDone();
    }

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<SessionEvent>());
      const SessionEvent* vEvent = event1->getExtension<SessionEvent>();
      EXPECT_TRUE(vEvent->getAction() == SessionEvent::STARTUP);
      EXPECT_TRUE(vEvent->getProgress() == SessionEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getApplication() == SessionEvent::SMARTEST);
      EXPECT_TRUE(!vEvent->isOnline());
      EXPECT_TRUE(!vEvent->getVersion().empty());
      EXPECT_TRUE(vEvent->getLoginUser() == getenv("USER"));
      monitor.eventDone();
    }

    stopMonitor(monitor);
  TRY_END_FAIL
}

