/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractTest.hpp"
#include <pthread.h>
#include <semaphore.h>
class TestRecipeEvent : public AbstractTest {
public:
  static string RECIPE_NORMAL_NAME;
  static string RECIPE_NORMAL;
  static string RECIPE_ABNORMAL_NAME;
  static string RECIPE_ABNORMAL;
};

string TestRecipeEvent::RECIPE_NORMAL_NAME = "test_handtest.xml";
string TestRecipeEvent::RECIPE_NORMAL = workspace + RECIPE_NORMAL_NAME;
string TestRecipeEvent::RECIPE_ABNORMAL_NAME = "test_handtest.xml";
string TestRecipeEvent::RECIPE_ABNORMAL = workspace + RECIPE_ABNORMAL_NAME;

class RecipeSpecificMonitor :  public AbstractTestSpecificMonitor {
public:
  void consumeRecipeEvent(const RecipeEvent &event)
  {
    setEvent(event);
    event.getSeconds();
    event.getMicroSeconds();
    event.getProperties();
  }
};



static void *startExecute(void *argument)
{
  Recipe* pExecutor = (Recipe*) argument;
  pExecutor->start();
}

/**
 *
 * @param path the recipe fill path to be executed
 */
Recipe * executeRecipe(const string& path, const TesterSession &session)
{
  RecipeManager &manager = RecipeManager::getInstance();
  Recipe *pExecutor = &manager.newRecipe(path);
  pExecutor->attachToTesterSession(session);
  pthread_t thread1;
  pthread_create(&thread1, NULL, startExecute, (void*) pExecutor);
  return pExecutor;
}

TEST_F(TestRecipeEvent, testRecipeEvent)
{
  TRY_BEGIN
  RecipeSpecificMonitor monitor;
    startMonitor(monitor);

    Recipe *pExecutor =  executeRecipe(RECIPE_NORMAL,*aSession);

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<RecipeEvent>());
      const RecipeEvent* vEvent = event1->getExtension<RecipeEvent>();
      EXPECT_TRUE(vEvent->getAction() == RecipeEvent::EXECUTE);
      EXPECT_TRUE(vEvent->getProgress() == RecipeEvent::STARTED);
      EXPECT_TRUE(vEvent->getRecipeName() == RECIPE_NORMAL);
      monitor.eventDone();
    }


    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<RecipeEvent>());
      const RecipeEvent* vEvent = event1->getExtension<RecipeEvent>();
      EXPECT_TRUE(vEvent->getAction() == RecipeEvent::HOLD);
      EXPECT_TRUE(vEvent->getProgress() == RecipeEvent::STARTED);
      EXPECT_TRUE(vEvent->getHoldDetail() == "PRE_LOT");
      pExecutor->resume();
      monitor.eventDone();
    }

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<RecipeEvent>());
      const RecipeEvent* vEvent = event1->getExtension<RecipeEvent>();
      EXPECT_TRUE(vEvent->getAction() == RecipeEvent::HOLD);
      EXPECT_TRUE(vEvent->getProgress() == RecipeEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getHoldDetail() == "PRE_LOT");
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<RecipeEvent>());
      const RecipeEvent* vEvent = event1->getExtension<RecipeEvent>();
      EXPECT_TRUE(vEvent->getAction() == RecipeEvent::RUN_LEVEL);
      EXPECT_TRUE(vEvent->getProgress() == RecipeEvent::STARTED);
      EXPECT_TRUE(vEvent->getLevelName() == "LOT");
      monitor.eventDone();
    }
    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<RecipeEvent>());
      const RecipeEvent* vEvent = event1->getExtension<RecipeEvent>();
      EXPECT_TRUE(vEvent->getAction() == RecipeEvent::RUN_LEVEL);
      EXPECT_TRUE(vEvent->getProgress() == RecipeEvent::STARTED);
      EXPECT_TRUE(vEvent->getLevelName() == "DEVICE");
      monitor.eventDone();
    }

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<RecipeEvent>());
      const RecipeEvent* vEvent = event1->getExtension<RecipeEvent>();
      EXPECT_TRUE(vEvent->getAction() == RecipeEvent::RUN_LEVEL);
      EXPECT_TRUE(vEvent->getProgress() == RecipeEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getLevelName() == "DEVICE");
      monitor.eventDone();
    }

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<RecipeEvent>());
      const RecipeEvent* vEvent = event1->getExtension<RecipeEvent>();
      EXPECT_TRUE(vEvent->getAction() == RecipeEvent::RUN_LEVEL);
      EXPECT_TRUE(vEvent->getProgress() == RecipeEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getLevelName() == "LOT");
      monitor.eventDone();
    }

    {
      const Event * event1 = monitor.getNextEvent();
      EXPECT_TRUE(event1->hasExtension<RecipeEvent>());
      const RecipeEvent* vEvent = event1->getExtension<RecipeEvent>();
      EXPECT_TRUE(vEvent->getAction() == RecipeEvent::EXECUTE);
      EXPECT_TRUE(vEvent->getProgress() == RecipeEvent::COMPLETED);
      EXPECT_TRUE(vEvent->getRecipeName() == RECIPE_NORMAL);
      monitor.eventDone();
    }

    stopMonitor(monitor);
  TRY_END_FAIL
}

