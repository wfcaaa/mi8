/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#ifndef H51EABF7C_81FD_4FF1_81E0_2CE2E2E219A9
#define H51EABF7C_81FD_4FF1_81E0_2CE2E2E219A9
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include <exception>
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <pthread.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <ctype.h>
#include <stdlib.h>
#include <errno.h>
#include <fstream>
#include <unistd.h>
#include <pwd.h>
#include <mqueue.h>
#include "exception_handler.hpp"
#include <semaphore.h>

using namespace xoc::tcapi;
using namespace std;

class AbstractTestSpecificMonitor : public SpecificMonitor {
public:

  AbstractTestSpecificMonitor():isStoped(false){
  }

  //Block until an event has been received
  const Event * getNextEvent()
  {
    while (!isStoped) {
      if (nextEvent != NULL) {
        return nextEvent;
      } else {
        sleep(2);
      }
    }
    return NULL;
  }

  void setEvent(const Event &event)
  {
    nextEvent = &event;
    //acquire the semaphore
    if(!isStoped){
      sem_wait(&mySemaphore);
    }

  }

  // After this is called, then next event can be consumed
  void eventDone()
  {
    nextEvent = NULL;
    sem_post(&mySemaphore);
  }

  Monitor& start()
  {
    sem_init(&mySemaphore, 0, 0);
    return SpecificMonitor::start();
  }

  Monitor& stop()
  {
    Monitor& montor = SpecificMonitor::stop();
    isStoped = true;
    sem_post(&mySemaphore);
    return montor;
  }

private:
  const Event * nextEvent = NULL;
  bool isStoped;
  sem_t mySemaphore;
};

class AbstractTest : public testing::Test {
public:
  AbstractTest();
  virtual ~AbstractTest();

  static void SetUpTestCase();

  static void TearDownTestCase();

  // Per-test set-up
  virtual void SetUp();

  virtual void TearDown();
  static TesterSession *aSession;
  static string testHome;
  static string wsHome;
  static string recipesDir;
  static string workspace;
  static string driverPath;
  static string driverConfig;

  static void *startListening(void *argument)
  {
    AbstractTestSpecificMonitor* monitor =
        (AbstractTestSpecificMonitor*) argument;
    monitor->start();
  }

  void startMonitor(AbstractTestSpecificMonitor& monitor)
  {
    pthread_create(&thread1, NULL, startListening, (void*) &monitor);
    while (!monitor.isStarted()) {
      sleep(2);
    }
  }

  void stopMonitor(AbstractTestSpecificMonitor& monitor)
  {
    monitor.stop();
    // need waiting for the thread to quit
    pthread_join (thread1, NULL);
  }

private:
  pthread_t thread1;
};
#endif /* H51EABF7C_81FD_4FF1_81E0_2CE2E2E219A9 */
