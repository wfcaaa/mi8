#ifndef TESTCELL_INTEGRATION_TEST_EXCEPTION_HANDLING_HPP
#define TESTCELL_INTEGRATION_TEST_EXCEPTION_HANDLING_HPP

#define TRY_BEGIN try \
                  {
#define TRY_END_FAIL }\
                     catch (TCException &exc) \
                     {\
                        FAIL() << "***********EXCEPTION******************\n" \
                        << "message: " << exc.message << "\n" \
                        << "origin:  " << exc.origin << "\n" \
                        << "type:    " << exc.typeString << "\n" \
                        << "**************************************\n"; \
                     }catch (...) {\
                       FAIL() << "Failed with unknown exception" << endl; \
                     }\

#endif
