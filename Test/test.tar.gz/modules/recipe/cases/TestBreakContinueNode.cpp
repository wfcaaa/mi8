/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestBreakContinueNode : public AbstractRecipeTest {
protected:
  static string TEST_CONTINUE_ELEMENT;
  static string TEST_BREAK_ELEMENT;
  static string TEST_EXPRESSION_ELEMENT;
};

string TestBreakContinueNode::TEST_CONTINUE_ELEMENT = recipesDir
    +"test_continue_level_element.xml";
string TestBreakContinueNode::TEST_BREAK_ELEMENT = recipesDir
    +"test_broken_level_element.xml";
string TestBreakContinueNode::TEST_EXPRESSION_ELEMENT = recipesDir
    +"test_expression_element.xml";

TEST_F(TestBreakContinueNode, testContinueElement)
{
  executeRecipe(TEST_CONTINUE_ELEMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "levelCount").getCommon();
  EXPECT_TRUE(value == "100");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "testedCount").getCommon();
  EXPECT_TRUE(value == "50");
}

TEST_F(TestBreakContinueNode, testBreakElement)
{
  executeRecipeNoException(TEST_BREAK_ELEMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "levelCount").getCommon();
  EXPECT_TRUE(value == "51");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "testedCount").getCommon();
}

TEST_F(TestBreakContinueNode, testExpressionElement)
{
  executeRecipeNoException(TEST_EXPRESSION_ELEMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "tested1").getCommon();
  EXPECT_TRUE(value != "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "tested2").getCommon();
  EXPECT_TRUE(value != "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "tested3").getCommon();
  EXPECT_TRUE(value != "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "tested4").getCommon();
  EXPECT_TRUE(value != "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "tested5").getCommon();
  EXPECT_TRUE(value != "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "tested6").getCommon();
  EXPECT_TRUE(value != "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "tested7").getCommon();
  EXPECT_TRUE(value != "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "tested8").getCommon();
  EXPECT_TRUE(value != "true");
}
