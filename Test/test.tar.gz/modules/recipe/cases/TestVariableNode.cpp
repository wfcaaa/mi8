#include "AbstractRecipeTest.hpp"
class TestVariableNode : public AbstractRecipeTest {
protected:
  static string TEST_TC_VARIABLES;
  static string TEST_TP_VARIABLES;
  static string TEST_ENV_VARIABLES;
  static string TEST_RECIPE_VARIABLES;
  static string TEST_PH_VARIABLES;
};

string TestVariableNode::TEST_TC_VARIABLES = recipesDir
    + "test_recipe_tc_variable.xml";
string TestVariableNode::TEST_TP_VARIABLES = recipesDir
    + "test_recipe_tp_variable.xml";
string TestVariableNode::TEST_ENV_VARIABLES = recipesDir
    + "test_recipe_env_variable.xml";
string TestVariableNode::TEST_RECIPE_VARIABLES = recipesDir
    + "test_recipe_rp_variable.xml";
string TestVariableNode::TEST_PH_VARIABLES = recipesDir
    + "test_recipe_ph_variable.xml";

// Test TC variable
 TEST_F(TestVariableNode , testTCVariable)
{
  executeRecipeNoException(TEST_TC_VARIABLES);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable1").getCommon();
  EXPECT_TRUE(value == "value1");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable2").getCommon();
  EXPECT_TRUE(value == "value2");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable3").getCommon();
  EXPECT_TRUE(value == "value3");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable4").getCommon();
  EXPECT_TRUE(value == "value3");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable5").getCommon();
  EXPECT_TRUE(value == "2");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable6").getCommon();
  EXPECT_TRUE(value == "2");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable7").getCommon();
  EXPECT_TRUE(value =="10");
  long valuel =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableLong(
          "variable8").getCommon();
  EXPECT_TRUE(valuel == 10);
  double valued =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableDouble(
          "variable9").getCommon();
  EXPECT_TRUE(valued == 10.00);
  bool valueb =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableBoolean(
          "variable10").getCommon();
  EXPECT_TRUE(valueb);
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable11").getCommon();
  EXPECT_TRUE(value == "value11");

    value =
       TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
            "val1").getCommon();
    EXPECT_TRUE(value == "fast");

   long valuel2 =
       TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableLong(
           "val2").getCommon();
   EXPECT_TRUE(valuel2 == 20);

   value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "val3").getCommon();
  EXPECT_TRUE(value == "29");
  double valued2 =
        TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableDouble(
            "val4").getCommon();
    EXPECT_TRUE(valued2 == 6.12);

}

//Test  TP variable

TEST_F(TestVariableNode , testTPVariable)
{
   executeRecipeNoException(TEST_TP_VARIABLES);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "variable1").getCommon();
  EXPECT_TRUE(value == "value1_recipe");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "variable2").getCommon();
  EXPECT_TRUE(value == "value2_recipe");
  long longvalue =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableLong(
          "variable3").getCommon();
  EXPECT_TRUE(longvalue == 4);
  double doublevalue =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableDouble(
          "variable4").getCommon();
  EXPECT_TRUE(doublevalue == 5.00);
  bool boolValue =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableBoolean(
          "variable5").getCommon();
  EXPECT_TRUE(!boolValue);
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable7").getCommon();
  EXPECT_TRUE(value == "5");

     value =
       TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
            "val1").getCommon();
     EXPECT_TRUE(value == "hello");

 value =
        TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
            "variable6").getCommon();
    EXPECT_TRUE(value == "World");
    long longvalue1 =
        TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableLong(
            "variable7").getCommon();
    EXPECT_TRUE(longvalue1 == 77);
    double doublevalue1 =
        TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableDouble(
            "variable8").getCommon();
    EXPECT_TRUE(doublevalue1 == 8.88);
    bool boolValue1 =
        TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableBoolean(
            "variable9").getCommon();
    EXPECT_TRUE(boolValue1);

  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID").getCommon();
  EXPECT_TRUE(value == "0");
}

//  Test environment variable

TEST_F(TestVariableNode , testENVVariable)
{
   executeRecipeNoException(TEST_ENV_VARIABLES);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable3").getCommon();
  EXPECT_TRUE(value == "value1");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable4").getCommon();
  EXPECT_TRUE(value == "value2");

  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable5").getCommon();
  EXPECT_TRUE(value == "false");
}


//test recipe variable
TEST_F(TestVariableNode , testRECIPEVariable)
{
   executeRecipeNoException(TEST_RECIPE_VARIABLES);

   string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable1").getCommon();
  EXPECT_TRUE(value == "abc");
   value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable2").getCommon();
  EXPECT_TRUE(value == "22");

}

//test ph variable
TEST_F(TestVariableNode , testPHVariable)
{
   executeRecipeNoException(TEST_PH_VARIABLES);

}
