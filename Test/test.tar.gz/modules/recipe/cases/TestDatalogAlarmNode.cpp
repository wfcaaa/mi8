/**
 * Copyright by Advantest, 2017
 *
 * @author  ivanlv
 * @date    Jan 11, 2017
 */
#ifndef H20A59DE6_FB14_4FBF_8C93_6F46C6C5E526
#define H20A59DE6_FB14_4FBF_8C93_6F46C6C5E526
#include "AbstractRecipeTest.hpp"

namespace integration_cor_remote_server {

  class TestDatalogAlarmNode : public AbstractRecipeTest {
  public:

    void check()
    {
      string value =
          TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
              "invalidAlarmHasHandled").getCommon();
      EXPECT_TRUE(value == "true");
      value =
          TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
              "genericHasHandled").getCommon();
      EXPECT_TRUE(value == "true");

      value =
          TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
              "datalogDefectedHasHandled").getCommon();
      EXPECT_TRUE(value == "false");
    }

    static string TEST_DATALOG_ALARM;
    static string TEST_DATALOG_ALARM1;
    static string TEST_DATALOG_ALARM2;
    static string TEST_DATALOG_IGNORE_WARNING;
    static string TEST_DATALOG_IGNORE_WARNING_FAIL;

  };

  string TestDatalogAlarmNode::TEST_DATALOG_ALARM = recipesDir
      + "test_datalog_alarm.xml";
  string TestDatalogAlarmNode::TEST_DATALOG_ALARM1 = recipesDir
      + "test_datalog_alarm1.xml";
  string TestDatalogAlarmNode::TEST_DATALOG_ALARM2 = recipesDir
      + "test_datalog_alarm2.xml";
  string TestDatalogAlarmNode::TEST_DATALOG_IGNORE_WARNING = recipesDir
      + "test_datalog_ignore_warning.xml";
  string TestDatalogAlarmNode::TEST_DATALOG_IGNORE_WARNING_FAIL = recipesDir
      + "test_datalog_ignore_warning_fail.xml";

  TEST_F(TestDatalogAlarmNode, testDatalogAlarm)
  {
    EXPECT_THROW(executeRecipe(TEST_DATALOG_ALARM), TCException);
  }

  TEST_F(TestDatalogAlarmNode, testDatalogAlarm1)
  {
    EXPECT_THROW(executeRecipe(TEST_DATALOG_ALARM1), TCException);
    check();
  }

  TEST_F(TestDatalogAlarmNode, testDatalogAlarm2)
  {
    EXPECT_THROW(executeRecipe(TEST_DATALOG_ALARM2), TCException);
    check();
  }


  TEST_F(TestDatalogAlarmNode, testIgnoreWarning)
  {
   EXPECT_NO_THROW(executeRecipe(TEST_DATALOG_IGNORE_WARNING));
  }

  TEST_F(TestDatalogAlarmNode, testFailToValidate)
  {
    EXPECT_THROW(executeRecipe(TEST_DATALOG_IGNORE_WARNING_FAIL), TCException);
  }
}
#endif /* H20A59DE6_FB14_4FBF_8C93_6F46C6C5E526 */
