/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestLibraryCallNode : public AbstractRecipeTest {
protected:
  static string TEST_LIBRARYCALL_ELEMENT;
  static string TEST_LIBRARYCALL_FAILED_ELEMENT;
  static string TEST_LIBRARYCALL_IN_SUB_ELEMENT;

};

string TestLibraryCallNode::TEST_LIBRARYCALL_ELEMENT = recipesDir
    + "test_librarycall_element.xml";
string TestLibraryCallNode::TEST_LIBRARYCALL_FAILED_ELEMENT = recipesDir
    + "test_librarycall_failed_element.xml";
string TestLibraryCallNode::TEST_LIBRARYCALL_IN_SUB_ELEMENT = recipesDir
    + "test_librarycall_in_sub_recipe.xml";

/**
 * Test using recipe to call a library function
 */TEST_F(TestLibraryCallNode, testLibraryCallElement)
{
   executeRecipeNoException(TEST_LIBRARYCALL_ELEMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable").getCommon();
  EXPECT_TRUE(value == "abcd");

  long ret =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableLong(
          "ret").getCommon();
  EXPECT_TRUE(ret == 1234);
}

 /**
  * Test a library call will be failed
  */TEST_F(TestLibraryCallNode, testLibraryCallInSubElement)
 {
    RecipeManager &manager = RecipeManager::getInstance();
    Recipe *pExecutor = &manager.newRecipe(TEST_LIBRARYCALL_IN_SUB_ELEMENT);
    executeRecipeNoException(TEST_LIBRARYCALL_IN_SUB_ELEMENT,pExecutor);
   string value =pExecutor->getAttachedTesterSession().testProgram().getTCVariableString(
           "variableInSub").getCommon();
   EXPECT_TRUE(value == "abcd");

   long ret = pExecutor->getAttachedTesterSession().testProgram().getTCVariableLong(
           "retInSub").getCommon();
   EXPECT_TRUE(ret == 1234);
 }


/**
 * Test a library call will be failed
 */TEST_F(TestLibraryCallNode, testLibraryCallElementFailed)
{
  EXPECT_THROW( executeRecipe(TEST_LIBRARYCALL_FAILED_ELEMENT), TCException);
}
