/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestExecutableNode : public AbstractRecipeTest {
protected:
  static string TEST_EXECUTABLE_ELEMENT;
  static string TEST_EXECUTE_ELEMENT_FAILED;
  static string TEST_EXECUTE_ELEMENT_IGNORE_FAILED;
  static string TEST_EXECUTE_WITH_CLEAN_ENV;
};

string TestExecutableNode::TEST_EXECUTABLE_ELEMENT = recipesDir
    + "test_executable_element.xml";

string TestExecutableNode::TEST_EXECUTE_ELEMENT_FAILED = recipesDir
    + "test_executable_element_fail.xml";
string TestExecutableNode::TEST_EXECUTE_ELEMENT_IGNORE_FAILED = recipesDir
    + "test_executable_element_ignore_fail.xml";
string TestExecutableNode::TEST_EXECUTE_WITH_CLEAN_ENV = recipesDir + "test_executable_clean_environment.xml";

/**
 * Test using recipe to execute a script file
 */
TEST_F(TestExecutableNode, testExecutableElement)
{
  executeRecipeNoException(TEST_EXECUTABLE_ELEMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable2").getCommon();
  EXPECT_TRUE(value == "value1");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable3").getCommon();
  EXPECT_TRUE(value == "value3");
}

/**
 * Test using recipe to execute a failed script file
 */
TEST_F(TestExecutableNode, testExecutableElementFailed)
{
  EXPECT_THROW(executeRecipe(TEST_EXECUTE_ELEMENT_FAILED), TCException);
}

/**
 * Test using recipe to execute a failed script file, the error is ignored
 */
TEST_F(TestExecutableNode, testExecutableElementFailIgnored)
{
   executeRecipeNoException(TEST_EXECUTE_WITH_CLEAN_ENV);
}

TEST_F(TestExecutableNode, testExecuteableElementWithCleanEnv){
  executeRecipeNoException(TEST_EXECUTE_ELEMENT_IGNORE_FAILED);
}
