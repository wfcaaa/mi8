/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#include "AbstractRecipeTest.hpp"
#include "exception_handler.hpp"
//static variable definition
string AbstractRecipeTest::testHome = getenv("XOC_TEST_MODULE");
string AbstractRecipeTest::wsHome = getenv("XOC_TEST_WORKSPACES");
string AbstractRecipeTest::recipesDir = AbstractRecipeTest::testHome
    + "/testbed/recipes/";

AbstractRecipeTest::AbstractRecipeTest()
{
  // TODO Auto-generated constructor stub

}

AbstractRecipeTest::~AbstractRecipeTest()
{
  // TODO Auto-generated destructor stub
}

// Per-test-case set-up.
void AbstractRecipeTest::SetUpTestCase()
{
  if (access("/opt/hp93000/soc/prod_env/lbin/kill_smarTest", X_OK) != 0
      || access("/opt/hp93000/soc/prod_env/bin/HPSmarTest", X_OK) != 0) {
    throw(runtime_error(
        "kill_smarTest and HPSmarTest are not executable. SmarTest may not be installed!"));
  }
}

// Per-test-case tear-down.
void AbstractRecipeTest::TearDownTestCase()
{
}

/**
 *
 * @param path the recipe fill path to be executed
 */
void AbstractRecipeTest::executeRecipe(const string& path, Recipe *pExecutor)
{
  TRY_BEGIN
    if (pExecutor == NULL) {
      RecipeManager &manager = RecipeManager::getInstance();
      pExecutor = &manager.newRecipe(path);
    }
    //executor.attachToTesterSession(TestCell::getInstance().testerSession("TesterSession_1"));
    //start the recipe execution
    cout << "Start executing recipe " << path << endl;
    pExecutor->start();
    cout << "Execute successfully" << endl;
  TRY_END_FAIL
}

/**
 *
 * @param path the recipe fill path to be executed
 */
void AbstractRecipeTest::executeRecipeNoException(const string& path,
    Recipe *pExecutor)
{
  try {
    executeRecipe(path, pExecutor);
  } catch (...) {
    FAIL() << "Execute recipe " << path << " failed";
  }
}

// Per-test set-up
void AbstractRecipeTest::SetUp()
{

}

// Per-test tear-down
void AbstractRecipeTest::TearDown()
{

  int ret = system("/opt/hp93000/soc/prod_env/lbin/kill_smarTest -f");
  if (ret == -1 || WEXITSTATUS(ret) != 0) {
    throw(runtime_error(
        "Failed to execute /opt/hp93000/soc/prod_env/lbin/kill_smarTest"));
  }
}
