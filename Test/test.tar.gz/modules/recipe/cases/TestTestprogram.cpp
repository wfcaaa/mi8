/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#include "AbstractRecipeTest.hpp"
class TestTestprogram : public AbstractRecipeTest {
protected:

  static string TEST_ACTIVATE_TESTPROGRAM;
  static string TEST_LINK_TESTPROGRAM;
  static string TEST_BIND_TESTPROGRAM;
  static string TEST_START_TESTPROGRAM;
  static string TEST_RUN_TESTPROGRAM;
  static string TEST_STOP_TESTPROGRAM;
  static string TEST_IGNORE_SITES_ELEMENT;
  static string TEST_TESTPROGRAM_SKIP_ACTIVATION;
  static string TEST_TESTPROGRAM_SKIP_ACTIVATION1;
  static string TEST_TESTPROGRAM_SKIP_ACTIVATION2;
  static string TEST_TESTPROGRAM_SKIP_ACTIVATION3;
  static string TEST_TESTPROGRAM_WORKSPACE_EMPTY;
  static string TEST_TESTPROGRAM_TESTPROGRAM_DYNAMIC;
  static string TEST_TESTPROGRAM_DUTBOARD_NOT_EXIST;
  static string TEST_RESET_TESTPROGRAM_DEFAULT;
  static string TEST_RESET_TESTPROGRAM;
  static string TEST_ERROR_RESET_TESTPROGRAM;
};

string TestTestprogram::TEST_ACTIVATE_TESTPROGRAM = recipesDir
    + "test_activate_testprogram.xml";
string TestTestprogram::TEST_LINK_TESTPROGRAM = recipesDir
    + "test_link_testprogram.xml";
string TestTestprogram::TEST_BIND_TESTPROGRAM = recipesDir
    + "test_bind_testprogram.xml";
string TestTestprogram::TEST_START_TESTPROGRAM = recipesDir
    + "test_start_testprogram.xml";
string TestTestprogram::TEST_RUN_TESTPROGRAM = recipesDir
    + "test_run_testprogram.xml";
string TestTestprogram::TEST_STOP_TESTPROGRAM = recipesDir
    + "test_stop_testprogram.xml";
string TestTestprogram::TEST_IGNORE_SITES_ELEMENT = recipesDir
    + "test_ignore_sites_element.xml";
string TestTestprogram::TEST_TESTPROGRAM_SKIP_ACTIVATION = recipesDir
    + "test_testprogram_skip_activation.xml";
string TestTestprogram::TEST_TESTPROGRAM_SKIP_ACTIVATION1 = recipesDir
    + "test_testprogram_skip_activation1.xml";
string TestTestprogram::TEST_TESTPROGRAM_SKIP_ACTIVATION2 = recipesDir
    + "test_testprogram_skip_activation2.xml";
string TestTestprogram::TEST_TESTPROGRAM_SKIP_ACTIVATION3 = recipesDir
    + "test_testprogram_skip_activation3.xml";

string TestTestprogram::TEST_TESTPROGRAM_WORKSPACE_EMPTY = recipesDir
    + "test_testprogram_workspace_empty.xml";

string TestTestprogram::TEST_TESTPROGRAM_TESTPROGRAM_DYNAMIC = recipesDir
    + "test_testprogram_testprogram_dynamic.xml";

string TestTestprogram::TEST_TESTPROGRAM_DUTBOARD_NOT_EXIST = recipesDir
    + "test_testprogram_dutboard_not_exist.xml";

string TestTestprogram::TEST_RESET_TESTPROGRAM_DEFAULT = recipesDir
    + "test_recipe_reset_tp_variable1.xml";

string TestTestprogram::TEST_RESET_TESTPROGRAM = recipesDir
    + "test_recipe_reset_tp_variable2.xml";

string TestTestprogram::TEST_ERROR_RESET_TESTPROGRAM = recipesDir
    + "test_recipe_reset_tp_variable3.xml";

TEST_F(TestTestprogram, testActivateTestprogram)
{
  executeRecipeNoException(TEST_ACTIVATE_TESTPROGRAM);
  EXPECT_TRUE(
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getState() >= TestProgram::ACTIVATED);
}

TEST_F(TestTestprogram, testLinkTestprogram)
{
  executeRecipeNoException(TEST_LINK_TESTPROGRAM);
  EXPECT_TRUE(
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getState() >= TestProgram::LOADED);
}

TEST_F(TestTestprogram, testBindTestprogram)
{
  executeRecipeNoException(TEST_BIND_TESTPROGRAM);
  EXPECT_TRUE(
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getState() >= TestProgram::BOUND);
}

TEST_F(TestTestprogram, testStartTestprogram)
{
  // listening the lot completed event
  EventExpector expector;
  map<string, string> lotLevelEnd;
  lotLevelEnd.insert(
      std::pair<string, string>("EXECUTION_STATE", "TESTPROGRAM_RUNNING"));
  expector.expectEvent(Event::TESTPROGRAM, lotLevelEnd, 1);
  executeRecipeNoException(TEST_START_TESTPROGRAM);
  EXPECT_TRUE(
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getState() >= TestProgram::BOUND);
  // check event
  sleep(2);
  expector.done();
  string value =
       TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
           "SYS.LOT_TYPE").getCommon();
  EXPECT_TRUE(value == "PACKAGE_TEST");
}

TEST_F(TestTestprogram, testRunTestprogram)
{
  // listening the lot completed event
  EventExpector expector;
  map<string, string> lotLevelEnd;
  lotLevelEnd.insert(
      std::pair<string, string>("EXECUTION_STATE", "TESTPROGRAM_RUNNING"));
  expector.expectEvent(Event::TESTPROGRAM, lotLevelEnd, 1);
  executeRecipeNoException(TEST_RUN_TESTPROGRAM);
  EXPECT_TRUE(
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getState() >= TestProgram::BOUND);
  // check event
  sleep(2);
  expector.done();
  string value =
        TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
            "SYS.LOT_TYPE").getCommon();
  EXPECT_TRUE(value == "WAFER_TEST");
}

//TODO to adapt the new custom library
/**
 * Test using recipe to run the test program
 */
TEST_F(TestTestprogram, testStopTestprogram)
{
  executeRecipeNoException(TEST_STOP_TESTPROGRAM);
  EXPECT_TRUE(
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getState() >= TestProgram::BOUND);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "datalogPath").getCommon();
  string custom = value + ".cus";
  ifstream fileCus;
  fileCus.open(custom.c_str());
  string line;
  bool find = false;
  while (getline(fileCus, line)) {
    if (line.find("doTestProgramEndEvent") != string::npos) {
      find = true;
      break;
    }
  }
  EXPECT_TRUE(find);
}

TEST_F(TestTestprogram, testIgnoreSites)
{
  executeRecipeNoException(TEST_IGNORE_SITES_ELEMENT);
  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");
  EXPECT_TRUE(partID.get(1) == "298");
  EXPECT_TRUE(partID.get(2) == "");
  EXPECT_TRUE(partID.get(3) == "299");
  EXPECT_TRUE(partID.get(4) == "300");
}

TEST_F(TestTestprogram, testSkipActivation)
{
  // listening the lot completed event
  EventExpector expector;
  map<string, string> activateEvent;
  activateEvent.insert(
      std::pair<string, string>("EXECUTION_STATE", "TESTPROGRAM_ACTIVATION_COMPLETED"));
  expector.expectEvent(Event::TESTPROGRAM, activateEvent, 1);
  executeRecipeNoException(TEST_TESTPROGRAM_SKIP_ACTIVATION);
  sleep(2);
  expector.done();
}

TEST_F(TestTestprogram, testSkipActivation1)
{
  // listening the lot completed event
  EventExpector expector;
  map<string, string> activateEvent;
  activateEvent.insert(
      std::pair<string, string>("EXECUTION_STATE", "TESTPROGRAM_ACTIVATION_COMPLETED"));
  expector.expectEvent(Event::TESTPROGRAM, activateEvent, 2);
  executeRecipeNoException(TEST_TESTPROGRAM_SKIP_ACTIVATION1);
  sleep(2);
  expector.done();
}

TEST_F(TestTestprogram, testSkipActivation2)
{
  // listening the lot completed event
  EventExpector expector;
  map<string, string> activateEvent;
  activateEvent.insert(
      std::pair<string, string>("EXECUTION_STATE", "TESTPROGRAM_ACTIVATION_COMPLETED"));
  expector.expectEvent(Event::TESTPROGRAM, activateEvent, 1);
  executeRecipeNoException(TEST_TESTPROGRAM_SKIP_ACTIVATION2);
  sleep(2);
  expector.done();
}

TEST_F(TestTestprogram, testSkipActivation3)
{
  // listening the lot completed event
  EventExpector expector;
  map<string, string> activateEvent;
  activateEvent.insert(
      std::pair<string, string>("EXECUTION_STATE", "TESTPROGRAM_ACTIVATION_COMPLETED"));
  expector.expectEvent(Event::TESTPROGRAM, activateEvent, 2);
  executeRecipeNoException(TEST_TESTPROGRAM_SKIP_ACTIVATION3);
  sleep(2);
  expector.done();
}

TEST_F(TestTestprogram, testWorkspaceEmpty)
{
  // When workspace is empty, should throw exception
  EXPECT_THROW(executeRecipe(TEST_TESTPROGRAM_WORKSPACE_EMPTY), TCException);
}

TEST_F(TestTestprogram, testTestProgramDynamic)
{
  // When workspace is empty, should throw exception
  EXPECT_THROW(executeRecipe(TEST_TESTPROGRAM_TESTPROGRAM_DYNAMIC), TCException);
}

TEST_F(TestTestprogram, testTestDutboardNotExist)
{
  // When workspace is empty, should throw exception
  EXPECT_THROW(executeRecipe(TEST_TESTPROGRAM_DUTBOARD_NOT_EXIST), TCException);
}

TEST_F(TestTestprogram, TestResetTestProgramDefault)
{
  executeRecipeNoException(TEST_RESET_TESTPROGRAM_DEFAULT);
  MultiSiteLong value1 = TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableLong("STDF.CENTER_X");
  MultiSiteLong value2 = TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableLong("STDF.CENTER_Y");
  EXPECT_TRUE(value1.get(1) == 1);
  EXPECT_TRUE(value2.get(1) == 2);
}

TEST_F(TestTestprogram, TestResetTestProgram)
{
  executeRecipeNoException(TEST_RESET_TESTPROGRAM);
  MultiSiteLong value1 = TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableLong("STDF.CENTER_X");
  MultiSiteLong value2 = TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableLong("STDF.CENTER_Y");
  EXPECT_TRUE(value1.get(1) == 0);
  EXPECT_TRUE(value2.get(1) == 0);
}

TEST_F(TestTestprogram, TestErrorResetTestProgram)
{
  EXPECT_THROW(executeRecipe(TEST_ERROR_RESET_TESTPROGRAM), TCException);
}