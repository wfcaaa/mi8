/**
 * Copyright by Advantest, 2017
 *
 * @author  ivanlv
 * @date    Jan 11, 2017
 */
#ifndef HD6AF7ED0_3283_4DAA_AEF9_76142AC76540
#define HD6AF7ED0_3283_4DAA_AEF9_76142AC76540
#include "AbstractRecipeTest.hpp"

class TestHooksNode : public AbstractRecipeTest {
  protected:

  static string TEST_HOOKS;
};

string TestHooksNode::TEST_HOOKS = recipesDir + "test_hooks.xml";

TEST_F(TestHooksNode, testHook)
{
  try {
  RecipeManager &manager = RecipeManager::getInstance();
  Recipe *pExecutor = &manager.newRecipe(TEST_HOOKS);

  RecipeResumeCallback *callback1 = new RecipeResumeCallback(pExecutor);
  RecipePauseCallback *callback2 = new RecipePauseCallback(pExecutor);
  RecipeStopCallback *callback3 = new RecipeStopCallback(pExecutor);
  // listening the lot hold event
  EventExpector expector4LotHoldStart;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(std::pair<string, string>("HOLD_DETAIL", "PRE_LOT"));
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_STARTED"));
    expector4LotHoldStart.expectEvent(Event::RECIPE, lotLevelStart, 1,
        callback1);
  }

  // listening the lot hold event
  EventExpector expector4Pause;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(std::pair<string, string>("HOLD_DETAIL", "PRE_LOT"));
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_COMPLETED"));
    expector4Pause.expectEvent(Event::RECIPE, lotLevelStart, 1, callback2);
  }

  // listening the lot hold event
  EventExpector expector4Resume;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_PAUSE_STARTED"));
    expector4Resume.expectEvent(Event::RECIPE, lotLevelStart, 1, callback1);
  }

  // listening the lot hold event
  EventExpector expector4Stop;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_PAUSE_COMPLETED"));
    expector4Stop.expectEvent(Event::RECIPE, lotLevelStart, 1, callback3);
  }

  executeRecipeNoException(TEST_HOOKS, pExecutor);

  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "RECIPE_HAS_HOLD").getCommon();
  // check 8 levels have been executed
  EXPECT_TRUE(value == "true");

  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "RECIPE_HAS_PAUSED").getCommon();
  // check 8 levels have been executed
  EXPECT_TRUE(value == "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "RECIPE_HAS_RESUMED").getCommon();
  // check 8 levels have been executed
  EXPECT_TRUE(value == "true");

  sleep(10);
  expector4LotHoldStart.done();
  expector4Pause.done();
  expector4Resume.done();
  expector4Stop.done();
  delete callback1;
  delete callback2;
  delete callback3;
  }catch (TCException&  e) {
    cout << e.message << endl;
  }
}

#endif /* HD6AF7ED0_3283_4DAA_AEF9_76142AC76540 */
