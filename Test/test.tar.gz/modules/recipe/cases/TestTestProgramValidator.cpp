/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Jun 7, 2016
 */
#include "AbstractRecipeTest.hpp"
class TestTestProgramValidator : public AbstractRecipeTest {
protected:
  static string TEST_VALIDATION_MUST_SPECIFY_LOTTYPE1;
  static string TEST_VALIDATION_MUST_SPECIFY_LOTTYPE2;
};

string TestTestProgramValidator::TEST_VALIDATION_MUST_SPECIFY_LOTTYPE1 = recipesDir
    + "test_validation_must_specify_lotType1.xml";
string TestTestProgramValidator::TEST_VALIDATION_MUST_SPECIFY_LOTTYPE2 = recipesDir
    + "test_validation_must_specify_lotType2.xml";

TEST_F(TestTestProgramValidator, testValidationMustSpecifyLottype1)
{
  EXPECT_THROW( executeRecipe(TEST_VALIDATION_MUST_SPECIFY_LOTTYPE1), TCException);
}

TEST_F(TestTestProgramValidator, testValidationMustSpecifyLottype2)
{
  EXPECT_THROW( executeRecipe(TEST_VALIDATION_MUST_SPECIFY_LOTTYPE2), TCException);
}
