/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestAssignmentNode : public AbstractRecipeTest {
protected:
  static string TEST_TC_VARIABLES_ASSIGNMENT;
  static string TEST_TP_VARIABLES_ASSIGNMENT;
  static string TEST_ENV_VARIABLES_ASSIGNMENT;
  static string TEST_INCREMENT_ASSIGNMENT_VALUE_ILLEGAL;
  static string TEST_INCREMENT_ASSIGNMENT_VALUE_ILLEGAL2;
};

string TestAssignmentNode::TEST_TC_VARIABLES_ASSIGNMENT = recipesDir
    + "test_tc_variable_assignment.xml";
string TestAssignmentNode::TEST_TP_VARIABLES_ASSIGNMENT = recipesDir
    + "test_tp_variable_assignment.xml";
string TestAssignmentNode::TEST_ENV_VARIABLES_ASSIGNMENT = recipesDir
    + "test_env_variable_assignment.xml";

string TestAssignmentNode::TEST_INCREMENT_ASSIGNMENT_VALUE_ILLEGAL = recipesDir
    + "test_increment_assignment_value_illegal.xml";

string TestAssignmentNode::TEST_INCREMENT_ASSIGNMENT_VALUE_ILLEGAL2 = recipesDir
    + "test_increment_assignment_value_illegal2.xml";
/**
 * Test using recipe to assignment the TC variable
 */
TEST_F(TestAssignmentNode, testTCVariableAssignment)
{
  executeRecipeNoException(TEST_TC_VARIABLES_ASSIGNMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable1").getCommon();
  EXPECT_TRUE(value == "value1");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable2").getCommon();
  EXPECT_TRUE(value == "value2");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable3").getCommon();
  EXPECT_TRUE(value == "value3");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable4").getCommon();
  EXPECT_TRUE(value == "value3");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable5").getCommon();
  EXPECT_TRUE(value == "2");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable6").getCommon();
  EXPECT_TRUE(value == "2");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable7").getCommon();
  EXPECT_TRUE(value =="10");
  long valuel =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableLong(
          "variable8").getCommon();
  EXPECT_TRUE(valuel == 10);
  double valued =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableDouble(
          "variable9").getCommon();
  EXPECT_TRUE(valued == 10.00);
  bool valueb =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableBoolean(
          "variable10").getCommon();
  EXPECT_TRUE(valueb);
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable11").getCommon();
  EXPECT_TRUE(value == "value11");
}

/**
 * Test using recipe to assignment the TP variable
 */TEST_F(TestAssignmentNode, testTPVariableAssignment)
{
   executeRecipeNoException(TEST_TP_VARIABLES_ASSIGNMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "variable1").getCommon();
  EXPECT_TRUE(value == "value1_recipe");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "variable2").getCommon();
  EXPECT_TRUE(value == "value2_recipe");
  long longvalue =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableLong(
          "variable3").getCommon();
  EXPECT_TRUE(longvalue == 4);
  double doublevalue =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableDouble(
          "variable4").getCommon();
  EXPECT_TRUE(doublevalue == 5.00);
  bool boolValue =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableBoolean(
          "variable5").getCommon();
  EXPECT_TRUE(!boolValue);
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable7").getCommon();
  EXPECT_TRUE(value == "5");

  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID").getCommon();
  EXPECT_TRUE(value == "0");
}

/**
 * Test using recipe to assignment the environment variable
 */TEST_F(TestAssignmentNode, testENVVariableAssignment)
{
   executeRecipeNoException(TEST_ENV_VARIABLES_ASSIGNMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable3").getCommon();
  EXPECT_TRUE(value == "value1");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "variable4").getCommon();
  EXPECT_TRUE(value == "value2");
}

 /**
  * Test Increment handle the illegal value
  */
 TEST_F(TestAssignmentNode, testIncrementIllegal) {
   //Test level count illegal
   EXPECT_THROW(executeRecipe(TEST_INCREMENT_ASSIGNMENT_VALUE_ILLEGAL), TCException);
   EXPECT_THROW(executeRecipe(TEST_INCREMENT_ASSIGNMENT_VALUE_ILLEGAL2), TCException);
 }
