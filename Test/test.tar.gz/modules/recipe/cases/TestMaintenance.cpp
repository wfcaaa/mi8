/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#include "AbstractRecipeTest.hpp"
class TestMaintenance : public AbstractRecipeTest {
protected:

  static string TEST_MAINTENANCE_WITH_EXCEPTION;

  static string TEST_MAINTENANCE;

};

string TestMaintenance::TEST_MAINTENANCE_WITH_EXCEPTION = recipesDir
    + "test_maintenance_state_with_exception.xml";

string TestMaintenance::TEST_MAINTENANCE = recipesDir + "test_maintenance_state.xml";

TEST_F(TestMaintenance, testMaintenance)
{
  executeRecipeNoException(TEST_MAINTENANCE);
}

TEST_F(TestMaintenance, testMaintenanceWithException)
{
  EXPECT_THROW( executeRecipe(TEST_MAINTENANCE_WITH_EXCEPTION), TCException);
}
