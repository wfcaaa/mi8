/**
 * Copyright by Advantest, 2019
 *
 * @author  zoyiyu
 * @date    Jul 8, 2019
 */

#include "AbstractRecipeTest.hpp"
class TestOOCRuleNode : public AbstractRecipeTest {
protected:
  static string TEST_OOCRULE_ELEMENT;
};

string TestOOCRuleNode::TEST_OOCRULE_ELEMENT = recipesDir
    + "test_ooc_rules_element.xml";

TEST_F(TestOOCRuleNode, testOOCRule)
{
  executeRecipeNoException(TEST_OOCRULE_ELEMENT);
  EXPECT_TRUE(
      !TestCell::getInstance().getTesterSessions()[0]->getSessionId().empty());
}
