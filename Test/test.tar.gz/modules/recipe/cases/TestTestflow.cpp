/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#include "AbstractRecipeTest.hpp"
class TestTestflow : public AbstractRecipeTest {
protected:

  static string TEST_EXECUTE_TESTFLOW_WITH_INPUT_OUTPUT_PARAMETERS;
};

string TestTestflow::TEST_EXECUTE_TESTFLOW_WITH_INPUT_OUTPUT_PARAMETERS =
    recipesDir + "test_execute_testflow_with_input_output_parameters.xml";

TEST_F(TestTestflow, testTestflowWithInputOutputParameters)
{
  executeRecipeNoException(TEST_EXECUTE_TESTFLOW_WITH_INPUT_OUTPUT_PARAMETERS);
  EXPECT_TRUE(
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getState() >= TestProgram::ACTIVATED);
  string value =
  TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
      "summer").getCommon();
  EXPECT_TRUE(value == "3");

  value =
  TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
      "fromENV").getCommon();
  EXPECT_TRUE(value == "3");

  value =
  TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
      "fromRecipe").getCommon();
  EXPECT_TRUE(value == "3");

  value =
  TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
      "fromPH").getCommon();
  EXPECT_TRUE(value == "3");

  int ret =
  TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableLong(
      "variable3").getCommon();
  EXPECT_TRUE(ret == 3);

}
