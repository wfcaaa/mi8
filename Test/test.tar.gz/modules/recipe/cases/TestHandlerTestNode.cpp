/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestHandlerTestNode : public AbstractRecipeTest {
protected:
  static string TEST_HANDLER_LOT_TESTING;
  static string TEST_HANDLER_LOT_TESTING1;
  static string TEST_HANDLER_LOT_TESTING2;

};

string TestHandlerTestNode::TEST_HANDLER_LOT_TESTING = recipesDir
    + "test_handler_lot_testing.xml";
string TestHandlerTestNode::TEST_HANDLER_LOT_TESTING1 = recipesDir
    + "test_handler_lot_testing1.xml";
string TestHandlerTestNode::TEST_HANDLER_LOT_TESTING2 = recipesDir
    + "test_handler_lot_testing2.xml";

TEST_F(TestHandlerTestNode, testHandlerTest)
{

  executeRecipeNoException(TEST_HANDLER_LOT_TESTING);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "datalogPath").getCommon();
  EXPECT_TRUE(!value.empty());
  string txt = value + ".txt";
  string edl = value + ".edl";
  string stdf = value + ".stdf";
  ifstream fileTxt(txt.c_str(), std::ifstream::ate | std::ifstream::binary);
  ifstream fileEdl(edl.c_str(), std::ifstream::ate | std::ifstream::binary);
  ifstream fileStdf(stdf.c_str(), std::ifstream::ate | std::ifstream::binary);

  EXPECT_TRUE(fileTxt.tellg() > 0);
  EXPECT_TRUE(fileEdl.tellg() > 0);
  EXPECT_TRUE(fileStdf.tellg() > 0);

  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");

  EXPECT_TRUE(partID.get(1) == "39");
  EXPECT_TRUE(partID.get(2) == "40");
}

TEST_F(TestHandlerTestNode, testHandlerTest1)
{

  executeRecipeNoException(TEST_HANDLER_LOT_TESTING1);
  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");
  EXPECT_TRUE(partID.get(1) == "39");
  EXPECT_TRUE(partID.get(2) == "40");
  EXPECT_TRUE(partID.get(3) == "");
  EXPECT_TRUE(partID.get(4) == "");
}

TEST_F(TestHandlerTestNode, testHandlerTest2)
{

  executeRecipeNoException(TEST_HANDLER_LOT_TESTING2);
  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");
  EXPECT_TRUE(partID.get(1) == "20");
  EXPECT_TRUE(partID.get(2) == "");
  EXPECT_TRUE(partID.get(3) == "");
  EXPECT_TRUE(partID.get(4) == "");
}
