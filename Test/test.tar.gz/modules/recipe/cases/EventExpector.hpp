/**
 * Copyright by Advantest, 2015
 *
 * @author  ivanlv
 * @date    Dec 3, 2015
 */
#ifndef HD86FA460_60CF_474C_9DA7_0A8AE7E720DE
#define HD86FA460_60CF_474C_9DA7_0A8AE7E720DE
#include "xoc/tcapi/tcapi.hpp"
#include <string>
#include <vector>
#include <map>
#include <iostream>
#include <pthread.h>
using namespace std;
using namespace xoc::tcapi;

class UnExpectException : public exception {
public:
  string reason;
  UnExpectException(string cause)
  {
    this->reason = cause;
  }

  ~UnExpectException() throw ()
  {
  }
  ;

  const char* what()
  {
    return reason.c_str();
  }

};

class Callback {
public:
  Callback()
  {

  }
  virtual ~Callback()
  {
  }
  ;

  virtual void run() = 0;
};

class RecipeResumeCallback : public Callback {
public:
  RecipeResumeCallback(Recipe* recipe)
  {
    pRecipe = recipe;
  }
  ~RecipeResumeCallback()
  {
  }
  void run()
  {
    if (pRecipe != NULL)
      pRecipe->resume();
  }
private:
  Recipe* pRecipe;
};

class RecipePauseCallback : public Callback {
public:
  RecipePauseCallback(Recipe* recipe)
  {
    pRecipe = recipe;
  }
  ~RecipePauseCallback()
  {
  }
  void run()
  {
    if (pRecipe != NULL) {
      pRecipe->pause();
    }
  }
private:
  Recipe* pRecipe;
};

class RecipeStopCallback : public Callback {
public:
  RecipeStopCallback(Recipe* recipe)
  {
    pRecipe = recipe;
  }
  ~RecipeStopCallback()
  {
  }
  void run()
  {
    if (pRecipe != NULL) {
      pRecipe->stop();
    }
  }
private:
  Recipe* pRecipe;
};
class MyMonitor;
class EventExpector {
public:
  EventExpector();
  virtual ~EventExpector();

  /**
   * Register a event lister with specified type, properties, and the count expected to be listened.
   *
   *
   * @param eventType the event type
   * @param properties the event properties
   * @param eventCount the event count to be expected to received
   */
  void expectEvent(Event::EventType eventType, map<string, string> properties,
      int eventCount, Callback* callbacker = NULL);

  void done() throw (UnExpectException);

  int getEventCount() const;

  Event::EventType getEventType();

  map<string, string>& getProperties();

  Callback* getCallback();

  void setReceiveCount(int);

  MyMonitor* monitor;
  bool isStartLisenting;

private:
  Event::EventType eventType;
  int receiveCount;
  map<string, string> properties;
  Callback* callbacker;
  int eventCount;
  pthread_t thread1;
};

class MyMonitor : public Monitor {
public:

  MyMonitor(EventExpector *expector) :
      pExpector(expector), receiveCount(0)
  {
  }

  int getCount()
  {
    return this->receiveCount;
  }

  void consume(const Event& event)
  {
    if (pExpector->getEventType() == event.getType()) {
      map<string, string>::iterator iter;
      bool find = false;
      for (iter = pExpector->getProperties().begin();
          iter != pExpector->getProperties().end(); iter++) {
        vector<TestCellEventProperty> properties = event.getProperties();
        for (unsigned int i = 0; i < event.getProperties().size(); i++) {
          if (iter->first == properties[i].name) {
            for (unsigned int j = 0; j < properties[i].value.size(); j++) {
              if (properties[i].value[j] == iter->second) {
                find = true;
                break;
              }
              if (j == properties[i].value.size() - 1) {
                find = false;
              }
            }
          }
        }
        if (!find) {
          break;
        }
      }

      if (find) {
        receiveCount++;
        if (pExpector->getCallback() != NULL) {
          pExpector->getCallback()->run();
        }
      }
    }
  }
private:
  EventExpector *pExpector;
  int receiveCount;
};
#endif /* HD86FA460_60CF_474C_9DA7_0A8AE7E720DE */
