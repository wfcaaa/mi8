/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestOnCrash : public AbstractRecipeTest {
protected:
  static string TEST_ONCRASH_ELEMENT;
};

string TestOnCrash::TEST_ONCRASH_ELEMENT = recipesDir
    + "test_oncrash_element.xml";
/**
 * Test using recipe to execute a script file
 */
TEST_F(TestOnCrash, testExecutableElement)
{
  EXPECT_THROW(executeRecipe(TEST_ONCRASH_ELEMENT), TCException);
  EXPECT_TRUE(-1 != access("/tmp/testcrash", F_OK));
}
