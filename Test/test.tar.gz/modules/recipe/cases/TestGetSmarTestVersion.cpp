/**
 * Copyright by Advantest, 2019
 *
 * @author  zoyiyu
 * @date    Aug 7, 2019
 */

#include "AbstractRecipeTest.hpp"
#include "util/Helper.hpp"

using namespace ::recipe::util;

class TestGetSmarTestVersion : public AbstractRecipeTest {
protected:
  string specifiedVersion;
  string workspaceVersion;
  string launchedSmarTestVersion;
  string smartestVersion;
  bool enforcePatchVersion;
  static vector<string> installedVersionList;
};

// init installedVersionList
vector<string> TestGetSmarTestVersion::installedVersionList = {
  "soc64_8.3.0.0_1x1_20190809_1111_C_BETA",
  "soc64_8.3.0.0_1x2_20190808_1111_C_BETA",
  "soc64_8.2.5.2",
  "soc64_8.2.5.1",
  "soc64_8.2.3.0.cs.2",
  "soc64_8.2.3.0.cs.1",
  "soc64_8.2.3.0",
  "soc64_8.2.1.1",
  "soc64_8.2.1.0",
  "soc64_8.2.1.0.cs.1",
  "soc64_Iworkspacesxxxx"
};

/**
 * Test getSmarTestVersion
 */
// For version was not specified in smartest and workspace
TEST_F(TestGetSmarTestVersion, emptyVersion)
{
  vector<string> versionList = ::Helper::getInstalledVersionList();

  specifiedVersion = "";
  workspaceVersion = "";

  // both specifiedVersion and workspaceVersion is empty
  launchedSmarTestVersion = "";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "");

  // both specifiedVersion and workspaceVersion is empty
  launchedSmarTestVersion = "8.2.5.2";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "");
}


// For version was specified in smartest node
TEST_F(TestGetSmarTestVersion, specifiedVersion)
{
  launchedSmarTestVersion = "";

  // both specifiedVersion and workspaceVersion is empty
  specifiedVersion = "";
  workspaceVersion = "";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "");

  // specifiedVersion not empty and exist installed smartest
  // ignore workspaceVersion and enforcePatchVersion
  specifiedVersion = "8.2.1.0";
  workspaceVersion = "8.2.1.1";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.1.0");

  // specifiedVersion not empty and exist installed smartest
  // ignore workspaceVersion and enforcePatchVersion
  specifiedVersion = "8.2.1.0";
  workspaceVersion = "8.2.1.1";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.1.0");

  // specifiedVersion not empty and exist installed smartest
  // ignore workspaceVersion and enforcePatchVersion
  specifiedVersion = "soc64_8.2.1.0";
  workspaceVersion = "8.2.1.1";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.1.0");

  // specifiedVersion not empty and not exist installed smartest
  // ignore workspaceVersion and enforcePatchVersion
  specifiedVersion = "9.9.9.9";
  workspaceVersion = "8.2.1.1";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_9.9.9.9");
}

// For version was parsed from workspace
TEST_F(TestGetSmarTestVersion, workspaceVersion)
{
  launchedSmarTestVersion = "";
  specifiedVersion = "";

  // specifiedVersion is empty
  // get workspaceVersion from workspace directory
  string workspace = AbstractRecipeTest::testHome + "/testbed/workspaces/ws";
  workspaceVersion = TestCell::getInstance().workspace(workspace).getSmarTestVersion();
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion.find(workspaceVersion) != string::npos);

  // specifiedVersion is empty
  // workspaceVersion not existed in installed smartest version list
  workspaceVersion = "9.9.9.9";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_9.9.9.9");

  // specifiedVersion is empty
  // workspaceVersion not existed in installed smartest version list
  workspaceVersion = "9.9.9.9";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_9.9.9.9");

  // exist installed smartest for workspaceVersion
  workspaceVersion = "8.3.0.0";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.3.0.0_1x1_20190809_1111_C_BETA");

  // exist installed smartest for workspaceVersion
  workspaceVersion = "8.3.0.0";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.3.0.0_1x1_20190809_1111_C_BETA");

  // not exist installed smartest for workspaceVersion
  workspaceVersion = "8.3.0.1";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.3.0.1");

  // exist compatible installed smartest for workspaceVersion
  workspaceVersion = "8.3.0.1";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.3.0.0_1x1_20190809_1111_C_BETA");

  // exist installed smartest for workspaceVersion
  workspaceVersion = "8.2.5.1";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.5.1");

  // exist compatible installed smartest for workspaceVersion
  workspaceVersion = "8.2.5.1";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.5.1");

  // not exist installed smartest for workspaceVersion
  workspaceVersion = "8.2.5.9";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.5.9");

  // not exist compatible installed smartest for workspaceVersion
  workspaceVersion = "8.2.5.9";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.5.9");

  // exist installed smartest for workspaceVersion
  workspaceVersion = "8.2.3.0";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.3.0");

  // exist compatible installed smartest for workspaceVersion
  workspaceVersion = "8.2.3.0";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.3.0");

  // exist installed smartest for workspaceVersion
  // need consider patch version x.x.x
  workspaceVersion = "8.2.3.0.cs.1";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.3.0.cs.1");

  // exist installed smartest for workspaceVersion
  // don't need consider patch version x.x.x
  workspaceVersion = "8.2.3.0.cs.1";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.3.0.cs.1");

  // not exist installed smartest for workspaceVersion
  // need consider patch version x.x.x.x
  workspaceVersion = "8.2.3.9";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.3.9");

  // not exist installed smartest for workspaceVersion
  // don't need consider patch version x.x.x
  workspaceVersion = "8.2.3.9";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.3.0.cs.2");

  // exist installed smartest for workspaceVersion
  // need consider patch version x.x.x.x
  workspaceVersion = "Iworkspacesxxxx";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_Iworkspacesxxxx");

  // exist installed smartest for workspaceVersion
  // don't need consider patch version x.x.x
  workspaceVersion = "Iworkspacesxxxx";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_Iworkspacesxxxx");

  // not exist installed smartest for workspaceVersion
  // need consider patch version x.x.x.x
  workspaceVersion = "GGGG";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_GGGG");

  // not exist installed smartest for workspaceVersion
  // don't need consider patch version x.x.x
  workspaceVersion = "GGGG";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_GGGG");

}

// For version was parsed from workspace and running smartest version
TEST_F(TestGetSmarTestVersion, launchedSmarTestVersion)
{
  // exist launched smartest for specifiedVersion
  specifiedVersion = "8.2.1.0";

  launchedSmarTestVersion = "8.2.1.0.cs.1";
  workspaceVersion = "8.2.1.1";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.1.0");

  // exist launched smartest for workspaceVersion
  specifiedVersion = "";

  // need consider patch version x.x.x
  launchedSmarTestVersion = "8.3.0.0_1x2_20190808_1111_C_BETA";
  workspaceVersion = "8.3.0.0";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.3.0.0_1x2_20190808_1111_C_BETA");

  // need consider patch version x.x.x.x
  launchedSmarTestVersion = "8.2.3.0.cs.1";
  workspaceVersion = "8.2.3.0.cs.2";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.3.0.cs.2");

  // need consider patch version x.x.x.x
  launchedSmarTestVersion = "8.2.3.0.cs.1";
  workspaceVersion = "8.2.3.0";
  enforcePatchVersion = true;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.3.0");

  // don't need consider patch version x.x.x
  launchedSmarTestVersion = "8.2.3.0.cs.1";
  workspaceVersion = "8.2.3.0";
  enforcePatchVersion = false;
  smartestVersion = ::Helper::getSmarTestVersion(specifiedVersion, workspaceVersion, launchedSmarTestVersion, installedVersionList, enforcePatchVersion);
  EXPECT_TRUE(smartestVersion == "soc64_8.2.3.0.cs.1");
}
