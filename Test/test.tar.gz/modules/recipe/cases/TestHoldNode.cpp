/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestHoldNode : public AbstractRecipeTest {
protected:
  static string TEST_HOLD_ELEMENT;
};

string TestHoldNode::TEST_HOLD_ELEMENT = recipesDir + "test_hold_element.xml";

/**
 * Test hold element
 */TEST_F(TestHoldNode, testHoldElement)
{

  RecipeManager &manager = RecipeManager::getInstance();
  Recipe *pExecutor = &manager.newRecipe(TEST_HOLD_ELEMENT);

  RecipeResumeCallback *callback1 = new RecipeResumeCallback(pExecutor);
  RecipeResumeCallback *callback2 = new RecipeResumeCallback(pExecutor);
  RecipeResumeCallback *callback3 = new RecipeResumeCallback(pExecutor);

  // listening the lot hold event
  EventExpector expector4LotHoldStart;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(std::pair<string, string>("HOLD_DETAIL", "PRE_LOT"));
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_STARTED"));
    expector4LotHoldStart.expectEvent(Event::RECIPE, lotLevelStart, 1, callback1);
  }
  // listening the lot hold event
  EventExpector expector4LotHoldEnd;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(std::pair<string, string>("HOLD_DETAIL", "PRE_LOT"));
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_COMPLETED"));
    expector4LotHoldEnd.expectEvent(Event::RECIPE, lotLevelStart, 1);
  }

// listening the lot hold event
  EventExpector expector4SubLotHoldStart;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(
        std::pair<string, string>("HOLD_DETAIL", "PRE_SUBLOT"));
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_STARTED"));
    expector4SubLotHoldStart.expectEvent(Event::RECIPE, lotLevelStart, 2,
        callback2);
  }
  // listening the lot hold event
  EventExpector expector4SubLotHoldEnd;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(
        std::pair<string, string>("HOLD_DETAIL", "PRE_SUBLOT"));
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_COMPLETED"));
    expector4SubLotHoldEnd.expectEvent(Event::RECIPE, lotLevelStart, 2);
  }

  // listening the lot hold event
  EventExpector expector4DeviceHoldStart;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(
        std::pair<string, string>("HOLD_DETAIL", "PRE_DEVICE"));
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_STARTED"));
    expector4DeviceHoldStart.expectEvent(Event::RECIPE, lotLevelStart, 4,
        callback3);
  }
  // listening the lot hold event
  EventExpector expector4DeviceHoldEnd;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(
        std::pair<string, string>("HOLD_DETAIL", "PRE_DEVICE"));
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_COMPLETED"));
    expector4DeviceHoldEnd.expectEvent(Event::RECIPE, lotLevelStart, 4);
  }

  executeRecipeNoException(TEST_HOLD_ELEMENT,pExecutor);

  sleep(10);
  expector4LotHoldStart.done();
  expector4LotHoldEnd.done();
  expector4SubLotHoldStart.done();
  expector4SubLotHoldEnd.done();
  expector4DeviceHoldStart.done();
  expector4DeviceHoldEnd.done();
  delete callback1;
  delete callback2;
  delete callback3;
}
