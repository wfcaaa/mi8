/**
 * Copyright by Advantest, 2020
 *
 * @author  harvey zhang
 * @date    Mar 03, 2020
 */

#include "AbstractRecipeTest.hpp"
class TestRecipeVariable : public AbstractRecipeTest {
protected:
  static string TEST_RECIPE_CONTAINER;
  static string RECIPES_DIR;
};

string TestRecipeVariable::RECIPES_DIR = recipesDir;

string TestRecipeVariable::TEST_RECIPE_CONTAINER = RECIPES_DIR
    + "test_recipe_variable_container.xml";

/**
  * Test recipe variable - container
  */TEST_F(TestRecipeVariable, testRecipeContainer)
 {
    executeRecipeNoException(TEST_RECIPE_CONTAINER);

    string recipeContainer = 
	TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString("recipeContainer").getCommon();

    EXPECT_TRUE(RECIPES_DIR == recipeContainer + "/");
 }

