/**
 * Copyright by Advantest, 2015
 *
 * @author  ivanlv
 * @date    Dec 3, 2015
 */
#include "EventExpector.hpp"
#include "exception_handler.hpp"
#include <pthread.h>
#include <sstream>
#include <unistd.h>
#include "gtest/gtest.h"

EventExpector::EventExpector() :
    eventCount(0)
{
}

EventExpector::~EventExpector()
{
  this->callbacker = NULL;
}

int EventExpector::getEventCount() const
{
  return eventCount;
}

Event::EventType EventExpector::getEventType()
{
  return eventType;
}

map<string, string>& EventExpector::getProperties()
{
  return properties;
}

void EventExpector::setReceiveCount(int cout)
{
  this->receiveCount = cout;
}

void *startListening(void *argument)
{
  try {
    EventExpector *expector = (EventExpector*) argument;
    MyMonitor monitor = MyMonitor(expector);
    expector->monitor = &monitor;
    expector->isStartLisenting = true;
    monitor.start();
  } catch (TCException &exc) {
    cout << "***********EXCEPTION******************" << endl;
    cout << "message: " << exc.message << endl;
    cout << "origin:  " << exc.origin << endl;
    cout << "type:    " << exc.typeString << endl;
    cout << "**************************************" << endl;
  }
}

void EventExpector::expectEvent(Event::EventType eventType,
    map<string, string> properties, int eventCount, Callback* callbacker)
{
  this->eventCount = eventCount;
  this->eventType = eventType;
  this->properties = properties;
  this->callbacker = callbacker;
  pthread_create(&thread1, NULL, startListening, (void*) this);
  while (!isStartLisenting) {
    usleep(500000);
  }
}

Callback* EventExpector::getCallback()
{
  return this->callbacker;
}

inline string printMap(map<string,string> myMap){
  stringstream ss;
  for(map<string, string >::const_iterator it = myMap.begin();
      it != myMap.end(); ++it)
  {
      ss << "(" << it->first << " " << it->second <<") ";
  }
  return ss.str();
}

void EventExpector::done() throw (UnExpectException)
{
  this->monitor->stop();
  this->isStartLisenting = false;
  this->setReceiveCount(monitor->getCount());
  pthread_join (thread1, NULL);
  if (receiveCount != this->eventCount) {
    stringstream ss;
    ss << "Expected event " << printMap(this->properties) <<" count is " << this->eventCount
        << ", receive count is " << receiveCount << endl;
    FAIL() << ss.str();
  }
}
