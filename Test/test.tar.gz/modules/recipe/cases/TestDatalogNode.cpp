/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestDatalogNode : public AbstractRecipeTest {
protected:
  static string TEST_DATALOG_ELEMENT;
  static string TEST_DATALOG_CANT_BE_CREATED;
  static string TEST_DATALOG_ALARM;
  static string TEST_DATALOG_FLUSH;
  static string TEST_DATALOG_IGNORE_KEY_EQUAL_TRUE;
  static string TEST_DATALOG_IGNORE_KEY_EQUAL_FALSE;
  static string TEST_CUSTOMFORMATTER_NOT_SUPPORT_PERTYPE_CONFIGURATION;
  static string TEST_SUMMARY_NOT_SUPPORT_PERTYPE_CONFIGURATION;
  static string TEST_CUSTOMFORMATTER_NOT_SUPPORT_PERFILE_CONFIGURATION;
};

string TestDatalogNode::TEST_DATALOG_ELEMENT = recipesDir
    + "test_datalog_element.xml";
string TestDatalogNode::TEST_DATALOG_CANT_BE_CREATED = recipesDir
    + "test_datalog_cant_be_created.xml";
string TestDatalogNode::TEST_DATALOG_ALARM = recipesDir
    + "test_datalog_alarm.xml";
string TestDatalogNode::TEST_DATALOG_FLUSH = recipesDir
    + "test_datalog_flush.xml";
string TestDatalogNode::TEST_DATALOG_IGNORE_KEY_EQUAL_TRUE = recipesDir
    + "test_data_ignore_keyEqualToTrue.xml";
string TestDatalogNode::TEST_DATALOG_IGNORE_KEY_EQUAL_FALSE = recipesDir
    + "test_data_ignore_keyEqualToFalse.xml";

string TestDatalogNode::TEST_CUSTOMFORMATTER_NOT_SUPPORT_PERTYPE_CONFIGURATION = recipesDir
    + "test_customformatter_not_support_pertype_configuration.xml";

string TestDatalogNode::TEST_SUMMARY_NOT_SUPPORT_PERTYPE_CONFIGURATION = recipesDir
    + "test_summary_not_support_pertype_configuration.xml";


string TestDatalogNode::TEST_CUSTOMFORMATTER_NOT_SUPPORT_PERFILE_CONFIGURATION = recipesDir
    + "test_customformatter_not_support_perfile_configuration.xml";


TEST_F(TestDatalogNode, testDatalogElement)
{
  executeRecipeNoException(TEST_DATALOG_ELEMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "datalogPath").getCommon();
  EXPECT_TRUE(!value.empty());
  string txt = value + ".txt";
  string edl = value + ".edl";
  string stdf = value + ".stdf";
  string custom = value + ".cus";
  ifstream fileTxt(txt.c_str(), std::ifstream::ate | std::ifstream::binary);
  ifstream fileEdl(edl.c_str(), std::ifstream::ate | std::ifstream::binary);
  ifstream fileStdf(stdf.c_str(), std::ifstream::ate | std::ifstream::binary);
  ifstream fileCustom(custom.c_str(),
      std::ifstream::ate | std::ifstream::binary);

  EXPECT_TRUE(fileTxt.tellg() > 0);
  EXPECT_TRUE(fileEdl.tellg() > 0);
  EXPECT_TRUE(fileStdf.tellg() > 0);
  EXPECT_TRUE(fileCustom.tellg() > 0);
}



TEST_F(TestDatalogNode, testDatalogCantBeCreatedElement)
{
  EXPECT_THROW(executeRecipe(TEST_DATALOG_CANT_BE_CREATED), TCException);
}


void checkDatalog(){
  string value =
       TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
           "datalogPath").getCommon();
   EXPECT_TRUE(!value.empty());
   string txt = value + ".txt";
   ifstream fileTxt;
   fileTxt.open(txt.c_str());
   string last;
   while (!fileTxt.eof()) {
     string line;
     //read data from file
     std::getline(fileTxt, line);

     size_t index = line.find_first_not_of(' ');
     if (index == 0) {
       last = line;
     }
   }
   fileTxt.close();
   std::cout << last << std::endl;
   string target = "Device PartID: \"50 ";
   EXPECT_TRUE(last.find(target) >= 0);
}


class MyCallback : public Callback {
public:
  MyCallback(Recipe* recipe)
  {
    pRecipe = recipe;
  }
  ~MyCallback()
  {
  }
  void run()
  {
    if (pRecipe != NULL)
      checkDatalog();
      pRecipe->resume();
   }
private:
  Recipe* pRecipe;
};

TEST_F(TestDatalogNode, testDatalogFlush)
{

  RecipeManager &manager = RecipeManager::getInstance();
  Recipe *pExecutor = &manager.newRecipe(TEST_DATALOG_FLUSH);
  // listening the lot hold event
  MyCallback *callback1 = new MyCallback(pExecutor);

  // listening the lot hold event
  EventExpector expector4LotHoldStart;
  {
    map<string, string> recipeHold;
    recipeHold.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_STARTED"));
    expector4LotHoldStart.expectEvent(Event::RECIPE, recipeHold, 1, callback1);
  }
  executeRecipeNoException(TEST_DATALOG_FLUSH, pExecutor);

  sleep(10);

  expector4LotHoldStart.done();

  delete callback1;
}

//execute a recipe which "ignoreNotSupportedConfiguration" = true
TEST_F(TestDatalogNode, testDatalogIgnoreNotSupportKeyFeature_keyEqualToTrue)
{
    executeRecipe(TEST_DATALOG_IGNORE_KEY_EQUAL_TRUE);
}

//execute a recipe which "ignoreNotSupportedConfiguration" = false
TEST_F(TestDatalogNode, testDatalogIgnoreNotSupportKeyFeature_keyEqualToFalse)
{
  string exceptionMessage;
  try
  {
     executeRecipe(TEST_DATALOG_IGNORE_KEY_EQUAL_FALSE);
  }
  catch(TCException& exc)
  {
    exceptionMessage = exc.message;
  }
  ASSERT_EQ(exceptionMessage,"The datalog config item \"testInopen\" is not supported!");
}

TEST_F(TestDatalogNode, testDatalogCustomFormatterNotSupportPerTypeConfiguration)
{
  EXPECT_THROW(executeRecipe(TEST_CUSTOMFORMATTER_NOT_SUPPORT_PERTYPE_CONFIGURATION), TCException);
}

TEST_F(TestDatalogNode, testDatalogSummaryNotSupportPerTypeConfiguration)
{
  EXPECT_THROW(executeRecipe(TEST_SUMMARY_NOT_SUPPORT_PERTYPE_CONFIGURATION), TCException);
}

TEST_F(TestDatalogNode, testDatalogCustomFormatterPerFileConfiguration)
{
  EXPECT_THROW(executeRecipe(TEST_CUSTOMFORMATTER_NOT_SUPPORT_PERFILE_CONFIGURATION), TCException);
}



