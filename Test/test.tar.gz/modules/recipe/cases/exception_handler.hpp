#ifndef TESTCELL_INTEGRATION_TEST_EXCEPTION_HANDLING_HPP
#define TESTCELL_INTEGRATION_TEST_EXCEPTION_HANDLING_HPP

#define TRY_BEGIN try \
                  {
#define TRY_END_FAIL }\
                     catch (TCException &exc) \
                     {\
                        cout << "***********EXCEPTION******************" << endl; \
                        cout << "message: " << exc.message << endl; \
                        cout << "origin:  " << exc.origin << endl; \
                        cout << "type:    " << exc.typeString << endl; \
                        cout << "**************************************" << endl; \
                        throw exc; \
                     }\

#endif
