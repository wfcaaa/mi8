/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestRecipeValidation : public AbstractRecipeTest {
protected:
  static string TEST_VARIABLES_ASSIGNMENT_VALIDATION_NAME_IS_EMPTY;
  static string TEST_VARIABLES_ASSIGNMENT_VALIDATION_NAME_IS_PRESERVED;
  static string TEST_RECIPE_DATALOG_VALIDATION_CONFIGURATION;
  static string TEST_RECIPE_DATALOG_VALIDATION_CONFIGURATION_NOPATH;
  static string TEST_RECIPE_DATALOG_VALIDATION_CONFIGURATION_NOPATH2;
  static string TEST_RECIPE_DATALOG_VALIDATION_CUSTOM_FORMATTER_LIBRARY_PATH;
  static string TEST_RECIPE_DATALOG_VALIDATION_OVERWRITE;
  static string TEST_RECIPE_EQUIPMENT_VALIDATION_STARTPH;
  static string TEST_RECIPE_EQUIPMENT_VALIDATION_1_INPUTPAR;
  static string TEST_RECIPE_EQUIPMENT_VALIDATION_1_INPUTPAR2;
  static string TEST_RECIPE_EQUIPMENT_VALIDATION_2_INPUTPAR;
  static string TEST_RECIPE_EQUIPMENT_VALIDATION_2_INPUTPAR2;
  static string TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_EMPTY;
  static string TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_VALID;
  static string TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_EXECUTABLE;
  static string TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_EXECUTABLE2;
  static string TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_WITH_SPACE;
  static string TEST_RECIPE_VALIDATION_EXPRESSION_LEFTVALUE_CANNOT_BE_EMPTY;
  static string TEST_RECIPE_VALIDATION_EXPRESSION_RIGHTVALUE_CANNOT_BE_EMPTY;
  static string TEST_RECIPE_VALIDATION_EXPRESSION_RIGHTVALUE_VALUE_CANNOT_BE_EMPTY2;
  static string TEST_RECIPE_VALIDATION_EXPRESSION_RIGHTVALUE_SHOULD_NOT_PRESENT;
  static string TEST_RECIPE_VALIDATION_LEVEL_NAME_CANNOT_BE_EMPTY;
  static string TEST_RECIPE_VALIDATION_LIBRARY_PATH_CANNOT_REPEAT;
  static string TEST_RECIPE_VALIDATION_LIBRARY_NAME_CANNOT_REPEAT;
  static string TEST_RECIPE_VALIDATION_LIBRARY_CALL_BE_LEGAL;
  static string TEST_RECIPE_VALIDATION_LIBRARY_FILE_MUST_EXIST;
  static string TEST_RECIPE_VALIDATION_OUT_CANNOT_BE_EMPTY;
  static string TEST_RECIPE_VALIDATION_OUT_CANNOT_BE_PRESERVED;
  static string TEST_RECIPE_VALIDATION_RULES_HARDBIN_SOFTBIN_EXCLUSIVE;
  static string TEST_RECIPE_VALIDATION_RULES_NEITHER_CONSECUTIVECOUNT_NOR_OVERALLCOUNT_SPECIFIED;
  static string TEST_RECIPE_VALIDATION_RULES_NEITHER_HARDBIN_NOR_SOFTBIN_SPECIFIED;
  static string TEST_RECIPE_VALIDATION_SMARTEST_ONLY_HAS_ONE_MODEL_ELEMENT;
  static string TEST_RECIPE_VALIDATION_SMARTEST__MODEL_FILE_INVALID;
  static string TEST_RECIPE_VALIDATION_SMARTEST_NO_INCREMENT_ELEMENT;
  static string TEST_RECIPE_VALIDATION_SMARTEST_ONLY_ENV_ASSIGNMENT_ALLOWED;
  static string TEST_RECIPE_VALIDATION_TESTPROGRAM_NAME_CANNOT_BE_EMPTY;
  static string TEST_RECIPE_VALIDATION_TESTPROGRAM_WORKSPACE_NAME_CANNOT_BE_EMPTY;
  static string TEST_RECIPE_VALIDATION_TESTPROGRAM_MUST_SPECIFY_THE_LOTTYPE;
  static string TEST_RECIPE_VALIDATION_TESTPROGRAM_ENABLE_MAINTENANCE_CHECK;
  static string TEST_RECIPE_VALIDATION_TESTPROGRAM_NAME_CANNOT_BE_SPECIFIED_IN_LOAD;
  static string TEST_RECIPE_VALIDATION_TESTFLOW_NAME_MUST_BE_EMPTY;
  static string TEST_RECIPE_VALIDATION_TESTFLOW_NAME_MUST_BE_SPECIFIED;
  static string TEST_RECIPE_VALIDATION_TESTFLOW_SITES_ARE_NOT_LEGAL;
  static string TEST_RECIPE_VALIDATION_TESTFLOW_SITES_ARE_NOT_LEGAL2;
  static string TEST_RECIPE_VALIDATION_TESTFLOW_SITES_ARE_NOT_LEGAL3;
  static string TEST_RECIPE_VALIDATION_TESTFLOW_INPUT_PARAMATER;
  static string TEST_RECIPE_VALIDATION_TESTFLOW_OUTPUT_PARAMATER;
  static string TEST_RECIPE_VALIDATION_VARIABLE;
  static string TEST_RECIPE_VALIDATION_ON_ALARM;
  static string TEST_RECIPE_VALIDATION_SUBRECIPE_ILLEGAL;
};

string TestRecipeValidation::TEST_VARIABLES_ASSIGNMENT_VALIDATION_NAME_IS_EMPTY =
    recipesDir + "test_recipe_assignment_validation_name_is_empty.xml";

string TestRecipeValidation::TEST_VARIABLES_ASSIGNMENT_VALIDATION_NAME_IS_PRESERVED =
    recipesDir + "test_recipe_assignment_validation_name_is_preserved.xml";

string TestRecipeValidation::TEST_RECIPE_DATALOG_VALIDATION_CONFIGURATION =
    recipesDir + "test_recipe_datalog_validation_configuration.xml";

string TestRecipeValidation::TEST_RECIPE_DATALOG_VALIDATION_CONFIGURATION_NOPATH =
    recipesDir + "test_recipe_datalog_validation_configuration_nopath.xml";

string TestRecipeValidation::TEST_RECIPE_DATALOG_VALIDATION_CONFIGURATION_NOPATH2 =
    recipesDir + "test_recipe_datalog_validation_configuration_nopath2.xml";

string TestRecipeValidation::TEST_RECIPE_DATALOG_VALIDATION_CUSTOM_FORMATTER_LIBRARY_PATH =
    recipesDir
        + "test_recipe_datalog_validation_custom_formatter_library_path.xml";

string TestRecipeValidation::TEST_RECIPE_DATALOG_VALIDATION_OVERWRITE =
    recipesDir + "test_recipe_datalog_validation_overwrite.xml";

string TestRecipeValidation::TEST_RECIPE_EQUIPMENT_VALIDATION_STARTPH =
    recipesDir + "test_recipe_equipment_validation_startph.xml";

string TestRecipeValidation::TEST_RECIPE_EQUIPMENT_VALIDATION_1_INPUTPAR =
    recipesDir + "test_recipe_equipment_validation_1_inputpar.xml";

string TestRecipeValidation::TEST_RECIPE_EQUIPMENT_VALIDATION_1_INPUTPAR2 =
    recipesDir + "test_recipe_equipment_validation_1_inputpar2.xml";

string TestRecipeValidation::TEST_RECIPE_EQUIPMENT_VALIDATION_2_INPUTPAR =
    recipesDir + "test_recipe_equipment_validation_2_inputpar.xml";

string TestRecipeValidation::TEST_RECIPE_EQUIPMENT_VALIDATION_2_INPUTPAR2 =
    recipesDir + "test_recipe_equipment_validation_2_inputpar2.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_EMPTY =
    recipesDir + "test_recipe_validation_executable_cmd_not_empty.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_VALID =
    recipesDir + "test_recipe_validation_executable_cmd_not_valid.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_EXECUTABLE =
    recipesDir + "test_recipe_validation_executable_cmd_not_executable.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_EXECUTABLE2 =
    recipesDir + "test_recipe_validation_executable_cmd_not_executable2.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_WITH_SPACE =
    recipesDir + "test_recipe_validation_executable_cmd_with_space.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_EXPRESSION_LEFTVALUE_CANNOT_BE_EMPTY =
    recipesDir + "test_recipe_validation_expression_leftvalue_cannot_be_empty.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_EXPRESSION_RIGHTVALUE_CANNOT_BE_EMPTY =
    recipesDir + "test_recipe_validation_expression_rightvalue_cannot_be_empty.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_EXPRESSION_RIGHTVALUE_SHOULD_NOT_PRESENT =
    recipesDir + "test_recipe_validation_expression_rightvalue_should_not_present.xml";


string TestRecipeValidation::TEST_RECIPE_VALIDATION_EXPRESSION_RIGHTVALUE_VALUE_CANNOT_BE_EMPTY2 =
    recipesDir + "test_recipe_validation_expression_rightvalue_value_cannot_be_empty2.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_LEVEL_NAME_CANNOT_BE_EMPTY =
    recipesDir + "test_recipe_validation_level_name_cannot_be_empty.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_LIBRARY_NAME_CANNOT_REPEAT =
    recipesDir + "test_recipe_validation_library_name_cannot_repeat.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_LIBRARY_PATH_CANNOT_REPEAT =
    recipesDir + "test_recipe_validation_library_path_cannot_repeat.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_LIBRARY_CALL_BE_LEGAL =
    recipesDir + "test_recipe_validation_library_call_be_legal.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_LIBRARY_FILE_MUST_EXIST =
    recipesDir + "test_recipe_validation_library_file_must_exist.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_OUT_CANNOT_BE_EMPTY =
    recipesDir + "test_recipe_validation_out_cannot_be_empty.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_OUT_CANNOT_BE_PRESERVED =
    recipesDir + "test_recipe_validation_out_cannot_be_preserved.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_RULES_HARDBIN_SOFTBIN_EXCLUSIVE =
    recipesDir + "test_recipe_validation_rules_hardbin_softbin_exclusive.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_RULES_NEITHER_CONSECUTIVECOUNT_NOR_OVERALLCOUNT_SPECIFIED =
    recipesDir + "test_recipe_validation_rules_neither_consecutivecount_nor_overallcount_specified.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_RULES_NEITHER_HARDBIN_NOR_SOFTBIN_SPECIFIED =
    recipesDir + "test_recipe_validation_rules_neither_hardbin_nor_softbin_specified.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_SMARTEST_ONLY_HAS_ONE_MODEL_ELEMENT =
    recipesDir + "test_recipe_validation_smartest_only_has_one_model_element.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_SMARTEST__MODEL_FILE_INVALID =
    recipesDir + "test_recipe_validation_smartest__model_file_invalid.xml";


string TestRecipeValidation::TEST_RECIPE_VALIDATION_SMARTEST_NO_INCREMENT_ELEMENT =
    recipesDir + "test_recipe_validation_smartest_no_increment_element.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_SMARTEST_ONLY_ENV_ASSIGNMENT_ALLOWED =
    recipesDir + "test_recipe_validation_smartest_only_env_assignment_allowed.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTPROGRAM_NAME_CANNOT_BE_EMPTY =
    recipesDir + "test_recipe_validation_testprogram_name_cannot_be_empty.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTPROGRAM_WORKSPACE_NAME_CANNOT_BE_EMPTY =
    recipesDir + "test_recipe_validation_testprogram_workspace_name_cannot_be_empty.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTPROGRAM_MUST_SPECIFY_THE_LOTTYPE =
    recipesDir + "test_recipe_validation_testprogram_must_specify_the_lottype.xml";


string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTPROGRAM_ENABLE_MAINTENANCE_CHECK =
    recipesDir + "test_recipe_validation_testprogram_enable_maintenance_check.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTPROGRAM_NAME_CANNOT_BE_SPECIFIED_IN_LOAD =
    recipesDir + "test_recipe_validation_testprogram_name_cannot_be_specified_in_load.xml";


string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTFLOW_NAME_MUST_BE_EMPTY =
    recipesDir + "test_recipe_validation_testflow_name_must_be_empty.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTFLOW_NAME_MUST_BE_SPECIFIED =
    recipesDir + "test_recipe_validation_testflow_name_must_be_specified.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTFLOW_SITES_ARE_NOT_LEGAL =
    recipesDir + "test_recipe_validation_testflow_sites_are_not_legal.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTFLOW_SITES_ARE_NOT_LEGAL2 =
    recipesDir + "test_recipe_validation_testflow_sites_are_not_legal2.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTFLOW_SITES_ARE_NOT_LEGAL3 =
    recipesDir + "test_recipe_validation_testflow_sites_are_not_legal3.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTFLOW_INPUT_PARAMATER =
    recipesDir + "test_recipe_validation_testflow_input_paramater.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_TESTFLOW_OUTPUT_PARAMATER =
    recipesDir + "test_recipe_validation_testflow_output_paramater.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_VARIABLE =
    recipesDir + "test_recipe_validation_variable.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_ON_ALARM =
    recipesDir + "test_recipe_validation_on_alarm.xml";

string TestRecipeValidation::TEST_RECIPE_VALIDATION_SUBRECIPE_ILLEGAL =
    recipesDir + "test_recipe_validation_subrecipe_illegal.xml";


TEST_F(TestRecipeValidation, validateAssignment)
{
  //Validate the variable name cannot be empty
  EXPECT_THROW(executeRecipe(TEST_VARIABLES_ASSIGNMENT_VALIDATION_NAME_IS_EMPTY), TCException);
  //Validate the variable name cannot be preserved
  EXPECT_THROW(executeRecipe(TEST_VARIABLES_ASSIGNMENT_VALIDATION_NAME_IS_PRESERVED), TCException);
}

TEST_F(TestRecipeValidation, validateDatalog)
{
  //Validate there must be a configuration item when it is per-type configuration
  EXPECT_THROW(executeRecipe(TEST_RECIPE_DATALOG_VALIDATION_CONFIGURATION), TCException);
  //Validate the path must not be specified when it is per-type configuration
  EXPECT_THROW(executeRecipe(TEST_RECIPE_DATALOG_VALIDATION_CONFIGURATION_NOPATH), TCException);
  //Validate the path must be specified when opening a data log file
  EXPECT_THROW(executeRecipe(TEST_RECIPE_DATALOG_VALIDATION_CONFIGURATION_NOPATH2), TCException);
  //Validate the library path must be specified when opening a custom formatter
  EXPECT_THROW(executeRecipe(TEST_RECIPE_DATALOG_VALIDATION_CUSTOM_FORMATTER_LIBRARY_PATH), TCException);
  //Validate the overwrite attribute can only be specified when opening a log file
  EXPECT_THROW(executeRecipe(TEST_RECIPE_DATALOG_VALIDATION_OVERWRITE), TCException);
}

TEST_F(TestRecipeValidation, validateEquipment) {
  //Validate there must be three input parameters for "START_PHCONTROL"
  EXPECT_THROW(executeRecipe(TEST_RECIPE_EQUIPMENT_VALIDATION_STARTPH), TCException);
  //Validate the input parameter number must be only one
  EXPECT_THROW(executeRecipe(TEST_RECIPE_EQUIPMENT_VALIDATION_1_INPUTPAR), TCException);
  //Validate the input parameter number must be only one
  EXPECT_THROW(executeRecipe(TEST_RECIPE_EQUIPMENT_VALIDATION_1_INPUTPAR2), TCException);
  //Validate the input parameter number must be two input parameters
  EXPECT_THROW(executeRecipe(TEST_RECIPE_EQUIPMENT_VALIDATION_2_INPUTPAR), TCException);
  //Validate the input parameter number must be two no empty input parameters
  EXPECT_THROW(executeRecipe(TEST_RECIPE_EQUIPMENT_VALIDATION_2_INPUTPAR2), TCException);
}

TEST_F(TestRecipeValidation, validateExecutable) {
  //Validate the command cannot be empty
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_EMPTY), TCException);
  //Validate the command is not valid
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_VALID), TCException);
  //Validate the command cannot be executed
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_EXECUTABLE), TCException);
  //Validate the command cannot be executed
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_NOT_EXECUTABLE2), TCException);
  // Validate the command with parameter
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_EXECUTABLE_CMD_WITH_SPACE), TCException);
}


TEST_F(TestRecipeValidation, validateExpression) {
  //Validate the left value of the expression cannot be empty
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_EXPRESSION_LEFTVALUE_CANNOT_BE_EMPTY), TCException);
  //Validate the right  value of the expression cannot be empty
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_EXPRESSION_RIGHTVALUE_CANNOT_BE_EMPTY), TCException);
  //Validate the value of the RightValue cannot be empty
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_EXPRESSION_RIGHTVALUE_VALUE_CANNOT_BE_EMPTY2), TCException);
  //Validate the right value should not present with some operator
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_EXPRESSION_RIGHTVALUE_SHOULD_NOT_PRESENT), TCException);
}

TEST_F(TestRecipeValidation, validateLevel) {
  //Validate the left value of the expression cannot be empty
   EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_LEVEL_NAME_CANNOT_BE_EMPTY), TCException);
}

TEST_F(TestRecipeValidation, validateLibraryCall) {
  //Validate the library name cannot be repeated
   EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_LIBRARY_NAME_CANNOT_REPEAT), TCException);
   //Validate the library path cannot be repeated
   EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_LIBRARY_PATH_CANNOT_REPEAT), TCException);
   //Validate the library call must be legal
   EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_LIBRARY_CALL_BE_LEGAL), TCException);
   //Validate the library must exist
   EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_LIBRARY_FILE_MUST_EXIST), TCException);
}

TEST_F(TestRecipeValidation, validateOut) {
  //Validate the Out element value cannot be empty
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_OUT_CANNOT_BE_EMPTY), TCException);
  //Validate the Out element value cannot be preserved
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_OUT_CANNOT_BE_PRESERVED), TCException);
}

TEST_F(TestRecipeValidation, validateRule) {
  //Validate the softbin and hardbin should be exclusive
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_RULES_HARDBIN_SOFTBIN_EXCLUSIVE), TCException);
  //Validate the consectivecount or the overallcount should be specified
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_RULES_NEITHER_CONSECUTIVECOUNT_NOR_OVERALLCOUNT_SPECIFIED), TCException);
  //Validate the softbin or the hardbin should be specified
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_RULES_NEITHER_HARDBIN_NOR_SOFTBIN_SPECIFIED), TCException);

}

TEST_F(TestRecipeValidation, validateSmarTestElement) {
  //Validate the mode element cannot repeat
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_SMARTEST_ONLY_HAS_ONE_MODEL_ELEMENT), TCException);
  //Validate the mode file must be valid
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_SMARTEST__MODEL_FILE_INVALID), TCException);
  //Validate no increment element
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_SMARTEST_NO_INCREMENT_ELEMENT), TCException);
  //Validate only ENV variables can be set in SmarTest element
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_SMARTEST_ONLY_ENV_ASSIGNMENT_ALLOWED), TCException);
}

TEST_F(TestRecipeValidation, validateTestProgram) {
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTPROGRAM_NAME_CANNOT_BE_EMPTY), TCException);
  //Validate the workspace name cannot be empty
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTPROGRAM_WORKSPACE_NAME_CANNOT_BE_EMPTY), TCException);
  //Validate the test program must be specified the lotType
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTPROGRAM_MUST_SPECIFY_THE_LOTTYPE), TCException);
  // The "enableMaintenanceCheck" can only be specified when the action is "LOAD" or "RUN"
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTPROGRAM_ENABLE_MAINTENANCE_CHECK), TCException);
  // The "name" can only be specified when the action is "ACTIVATE" or "RUN"
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTPROGRAM_NAME_CANNOT_BE_SPECIFIED_IN_LOAD), TCException);
}

TEST_F(TestRecipeValidation, validateTestflow) {
  //ExecuteMain does not need specify the name
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTFLOW_NAME_MUST_BE_EMPTY), TCException);
  //Validate sub need specify the name
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTFLOW_NAME_MUST_BE_SPECIFIED), TCException);
  //Validate the site specified is illegal
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTFLOW_SITES_ARE_NOT_LEGAL), TCException);
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTFLOW_SITES_ARE_NOT_LEGAL2), TCException);
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTFLOW_SITES_ARE_NOT_LEGAL3), TCException);

  //Validate the input parameter must specify parameter name
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTFLOW_INPUT_PARAMATER), TCException);
  //Validate the out parameter must specify parameter name
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_TESTFLOW_OUTPUT_PARAMATER), TCException);
}


TEST_F(TestRecipeValidation, validateVaraible) {
  //Validate the name cannot contain $
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_VARIABLE), TCException);
}

TEST_F(TestRecipeValidation, validateAlaram) {
  //Fatal alarm must exit recipe
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_ON_ALARM), TCException);
}

TEST_F(TestRecipeValidation, validateSubRecipe) {
  //Fatal alarm must exit recipe
  EXPECT_THROW(executeRecipe(TEST_RECIPE_VALIDATION_SUBRECIPE_ILLEGAL), TCException);
}
