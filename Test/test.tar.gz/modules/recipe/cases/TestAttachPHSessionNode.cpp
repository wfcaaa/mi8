#include "AbstractRecipeTest.hpp"

int executeCustomCommand(const string & command);
string& trim(string &s);

class TestAttachPHSessionNode : public AbstractRecipeTest {
protected:
  static string RECIPE_PATH;
  static string DRIVER_PATH;
  static string CONFIG_PATH;
};

// init recipe path
string TestAttachPHSessionNode::RECIPE_PATH = recipesDir + "test_attachPHSession.xml";
string TestAttachPHSessionNode::DRIVER_PATH=recipesDir+"../drivers/Multitest";
string TestAttachPHSessionNode::CONFIG_PATH=recipesDir+"../drivers/Multitest/config/MT9308-GPIB-4.cfg";


 TEST_F(TestAttachPHSessionNode , testRecipeForAttachPHSession)
{


  cout << " recipePath: " << RECIPE_PATH <<endl;

  TRY_BEGIN
    // Get the RecipeManager instance
    RecipeManager &manager = RecipeManager::getInstance();
    // Create a new Recipe instance
    Recipe &recipe = manager.newRecipe(RECIPE_PATH);
    
    cout << "Start to get TestCell instance "<< endl;
    TestCell& testCell = TestCell::getInstance();

    cout << "Start to create new PHSession "<< endl;
    // Start the PHControl session and connect the equipment
    PHSession &phSession = testCell.newPHSession();
    phSession.setDriverPath(DRIVER_PATH)
    .setConfigPath(CONFIG_PATH).start().connect();
    //Attach to a running PHSession
    recipe.attachToPHSession(phSession);
    cout << "AttachToPHSession complete "<< std::endl;
    PHSession &aSession = recipe.getAttachedPHSession();
    EXPECT_EQ(aSession.getSessionId(), phSession.getSessionId());
    // Start the recipe execution
    cout << "Recipe execute start "<< endl;
    recipe.start();
    
    while(recipe.getState()!= Recipe::UNDEFINED){
    
     cout<< "Recipe State: " <<recipe.getState() <<endl; 
    }
    cout<< "Recipe executing over state: " <<recipe.getState() <<endl;
    cout << "Start to stop PHSession "<< endl;
    phSession.stop();
    cout << "End stopping PHSession "<< endl;
  TRY_END_FAIL

  cout << "Recipe execute end "<< endl;

}




