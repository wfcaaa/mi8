/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestSubRecipeNode : public AbstractRecipeTest {
protected:
  static string TEST_SUBRECIPE_ELEMENT;
  static string TEST_SUBRECIPE_ELEMENT_INEXIST;
  static string TEST_SUBRECIPE_PATH_DYNAMIC;
  static string TEST_SUBRECIPE_VALIDATION_FAIL;
};


string TestSubRecipeNode::TEST_SUBRECIPE_ELEMENT = recipesDir
    + "test_subrecipe_element.xml";

string TestSubRecipeNode::TEST_SUBRECIPE_ELEMENT_INEXIST = recipesDir
    + "test_subrecipe_element_inexist.xml";

string TestSubRecipeNode::TEST_SUBRECIPE_PATH_DYNAMIC = recipesDir
    + "test_subrecipe_path_dynamic.xml";

string TestSubRecipeNode::TEST_SUBRECIPE_VALIDATION_FAIL = recipesDir
    + "test_subrecipe_validation_fail.xml";


TEST_F(TestSubRecipeNode, testSubRecipeElement)
{
  RecipeManager &manager = RecipeManager::getInstance();
   Recipe *pExecutor = &manager.newRecipe(TEST_SUBRECIPE_ELEMENT);
  RecipeResumeCallback *callback1 = new RecipeResumeCallback(pExecutor);
  // listening the lot hold event
  EventExpector expector4LotHoldStart;
  {
    map<string, string> lotLevelStart;
    lotLevelStart.insert(std::pair<string, string>("HOLD_DETAIL", "PRE_LOT"));
    lotLevelStart.insert(
        std::pair<string, string>("EXECUTION_STATE", "RECIPE_HOLD_STARTED"));
    expector4LotHoldStart.expectEvent(Event::RECIPE, lotLevelStart, 1, callback1);
  }
  executeRecipeNoException(TEST_SUBRECIPE_ELEMENT,pExecutor);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "levelCount").getCommon();
  // check 8 levels have been executed
  EXPECT_TRUE(value == "8");
  sleep(10);
  expector4LotHoldStart.done();
  delete callback1;
}

TEST_F(TestSubRecipeNode, testSubRecipeElementinexist)
{
  EXPECT_THROW(executeRecipe(TEST_SUBRECIPE_ELEMENT_INEXIST), TCException);
}

TEST_F(TestSubRecipeNode, testRecipePathDynamic)
{
  EXPECT_THROW(executeRecipe(TEST_SUBRECIPE_PATH_DYNAMIC), TCException);
}

TEST_F(TestSubRecipeNode, testValidationFail)
{
  EXPECT_THROW(executeRecipe(TEST_SUBRECIPE_VALIDATION_FAIL), TCException);
}
