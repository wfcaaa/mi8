/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestLevelNode : public AbstractRecipeTest {
protected:
  static string TEST_LEVEL_ELEMENT;
  static string TEST_EXECUTE_TESTFLOW_IN_LEVEL_ELEMENT;
  static string TEST_LEVEL_COUNT_ILLEGAL;
  static string TEST_LEVEL_COUNT_ILLEGAL2;
};

string TestLevelNode::TEST_LEVEL_ELEMENT = recipesDir
    + "test_level_element.xml";
string TestLevelNode::TEST_LEVEL_COUNT_ILLEGAL = recipesDir
    + "test_level_element2.xml";

string TestLevelNode::TEST_LEVEL_COUNT_ILLEGAL2 = recipesDir
    + "test_level_element3.xml";

string TestLevelNode::TEST_EXECUTE_TESTFLOW_IN_LEVEL_ELEMENT = recipesDir
    + "test_level_execute_testflow_element.xml";

/**
 * The the level element, check the level start and leven completed event
 */TEST_F(TestLevelNode, testLevelElement)
{
  // listening the lot level event
  EventExpector expector4LotStart;
  map<string, string> lotLevelStart;
  lotLevelStart.insert(std::pair<string, string>("LEVEL_NAME", "LOT"));
  lotLevelStart.insert(
      std::pair<string, string>("EXECUTION_STATE", "LEVEL_STARTED"));
  expector4LotStart.expectEvent(Event::RECIPE, lotLevelStart, 2);

  // listening the lot completed event
  EventExpector expector4LotEnd;
  map<string, string> lotLevelEnd;
  lotLevelEnd.insert(std::pair<string, string>("LEVEL_NAME", "LOT"));
  lotLevelEnd.insert(
      std::pair<string, string>("EXECUTION_STATE", "LEVEL_COMPLETED"));
  expector4LotEnd.expectEvent(Event::RECIPE, lotLevelEnd, 2);

  // listening the device level event
  EventExpector expector4DeviceStart;
  map<string, string> deviceLevelStart;
  deviceLevelStart.insert(std::pair<string, string>("LEVEL_NAME", "DEVICE"));
  deviceLevelStart.insert(
      std::pair<string, string>("EXECUTION_STATE", "LEVEL_STARTED"));
  expector4DeviceStart.expectEvent(Event::RECIPE, deviceLevelStart, 8);

  // listening the device level event
  EventExpector expector4DeviceEnd;
  map<string, string> deviceLevelEnd;
  deviceLevelEnd.insert(std::pair<string, string>("LEVEL_NAME", "DEVICE"));
  deviceLevelEnd.insert(
      std::pair<string, string>("EXECUTION_STATE", "LEVEL_COMPLETED"));
  expector4DeviceEnd.expectEvent(Event::RECIPE, deviceLevelEnd, 8);

  //execute the recipe
  executeRecipeNoException(TEST_LEVEL_ELEMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "levelCount").getCommon();
  // check 8 levels have been executed
  EXPECT_TRUE(value == "8");

// check event
  sleep(10);
  expector4LotStart.done();
  expector4LotEnd.done();
  expector4DeviceStart.done();
  expector4DeviceEnd.done();
}

/**
 * test execute main flow and subflow in recipe level element
 */TEST_F(TestLevelNode, testExecuteTestflowInLevelElement)
{
   executeRecipeNoException(TEST_EXECUTE_TESTFLOW_IN_LEVEL_ELEMENT);
  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");
  EXPECT_TRUE(partID.get(1) == "15");
  EXPECT_TRUE(partID.get(2) == "16");
}
/**
 */
 TEST_F(TestLevelNode, testLevelCountIllegal) {
   //Test level count illegal
   EXPECT_THROW(executeRecipe(TEST_LEVEL_COUNT_ILLEGAL), TCException);
   EXPECT_THROW(executeRecipe(TEST_LEVEL_COUNT_ILLEGAL2), TCException);
 }
