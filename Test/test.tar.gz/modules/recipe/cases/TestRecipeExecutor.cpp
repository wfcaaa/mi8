/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#include "AbstractRecipeTest.hpp"
class TestRecipeExecutor : public AbstractRecipeTest {
protected:

  static string TEST_RECIPE_PH_DRIVERTYPE;
  static string TEST_RECIPE_PH_DRIVERFOLDER1;
  static string TEST_RECIPE_PH_DRIVERFOLDER2;
  static string TEST_RECIPE_PH_DRIVERCONFIG;

  static string TEST_RECIPE_PH_WAFER1;
  static string TEST_RECIPE_PH_WAFER2;
};

string TestRecipeExecutor::TEST_RECIPE_PH_DRIVERTYPE = recipesDir
    + "test_recipe_drivertype.xml";

string TestRecipeExecutor::TEST_RECIPE_PH_DRIVERFOLDER1 = recipesDir
    + "test_recipe_driverfolder1.xml";

string TestRecipeExecutor::TEST_RECIPE_PH_DRIVERFOLDER2 = recipesDir
    + "test_recipe_driverfolder2.xml";

string TestRecipeExecutor::TEST_RECIPE_PH_DRIVERCONFIG = recipesDir
    + "test_recipe_driverconfig.xml";

string TestRecipeExecutor::TEST_RECIPE_PH_WAFER1 = recipesDir
    + "test_wafertest1.xml";

string TestRecipeExecutor::TEST_RECIPE_PH_WAFER2 = recipesDir
    + "test_wafertest2.xml";

TEST_F(TestRecipeExecutor, testInvalidPHSetting)
{
  EXPECT_THROW(executeRecipe(TEST_RECIPE_PH_DRIVERTYPE), TCException);
  EXPECT_THROW(executeRecipe(TEST_RECIPE_PH_DRIVERFOLDER1), TCException);
  EXPECT_THROW(executeRecipe(TEST_RECIPE_PH_DRIVERFOLDER2), TCException);
  EXPECT_THROW(executeRecipe(TEST_RECIPE_PH_DRIVERCONFIG), TCException);
}

TEST_F(TestRecipeExecutor, testwafertest1)
{
  executeRecipeNoException(TEST_RECIPE_PH_WAFER1);
}

TEST_F(TestRecipeExecutor, testwafertest2)
{
  EXPECT_THROW(executeRecipe(TEST_RECIPE_PH_WAFER2), TCException);
}
