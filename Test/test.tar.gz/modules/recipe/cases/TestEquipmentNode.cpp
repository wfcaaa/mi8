/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestEquipmentNode : public AbstractRecipeTest {
protected:
  static string TEST_EQUIPMENTCONTROL_ELEMENT;
};

string TestEquipmentNode::TEST_EQUIPMENTCONTROL_ELEMENT = recipesDir
    + "test_equipmentcontrol_element.xml";

TEST_F(TestEquipmentNode, testEquipmentControlNode)
{
  // listening the phsession start event
  EventExpector expector4SessionEnd;
  {
    map<string, string> properties;
    properties.insert(
        std::pair<string, string>("EXECUTION_STATE",
            "PH_CONNECTING_COMPLETED"));
    expector4SessionEnd.expectEvent(Event::PH, properties, 1);
  }

  // listening the ph lot start event
  EventExpector expector4LotEnd;
  {
    map<string, string> properties;
    properties.insert(
        std::pair<string, string>("EXECUTION_STATE",
            "PH_LOT_LOADING_COMPLETED"));
    expector4LotEnd.expectEvent(Event::PH, properties, 1);
  }

  // listening the ph lot start event
  EventExpector expector4DeviceLoadingEnd;
  {
    map<string, string> properties;
    properties.insert(
        std::pair<string, string>("EXECUTION_STATE",
            "PH_DEVICE_LOADING_COMPLETED"));
    expector4DeviceLoadingEnd.expectEvent(Event::PH, properties, 1);
  }

  // listening the ph lot start event
  EventExpector expector4DeviceBinningEnd;
  {
    map<string, string> properties;
    properties.insert(
        std::pair<string, string>("EXECUTION_STATE",
            "PH_DEVICE_BINNING_COMPLETED"));
    expector4DeviceBinningEnd.expectEvent(Event::PH, properties, 1);
  }

  // listening the ph lot start event
  EventExpector expector4LotUnloadEnd;
  {
    map<string, string> properties;
    properties.insert(
        std::pair<string, string>("EXECUTION_STATE",
            "PH_LOT_UNLOADING_COMPLETED"));
    expector4LotUnloadEnd.expectEvent(Event::PH, properties, 1);
  }

  // listening the ph lot start event
  EventExpector expector4PHDisconnectionEnd;
  {
    map<string, string> properties;
    properties.insert(
        std::pair<string, string>("EXECUTION_STATE",
            "PH_DISCONNECTING_COMPLETED"));
    expector4PHDisconnectionEnd.expectEvent(Event::PH, properties, 1);
  }

  executeRecipeNoException(TEST_EQUIPMENTCONTROL_ELEMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "driver").getCommon();
  // check 8 levels have been executed
  EXPECT_TRUE(!value.empty());
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "equipment").getCommon();
  // check 8 levels have been executed
  EXPECT_TRUE(!value.empty());
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "name").getCommon();
  // check 8 levels have been executed
  EXPECT_TRUE(value == "\"test\"");

  sleep(10);
  expector4SessionEnd.done();
  expector4LotEnd.done();
  expector4DeviceLoadingEnd.done();
  expector4DeviceBinningEnd.done();
  expector4LotUnloadEnd.done();
  expector4PHDisconnectionEnd.done();
}
