/**
 * Copyright by Advantest, 2019
 *
 * @author  Zoyi Yu
 * @date    Jul 15, 2019
 */

#include "AbstractRecipeTest.hpp"
class TestRecipe : public AbstractRecipeTest {
protected:
  static string TEST_NORMAL_RECIPE;
  static string TEST_INEXIST_RECIPE;
  static string TEST_INVALID_RECIPE;
  static string TEST_EMPTY_RECIPE;
};


string TestRecipe::TEST_NORMAL_RECIPE = recipesDir
    + "test_normal_recipe.xml";
string TestRecipe::TEST_INEXIST_RECIPE = recipesDir
    + "test_inexist_recipe.xml";
string TestRecipe::TEST_INVALID_RECIPE = recipesDir
    + "test_invalid_recipe.xml";
string TestRecipe::TEST_EMPTY_RECIPE = recipesDir
    + "test_empty_recipe.xml";

void *startExecuteRecipe(void* pExecutor)
{
  try {
    ((Recipe*)pExecutor)->start();
  } catch (TCException &exc) {
    cout << "***********EXCEPTION******************" << endl;
    cout << "message: " << exc.message << endl;
    cout << "origin:  " << exc.origin << endl;
    cout << "type:    " << exc.typeString << endl;
    cout << "**************************************" << endl;
  }
}

TEST_F(TestRecipe, testInexistRecipe)
{
  EXPECT_THROW(executeRecipe(TEST_INEXIST_RECIPE), TCException);
}

TEST_F(TestRecipe, testInvalidRecipe)
{
  EXPECT_THROW(executeRecipe(TEST_INVALID_RECIPE), TCException);
}

TEST_F(TestRecipe, testEmptyRecipe)
{
  EXPECT_THROW(executeRecipe(TEST_EMPTY_RECIPE), TCException);
}

TEST_F(TestRecipe, testRecipeManagement)
{
  RecipeManager &manager = RecipeManager::getInstance();
  Recipe* pExecutor = &manager.newRecipe(TEST_NORMAL_RECIPE);

  EXPECT_TRUE(pExecutor->getPath() == TEST_NORMAL_RECIPE);

  pthread_t thread1;
  pthread_create(&thread1, NULL, startExecuteRecipe, (void*)pExecutor);
  while(pExecutor->getState() == Recipe::UNDEFINED)
  {
    sleep(1);
  }

  if(pExecutor->getState() == Recipe::EXECUTING)
  {
    pExecutor->pause();
    while(pExecutor->getState() != Recipe::PAUSED && pExecutor->getState() != Recipe::HOLD)
    {
      sleep(1);
    }

    EXPECT_TRUE(pExecutor->getAttachedTesterSession().getSessionId() == "TesterSession_1");

    pExecutor->resume();

    pExecutor->stop();
    EXPECT_TRUE(pExecutor->getState() == Recipe::UNDEFINED);
  }
}

TEST_F(TestRecipe, testRecipeManagement1)
{
  RecipeManager &manager = RecipeManager::getInstance();
  Recipe &pExecutor = manager.newRecipe(TEST_NORMAL_RECIPE);

  EXPECT_THROW(pExecutor.stop(), TCException);
}

