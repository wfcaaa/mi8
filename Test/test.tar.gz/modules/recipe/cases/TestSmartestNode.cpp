/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestSmartestNode : public AbstractRecipeTest {
protected:
  static string TEST_SMARTEST_ELEMENT;
  static string TEST_SMARTEST_ELEMENT_VERSION;
  static string TEST_SMARTEST_ENFORCEPATCHVERSION_FALSE;
  static string TEST_SMARTEST_ENFORCEPATCHVERSION_TRUE;
};

string TestSmartestNode::TEST_SMARTEST_ELEMENT = recipesDir
    + "test_smartest_element.xml";

string TestSmartestNode::TEST_SMARTEST_ELEMENT_VERSION = recipesDir
    + "test_smartest_element_version.xml";

string TestSmartestNode::TEST_SMARTEST_ENFORCEPATCHVERSION_FALSE = recipesDir
    + "test_smartest_enforcepatchversion_false.xml";

string TestSmartestNode::TEST_SMARTEST_ENFORCEPATCHVERSION_TRUE = recipesDir
    + "test_smartest_enforcepatchversion_true.xml";

TEST_F(TestSmartestNode, testStartSmartest)
{
  executeRecipeNoException(TEST_SMARTEST_ELEMENT);
  EXPECT_TRUE(
      !TestCell::getInstance().getTesterSessions()[0]->getSessionId().empty());
}

TEST_F(TestSmartestNode, testSmartestenforcepatchversionfalse)
{
  executeRecipeNoException(TEST_SMARTEST_ENFORCEPATCHVERSION_FALSE);
  EXPECT_TRUE(
      !TestCell::getInstance().getTesterSessions()[0]->getSessionId().empty());
}

TEST_F(TestSmartestNode, testSmartestenforcepatchversiontrue)
{
  executeRecipeNoException(TEST_SMARTEST_ENFORCEPATCHVERSION_TRUE);
  EXPECT_TRUE(
      !TestCell::getInstance().getTesterSessions()[0]->getSessionId().empty());
}

TEST_F(TestSmartestNode, testStartSmartestversion)
{
  EXPECT_THROW(executeRecipe(TEST_SMARTEST_ELEMENT_VERSION), TCException);
}
