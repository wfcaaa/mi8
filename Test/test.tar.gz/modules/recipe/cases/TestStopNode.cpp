/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestStopNode : public AbstractRecipeTest {
protected:
  static string TEST_STOP_ELEMENT;
  static string TEST_STOP_RECIPE;
};

string TestStopNode::TEST_STOP_ELEMENT = recipesDir
    +"test_stop_level_element.xml";

string TestStopNode::TEST_STOP_RECIPE = recipesDir
    +"test_stop_recipe.xml";

TEST_F(TestStopNode, testStopElement)
{
  executeRecipeNoException(TEST_STOP_ELEMENT);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "levelCount").getCommon();
  EXPECT_TRUE(value == "51");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "testedCount").getCommon();
  EXPECT_TRUE(value == "50");

  value = TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
            "end").getCommon();
  EXPECT_TRUE(value == "true");

  value = TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
             "end2").getCommon();
   EXPECT_TRUE(value == "false");
}

TEST_F(TestStopNode, testStopRecipe) {
  executeRecipeNoException(TEST_STOP_RECIPE);
  string value = TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
            "end").getCommon();
  EXPECT_TRUE(value == "true");
}
