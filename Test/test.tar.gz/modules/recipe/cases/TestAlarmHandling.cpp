/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestAlarmHandling : public AbstractRecipeTest {
protected:
  static string TEST_PARTID_MISSING;
  static string TEST_DYNAMIC_BIND_ALARM;
  static string TEST_UNDEFINED_ALARM;
};

string TestAlarmHandling::TEST_PARTID_MISSING = recipesDir
    + "test_datalog_missing_partid_alarm.xml";

string TestAlarmHandling::TEST_UNDEFINED_ALARM = recipesDir
    + "test_undefined_alarm.xml";

string TestAlarmHandling::TEST_DYNAMIC_BIND_ALARM = recipesDir
    + "test_dynamic_bind_alarm.xml";

/**
 * Test using recipe to handle the PART_ID_MISSING alarm
 */TEST_F(TestAlarmHandling, testPartIDMissingAlarm)
{
  EXPECT_THROW(executeRecipe(TEST_PARTID_MISSING), TCException);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "GetDatalogAlarm").getCommon();
  EXPECT_TRUE(value == "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "GetDynamicBindAlarm").getCommon();
  EXPECT_TRUE(value == "false");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "HandleAll").getCommon();
  EXPECT_TRUE(value == "true");
}

 /**
  * Test using recipe to handle the undefined alarm
  */TEST_F(TestAlarmHandling, testUndefinedAlarm)
 {
   EXPECT_THROW(executeRecipe(TEST_UNDEFINED_ALARM), TCException);
 }

/**
 * Test using recipe to handle the Dynamic_Bind alarm
 */TEST_F(TestAlarmHandling, testDynamicBindAlarm)
{
  EXPECT_THROW(executeRecipe(TEST_DYNAMIC_BIND_ALARM), TCException);
  string value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "GetDatalogAlarm").getCommon();
  EXPECT_TRUE(value == "true");
  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "GetDynamicBindAlarm").getCommon();
  EXPECT_TRUE(value == "true");

  value =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "HandleAll").getCommon();
  EXPECT_TRUE(value == "true");
}
