/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestPerformance : public AbstractRecipeTest {
protected:
  static string TEST_PERFORMANCE;
};

string TestPerformance::TEST_PERFORMANCE = recipesDir
    + "test_performance_element.xml";

TEST_F(TestPerformance, testPerformance)
{
  executeRecipeNoException(TEST_PERFORMANCE);
  string datalogPath =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
          "datalogPath").getCommon();
  string datalogfile = datalogPath + "/recipe_10000_run.edl";
  ifstream fileEDL(datalogfile.c_str(),
      std::ifstream::ate | std::ifstream::binary);
  EXPECT_TRUE(fileEDL.tellg() > 0);
}
