/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#include "AbstractRecipeTest.hpp"
class TestSWCStartUpOrShutdown : public AbstractRecipeTest {
protected:

  static string TEST_SHUTDOWN_SWC;

  static string TEST_STARTUP_SWC;
};

string TestSWCStartUpOrShutdown::TEST_SHUTDOWN_SWC = recipesDir
    + "test_shutdown_swc.xml";

string TestSWCStartUpOrShutdown::TEST_STARTUP_SWC = recipesDir
    + "test_startup_swc.xml";



TEST_F(TestSWCStartUpOrShutdown, testRecipeShutDownSWC)
{

  TesterSession& testerSession = TestCell::getInstance().newTesterSession();
  testerSession.start();
  testerSession.openSWC();
  RecipeManager &manager = RecipeManager::getInstance();
  Recipe& executor = manager.newRecipe(TEST_SHUTDOWN_SWC);
  executor.attachToTesterSession(testerSession);
  executeRecipeNoException(TEST_SHUTDOWN_SWC, &executor);
  EXPECT_FALSE(testerSession.isSWCOpen());
}

TEST_F(TestSWCStartUpOrShutdown, testRecipeStartUpSWC)
{

  TesterSession& testerSession = TestCell::getInstance().newTesterSession();
  testerSession.start();
  RecipeManager &manager = RecipeManager::getInstance();
  Recipe& executor = manager.newRecipe(TEST_STARTUP_SWC);
  executor.attachToTesterSession(testerSession);
  executeRecipeNoException(TEST_STARTUP_SWC, &executor);
  EXPECT_TRUE(testerSession.isSWCOpen());
}
