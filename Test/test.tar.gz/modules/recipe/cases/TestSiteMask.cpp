/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */

#include "AbstractRecipeTest.hpp"
class TestSiteMask : public AbstractRecipeTest {
protected:
  static string TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT;
  static string TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT1;
  static string TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT2;
  static string TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT3;
  static string TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT4;
  static string TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT5;

};

string TestSiteMask::TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT = recipesDir
    + "test_execute_testflow_with_sitemask_element.xml";
string TestSiteMask::TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT1 = recipesDir
    + "test_execute_testflow_with_sitemask_element1.xml";
string TestSiteMask::TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT2 = recipesDir
    + "test_execute_testflow_with_sitemask_element2.xml";
string TestSiteMask::TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT3 = recipesDir
    + "test_execute_testflow_with_sitemask_element3.xml";
string TestSiteMask::TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT4 = recipesDir
    + "test_execute_testflow_with_sitemask_element4.xml";
string TestSiteMask::TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT5 = recipesDir
    + "test_execute_testflow_with_sitemask_element5.xml";

TEST_F(TestSiteMask, testSiteMask)
{
  executeRecipe(TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT);
  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");
  EXPECT_TRUE(partID.get(1) == "19");
  EXPECT_TRUE(partID.get(2) == "");
  EXPECT_TRUE(partID.get(3) == "");
  EXPECT_TRUE(partID.get(4) == "20");
}

TEST_F(TestSiteMask, testSiteMask1)
{
  executeRecipeNoException(TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT1);
  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");
  EXPECT_TRUE(partID.get(1) == "");
  EXPECT_TRUE(partID.get(2) == "10");
}

TEST_F(TestSiteMask, testSiteMask2)
{
  executeRecipeNoException(TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT2);
  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");
  EXPECT_TRUE(partID.get(1) == "10");
  EXPECT_TRUE(partID.get(2) == "");
}

TEST_F(TestSiteMask, testSiteMask3)
{
  executeRecipeNoException(TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT3);
  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");
  EXPECT_TRUE(partID.get(1) == "19");
  EXPECT_TRUE(partID.get(2) == "");
  EXPECT_TRUE(partID.get(3) == "");
  EXPECT_TRUE(partID.get(4) == "20");
}

TEST_F(TestSiteMask, testSiteMask4)
{
  executeRecipeNoException(TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT4);
  MultiSiteString partID =
      TestCell::getInstance().getTesterSessions()[0]->testProgram().getTPVariableString(
          "STDF.PART_ID");
  EXPECT_TRUE(partID.get(1) == "19");
  EXPECT_TRUE(partID.get(2) == "");
  EXPECT_TRUE(partID.get(3) == "");
  EXPECT_TRUE(partID.get(4) == "20");
}

TEST_F(TestSiteMask, testSiteMask5)
{

  EXPECT_THROW( executeRecipe(TEST_EXECUTE_TESTFLOW_WITH_SITEMASK_ELEMENT5),
      TCException);
}
