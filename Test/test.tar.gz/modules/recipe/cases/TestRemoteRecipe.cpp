/**
 * Copyright by Advantest, 2019
 *
 * @author  Zoyi Yu
 * @date    Jul 15, 2019
 */

#include "AbstractRecipeTest.hpp"

string test_command;

class TestRemoteRecipe : public AbstractRecipeTest {
public:
  static string TEST_REMOTE_RECIPE;


  static void TearDownTestCase()
  {
    string command = string(getenv("XOC_SYSTEM")) + "/bin/killTcct";
    int ret = system(command.c_str());
    if (ret == -1 || WEXITSTATUS(ret) != 0) {
          throw(runtime_error(
              "Failed to execute kill TCCT command"));
    }
  }

};

string TestRemoteRecipe::TEST_REMOTE_RECIPE = recipesDir
    + "test_remote_recipe.xml";


// Start the recipe execution in another client
void *startExecuteRemoteRecipe(void* argument)
{
  try {
    test_command = TestRemoteRecipe::recipesDir + "remote.exe" + " " + TestRemoteRecipe::TEST_REMOTE_RECIPE;
    system(test_command.c_str());
  } catch (TCException &exc) {
    cout << "***********EXCEPTION******************" << endl;
    cout << "message: " << exc.message << endl;
    cout << "origin:  " << exc.origin << endl;
    cout << "type:    " << exc.typeString << endl;
    cout << "**************************************" << endl;
  }
}

// Start the remote recipe execution with local instance
void *startExecuteRemoteFromLocalReference(void* argument)
{
  try {
    Recipe* remoteRecipe = (Recipe*)argument;
    remoteRecipe->setEnableProfiling(true);
    remoteRecipe->start();
  } catch (TCException &exc) {
    cout << "***********EXCEPTION******************" << endl;
    cout << "message: " << exc.message << endl;
    cout << "origin:  " << exc.origin << endl;
    cout << "type:    " << exc.typeString << endl;
    cout << "**************************************" << endl;
  }
}

void *startRunTCCT(void* argument){
  string command  = string(getenv("XOC_SYSTEM")) + "/bin/tcct -r " + TestRemoteRecipe::TEST_REMOTE_RECIPE;
  system(command.c_str());
}

//Test recipe can be executed by TCCT, and query the status in another client
TEST_F(TestRemoteRecipe, testRunByTCCT)
{
  TRY_BEGIN
  pthread_t thread1;
  pthread_create(&thread1, NULL, startRunTCCT, (void*)this);


  RecipeManager &manager = RecipeManager::getInstance();
  vector<Recipe*> recipes = manager.getRecipes();

  while(recipes.size() <  1)
  {
    sleep(1);
    recipes = manager.getRecipes();
  }

  Recipe* remoteRecipe = recipes[0];
  remoteRecipe->pause();
  while(remoteRecipe->getState() != Recipe::PAUSED)
  {
    sleep(1);
  }



  TesterSession & session = remoteRecipe->getAttachedTesterSession();

  remoteRecipe->attachToTesterSession(session);
  remoteRecipe->setEnableProfiling(true);

  PHSession &aSession = TestCell::getInstance().newPHSession();
  string testModulePath = getenv("XOC_TEST_MODULE");
  string driverPath = testModulePath + "/testbed/drivers/Multitest/";
  string driverConfig = testModulePath + "/testbed/drivers/Multitest/config/MT9918-GPIB-4.cfg";

  aSession.setDriverPath(driverPath).setConfigPath(driverConfig).start().connect();

  remoteRecipe->attachToPHSession(aSession);

  remoteRecipe->resume();
  remoteRecipe->pause();

  EXPECT_TRUE(remoteRecipe->getPath() == TEST_REMOTE_RECIPE);
  EXPECT_TRUE(remoteRecipe->getAttachedPHSession().getSessionId() == aSession.getSessionId());
  EXPECT_TRUE(remoteRecipe->getAttachedTesterSession().getSessionId() == session.getSessionId());

  remoteRecipe->stop();

  TRY_END_FAIL
}

//Test recipe can be executed by one tc-client and query the status by another client
TEST_F(TestRemoteRecipe, testRemoteRecipeManagement)
{
  TRY_BEGIN
  RecipeManager &manager = RecipeManager::getInstance();
  vector<Recipe*> recipes = manager.getRecipes();
  int recipes_count = recipes.size();

  // Generate a test cell session to run recipe
  pthread_t thread1;
  pthread_create(&thread1, NULL, startExecuteRemoteRecipe, (void*)this);

  while(recipes.size() < recipes_count + 1)
  {
    sleep(1);
    recipes = manager.getRecipes();
  }

  Recipe* remoteRecipe = recipes[recipes_count];

  if(remoteRecipe->getState() == Recipe::EXECUTING)
  {
    EXPECT_TRUE(!remoteRecipe->getPath().empty());

    remoteRecipe->pause();
    while(remoteRecipe->getState() != Recipe::PAUSED && remoteRecipe->getState() != Recipe::HOLD)
    {
      sleep(1);
    }

    remoteRecipe->resume();
    remoteRecipe->stop();
  }

  if(remoteRecipe->getState() == Recipe::UNDEFINED) {
    pthread_t thread1;
    pthread_create(&thread1, NULL, startExecuteRemoteFromLocalReference, remoteRecipe);
    TesterSession * session = TestCell::getInstance().getTesterSessions()[0];
    EXPECT_TRUE(session->getSessionId() == remoteRecipe->getAttachedTesterSession().getSessionId());
    EXPECT_TRUE(remoteRecipe->getPath() == TEST_REMOTE_RECIPE);
    EXPECT_TRUE(remoteRecipe->getAttachedPHSession().getSessionId().empty());
  }
  TRY_END_FAIL
}


