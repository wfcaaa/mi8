/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#include "AbstractRecipeTest.hpp"
class TestPredefineVariables : public AbstractRecipeTest {
protected:

  static string TEST_PREDEFINE_VARIABLES;
};

string TestPredefineVariables::TEST_PREDEFINE_VARIABLES = recipesDir
    + "test_pre_define_variables.xml";


TEST_F(TestPredefineVariables, testVariables)
{
  executeRecipeNoException(TEST_PREDEFINE_VARIABLES);
  string value =
        TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
            "smtID").getCommon();
  EXPECT_TRUE(value.find("TesterSession") == 0);

  value =
          TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
              "phID").getCommon();
  EXPECT_TRUE(value.find("PHControl") == 0);

  value =
           TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
               "path").getCommon();
  EXPECT_TRUE(value == TestPredefineVariables::TEST_PREDEFINE_VARIABLES);

  value =
            TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
                "enableSites").getCommon();
  EXPECT_TRUE(value == "1 2 3 4");

  value =
            TestCell::getInstance().getTesterSessions()[0]->testProgram().getTCVariableString(
                "testProgramAvailableSites").getCommon();
  EXPECT_TRUE(value == "1 2 3 4");

}

