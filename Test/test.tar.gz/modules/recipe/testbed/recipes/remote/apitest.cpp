#include "xoc/tcapi/tcapi.hpp"
#include <iostream> 
#include <vector>
#include <unistd.h>
#include <memory>
#include <stdlib.h>
#include <pthread.h>
using namespace std;
using namespace xoc::tcapi;

int main(int argc, char *argv[])
{
try
{

  string recipe = argv[1];
  TestCell &testCell = TestCell::getInstance();

  RecipeManager &manager = RecipeManager::getInstance();
  Recipe* pExecutor = &manager.newRecipe(recipe);
  pExecutor->start();
  //Keep running until killed when test case exits
  while (true){
   sleep(1);
  }
  return 0;
}
catch(TCException &exc)
{
    //exception handling
    cout << "***********EXCEPTION******************" << endl;
    cout << "message: " << exc.message << endl;
    cout << "origin:  " << exc.origin << endl;
    cout << "type:    " << exc.typeString << endl;
    cout << "**************************************" << endl;
}
}

