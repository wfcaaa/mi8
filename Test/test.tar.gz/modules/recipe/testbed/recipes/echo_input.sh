#!/bin/sh
echo $1
exit 0