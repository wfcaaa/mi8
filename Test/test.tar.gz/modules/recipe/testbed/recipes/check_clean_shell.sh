#!/bin/sh
# Recipe will create a new environment only contains few variables defined by following array
declare -a variables=("DISPLAY" "USER" "LOGNAME" "HOME" "HOSTNAME" "XAUTHORITY")
for var in ${variables[@]}
do 
if [[ -z ${!var} ]]
    then
        echo "$var is empty"
        exit 1
    fi  
done

# Now we test another variable
if [[ -n $XOC_SESSION ]] 
then
    echo $XOC_SESSION
    echo "Recipe do not create a clean shell to execute the script"
    exit 1
fi

exit 0