#include "Impl.hpp"

#include <iostream>

using namespace xoc::edlapi;
using namespace google::protobuf;
using namespace ::std;

void Impl::doFunctionalTestEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doParametricTestEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doScanTestEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doSignatureEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doSetupDefinitionEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doSignalDefinitionEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doBinningTableEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doVariableChangeEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doTestProgramStartEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doTestProgramEndEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doExecutionStartEvent( const ::xoc::edlapi::Event& ev )
{
 throw "Custom formatter crashed";
}

void Impl::doExecutionEndEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doBinEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doTestFlowStartEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doTestFlowEndEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doTestSuiteStartEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doTestSuiteEndEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doMeasurementStartEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doMeasurementEndEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doGenericDataEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doTextEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doCharacterizationStartEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doCharacterizationResultEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doCharacterizationEndEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doCharacterizationEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doTestCellEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doTimerEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doPerformanceTransactionStartEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}

void Impl::doPerformanceTransactionEndEvent( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
}
