#pragma once

#include <fstream>
#include <xoc/edlapi/Datalog.pb.h>

class Impl
{
  public:

    Impl(std::ofstream& ofs) : mOutput(ofs) {}

    void doFunctionalTestEvent( const ::xoc::edlapi::Event& ev );
    void doParametricTestEvent( const ::xoc::edlapi::Event& ev );
    void doScanTestEvent( const ::xoc::edlapi::Event& ev );
    void doSignatureEvent( const ::xoc::edlapi::Event& ev );
    void doSetupDefinitionEvent( const ::xoc::edlapi::Event& ev );
    void doSignalDefinitionEvent( const ::xoc::edlapi::Event& ev );
    void doBinningTableEvent( const ::xoc::edlapi::Event& ev );
    void doVariableChangeEvent( const ::xoc::edlapi::Event& ev );
    void doTestProgramStartEvent( const ::xoc::edlapi::Event& ev );
    void doTestProgramEndEvent( const ::xoc::edlapi::Event& ev );
    void doExecutionStartEvent( const ::xoc::edlapi::Event& ev );
    void doExecutionEndEvent( const ::xoc::edlapi::Event& ev );
    void doBinEvent( const ::xoc::edlapi::Event& ev );
    void doTestFlowStartEvent( const ::xoc::edlapi::Event& ev );
    void doTestFlowEndEvent( const ::xoc::edlapi::Event& ev );
    void doTestSuiteStartEvent( const ::xoc::edlapi::Event& ev );
    void doTestSuiteEndEvent( const ::xoc::edlapi::Event& ev );
    void doMeasurementStartEvent( const ::xoc::edlapi::Event& ev );
    void doMeasurementEndEvent( const ::xoc::edlapi::Event& ev );
    void doGenericDataEvent( const ::xoc::edlapi::Event& ev );
    void doTextEvent( const ::xoc::edlapi::Event& ev );
    void doCharacterizationStartEvent( const ::xoc::edlapi::Event& ev );
    void doCharacterizationResultEvent( const ::xoc::edlapi::Event& ev );
    void doCharacterizationEndEvent( const ::xoc::edlapi::Event& ev );
    void doCharacterizationEvent( const ::xoc::edlapi::Event& ev );
    void doTestCellEvent( const ::xoc::edlapi::Event& ev );
    void doTimerEvent( const ::xoc::edlapi::Event& ev );
    void doPerformanceTransactionStartEvent( const ::xoc::edlapi::Event& ev );
    void doPerformanceTransactionEndEvent( const ::xoc::edlapi::Event& ev );

  private:
    Impl(const Impl&);
    Impl& operator=(const Impl&);

  private:
    std::ofstream&  mOutput;
};
