#pragma once

/**
 * Copyright by Advantest Europe GmbH
 *
 * Template formatter for developing your own formatter library
 *
 * Implementing your own formatter library by inheritance from the xoc::cfapi::ConfigurableCustomEventHandler.
 * the only comsume*(...) memberfunctions which Event you care need to be implmented.
 *
 * NOTE: make sure your formatter library have the implmentation of "extern "C" CustomEventHandler *create()", for example
 *         extern "C" CustomEventHandler *create()
 *         {
 *           // need to make sure new your formatter instance here
 *           return new MyLibrary();
 *         }
 *
 */

#include <map>
#include "xoc/cfapi/ConfigurableCustomEventHandler.hpp"
#include <xoc/edlapi/EventsSorter.hpp>

class Impl;

class MyLibrary : public xoc::cfapi::ConfigurableCustomEventHandler
{
  public:

    MyLibrary();

    void consumeFunctionalTestEvent( const ::xoc::edlapi::Event& ev );
    void consumeParametricTestEvent( const ::xoc::edlapi::Event& ev );
    void consumeScanTestEvent( const ::xoc::edlapi::Event& ev );
    void consumeSignatureEvent( const ::xoc::edlapi::Event& ev );
    void consumeSetupDefinitionEvent( const ::xoc::edlapi::Event& ev );
    void consumeSignalDefinitionEvent( const ::xoc::edlapi::Event& ev );
    void consumeBinningTableEvent( const ::xoc::edlapi::Event& ev );
    void consumeVariableChangeEvent( const ::xoc::edlapi::Event& ev );
    void consumeTestProgramStartEvent( const ::xoc::edlapi::Event& ev );
    void consumeTestProgramEndEvent( const ::xoc::edlapi::Event& ev );
    void consumeExecutionStartEvent( const ::xoc::edlapi::Event& ev );
    void consumeExecutionEndEvent( const ::xoc::edlapi::Event& ev );
    void consumeBinEvent( const ::xoc::edlapi::Event& ev );
    void consumeTestFlowStartEvent( const ::xoc::edlapi::Event& ev );
    void consumeTestFlowEndEvent( const ::xoc::edlapi::Event& ev );
    void consumeTestSuiteStartEvent( const ::xoc::edlapi::Event& ev );
    void consumeTestSuiteEndEvent( const ::xoc::edlapi::Event& ev );
    void consumeMeasurementStartEvent( const ::xoc::edlapi::Event& ev );
    void consumeMeasurementEndEvent( const ::xoc::edlapi::Event& ev );
    void consumeGenericDataEvent( const ::xoc::edlapi::Event& ev );
    void consumeTextEvent( const ::xoc::edlapi::Event& ev );
    void consumeCharacterizationStartEvent( const ::xoc::edlapi::Event& ev );
    void consumeCharacterizationResultEvent( const ::xoc::edlapi::Event& ev );
    void consumeCharacterizationEndEvent( const ::xoc::edlapi::Event& ev );
    void consumeCharacterizationEvent( const ::xoc::edlapi::Event& ev );
    void consumeTestCellEvent( const ::xoc::edlapi::Event& ev );
    void consumeTimerEvent( const ::xoc::edlapi::Event& ev );
    void consumePerformanceTransactionStartEvent( const ::xoc::edlapi::Event& ev );
    void consumePerformanceTransactionEndEvent( const ::xoc::edlapi::Event& ev );
    void handleUnknown ( const ::xoc::edlapi::Event& ev );

    void parseConfiguration( const std::string& config );

    ~MyLibrary();

  private:
    void handleEvent( const ::xoc::edlapi::Event& ev );

  private:
    std::map<std::string, std::string> mSetting;
    Impl *mImpl;
    bool mEnableEventsSorting;
    xoc::edlapi::EventsSorter mEventsSorter;
};

