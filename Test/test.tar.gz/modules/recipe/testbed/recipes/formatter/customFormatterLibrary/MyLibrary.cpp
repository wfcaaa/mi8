#include "MyLibrary.hpp"
#include "Impl.hpp"

#include <iostream>
#include <vector>
#include <boost/algorithm/string.hpp>
#include <sstream>

using namespace xoc::edlapi;
using namespace ::std;
using namespace xoc::cfapi;

// ---- MUST HAVE BEGIN ----
extern "C" CustomEventHandler *create()
{
  // need to make sure new your formatter instance here
  return new MyLibrary();
}
// ---- MUST HAVE END ----


MyLibrary::MyLibrary() : mImpl(new Impl(mOutput)), mEnableEventsSorting(true)
{
}

MyLibrary::~MyLibrary()
{
  delete mImpl;
}

void MyLibrary::consumeFunctionalTestEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doFunctionalTestEvent(ev);
}

void MyLibrary::consumeParametricTestEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doParametricTestEvent(ev);
}

void MyLibrary::consumeScanTestEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doScanTestEvent(ev);
}

void MyLibrary::consumeSignatureEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doSignatureEvent(ev);
}

void MyLibrary::consumeSetupDefinitionEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doSetupDefinitionEvent(ev);
}

void MyLibrary::consumeSignalDefinitionEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doSignalDefinitionEvent(ev);
}

void MyLibrary::consumeBinningTableEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doBinningTableEvent(ev);
}

void MyLibrary::consumeVariableChangeEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doVariableChangeEvent(ev);
  if(!ev.HasExtension(VariableChangeEvent::type)) return;
  const VariableChangeEvent& variableChangeEvent = ev.GetExtension(VariableChangeEvent::type);
  if("DATALOG.PASSWORD" == variableChangeEvent.variable()) {
    stringstream ss;
    int site_size = variableChangeEvent.value_size();
    for (int siteIdx=0; siteIdx<site_size; ++siteIdx)
    {
      const Value &value = variableChangeEvent.value(siteIdx);
      int value_size = value.string_size();
      for (int vIdx=0; vIdx<value_size; ++vIdx)
      {
        ss << value.string(vIdx) << endl;
      }
    }
    startDecrypter(ss.str());
  }
}

void MyLibrary::consumeTestProgramStartEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doTestProgramStartEvent(ev);
}

void MyLibrary::consumeTestProgramEndEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doTestProgramEndEvent(ev);
}

void MyLibrary::consumeExecutionStartEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting)
  {
    mEventsSorter.reset();
    handleEvent(ev);
  }
  else mImpl->doExecutionStartEvent(ev);
}

void MyLibrary::consumeExecutionEndEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting)
  {
    handleEvent(ev);
    mEventsSorter.checkCompeleted();
  }
  else mImpl->doExecutionEndEvent(ev);
}

void MyLibrary::consumeBinEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doBinEvent(ev);
}

void MyLibrary::consumeTestFlowStartEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doTestFlowStartEvent(ev);
}

void MyLibrary::consumeTestFlowEndEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doTestFlowEndEvent(ev);
}

void MyLibrary::consumeTestSuiteStartEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doTestSuiteStartEvent(ev);
}

void MyLibrary::consumeTestSuiteEndEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doTestSuiteEndEvent(ev);
}

void MyLibrary::consumeMeasurementStartEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doMeasurementStartEvent(ev);
}

void MyLibrary::consumeMeasurementEndEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doMeasurementEndEvent(ev);
}

void MyLibrary::consumeGenericDataEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
    else mImpl->doGenericDataEvent(ev);
}

void MyLibrary::consumeTextEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doTextEvent(ev);
}

void MyLibrary::consumeCharacterizationStartEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doCharacterizationStartEvent(ev);
}

void MyLibrary::consumeCharacterizationResultEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doCharacterizationResultEvent(ev);
}

void MyLibrary::consumeCharacterizationEndEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doCharacterizationEndEvent(ev);
}

void MyLibrary::consumeCharacterizationEvent( const ::xoc::edlapi::Event& ev )
{
  if(mEnableEventsSorting) handleEvent(ev);
  else mImpl->doCharacterizationEvent(ev);
}

void MyLibrary::consumeTestCellEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doTestCellEvent(ev);
}

void MyLibrary::consumeTimerEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doTimerEvent(ev);
}

void MyLibrary::consumePerformanceTransactionStartEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doPerformanceTransactionStartEvent(ev);
}

void MyLibrary::consumePerformanceTransactionEndEvent( const ::xoc::edlapi::Event& ev )
{
  mImpl->doPerformanceTransactionEndEvent(ev);
}

void MyLibrary::handleUnknown ( const ::xoc::edlapi::Event& ev )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;
  if (ev.type() == Event::ENCRYPTED_EVENT) {
    mOutput << "*** encrypted event: id= " << ev.id() << endl;
  }
}

void MyLibrary::parseConfiguration ( const std::string& config )
{
  mOutput << "*** called: " << __FUNCTION__ << endl;

  // the configuration string is parsed.
  // multiple configuration items are seperated by ';', and the key/value be seperated by '='.
  vector<string> config_items;
  boost::split(config_items, config, boost::is_any_of("; "), boost::token_compress_on);
  for (vector<string>::const_iterator it = config_items.begin(); it != config_items.end(); ++it)
  {
    vector<string> ret;
    boost::split(ret, *it, boost::is_any_of("= "), boost::token_compress_on);
    if(ret.size() >= 2) mSetting[ret[0]] = ret[1];
  }

  for (map<string, string>::iterator it = mSetting.begin(); it != mSetting.end(); ++it)
  {
    mOutput << it->first << " = " << it->second << endl;
  }
}

void MyLibrary::handleEvent( const ::xoc::edlapi::Event& ev )
{
  const std::list< ::xoc::edlapi::Event >& events = mEventsSorter.consumeEvent(ev);
  for(std::list< ::xoc::edlapi::Event >::const_iterator it = events.begin(); it != events.end(); ++it)
  {
    switch ( it->type() )
    {
      case Event::EXECUTION_START_EVENT:
        mImpl->doExecutionStartEvent(ev);
        break;
      case Event::EXECUTION_END_EVENT:
        mImpl->doExecutionEndEvent(ev);
        break;
      case Event::FUNCTIONAL_TEST_EVENT:
        mImpl->doFunctionalTestEvent(ev);
        break;
      case Event::PARAMETRIC_TEST_EVENT:
        mImpl->doParametricTestEvent(ev);
        break;
      case Event::SCAN_TEST_EVENT:
        mImpl->doScanTestEvent(ev);
        break;
      case Event::BIN_EVENT:
        mImpl->doBinEvent(ev);
        break;
      case Event::TEST_FLOW_START_EVENT:
        mImpl->doTestFlowStartEvent(ev);
        break;
      case Event::TEST_FLOW_END_EVENT:
        mImpl->doTestFlowEndEvent(ev);
        break;
      case Event::TEST_SUITE_START_EVENT:
        mImpl->doTestSuiteStartEvent(ev);
        break;
      case Event::TEST_SUITE_END_EVENT:
        mImpl->doTestSuiteEndEvent(ev);
        break;
      case Event::MEASUREMENT_START_EVENT:
        mImpl->doMeasurementStartEvent(ev);
        break;
      case Event::MEASUREMENT_END_EVENT:
        mImpl->doMeasurementEndEvent(ev);
        break;
      case Event::GENERIC_DATA_EVENT:
        mImpl->doGenericDataEvent(ev);
        break;
      case Event::TEXT_EVENT:
        mImpl->doTextEvent(ev);
        break;
      case Event::Event::CHARACTERIZATION_START_EVENT:
        mImpl->doCharacterizationStartEvent(ev);
        break;
      case Event::CHARACTERIZATION_RESULT_EVENT:
        mImpl->doCharacterizationResultEvent(ev);
        break;
      case Event::CHARACTERIZATION_END_EVENT:
        mImpl->doCharacterizationEndEvent(ev);
        break;
      case Event::CHARACTERIZATION_EVENT:
        mImpl->doCharacterizationEvent(ev);
        break;
      default:
        break;
      }
    }
  }
