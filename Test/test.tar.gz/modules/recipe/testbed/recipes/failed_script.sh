#!/bin/sh
echo this is a failed script >&2
exit 1