package common;

import ate.ext.prog.javaflow.AbstractFlow;
import ate.ext.prog.javaflow.MultiSiteIf;
import ate.ext.prog.javaflow.context.TestProgramContext;
import exampleTests.Suite_ExampleTestMethod;
import xoc.dta.internal.annotations.SuppressFBWarnings;
import xoc.dta.measurement.IMeasurement;

/**
 * Small flow with one "Functional" testsuite
 */
@SuppressFBWarnings
@SuppressWarnings("all")
public class ExampleMain extends AbstractFlow {
  public static class Suite_ExampleTestMethod_Functional extends Suite_ExampleTestMethod {
    private ExampleMain parentTestflow;
    
    public Suite_ExampleTestMethod_Functional(final ExampleMain parentTestflow, final boolean isCalled) {
      super(parentTestflow, "Functional", "/0/@testflow/@setup/@suites.0", isCalled);
      this.parentTestflow = parentTestflow;
    }
    
    public void setupParameters() {
      super.setupParameters();
      testMethod.messageLogLevel = parentTestflow.messageLogLevel.getAsInt();
      parentTestflow.setupParametersOf_Functional(this, parentTestflow);
    }
    
    public void debugHook() {
      
    }
    
    public void debugHookOnFail() {
      ate.ext.prog.javaflow.GlobalDebugHookOnFail.debugHookOnFail();
    }
  }
  
  public final ExampleMain.Suite_ExampleTestMethod_Functional Functional = new ExampleMain.Suite_ExampleTestMethod_Functional(this, true);
  
  public void addChildren() {
    // add suites
    suites.add(Functional);
  }
  
  public ExampleMain(final TestProgramContext context, final String name) {
    super(context, name, "common.ExampleMain", "example/src/common/ExampleMain.flow");
    addChildren();
  }
  
  public ExampleMain(final AbstractFlow parentTestflow, final String localName, final boolean isCalled) {
    super(parentTestflow, localName, "common.ExampleMain", "example/src/common/ExampleMain.flow", isCalled);
    addChildren();
  }
  
  public void initialize() {
    super.initialize();
    
    // initialize chars
    
    // collect flow parameters
  }
  
  /**
   * Set up parameters of the subflow Functional
   */
  private void setupParametersOf_Functional(final ExampleMain.Suite_ExampleTestMethod_Functional it, final ExampleMain ExampleMain) {
    IMeasurement __get_measurement = it._get_measurement();
    __get_measurement._set_specification("exampleTests.ExampleSpec");
    IMeasurement __get_measurement_1 = it._get_measurement();
    __get_measurement_1._set_operatingSequence("exampleTests.ExampleOperatingSequence");
  }
  
  /**
   * Generated code of the execute method
   */
  protected void executeTestflow() {
    this.Functional.execute();
    final Runnable _function = () -> {
      this.println("Yeah!");
      this.addBin(1);
    };
    final Runnable _function_1 = () -> {
      this.println("OMG!");
      this.addBin(2);
    };
    MultiSiteIf.run(this.Functional.getPass(), _function, _function_1);
    if (hasNoActiveSites()) {
        return;
    }
    
  }
  
  public void debugHook() {
    
  }
}
