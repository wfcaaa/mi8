package common;

import ate.ext.prog.javaflow.AbstractFlow;
import ate.ext.prog.javaflow.AbstractSuite;
import common.DefineBins;
import xoc.dta.internal.Dependencies;
import xoc.dta.internal.FlowVisible;

@SuppressWarnings("all")
public abstract class Suite_DefineBins extends AbstractSuite<DefineBins> {
  private static class TestMethodFactory implements AbstractSuite.TestMethodFactory {
    public DefineBins create() {
      return new DefineBins();
    }
  }
  
  public Suite_DefineBins(final AbstractFlow parentTestflow, final String localName, final String suiteLocation, final boolean isCalled) {
    super(
        parentTestflow,
        new TestMethodFactory(),
        "common.DefineBins",
        localName,
        suiteLocation,
        isCalled);
  }
  
  /**
   * See {@link xoc.dta.TestMethod#messageLogLevel TestMethod.messageLogLevel}
   */
  @FlowVisible
  public synchronized int _get_messageLogLevel() {
    return testMethod.messageLogLevel;
  }
  
  /**
   * See {@link xoc.dta.TestMethod#messageLogLevel TestMethod.messageLogLevel}
   */
  @FlowVisible
  public synchronized void _set_messageLogLevel(final int messageLogLevel) {
    testMethod.messageLogLevel = messageLogLevel;
  }
  
  public void initialize() {
    // Register parameters
    parameters.addParameter("dependencies", Dependencies.class, true, testMethod);
    parameters.addParameter("messageLogLevel", int.class, true, testMethod);
    
    super.initialize();
    
    // Initialize measurements
    
    // Initialize test descriptors
  }
}
