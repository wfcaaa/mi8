package common;

import ate.ext.prog.javaflow.AbstractFlow;
import ate.ext.prog.javaflow.context.TestProgramContext;
import common.Suite_DefineBins;
import xoc.dta.internal.annotations.SuppressFBWarnings;

@SuppressFBWarnings
@SuppressWarnings("all")
public class ExamplePreBind extends AbstractFlow {
  public static class Suite_DefineBins_defineBins extends Suite_DefineBins {
    private ExamplePreBind parentTestflow;
    
    public Suite_DefineBins_defineBins(final ExamplePreBind parentTestflow, final boolean isCalled) {
      super(parentTestflow, "defineBins", "/0/@testflow/@setup/@suites.0", isCalled);
      this.parentTestflow = parentTestflow;
    }
    
    public void setupParameters() {
      super.setupParameters();
      testMethod.messageLogLevel = parentTestflow.messageLogLevel.getAsInt();
      parentTestflow.setupParametersOf_defineBins(this, parentTestflow);
    }
    
    public void debugHook() {
      
    }
    
    public void debugHookOnFail() {
      ate.ext.prog.javaflow.GlobalDebugHookOnFail.debugHookOnFail();
    }
  }
  
  public final ExamplePreBind.Suite_DefineBins_defineBins defineBins = new ExamplePreBind.Suite_DefineBins_defineBins(this, true);
  
  public void addChildren() {
    // add suites
    suites.add(defineBins);
  }
  
  public ExamplePreBind(final TestProgramContext context, final String name) {
    super(context, name, "common.ExamplePreBind", "example/src/common/ExamplePreBind.flow");
    addChildren();
  }
  
  public ExamplePreBind(final AbstractFlow parentTestflow, final String localName, final boolean isCalled) {
    super(parentTestflow, localName, "common.ExamplePreBind", "example/src/common/ExamplePreBind.flow", isCalled);
    addChildren();
  }
  
  public void initialize() {
    super.initialize();
    
    // initialize chars
    
    // collect flow parameters
  }
  
  /**
   * Set up parameters of the subflow defineBins
   */
  private void setupParametersOf_defineBins(final ExamplePreBind.Suite_DefineBins_defineBins it, final ExamplePreBind ExamplePreBind) {
  }
  
  /**
   * Generated code of the execute method
   */
  protected void executeTestflow() {
    this.defineBins.execute();
  }
  
  public void debugHook() {
    
  }
}
