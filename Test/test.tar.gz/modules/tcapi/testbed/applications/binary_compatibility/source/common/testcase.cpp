#include "xoc/tcapi/tcapi.hpp"
#include <iostream> 
#include <vector>
#include <unistd.h>
#include <memory>
#include <stdlib.h>
using namespace std;
using namespace xoc::tcapi;


TesterSession &startTesterSession()
{
  vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
  if(allTS.size() == 0)
  {
    string testHome = getenv("XOC_TEST_HOME");
    string wsHome = getenv("XOC_TEST_WORKSPACES");
    string modelFile =  testHome + "/resources/models/model.tc_test_device";
    vector<string> ws;

    ws.push_back(wsHome + "/ws");
    ws.push_back(wsHome + "/dummy_ws1");
    ws.push_back(wsHome + "/dummy_ws2");
    ws.push_back(wsHome + "/dummy_ws3");
    ws.push_back(wsHome + "/dummy_ws4");
    
    //start a session
    return  TestCell::getInstance().
                      newTesterSession().
                      setModelFile(modelFile).
                      setWorkspace(ws[0]).
                      start();
  }
 
  return *allTS[0];
}

int main()
{
  try
  {
    // Startup a session
    TesterSession& aSession = startTesterSession();

    // Execute testflow
    TestProgram &tp = aSession.testProgram();
    tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").load().bind().run();
    Testflow &testflow = tp.testflow("Main");
    testflow.execute();
    tp.stop();

    return 0;
  }
  catch (TCException &exc) 
  {
    //exception handling
    cout << "***********EXCEPTION******************" << endl;
    cout << "message: " << exc.message << endl;
    cout << "origin:  " << exc.origin << endl;
    cout << "type:    " << exc.typeString << endl;
    cout << "**************************************" << endl;
  }

  return 0;
}

