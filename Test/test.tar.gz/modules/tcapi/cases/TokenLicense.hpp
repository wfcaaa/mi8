/**
 * Copyright by Advantest, 2019
 *
 * @date    May 10, 2019
 */


#pragma once
namespace TokenLicense {
  /**
   *
   * @param durationInSec the valid token duration period
   * @param keyMessage the input message
   * @return true if token is created successfully, otherwise return false
   */
  bool createTokenFile(long durationInSec, std::string keyMessage);
  /**
   *
   * @param keyMessage the input message
   * @return true if the token of "keyMessage" is valid, otherwise return false
   */
  bool isTokenValid(std::string keyMessage);
}




