#ifndef TESTCELL_INTEGRATION_TEST_EXCEPTION_HANDLING_HPP
#define TESTCELL_INTEGRATION_TEST_EXCEPTION_HANDLING_HPP

#define TRY_BEGIN try \
                  {
#define TRY_END_FAIL }\
                     catch (TCException &exc) \
                     {\
                       FAIL() << "******************TCException******************" \
                              << "\nType = " << exc.typeString \
                              << "\nMessage = " << exc.message \
                              << "\nOrigin = " << exc.origin \
                              << "\n*********************************************";\
                     }

#endif
