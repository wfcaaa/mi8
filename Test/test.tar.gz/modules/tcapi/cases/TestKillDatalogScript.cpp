
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TestKillDatalogScript : public AbstractTCAPITest
{

protected:

  TesterSession &startTesterSession()
  {
    vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
    if(allTS.size() == 0)
    {

      //start a session
      return  TestCell::getInstance().
                        newTesterSession().
                        setModelFile(modelFile).
                        setWorkspace(ws[0]).
                        start();
    }

    return *allTS[0];
  }
};

//normal/sequential test program operations
TEST_F(TestKillDatalogScript, testCloseFiles)
{
  TestProgram::State rState = TestProgram::UNDEFINED;
  string rName = "";
  string rWS = "";

  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog").load().bind().run();
  aSession.datalog().newDatalogFile("/tmp/edl").setFormatterType(DatalogFile::EDL).open();
  aSession.datalog().newDatalogFile("/tmp/stdf").setFormatterType(DatalogFile::STDF).open();


  string script= string(getenv("XOC_SYSTEM")) + "/bin/close_datalog_services";
  int ret = system(script.c_str());

  if(ret == -1 || WEXITSTATUS(ret) != 0)
  {
    FAIL() << "Failed to execute the killPH script to kill PH session";
  }

  sleep(1);

  ASSERT_TRUE(aSession.datalog().getDatalogFiles().size() == 0);

  TRY_END_FAIL
}










