#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <iostream> 
#include <vector>
#include <unistd.h>
#include <exception>
#include <stdlib.h>
#include <boost/lexical_cast.hpp>
using namespace std;
using namespace xoc::tcapi;

string smt_version;
char* model_file;
char* test_program;

inline bool file_exists (const std::string& name){
    struct stat buffer;
    return (stat (name.c_str(), &buffer) == 0);
}

class TestCrossFunc : public AbstractTCAPITest
{
    protected:
        TesterSession &startTesterSession()
        {
            vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
            if(allTS.size() == 0)
            {
        
                //start a session
                return  TestCell::getInstance().
                                  newTesterSession().
                                  setModelFile(modelFileInco4).
                                  setWorkspace(ws[5]).
                                  start();
            }
        
            return *allTS[0];
        }

    
};

//
TEST_F(TestCrossFunc, smoke)
{
    TRY_BEGIN
    TestProgram::State tp_state;
    DatalogFile::State datalog_state;

    TesterSession &ts = startTesterSession();

    TestProgram &tp = ts.testProgram();
    tp = tp.activate("inco4/src/testPrograms/FCS74ACT299_QuadSite.prog");  //activate test program
    tp_state = tp.getState();
    EXPECT_EQ(tp_state, TestProgram::ACTIVATED);

    map<TestProgramConfigName, string> kvMap;
    kvMap.insert(make_pair<TestProgramConfigName, string>(ENABLE_SETUP_GENERATION_ALLOWED, "true"));
    //tp.loadWithConfig(kvMap);  //load test program
    tp.load();  //load test program
    tp_state = tp.getState();
    EXPECT_EQ(tp_state, TestProgram::LOADED);
    tp.bind();  //bind test program
    tp_state = tp.getState();
    EXPECT_EQ(tp_state, TestProgram::BOUND);
    tp.run();  //run test program
    tp_state = tp.getState();
    EXPECT_EQ(tp_state, TestProgram::RUNNING);
    
    MultiSiteString partId;
    partId.set(1,"1");
    partId.set(2,"2");
    partId.set(3,"3");
    partId.set(4,"4");
    tp.setTPVariable("STDF.PART_ID",partId);

    DatalogFile &stdfLog = ts.datalog().newDatalogFile(ws[5]+"/datalog.stdf"); 
    datalog_state = stdfLog.getState();
    EXPECT_EQ(datalog_state, DatalogFile::UNDEFINED);
    stdfLog.setFormatterType(DatalogFile::STDF).open();
    datalog_state = stdfLog.getState();
    EXPECT_EQ(datalog_state, DatalogFile::OPENED);
    stdfLog.pause();
    datalog_state = stdfLog.getState();
    EXPECT_EQ(datalog_state, DatalogFile::PAUSED);
    stdfLog.resume();
    datalog_state = stdfLog.getState();
    EXPECT_EQ(datalog_state, DatalogFile::OPENED);
    string datalog_path = stdfLog.getPath();
    EXPECT_EQ(datalog_path, ws[5]+"/datalog.stdf");
    bool alive = stdfLog.isAlive();
    EXPECT_EQ(alive, true);
    stdfLog.flush();
    alive = stdfLog.isAlive();
    EXPECT_EQ(alive, true);
    
 
    //create summary datalog
    DatalogFile &summaryLog = ts.datalog().newDatalogFile(ws[5]+"/datalog.sum");
    datalog_state = summaryLog.getState();
    EXPECT_EQ(datalog_state, DatalogFile::UNDEFINED);
    summaryLog.setFormatterType(DatalogFile::SUMMARY).open();
    datalog_state = summaryLog.getState();
    EXPECT_EQ(datalog_state, DatalogFile::OPENED);

    //ts.openSWC();

    Testflow &tf = tp.testflow("Main");
    
    vector<long> tf_enabled_sites = tf.getEnabledSites();
    tf_enabled_sites.push_back(1);
    tf_enabled_sites.push_back(2);
    tf_enabled_sites.push_back(3);
    tf_enabled_sites.push_back(4);
    tf.setEnabledSites(tf_enabled_sites);
    EXPECT_GT(tf_enabled_sites.size(), 0);
    tf.execute();

    summaryLog.saveAs(ws[5]+"/datalog2.sum");
    EXPECT_EQ(file_exists(ws[5]+"/datalog2.sum"), 1);

    stdfLog.close();
    summaryLog.close();
    datalog_state = stdfLog.getState();
    EXPECT_EQ(datalog_state, DatalogFile::CLOSED);

    tp.stop();
    tp_state = tp.getState();
    EXPECT_EQ(tp_state, TestProgram::BOUND);
    tp.terminate();
    tp_state = tp.getState();
    EXPECT_EQ(tp_state, TestProgram::ACTIVATED);
    //ts.closeSWC();
    ts.stop();

    TRY_END_FAIL
}


TEST_F(TestCrossFunc, modelFile)
{
    // set empty workspace, modelFile
    TRY_BEGIN
    TestProgram::State tp_state;

    TesterSession &ts = TestCell::getInstance().newTesterSession();
    EXPECT_THROW(ts.setModelFile(" "),TCException);
    string current_model_file = ts.getModelFile();
    EXPECT_EQ("", current_model_file);
    ts.setOnline( false );
    EXPECT_THROW(ts.setWorkspace(" "),TCException);
    TRY_END_FAIL
}


TEST_F(TestCrossFunc, testerSessionErrorPara)
{
    // set empty not existing version
    TRY_BEGIN

    TesterSession &ts = TestCell::getInstance().newTesterSession();
    ts.setWorkspace(ws[5]);
    EXPECT_THROW(ts.setVersion("not existing version"),TCException);

    TRY_END_FAIL
}


TEST_F(TestCrossFunc, ewcError)
{
    // start ewc before smartest
    TRY_BEGIN

    TesterSession &ts = TestCell::getInstance().newTesterSession();
    EXPECT_THROW(ts.openSWC(),TCException);

    TRY_END_FAIL
}


TEST_F(TestCrossFunc, multiTesterSession)
{
    // start 3 tester session and get property
    TRY_BEGIN
    string sessionId;
    TesterSession::State state;
    SoftwareVersion version;

    TesterSession &ts1 = TestCell::getInstance().newTesterSession();
    TesterSession &ts2 = TestCell::getInstance().newTesterSession();
    TesterSession &ts3 = TestCell::getInstance().newTesterSession();
    ts2.setOnline(false);
    ts3.setOnline(false);
    ts1.start();
    ts2.start();
    ts3.start();
    vector<TesterSession *> list_testersessions = TestCell::getInstance().getTesterSessions();
    EXPECT_EQ(list_testersessions.size(),3);
    for( unsigned int i = 0; i < list_testersessions.size(); i++ ){
        sessionId = list_testersessions[i]->getSessionId(); 
        TesterSession &ts4 = TestCell::getInstance().testerSession(sessionId);
        state = ts4.getState();
        EXPECT_EQ(state,TesterSession::READY);
    }
    ts1.stop();
    ts2.stop();
    ts3.stop();

    TRY_END_FAIL
}

TEST_F(TestCrossFunc, variables)
{
    // check tc variable and tp variable
    TRY_BEGIN

    TesterSession &ts = TestCell::getInstance().newTesterSession();
    ts.setWorkspace(ws[5]);
    ts.start();

    TestProgram &tp = ts.testProgram();
    tp.activate("inco4/src/testPrograms/FCS74ACT299_QuadSite.prog");
    tp.load();

    string sk, sv;

    tp.setTCVariable("tc1_string", "this is tc1_string");
    tp.setTCVariable("tc2_empty","");
    tp.setTCVariable("tc3_int", 23333);
    tp.setTCVariable("tc4_double", 123.456);
    tp.setTCVariable("tc5_bool", true);

    string s = tp.getTCVariableString("tc1_string").getCommon();
    EXPECT_EQ(s, "this is tc1_string");
    s = tp.getTCVariableString("tc2_empty").getCommon();
    EXPECT_EQ(s, "");
    int i = tp.getTCVariableLong("tc3_int").getCommon();
    EXPECT_EQ(i, 23333);
    double d = tp.getTCVariableDouble("tc4_double").getCommon();
    EXPECT_EQ(d, 123.456);
    bool b = tp.getTCVariableBoolean("tc5_bool").getCommon();
    EXPECT_EQ(b, true);

    MultiSiteValueList allTCVars = tp.getTCVariables();
    map<std::string,MultiSiteString> string_list = allTCVars.listString;
    map<std::string,MultiSiteLong> long_list = allTCVars.listLong;
    map<std::string,MultiSiteBoolean> bool_list = allTCVars.listBoolean;
    map<std::string,MultiSiteDouble> double_list = allTCVars.listDouble;

    map<string,MultiSiteString>::iterator iter_string = string_list.begin();
    while (iter_string!=string_list.end())
    {
        sk = iter_string->first;
        if (sk == "tc1_string"){
            sv = iter_string->second.getCommon();
            EXPECT_EQ(sv, "this is tc1_string");
        }
        else if (sk =="tc2_empty"){
            sv = iter_string->second.getCommon();
            EXPECT_EQ(sv, "");
        }
        iter_string++;
    }
    
    i = long_list.begin()->second.getCommon();
    EXPECT_EQ(i, 23333);
    d = double_list.begin()->second.getCommon();
    EXPECT_EQ(d, 123.456);
    b = bool_list.begin()->second.getCommon();
    EXPECT_EQ(b, true);

    MultiSiteValueList allTPVars = tp.getTPVariables();

    map<std::string,MultiSiteString> tpv_string_list = allTPVars.listString;
    map<string,MultiSiteString>::iterator tpv_iter_string = tpv_string_list.begin();
    while (tpv_iter_string!=tpv_string_list.end())
    {
        sk = tpv_iter_string->first;
        sv = tpv_iter_string->second.getCommon();
      tpv_iter_string++;
    }
    
    TRY_END_FAIL
}

//check alarm, name not tested
void handle_alarm( TesterSession& session)
{
	vector<long> sites;
    if(session.hasAlarm())
    {
      vector< Alarm > alarms = session.getAlarms();
      for(size_t i = 0; i < alarms.size(); i++)
      {
          Alarm::AlarmName alarm_name = alarms[i].name;
          string alarm_dn = alarms[i].displayName;
          EXPECT_FALSE(alarm_dn.empty());
          string alarm_des = alarms[i].description;
          EXPECT_FALSE(alarm_des.empty());
		  sites = alarms[i].sites;
		  for(int j = 0; j < sites.size(); j++)
		  {
		      cout << "sites : "<< sites[j] << endl;
		  }
      }
      session.clearAlarms();
      EXPECT_FALSE(session.hasAlarm());
    }
    else
    {
        EXPECT_EQ("Alarm","No Alarm");
    }
}


TEST_F(TestCrossFunc, alarms_abort)
{
    // no alarm when abort
    TRY_BEGIN

    string sessionId;
    TesterSession &ts = startTesterSession();
    sessionId = ts.getSessionId();
    DatalogFile::State ds;

    TestProgram &tp = ts.testProgram();
    tp.activate("inco4/src/testPrograms/FCS74ACT299_QuadSite.prog");
    Testflow &testflow = tp.load().bind().run().testflow("Main");
    vector<long> sites;
    sites.push_back(1);
    sites.push_back(3);
    sites.push_back(4);

    DatalogFile &logFile1= ts.datalog().newDatalogFile(ws[5]+"/datalog.cus");
    logFile1.setFormatterType(DatalogFile::CUSTOM).setCustomFormatterPath(ws[5]+"/library/libmylibrary.so").open();

    try{
        testflow.setEnabledSites(sites).execute();
    }
    catch (TCException &exc)
    {
        EXPECT_EQ(exc.typeString, "ILLEGAL_OPERATION");
	    TestCell &testCell = TestCell::getInstance();
        TesterSession &session = testCell.testerSession(sessionId);
        handle_alarm(session);
    }

    DatalogFile &logFile2= ts.datalog().newDatalogFile(ws[5]+"/datalog.cus");
    logFile2.setConfigParam("abortProductionOnDatalogAlarm", "false");
    logFile2.setFormatterType(DatalogFile::CUSTOM).setCustomFormatterPath(ws[5]+"/library/libmylibrary.so").open();

    testflow.setEnabledSites(sites).execute();

    // found alarm when abort
    DatalogFile &logFile3= ts.datalog().newDatalogFile(ws[5]+"/datalog.cus");
    logFile3.setConfigParam("abortProductionOnDatalogAlarm", "true");
    logFile3.setFormatterType(DatalogFile::CUSTOM).setCustomFormatterPath(ws[5]+"/library/libmylibrary.so").open();

    tp.activate("inco4/src/testPrograms/FCS74ACT299_QuadSite.prog");
    testflow = tp.load().bind().run().testflow("Main");

    try{
        testflow.setEnabledSites(sites).execute();
    }
    catch (TCException &exc)
    {
        EXPECT_EQ(exc.typeString, "ILLEGAL_OPERATION");
	    TestCell &testCell = TestCell::getInstance();
        TesterSession &session = testCell.testerSession(sessionId);
        handle_alarm(session);
    }
    TRY_END_FAIL

}

TEST_F(TestCrossFunc, alarms_illegal_operation)
{
    string sessionId;
    TesterSession &ts = startTesterSession();
    sessionId = ts.getSessionId();

    try{
        string sessionId;
        TesterSession &ts = startTesterSession();
        sessionId = ts.getSessionId();

        TestProgram &tp = ts.testProgram();
        tp.activate("inco4/src/testPrograms/FCS74ACT299_QuadSite.prog");
        Testflow &testflow = tp.load().bind().run().testflow("Main");
        vector<long> sites;
        sites.push_back(0);
        testflow.setEnabledSites(sites).execute();
    }
    catch (TCException &exc)
    {
        EXPECT_EQ(exc.typeString, "ILLEGAL_OPERATION");
	    TestCell &testCell = TestCell::getInstance();
        TesterSession &session = testCell.testerSession(sessionId);
        handle_alarm(session);
    }
}

TEST_F(TestCrossFunc, testProgram)
{
    // TestPrograms
    TRY_BEGIN

    string tpName1 = "inco4/src/testPrograms/FCS74ACT299_QuadSite.prog";
    string tpName2 = "inco4/src/testPrograms/Inco4.prog";
    TesterSession &ts = startTesterSession();
    TestProgram::State tp_state;
    TestProgram &tp1 = ts.testProgram();
    TestProgram &tp2 = ts.testProgram();
    tp1 = tp1.activate(tpName1);
    tp_state = tp1.getState();
    EXPECT_EQ(tp_state, TestProgram::ACTIVATED);
    tp1.load();
    tp_state = tp1.getState();
    EXPECT_EQ(tp_state, TestProgram::LOADED);
    tp1.terminate();
    tp_state = tp1.getState();
    EXPECT_EQ(tp_state, TestProgram::ACTIVATED);
    tp1.load().bind();
    tp_state = tp1.getState();
    EXPECT_EQ(tp_state, TestProgram::BOUND);
    tp1.terminate();
    tp_state = tp1.getState();
    EXPECT_EQ(tp_state, TestProgram::ACTIVATED);
    tp1.load().bind().run();
    tp_state = tp1.getState();
    EXPECT_EQ(tp_state, TestProgram::RUNNING);
    tp1.terminate();
    tp_state = tp1.getState();
    EXPECT_EQ(tp_state, TestProgram::ACTIVATED);

    tp1 = tp1.activate(tpName1);
    int avilableSitesNum = tp1.getAvailableSites().size();
    EXPECT_EQ(avilableSitesNum, 4);
    Testflow &tf1= tp1.load().bind().run().testflow("Main");
    vector<long> sites;
    sites.push_back(1);
    sites.push_back(2);
    sites.push_back(3);
    sites.push_back(4);
    tf1.setEnabledSites(sites).execute();

    vector<SoftBin> softBins= tp1.getSoftBins();
    vector<HardBin> hardBins= tp1.getHardBins();
    for (int i = 0; i<softBins.size(); i++){
        softBins[i].id;
        EXPECT_FALSE(softBins[i].name.empty());
        softBins[i].resultType;
        softBins[i].color;
        softBins[i].hardBinId;
    }
    
    tp2 = tp2.activate(tpName2).deactivate();

    

    TRY_END_FAIL
}


 
TEST_F(TestCrossFunc, testflowExec)
{
    TRY_BEGIN

    TesterSession &ts = startTesterSession();
    TestProgram &tp = ts.testProgram();
    tp.activate("inco4/src/testPrograms/FCS74ACT299_QuadSite.prog");
    Testflow &tfc= tp.load().bind().run().testflow("Continuity");
    Testflow &tfm= tp.load().bind().run().testflow("Main");

//    TestflowConfig tfConfig;
//    tfConfig.enablePerSignalResult = true;
    map<string, string> tfconfig;
    tfconfig["ENABLE_PER_TEST_RESULTS"] = "true"; 

    vector<long> sites;

    sites.push_back(1);
    tfc.setEnabledSites(sites).executeWithConfig(tfconfig);

    sites.push_back(3);
    tfc.setEnabledSites(sites).execute();

    sites.push_back(4);
    ExtendedTestResultsPerTest results = tfc.setEnabledSites(sites).executeWithConfig(tfconfig);

    std::map< long, std::vector< ExtendedSignalResult > > testResults = results.testResults;
    std::map< long, std::vector< ExtendedSignalResult > >::const_iterator testResultsIt = testResults.begin();
    while(testResultsIt != testResults.end())
    {
        int site = testResultsIt->first;
        ASSERT_NE(site, 2);
        std::vector< ExtendedSignalResult > signalResultPerTestCol =  testResultsIt->second;
        for(size_t i = 0; i < signalResultPerTestCol.size(); i++)
        {
            string signalName = signalResultPerTestCol[i].name;
            if (signalName == "IO0"){
                std::vector< SignalResultPerTest > signalResultPerTest = signalResultPerTestCol[i].signalResultPerTest;
                for(size_t j = 0; j < signalResultPerTest.size(); j++)
                {
                    SignalResultPerTest perTest = signalResultPerTest[j];
                    if (perTest.testName == "Continuity.Continuity1.ptdPos"){
                        bool hasValue = perTest.hasParametricValue;
                        ASSERT_TRUE(hasValue);
                        double lowLimit = perTest.lowLimit;
                        ASSERT_NE(lowLimit,0);
                        double highLimit = perTest.highLimit;
                        ASSERT_NE(highLimit,0);
                    }
                    if (perTest.testName == "Continuity.Continuity1.ptdNeg"){
                        bool hasValue = perTest.hasParametricValue;
                        ASSERT_TRUE(hasValue);
                        double lowLimit = perTest.lowLimit;
                        ASSERT_NE(lowLimit,0);
                        double highLimit = perTest.highLimit;
                        ASSERT_NE(highLimit,0);
                    }
                }
            }
        }
        testResultsIt++;
    }
    
    

    //tfconfig["ENABLE_PER_TEST_RESULTS"] = "false"; 
    sites.push_back(2);
    tfc.setEnabledSites(sites).executeWithConfig(tfconfig);
    
    tp.stop();

    TRY_END_FAIL
}


TEST_F(TestCrossFunc, datalogAndStatistics)
{
    TRY_BEGIN

    string setLogPath, gotLogPath, gotValue;
    setLogPath = ws[5]+"/datalog.stdf";
    TesterSession &ts = startTesterSession();
    TestProgram &tp = ts.testProgram();
    Datalog &dl = ts.datalog();
    //dl.setConfigParam(DatalogFile::STDF, "some_name", "some_value");
    map<string,string> configParams = dl.getConfigParams(DatalogFile::STDF);
    map<string,string>::iterator it;
    map<string,string> np;
    for( it = configParams.begin(); it != configParams.end(); it++)
    {
        if (it->second == "false"){
            dl.setConfigParam(DatalogFile::STDF,it->first,"true");
            np.insert(pair<string,string>(it->first,it->second));
        }
    }

    DatalogFile &stdfLog = dl.newDatalogFile(ws[5]+"/datalog.stdf"); 
    gotLogPath = stdfLog.getPath();
    ASSERT_EQ(setLogPath,gotLogPath);
    ASSERT_EQ(gotValue, "");

    Statistics &stat = dl.newStatistics();
    stat.start();
    tp.activate("inco4/src/testPrograms/FCS74ACT299_QuadSite.prog");
    //Testflow &tfm= tp.load().bind().run().testflow("Main");
    Testflow &tf= tp.load().bind().run().testflow();
    vector<long> enabledSites;
    enabledSites.push_back(1);
    enabledSites.push_back(2);
    enabledSites.push_back(3);
    enabledSites.push_back(4);

    MultiSiteString partId;
    long currentPartId = 1;

    for(unsigned int i = 0; i < enabledSites.size(); i++)
        {
          partId.set(enabledSites[i], boost::lexical_cast<string>(currentPartId ++));
        }
    // Set the part ID
    tp.setTPVariable("STDF.PART_ID", partId);
    tf.setEnabledSites(enabledSites).execute();

    AllSiteBinSummary asbs = stat.getAllSiteBinSummary();
    ASSERT_EQ(asbs.testedDevices, 4);

    stat.pause();
    for(unsigned int i = 0; i < enabledSites.size(); i++)
        {
          partId.set(enabledSites[i], boost::lexical_cast<string>(currentPartId ++));
        }
    // Set the part ID
    tp.setTPVariable("STDF.PART_ID", partId);
    tf.setEnabledSites(enabledSites).execute();
    asbs = stat.getAllSiteBinSummary();
    ASSERT_EQ(asbs.testedDevices, 4);

    stat.resume();
    for(unsigned int i = 0; i < enabledSites.size(); i++)
        {
          partId.set(enabledSites[i], boost::lexical_cast<string>(currentPartId ++));
        }
    // Set the part ID
    tp.setTPVariable("STDF.PART_ID", partId);
    tf.setEnabledSites(enabledSites).execute();
    asbs = stat.getAllSiteBinSummary();
    ASSERT_EQ(asbs.testedDevices, 8);

    stat.pause();
    stat.stop();

    stat.start();
    PerSiteBinSummary psbs = stat.getPerSiteBinSummary(4);
    ASSERT_EQ(psbs.testedDevices, 2);
    EXPECT_THROW(stat.getPerSiteBinSummary(5),TCException);
    stat.pause();
    stat.stop();

    TRY_END_FAIL
}



TEST_F(TestCrossFunc, recipe)
{
    TRY_BEGIN
    TesterSession &ts = startTesterSession();
    RecipeManager &manager = RecipeManager::getInstance();

    Recipe &recipe = manager.newRecipe(ws[5]+"/recipe/recipe_abort.xml");
    recipe.attachToTesterSession(ts);
    ASSERT_THROW(recipe.start(), TCException);
    Recipe &recipe2 = manager.newRecipe(ws[5]+"/recipe/recipe_abort_false.xml");
    recipe2.attachToTesterSession(ts);
    recipe2.start();
    Recipe &recipe3 = manager.newRecipe(ws[5]+"/recipe/recipe_abort_true.xml");
    recipe3.attachToTesterSession(ts);
    ASSERT_THROW(recipe3.start(), TCException);

    TRY_END_FAIL
}
