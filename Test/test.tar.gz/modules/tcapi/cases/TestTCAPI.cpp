#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TestTCAPI : public ::testing::Test {


};

static string message = "this_is_the_test_message";

void *startWriteMessage(void* argument) {
  TestCell &tc = TestCell::getInstance();
  while(true){
    tc.writeMessage(message);
    sleep(1);
  }
}

TEST_F(TestTCAPI, testCellException)
{
  TRY_BEGIN

  string rcFile = getenv("ZENITH_RC_FILE");
  unsetenv("ZENITH_RC_FILE");
  EXPECT_THROW(TestCell::getInstance(), TCException);
  setenv("ZENITH_RC_FILE", rcFile.c_str(), 1);

  TCException e;
  TRY_END_FAIL
}

// system output test
TEST_F(TestTCAPI, testWriteAndReadMessage)
{
  TRY_BEGIN
  // Generate a test cell session to run recipe
  pthread_t thread1;
  pthread_create(&thread1, NULL, startWriteMessage, (void*)this);
  SystemOutput& aSys = TestCell::getInstance().newSystemOutput(false);
  while(true){
    string output = aSys.getNext().message;
    if(output == message){
      break;
    }
    sleep(1);
  }
  TRY_END_FAIL
}


