/**
 * Copyright by Advantest, 2016
 *
 * @author  ivanlv
 * @date    Apr 15, 2016
 */
#include "AbstractTCAPITest.hpp"
//static variable definition
string AbstractTCAPITest::testHome = getenv("XOC_TEST_HOME");
string AbstractTCAPITest::wsHome = getenv("XOC_TEST_WORKSPACES");
string AbstractTCAPITest::modelFile =  testHome + "/resources/models/model.tc_test_device";
string AbstractTCAPITest::modelFileInco4 =  testHome + "/resources/models/model.dd1";
vector<string> AbstractTCAPITest::ws = vector<string>();


AbstractTCAPITest::AbstractTCAPITest()
{
  // TODO Auto-generated constructor stub

}

AbstractTCAPITest::~AbstractTCAPITest()
{
  // TODO Auto-generated destructor stub
}

// Per-test-case set-up.
void AbstractTCAPITest::SetUpTestCase()
{
  if(access("/opt/hp93000/soc/prod_env/lbin/kill_smarTest", X_OK) != 0 ||
     access("/opt/hp93000/soc/prod_env/bin/HPSmarTest", X_OK) != 0 )
  {
    throw(runtime_error("kill_smarTest and HPSmarTest are not executable. SmarTest may not be installed!"));
  }

  ws.push_back(wsHome + "/ws");
  ws.push_back(wsHome + "/dummy_ws1");
  ws.push_back(wsHome + "/dummy_ws2");
  ws.push_back(wsHome + "/dummy_ws3");
  ws.push_back(wsHome + "/dummy_ws4");
  ws.push_back(wsHome + "/ws1");
}

// Per-test-case tear-down.
void AbstractTCAPITest::TearDownTestCase()
{
}

// Per-test set-up
void AbstractTCAPITest::SetUp()
{
  int ret = system("/opt/hp93000/soc/prod_env/lbin/kill_smarTest -f");

  if(ret == -1 || WEXITSTATUS(ret) != 0)
  {
    throw(runtime_error("Failed to execute /opt/hp93000/soc/prod_env/lbin/kill_smarTest"));
  }

  sleep(1);
}

// Per-test tear-down
void AbstractTCAPITest::TearDown()
{
}
