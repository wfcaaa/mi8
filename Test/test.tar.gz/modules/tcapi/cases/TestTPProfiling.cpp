#include "xoc/tcapi/tcapi.hpp"
#include "TokenLicense.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TestTPProfiling : public AbstractTCAPITest {
protected:

  TesterSession &startTesterSession()
  {
    vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
    if (allTS.size() == 0) {

      //start a session
      return TestCell::getInstance().newTesterSession().setModelFile(modelFile).setWorkspace(
          ws[0]).start();
    }

    return *allTS[0];
  }
};

TEST_F(TestTPProfiling, testSetupLogging)
{
  TRY_BEGIN
  TesterSession &aSession = startTesterSession();
  TestProgram &aTP = aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog");
  map<TestProgramConfigName, string> kvMap;
  kvMap.insert(make_pair<TestProgramConfigName, string>(ENABLE_SETUP_LOGGING, "true"));
  EXPECT_NO_THROW(aTP.loadWithConfig(kvMap));

  aTP.bind().run().testflow("Main").execute();
  TRY_END_FAIL
}

TEST_F(TestTPProfiling, testStateLogging)
{
  TRY_BEGIN
  TesterSession &aSession = startTesterSession();
  TestProgram &aTP = aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog");
  map<TestProgramConfigName, string> kvMap;
  kvMap.insert(make_pair<TestProgramConfigName, string>(ENABLE_STATE_LOGGING, "true"));
  EXPECT_NO_THROW(aTP.loadWithConfig(kvMap));

  aTP.bind().run().testflow("Main").execute();
  TRY_END_FAIL
}

