
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TestCompatibility : public ::testing::Test
{

protected:

  // Per-test-case set-up.
  static void SetUpTestCase()
  {
  }

  // Per-test-case tear-down.
  static void TearDownTestCase()
  {
  }

  // Per-test set-up
  virtual void SetUp()
  {
  }

  // Per-test tear-down
  virtual void TearDown()
  {
  }


  void executeApplication(string name)
  {
    TestProgram::State rState = TestProgram::UNDEFINED;
    string testBed = getenv("XOC_TEST_BED");

    TRY_BEGIN

    string command = testBed + "/applications/binary_compatibility/app/" + name;
    int ret = system(command.c_str());
    ASSERT_EQ(ret, 0);

    TRY_END_FAIL
  }
};


  TEST_F(TestCompatibility, binaryCompatibility_8210_fa)
  {
    executeApplication("testcellaccess_8.2.1.0_fa");
  }
  
  TEST_F(TestCompatibility, binaryCompatibility_8200_fa)
  {
    executeApplication("testcellaccess_8.2.0.0_fa");
  }
  
  TEST_F(TestCompatibility, binaryCompatibility_2110_fa)
  {
    executeApplication("testcellaccess_2.11.0_fa");
  }

  TEST_F(TestCompatibility, binaryCompatibility_8220_fa)
 {
  executeApplication("testcellaccess_8.2.2.0_fa");
 }

  TEST_F(TestCompatibility, binaryCompatibility_8230_fa)
 {
  executeApplication("testcellaccess_8.2.3.0_fa");
 }

  TEST_F(TestCompatibility, binaryCompatibility_8250_fa)
 {
  executeApplication("testcellaccess_8.2.5.0_fa");
 }


TEST_F(TestCompatibility, binaryCompatibility_230_fa)
{
  executeApplication("testcellaccess_2.3.0_fa");
}

TEST_F(TestCompatibility, binaryCompatibility_240_fa)
{
  executeApplication("testcellaccess_2.4.0_fa");
}

TEST_F(TestCompatibility, binaryCompatibility_250_fa)
{
  executeApplication("testcellaccess_2.5.0_fa");
}

TEST_F(TestCompatibility, Compatibility_260_fa)
{
  executeApplication("testcellaccess_2.6.0_fa");
}

TEST_F(TestCompatibility, Compatibility_8310_fa)
{
  executeApplication("testcellaccess_8.3.1.0_fa");
}

TEST_F(TestCompatibility, Compatibility_8300_fa)
{
  executeApplication("testcellaccess_8.3.0.0_fa");
}



