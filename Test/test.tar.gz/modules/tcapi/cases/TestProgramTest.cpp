
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TestProgramTest : public AbstractTCAPITest
{
protected:

  TesterSession &startTesterSession()
  {
    vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
    if(allTS.size() == 0)
    {

      //start a session
      return  TestCell::getInstance().
                        newTesterSession().
                        setModelFile(modelFile).
                        setWorkspace(ws[0]).
                        start();
    }

    return *allTS[0];
  }

  void stopTesterSession()
  {
    vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
    for(unsigned int i = 0; i < allTS.size(); i++ )
    {
      allTS[i]->stop();
    }
  }
};

//normal/sequential test program operations
TEST_F(TestProgramTest, normalTPRun)
{
  TestProgram::State rState = TestProgram::UNDEFINED;
  string rName = "";
  string rWS = "";

  TRY_BEGIN

  TesterSession &aSession = startTesterSession();

  WorkspaceData rWs = aSession.getWorkspace();
  ASSERT_EQ(rWs.testProgramPaths.size(), 5);
  ASSERT_EQ(aSession.testProgram().getState(), TestProgram::UNDEFINED);

  //continuously activate the tp for 5 times
  for(int i = 0; i < 5; i++)
  {
    aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog");
    ASSERT_EQ(aSession.testProgram().getState(), TestProgram::ACTIVATED);
    ASSERT_EQ(aSession.testProgram().getPath(), "tc_test_device/src/common/tc_test_4_sites.prog");

    aSession.testProgram().load();
    ASSERT_EQ(aSession.testProgram().getState(), TestProgram::LOADED);
    aSession.testProgram().bind();
    ASSERT_EQ(aSession.testProgram().getState(), TestProgram::BOUND);
    aSession.testProgram().run();
    ASSERT_EQ(aSession.testProgram().getState(), TestProgram::RUNNING);
  }

  stopTesterSession();

  TRY_END_FAIL
}


//list all test flows
TEST_F(TestProgramTest, listTestflows)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog").load();
  vector<Testflow *> testflows = aSession.testProgram().getTestflows();
  ASSERT_EQ(testflows.size(), 9);

  bool foundMain = false;
  bool foundPreBind = false;
  bool foundPreStart = false;
  bool foundPreRun = false;
  bool foundPreStop = false;
  bool foundPowerUp = false;
  bool foundPowerDown = false;
  bool foundSubFlow = false;
  bool foundContinuityFlow = false;

  for(unsigned int i = 0; i < testflows.size(); i++)
  {
    if(testflows[i]->getName() == "Main")
    {
      ASSERT_EQ(testflows[i]->isMainFlow(), true);
      ASSERT_EQ(testflows[i]->getPath(), "common/Main.flow");
      foundMain = true;
    }
    else if(testflows[i]->getName() == "PreBind")
    {
      ASSERT_EQ(testflows[i]->isMainFlow(), false);
      ASSERT_EQ(testflows[i]->getPath(), "common/PreBind.flow");
      foundPreBind = true;
    }
    if(testflows[i]->getName() == "PreStart")
    {
      ASSERT_EQ(testflows[i]->isMainFlow(), false);
      ASSERT_EQ(testflows[i]->getPath(), "common/PreStart.flow");
      foundPreStart = true;
    }
    else if(testflows[i]->getName() == "PreRun")
    {
      ASSERT_EQ(testflows[i]->isMainFlow(), false);
      ASSERT_EQ(testflows[i]->getPath(), "common/PreRun.flow");
      foundPreRun = true;
    }
    if(testflows[i]->getName() == "PreStop")
    {
      ASSERT_EQ(testflows[i]->isMainFlow(), false);
      ASSERT_EQ(testflows[i]->getPath(), "common/PreStop.flow");
      foundPreStop = true;
    }
    else if(testflows[i]->getName() == "PowerUp")
    {
      ASSERT_EQ(testflows[i]->isMainFlow(), false);
      ASSERT_EQ(testflows[i]->getPath(), "common/PowerUp.flow");
      foundPowerUp = true;
    }
    else if(testflows[i]->getName() == "PowerDown")
    {
      ASSERT_EQ(testflows[i]->isMainFlow(), false);
      ASSERT_EQ(testflows[i]->getPath(), "common/PowerDown.flow");
      foundPowerDown = true;
    }
    else if(testflows[i]->getName() == "SubFlow")
    {
      ASSERT_EQ(testflows[i]->isMainFlow(), false);
      ASSERT_EQ(testflows[i]->getPath(), "common/SubFlow.flow");
      foundSubFlow = true;
    }
    else if(testflows[i]->getName() == "Continuity")
    {
      ASSERT_EQ(testflows[i]->isMainFlow(), false);
      ASSERT_EQ(testflows[i]->getPath(), "common/continuity.flow");
      foundContinuityFlow = true;
    }
  }

  ASSERT_EQ(foundMain, true);
  ASSERT_EQ(foundPreBind, true);
  ASSERT_EQ(foundPreStart, true);
  ASSERT_EQ(foundPreRun, true);
  ASSERT_EQ(foundPreStop, true);
  ASSERT_EQ(foundPowerUp, true);
  ASSERT_EQ(foundPowerDown, true);
  ASSERT_EQ(foundSubFlow, true);
  ASSERT_EQ(foundContinuityFlow, true);

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, executeMainflow_Site_1234)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();

  long enabledSitesA[4] = {1,2,3,4};
  vector<long> enabledSites(enabledSitesA, enabledSitesA + 4);

  aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog").load().bind().run();
  TestResults tr = aSession.testProgram().testflow().setEnabledSites(enabledSites).execute();

  ASSERT_EQ(tr.binResult.size(), 4);

  for(long site = 1; site <= 4; site++)
  {
    ASSERT_EQ(tr.binResult[site].id, 10);
    ASSERT_EQ(tr.binResult[site].hardBinId, 1);
    ASSERT_EQ(tr.binResult[site].name, "SB_10");
    ASSERT_EQ(tr.binResult[site].resultType, PASS);
    ASSERT_EQ(tr.binResult[site].color, 4);
  }

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, executeMainflow_Site_3)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();

  long enabledSitesA[1] = {3};
  vector<long> enabledSites(enabledSitesA, enabledSitesA + 1);

  aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog").load().bind().run();
  TestResults tr = aSession.testProgram().testflow().setEnabledSites(enabledSites).execute();

  ASSERT_EQ(tr.binResult.size(), 1);

  ASSERT_EQ(tr.binResult[3].id, 10);
  ASSERT_EQ(tr.binResult[3].hardBinId, 1);
  ASSERT_EQ(tr.binResult[3].name, "SB_10");
  ASSERT_EQ(tr.binResult[3].resultType, PASS);
  ASSERT_EQ(tr.binResult[3].color, 4);

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, executeSubflow_Site_1234)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();

  long enabledSitesA[4] = {1,2,3,4};
  vector<long> enabledSites(enabledSitesA, enabledSitesA + 4);

  aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog").load().bind().run();
  TestResults tr = aSession.testProgram().testflow("SubFlow").setEnabledSites(enabledSites).execute();

  ASSERT_EQ(tr.binResult.size(), 4);

  for(long site = 1; site <= 4; site++)
  {
    ASSERT_EQ(tr.binResult[site].id, 20);
    ASSERT_EQ(tr.binResult[site].hardBinId, 2);
    ASSERT_EQ(tr.binResult[site].name, "SB_20");
    ASSERT_EQ(tr.binResult[site].resultType, PASS);
    ASSERT_EQ(tr.binResult[site].color, 4);
  }

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, deactivateTP)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();

  if(aSession.getVersion().version .compare(0, strlen("x.x.x"), "8.0.4") >= 0)
  {
    aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog");
    aSession.testProgram().deactivate();
    ASSERT_EQ(aSession.testProgram().getState(), TestProgram::UNDEFINED);

    aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog").load();
    aSession.testProgram().deactivate();
    ASSERT_EQ(aSession.testProgram().getState(), TestProgram::UNDEFINED);

    aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog").load().bind();
    aSession.testProgram().deactivate();
    ASSERT_EQ(aSession.testProgram().getState(), TestProgram::UNDEFINED);

    aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog").load().bind().run();
    aSession.testProgram().deactivate();
    ASSERT_EQ(aSession.testProgram().getState(), TestProgram::UNDEFINED);

    aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog").load().bind().run().stop();
    aSession.testProgram().deactivate();
    ASSERT_EQ(aSession.testProgram().getState(), TestProgram::UNDEFINED);
  }
  else
  {
    SUCCEED() << "Cases bypassed for SMT < 8.0.4";
  }

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, execute_with_config_new)
{
  TRY_BEGIN

  ofstream aFile;
  aFile.open("testbed/per_test_result");

  TesterSession &aSession = startTesterSession();

  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog");
  Testflow& tf = tp.load().bind().run().testflow("Continuity");

  vector<long> enabledSites;
  enabledSites.push_back(1);
  enabledSites.push_back(2);
  enabledSites.push_back(3);
  enabledSites.push_back(4);

  map<string, string> config;
  config["ENABLE_PER_TEST_RESULTS"] = "true";
  ExtendedTestResultsPerTest result = tf.setEnabledSites(enabledSites).executeWithConfig(config);

  // Verify the binResult
  aFile << "\n==========================  Bin Result  ======================================================\n";
  std::map<long,SoftBin> binResult = result.binResult;
  std::map<long,SoftBin>::const_iterator binResultIt = binResult.begin();
  while(binResultIt != binResult.end())
  {
    aFile << "site : " << binResultIt->first << ", bin number : " << binResultIt->second.id << ", bin name : " << binResultIt->second.name << "\n";
    binResultIt++;
  }

  // Verify the signalResults
  aFile << "\n==========================  Signal Result  ===================================================\n";
  std::map< long,std::vector<SignalResult> > signalResults = result.signalResults;
  std::map< long,std::vector<SignalResult> >::const_iterator signalResultsIt = signalResults.begin();
  while(signalResultsIt != signalResults.end())
  {
    aFile << "site : " << signalResultsIt->first << "\n";
    std::vector<SignalResult> sigResults = signalResultsIt->second;
    for(size_t i = 0; i < sigResults.size();i++)
    {
      SignalResult sigResult = sigResults[i];
      aFile << "  signal name : " << sigResult.name << ", pogo pin : " << sigResult.pogoPin << " ,isPassed : " << (sigResult.isPassed ? "True" : "False") << "\n";
    }

    signalResultsIt++;
  }

  //ExtendedTestResultsPerTest::testResults
  aFile << "\n==========================  Extended Signal Result  ==========================================\n";
  std::map< long, std::vector< ExtendedSignalResult > > testResults = result.testResults;
  std::map< long, std::vector< ExtendedSignalResult > >::const_iterator testResultsIt = testResults.begin();
  while(testResultsIt != testResults.end())
  {
    aFile << "  site : " << testResultsIt->first << "\n";
    std::vector< ExtendedSignalResult > signalResultPerTestCol =  testResultsIt->second;
    for(size_t i = 0; i < signalResultPerTestCol.size(); i++)
    {
      aFile << "    signal name : " << signalResultPerTestCol[i].name << ", pogo pin : " << signalResultPerTestCol[i].pogoPin << ", isPassed : " << (signalResultPerTestCol[i].isPassed ? "True" : "False") << "\n";
      std::vector< SignalResultPerTest > signalResultPerTest = signalResultPerTestCol[i].signalResultPerTest;
      for(size_t j = 0; j < signalResultPerTest.size(); j++)
      {
        SignalResultPerTest perTest = signalResultPerTest[j];
        aFile << "    test name          : " << perTest.testName << "\n";
        aFile << "    isPassed           : " << (perTest.isPassed ? "True" : "False") << "\n";
        aFile << "    has value          : " << (perTest.hasParametricValue ? "True" : "False") << "\n";
        aFile << "    unit               : " << perTest.unit << "\n";
        aFile << "    value              : " << perTest.resultValue << "\n";
        aFile << "    low limit          : " << perTest.lowLimit << "\n";
        aFile << "    high limit         : " << perTest.highLimit << "\n";
        aFile << "    value scaling      : " << perTest.valueScalingExponent << "\n";
        aFile << "    low limit scaling  : " << perTest.lowLimitScalingExponent << "\n";
        aFile << "    high limit scaling : " << perTest.highLimitScalingExponent << "\n\n";
      }
    }
    testResultsIt++;
  }

  aFile.close();

  // Compare the result file with template
  string command = "diff testbed/per_test_result testbed/per_test_result_template";
  FILE *pInfo = popen(command.c_str(), "r");

  bool isDiffPassed = true;
  char testprogramBuffer[1024] = {0};
  int  bufSize = sizeof(testprogramBuffer) - 1;
  fgets(testprogramBuffer, bufSize, pInfo);
  if(strlen(testprogramBuffer) != 0)
  {
    while(NULL != fgets(testprogramBuffer, bufSize, pInfo))
    {
      cout << testprogramBuffer;
    }

    isDiffPassed = false;
  }

  pclose(pInfo);
  pInfo = NULL;

  ASSERT_EQ(isDiffPassed, true);

  stopTesterSession();
  TRY_END_FAIL
}


TEST_F(TestProgramTest, execute_with_config_new_exception)
{
  TRY_BEGIN
  TesterSession &aSession = startTesterSession();

  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog");
  Testflow& tf = tp.load().bind().run().testflow("Continuity");

  map<string, string> config;
  config["ENABLE_PER_TEST_RESULTS_INVALID"] = "true";
  EXPECT_THROW(tf.executeWithConfig(config), TCException);

  stopTesterSession();
  TRY_END_FAIL
}


TEST_F(TestProgramTest, execute_with_config)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();

  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog");
  Testflow& tf = tp.load().bind().run().testflow("Continuity");

  vector<long> enabledSites;
  enabledSites.push_back(1);
  enabledSites.push_back(2);
  enabledSites.push_back(3);
  enabledSites.push_back(4);

  TestflowConfig config;
  config.enablePerSignalResult = true;
  ExtendedTestResults result = tf.setEnabledSites(enabledSites).executeWithConfig(config);

  // Verify the binResult
  std::map<long,SoftBin> binResult = result.binResult;
  ASSERT_EQ(binResult.size(), 4);
  ASSERT_EQ(binResult[1].id, 30);
  ASSERT_EQ(binResult[1].hardBinId, 3);
  ASSERT_EQ(binResult[1].name, "SB_30");
  ASSERT_EQ(binResult[1].resultType, FAIL);
  ASSERT_EQ(binResult[1].color, 4);

  // Verify the signalResults
  std::map< long,std::vector<SignalResult> > signalResultsPerSite = result.signalResults;
  ASSERT_EQ(signalResultsPerSite.size(), 4);
  std::vector<SignalResult> signalResults = signalResultsPerSite[1];
  ASSERT_EQ(signalResults.size(), 1);
  ASSERT_EQ(signalResults[1].name, "P");
  ASSERT_EQ(signalResults[1].pogoPin, "10201");
  ASSERT_EQ(signalResults[1].isPassed, false);
  signalResults.clear();
  signalResults = signalResultsPerSite[2];
  ASSERT_EQ(signalResults.size(), 1);
  ASSERT_EQ(signalResults[1].name, "P");
  ASSERT_EQ(signalResults[1].pogoPin, "10202");
  ASSERT_EQ(signalResults[1].isPassed, true);
  signalResults.clear();
  signalResults = signalResultsPerSite[3];
  ASSERT_EQ(signalResults.size(), 1);
  ASSERT_EQ(signalResults[1].name, "P");
  ASSERT_EQ(signalResults[1].pogoPin, "10203");
  ASSERT_EQ(signalResults[1].isPassed, false);
  signalResults.clear();
  signalResults = signalResultsPerSite[4];
  ASSERT_EQ(signalResults.size(), 1);
  ASSERT_EQ(signalResults[1].name, "P");
  ASSERT_EQ(signalResults[1].pogoPin, "10204");
  ASSERT_EQ(signalResults[1].isPassed, false);

  tf.getLastTestResults();

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, input_output_parameter)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();

  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog");
  Testflow& tf = tp.load().bind().run().testflow("Main");

  vector<long> enabledSites;
  enabledSites.push_back(1);
  enabledSites.push_back(2);
  enabledSites.push_back(3);
  enabledSites.push_back(4);

  // Test parameter with type string
  {
    MultiSiteString value;
    value.setCommon("a");
    value.set(1, "b");
    value.set(3, "c");
    value.set(4, "d");

    tf.setEnabledSites(enabledSites).setInputParameter("param_in_string", value).execute();
    MultiSiteString out = tf.getOutputParamString("param_out_string");
    ASSERT_EQ(out.get(1), "b");
    ASSERT_EQ(out.get(2), "a");
    ASSERT_EQ(out.get(3), "c");
    ASSERT_EQ(out.get(4), "d");
  }

  // Test parameter with type long
  {
    MultiSiteString value;
    value.setCommon("0");
    value.set(1, "1");
    value.set(3, "2");
    value.set(4, "3");

    tf.setEnabledSites(enabledSites).setInputParameter("param_in_long", value).execute();
    MultiSiteString out = tf.getOutputParamString("param_out_long");
    ASSERT_EQ(out.get(1), "1");
    ASSERT_EQ(out.get(2), "0");
    ASSERT_EQ(out.get(3), "2");
    ASSERT_EQ(out.get(4), "3");
  }

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, output_parameter_with_exception)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog");
  Testflow& tf = tp.load().bind().run().testflow("Main");

  // Test output parameter should not be empty
  EXPECT_THROW(tf.getOutputParamString(""), TCException);
  // Test output parameter name does not exist
  EXPECT_THROW(tf.getOutputParamString("param_out_exception"), TCException);

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, testTCTPVariable_String)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").load();

  string tcVariableName = "a_variable";
  string tpVariableName = "STDF.PART_TXT";
  string commonValue = "the_value";
  string valueSite1 = "value_site1";
  string valueSite3 = "value_site3";

  // Test tc variable
  {
    tp.setTCVariable(tcVariableName, commonValue);
    MultiSiteString var = tp.getTCVariableString(tcVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);

    //set site specific value
    var.set(1,valueSite1);
    var.set(3,valueSite3);

    //test site specific values after set/get operation
    tp.setTCVariable(tcVariableName, var);
    MultiSiteString var1 = tp.getTCVariableString(tcVariableName);
    ASSERT_EQ(var1.isCommon(), false);
    EXPECT_THROW(var1.getCommon(), TCException);
    ASSERT_EQ(var1.get(1), valueSite1);
    ASSERT_EQ(var1.get(2), commonValue);
    ASSERT_EQ(var1.get(3), valueSite3);
    ASSERT_EQ(var1.get(4), commonValue);
  }

  // test tp variable
  {
    tp.setTPVariable(tpVariableName, commonValue);
    MultiSiteString var = tp.getTPVariableString(tpVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);

    //set site specific value
    var.set(1,valueSite1);
    var.set(3,valueSite3);

    //test site specific values after set/get operation
    tp.setTPVariable(tpVariableName, var);
    MultiSiteString var1 = tp.getTPVariableString(tpVariableName);
    ASSERT_EQ(var1.isCommon(), false);
    EXPECT_THROW(var1.getCommon(), TCException);
    ASSERT_EQ(var1.get(1), valueSite1);
    ASSERT_EQ(var1.get(2), commonValue);
    ASSERT_EQ(var1.get(3), valueSite3);
    ASSERT_EQ(var1.get(4), commonValue);
  }

  // test tp variable(char *)
  {
    tp.setTPVariable(tpVariableName, "the_value");
    MultiSiteString var = tp.getTPVariableString(tpVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);
  }

  // test tc variable(char *)
  {
    tp.setTCVariable(tcVariableName, "the_value");
    MultiSiteString var = tp.getTCVariableString(tcVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);
  }

  //test exception
  {
    EXPECT_THROW(tp.getTCVariableString(""), TCException);
    EXPECT_THROW(tp.getTCVariableString("variable_not_exist"), TCException);
    EXPECT_THROW(tp.getTPVariableString(""), TCException);
    EXPECT_THROW(tp.getTPVariableString("variable_not_exist"), TCException);
    EXPECT_THROW(tp.setTCVariable("", commonValue), TCException);
    EXPECT_THROW(tp.setTPVariable("", commonValue), TCException);
    EXPECT_THROW(tp.setTCVariable("", MultiSiteString()), TCException);
    EXPECT_THROW(tp.setTPVariable("", MultiSiteString()), TCException);
  }

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, testTCTPVariable_Long)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").load();

  string tcVariableName = "a_variable";
  string tpVariableName = "STDF.STAT_NUM";
  long commonValue = 10;
  long valueSite1 = 1;
  long valueSite3 = 3;

  // Test tc variable
  {
    tp.setTCVariable(tcVariableName, commonValue);
    MultiSiteLong var = tp.getTCVariableLong(tcVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);

    //set site specific value
    var.set(1,valueSite1);
    var.set(3,valueSite3);

    //test site specific values after set/get operation
    tp.setTCVariable(tcVariableName, var);
    MultiSiteLong var1 = tp.getTCVariableLong(tcVariableName);
    ASSERT_EQ(var1.isCommon(), false);
    EXPECT_THROW(var1.getCommon(), TCException);
    ASSERT_EQ(var1.get(1), valueSite1);
    ASSERT_EQ(var1.get(2), commonValue);
    ASSERT_EQ(var1.get(3), valueSite3);
    ASSERT_EQ(var1.get(4), commonValue);
  }

  // Test tp variable
  {
    tp.setTPVariable(tpVariableName, commonValue);
    MultiSiteLong var = tp.getTPVariableLong(tpVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);

    //set site specific value
    var.set(1,valueSite1);
    var.set(3,valueSite3);

    //test site specific values after set/get operation
    tp.setTPVariable(tpVariableName, var);
    MultiSiteLong var1 = tp.getTPVariableLong(tpVariableName);
    ASSERT_EQ(var1.isCommon(), false);
    EXPECT_THROW(var1.getCommon(), TCException);
    ASSERT_EQ(var1.get(1), valueSite1);
    ASSERT_EQ(var1.get(2), commonValue);
    ASSERT_EQ(var1.get(3), valueSite3);
    ASSERT_EQ(var1.get(4), commonValue);
  }

  // Test tp variable(int)
  {
    tp.setTPVariable(tpVariableName, (int)commonValue);
    MultiSiteLong var = tp.getTPVariableLong(tpVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);
  }

  // Test tc variable(int)
  {
    tp.setTCVariable(tcVariableName, (int)commonValue);
    MultiSiteLong var = tp.getTCVariableLong(tcVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);
  }

  //test exception
  {
    EXPECT_THROW(tp.getTCVariableLong(""), TCException);
    EXPECT_THROW(tp.getTCVariableLong("variable_not_exist"), TCException);
    EXPECT_THROW(tp.getTPVariableLong(""), TCException);
    EXPECT_THROW(tp.getTPVariableLong("variable_not_exist"), TCException);
    EXPECT_THROW(tp.setTCVariable("", commonValue), TCException);
    EXPECT_THROW(tp.setTPVariable("", commonValue), TCException);
    EXPECT_THROW(tp.setTCVariable("", MultiSiteLong()), TCException);
    EXPECT_THROW(tp.setTPVariable("", MultiSiteLong()), TCException);
  }

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, testTCTPVariable_Double)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").load();

  string tcVariableName = "a_variable";
  string tpVariableName = "STDF.WAFR_SIZ";
  double commonValue = 10.0;
  double valueSite1 = 1.0;
  double valueSite3 = 3.0;

  // Test tc variable
  {
    tp.setTCVariable(tcVariableName, commonValue);
    MultiSiteDouble var = tp.getTCVariableDouble(tcVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);

    //set site specific value
    var.set(1,valueSite1);
    var.set(3,valueSite3);

    //test site specific values after set/get operation
    tp.setTCVariable(tcVariableName, var);
    MultiSiteDouble var1 = tp.getTCVariableDouble(tcVariableName);
    ASSERT_EQ(var1.isCommon(), false);
    EXPECT_THROW(var1.getCommon(), TCException);
    ASSERT_EQ(var1.get(1), valueSite1);
    ASSERT_EQ(var1.get(2), commonValue);
    ASSERT_EQ(var1.get(3), valueSite3);
    ASSERT_EQ(var1.get(4), commonValue);
  }

  // Test tp variable
  {
    tp.setTPVariable(tpVariableName, commonValue);
    MultiSiteDouble var = tp.getTPVariableDouble(tpVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);

    //set site specific value
    var.set(1,valueSite1);
    var.set(3,valueSite3);

    //test site specific values after set/get operation
    tp.setTPVariable(tpVariableName, var);
    MultiSiteDouble var1 = tp.getTPVariableDouble(tpVariableName);
    ASSERT_EQ(var1.isCommon(), false);
    EXPECT_THROW(var1.getCommon(), TCException);
    ASSERT_EQ(var1.get(1), valueSite1);
    ASSERT_EQ(var1.get(2), commonValue);
    ASSERT_EQ(var1.get(3), valueSite3);
    ASSERT_EQ(var1.get(4), commonValue);
  }

  //test exception
  {
    EXPECT_THROW(tp.getTCVariableDouble(""), TCException);
    EXPECT_THROW(tp.getTCVariableDouble("variable_not_exist"), TCException);
    EXPECT_THROW(tp.getTPVariableDouble(""), TCException);
    EXPECT_THROW(tp.getTPVariableDouble("variable_not_exist"), TCException);
    EXPECT_THROW(tp.setTCVariable("", commonValue), TCException);
    EXPECT_THROW(tp.setTPVariable("", commonValue), TCException);
    EXPECT_THROW(tp.setTCVariable("", MultiSiteDouble()), TCException);
    EXPECT_THROW(tp.setTPVariable("", MultiSiteDouble()), TCException);
  }

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, testTCTPVariable_Boolean)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").load();

  string tcVariableName = "a_variable";
  string tpVariableName = "SYS.OFFLINE";
  bool commonValue = true;
  bool valueSite1 = false;
  bool valueSite3 = false;

  // Test tc variable
  {
    tp.setTCVariable(tcVariableName, commonValue);
    MultiSiteBoolean var = tp.getTCVariableBoolean(tcVariableName);

    //verify return value
    ASSERT_EQ(var.isCommon(), true);
    ASSERT_EQ(var.getCommon(), commonValue);

    //set site specific value
    var.set(1,valueSite1);
    var.set(3,valueSite3);

    //test site specific values after set/get operation
    tp.setTCVariable(tcVariableName, var);
    MultiSiteBoolean var1 = tp.getTCVariableBoolean(tcVariableName);
    ASSERT_EQ(var1.isCommon(), false);
    EXPECT_THROW(var1.getCommon(), TCException);
    ASSERT_EQ(var1.get(1), valueSite1);
    ASSERT_EQ(var1.get(2), commonValue);
    ASSERT_EQ(var1.get(3), valueSite3);
    ASSERT_EQ(var1.get(4), commonValue);
  }

  // ONLY coverage test. No test against tp variable with type boolean because no such tp variable defined yet
  {
    EXPECT_THROW(tp.setTPVariable(tpVariableName, commonValue), TCException);
    MultiSiteBoolean var = tp.getTPVariableBoolean(tpVariableName);
    EXPECT_THROW(tp.setTPVariable(tpVariableName, var),TCException);
  }

  //test exception
  {
    EXPECT_THROW(tp.getTCVariableBoolean(""), TCException);
    EXPECT_THROW(tp.getTCVariableBoolean("variable_not_exist"), TCException);
    EXPECT_THROW(tp.getTPVariableBoolean(""), TCException);
    EXPECT_THROW(tp.getTPVariableBoolean("variable_not_exist"), TCException);
    EXPECT_THROW(tp.setTCVariable("", commonValue), TCException);
    EXPECT_THROW(tp.setTPVariable("", commonValue), TCException);
    EXPECT_THROW(tp.setTCVariable("", MultiSiteBoolean()), TCException);
    EXPECT_THROW(tp.setTPVariable("", MultiSiteBoolean()), TCException);
  }

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, DeleteTCVariable)
{
  TRY_BEGIN

  //these two interfaces have been deprecated
  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();

  EXPECT_THROW(tp.deleteTCVariable("variable"), TCException);
  EXPECT_THROW(tp.deleteTCVariables(), TCException);

  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, MultiSiteVariable)
{
  TRY_BEGIN

  string varName = "aVariable";
  string commonValue = "the_value";
  string valueSite1 = "value_site1";
  string valueSite3 = "value_site3";
  MultiSiteString var;

  //test common value locally
  var.setCommon(commonValue);
  ASSERT_EQ(var.isCommon(), true);
  ASSERT_EQ(var.getCommon(), commonValue);
  ASSERT_EQ(var.get(1), commonValue);
  ASSERT_EQ(var.get(2), commonValue);
  ASSERT_EQ(var.get(3), commonValue);
  ASSERT_EQ(var.get(4), commonValue);

  //test site specific values locally
  var.set(1,valueSite1);
  var.set(3,valueSite3);
  ASSERT_EQ(var.isCommon(), false);
  EXPECT_THROW(var.getCommon(), TCException);
  ASSERT_EQ(var.get(1), valueSite1);
  ASSERT_EQ(var.get(2), commonValue);
  ASSERT_EQ(var.get(3), valueSite3);
  ASSERT_EQ(var.get(4), commonValue);

  TRY_END_FAIL
}

TEST_F(TestProgramTest, loadWithConfig)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog");

  TestProgramConfig config;
  config.enablePerfData = false;
  tp.loadWithConfig(config);

  // [TODO] Add verification to the result of loadWithConfig()
  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, loadWithConfig_new)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog");

  map<TestProgramConfigName, string> config;
  config[ENABLE_PERF_DATA] = "TRUE";
  config[ENABLE_LICENSE_LOGGING] = "TRUE";
  config[ENABLE_MAINTENANCE_CHECK] = "FALSE";
  config[ENABLE_EXECUTING_PROFILING] = "FALSE";
  config[ENABLE_SETUP_GENERATION_ALLOWED] = "FALSE";

  tp.loadWithConfig(config);

  // [TODO] Add verification to the result of loadWithConfig()
  stopTesterSession();
  TRY_END_FAIL
}

TEST_F(TestProgramTest, getCurrentDutBoardFile)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  ASSERT_EQ(tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").getCurrentDutBoardFile(), "common/QuadSites.dbd");
  stopTesterSession();

  TRY_END_FAIL
}

TEST_F(TestProgramTest, getTPLicenseFile)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").load();

  TestProgramLicenseInfo tpInfo = tp.getTestProgramLicenseFile();
  stopTesterSession();

  TRY_END_FAIL
}

TEST_F(TestProgramTest, getTPLicenseFileWithCategory)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").load();

  EXPECT_THROW(tp.getTestProgramLicenseFileWithCategory(false, "A", vector< string>()), TCException);
  stopTesterSession();

  TRY_END_FAIL
}

TEST_F(TestProgramTest, getConfiguredSites)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  vector<long> configuredSite = tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").getConfiguredSites();
  ASSERT_EQ(configuredSite[0],1);
  ASSERT_EQ(configuredSite[1],2);
  ASSERT_EQ(configuredSite[2],3);
  ASSERT_EQ(configuredSite[3],4);
  stopTesterSession();

  TRY_END_FAIL
}

TEST_F(TestProgramTest, loadWithConfig_resetTestprogram)
{
  TRY_BEGIN

  map<TestProgramConfigName, string> config;
  config[ENABLE_RESET_TESTPROGRAM] = "FALSE";

  TesterSession &aSession = startTesterSession();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").loadWithConfig(config).bind();

  int siteNum = tp.getAvailableSites().size();
  ASSERT_LT(0, siteNum);
  long CenterXDefault = tp.getTPVariableLong("STDF.CENTER_X").get(1);
  tp.setTPVariable("STDF.CENTER_X", 1);
  tp.setTPVariable("STDF.BURN_TIM", 2);  
  tp.run();
  tp.stop();

  //ENABLE_RESET_TESTPROGRAM = false
  tp.loadWithConfig(config).bind();
  tp.setTPVariable("STDF.CENTER_X", 3);
  tp.run();
  tp.stop();

  long centerXOne = tp.getTPVariableLong("STDF.CENTER_X").get(1);
  long burnTimOne = tp.getTPVariableLong("STDF.BURN_TIM").get(1);
  ASSERT_EQ(centerXOne, 3);
  ASSERT_EQ(burnTimOne, 2);

  //ENABLE_RESET_TESTPROGRAM = true
  config[ENABLE_RESET_TESTPROGRAM] = "TRUE";
  tp.loadWithConfig(config).bind();
  tp.setTPVariable("STDF.BURN_TIM", 4);
  tp.run();

  long centerXTwo = tp.getTPVariableLong("STDF.CENTER_X").get(1);
  long burnTimTwo = tp.getTPVariableLong("STDF.BURN_TIM").get(1);
  ASSERT_EQ(centerXTwo, CenterXDefault);
  ASSERT_EQ(burnTimTwo, 4);
  tp.stop();

  stopTesterSession();
  TRY_END_FAIL
}
