
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TestMaintenance : public AbstractTCAPITest
{
protected:

  TesterSession &startTesterSession()
  {
    vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
    if(allTS.size() == 0)
    {

      //start a session
      return  TestCell::getInstance().
                        newTesterSession().
                        setModelFile(modelFile).
                        setWorkspace(ws[0]).
                        start();
    }

    return *allTS[0];
  }
};

TEST_F(TestMaintenance, getMaintenanceState)
{
  TRY_BEGIN

  TesterSession& aSession = startTesterSession();
  Maintenance& aMaintenance = aSession.maintenance();
  TestProgram &tp = aSession.testProgram();
  tp.activate("tc_test_device/src/common/tc_test_4_sites.prog");

  MaintenanceState maintState = aMaintenance.getMaintenanceState(MaintenanceState::TESTER, 10);
  ASSERT_EQ(maintState.state, MaintenanceState::UNKNOWN);
  ASSERT_EQ(maintState.expiration, 0);
  ASSERT_EQ(maintState.scope, MaintenanceState::TESTER);
  ASSERT_EQ(maintState.type, MaintenanceState::UNKNOWN_TYPE);
  ASSERT_EQ(maintState.option, MaintenanceState::UNKNOWN_OPTION);
  ASSERT_EQ(sizeof(maintState.supplementaryStates), 24);

  TRY_END_FAIL
}

