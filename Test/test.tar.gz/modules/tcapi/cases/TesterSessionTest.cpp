
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TesterSessionTest : public AbstractTCAPITest
{
};

//start and then shutdown single session
TEST_F(TesterSessionTest, startShutdown)
{
  string rSId = "";
  TesterSession::State rState = TesterSession::UNDEFINED;
  string rModelFile = "";
  string rWS = "";
  map<string, string> envVariable;
  envVariable["XOC_PMON_DEBUG"] = "TRUE";

  TRY_BEGIN

  //start a session
  TesterSession &aSession = TestCell::getInstance().newTesterSession();
  aSession.setModelFile(modelFile).setWorkspace(ws[0]).setEnvVariables(envVariable).start();
  rSId = aSession.getSessionId();
  rState = aSession.getState();
  rModelFile = aSession.getModelFile();
  rWS = aSession.getWorkspace().workspacePath;

  ASSERT_EQ(rSId, "TesterSession_1");
  ASSERT_EQ(rState, TesterSession::READY);
  //ASSERT_EQ(rModelFile, modelFile);
  ASSERT_EQ(rWS, ws[0]);
  ASSERT_EQ(aSession.isSWCOpen(), false);
  ASSERT_EQ(aSession.isOnline(), false);
  ASSERT_NE(aSession.getLoginUser(), "");


  //for SMT>=8.0.4.0, test the SWC automatically
  //SMT8.0.3.x always pops up the workspace selection dialog, which cannot be
  //handled by auto test
  if(aSession.getVersion().version .compare(0, strlen("x.x.x"), "8.0.4") >= 0)
  {
    //start swc
    aSession.openSWC();
    ASSERT_EQ(aSession.isSWCOpen(), true);

    //close swc
    aSession.closeSWC();
    ASSERT_EQ(aSession.isSWCOpen(), false);

    //start swc again
    aSession.openSWC();
    ASSERT_EQ(aSession.isSWCOpen(), true);
  }

  //shut down a session
  aSession.stop();
  rSId = aSession.getSessionId();
  rState = aSession.getState();
  ASSERT_EQ(rSId, "");
  ASSERT_EQ(rState, TesterSession::UNDEFINED);

  TRY_END_FAIL
}

//start and then shut down multiple session
TEST_F(TesterSessionTest, startShutdownMutiSessions)
{
  const int MAXSESSIONS = 3;

  TRY_BEGIN

  for(int i = 1; i <= MAXSESSIONS; i++)
  {
    TesterSession &aSession = TestCell::getInstance().newTesterSession();
    aSession.setModelFile(modelFile).setWorkspace(ws[i-1]).start();
    string rId = aSession.getSessionId();
    TesterSession::State rState = aSession.getState();
    string rWS = aSession.getWorkspace().workspacePath;
    stringstream eId;
    eId << "TesterSession_" << i;

    ASSERT_EQ(rId, eId.str());
    ASSERT_EQ(rState, TesterSession::READY);
    ASSERT_EQ(rWS, ws[i-1]);
  }

  vector<SoftwareVersion> testVersions = TestCell::getInstance().getTesterVersions();
  ASSERT_NO_THROW(testVersions.size());

  for(int i = 1; i <= MAXSESSIONS; i++)
  {
    stringstream expectId;
    expectId << "TesterSession_" << i;

    TesterSession &aSession = TestCell::getInstance().testerSession(expectId.str());
    aSession.stop();
    string rId = aSession.getSessionId();
    TesterSession::State rState = aSession.getState();
    ASSERT_EQ(rId, "");
    ASSERT_EQ(rState, TesterSession::UNDEFINED);
  }

  vector<TesterSession *> allSessions = TestCell::getInstance().getTesterSessions();
  ASSERT_EQ(allSessions.size(), 0);

  TRY_END_FAIL
}

//start tester session from command line and access with API
TEST_F(TesterSessionTest, differentSessionSameWorkspace)
{
  TRY_BEGIN

  TesterSession &session1 = TestCell::getInstance().newTesterSession();
  TesterSession &session2 = TestCell::getInstance().newTesterSession();

  session1.setModelFile(modelFile).setWorkspace(ws[0]).start();

  EXPECT_THROW(session1.setModelFile(modelFile).setWorkspace(ws[0]).start(), TCException);

  TRY_END_FAIL
}

TEST_F(TesterSessionTest, setOnline)
{
  TRY_BEGIN

  TesterSession &session1 = TestCell::getInstance().newTesterSession();

  EXPECT_THROW(session1.setOnline(), TCException);

  TRY_END_FAIL
}

TEST_F(TesterSessionTest, licenses)
{
  TRY_BEGIN

  TesterSession &aSession = TestCell::getInstance().newTesterSession();
  aSession.setModelFile(modelFile).setWorkspace(ws[0]).start();

  vector<LicenseInfo> licInfo = aSession.getCheckedOutLicenses();
  ASSERT_EQ(licInfo.size(), 1);

  string licFile = string(getenv("XOC_TEST_MODULE")) + "/testbed/tplf.lic";
  ifstream aTPLFFile(licFile.c_str());
  stringstream strStream;
  strStream << aTPLFFile.rdbuf();
  aTPLFFile.close();
  aSession.signTestProgramLicenseFile(strStream.str());

  EXPECT_THROW(aSession.signTestProgramLicenseFile("IVALID_KEY"), TCException);
  EXPECT_NO_THROW(aSession.getUsedLicenseFeatures());

  TRY_END_FAIL
}

TEST_F(TesterSessionTest, systemOutput)
{
  TRY_BEGIN

  TesterSession &aSession = TestCell::getInstance().newTesterSession();
  SystemOutput& output = aSession.newSystemOutput();

  TRY_END_FAIL
}

TEST_F(TesterSessionTest, Fpgadlm)
{
  TRY_BEGIN

  TesterSession &aSession = TestCell::getInstance().newTesterSession();
  aSession.start().setWorkspace(ws[0]);
  Fpgadlm &fpga = aSession.fpgadlm();
  bool state = fpga.isRunning();
  ASSERT_EQ(state, false);

  TRY_END_FAIL
}
