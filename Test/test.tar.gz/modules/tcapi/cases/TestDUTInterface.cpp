#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "exception_handling.hpp"
#include "AbstractTCAPITest.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class DutInterfaceTest : public AbstractTCAPITest {

protected:

  TesterSession &startTesterSession()
  {
    vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
    if(allTS.size() == 0)
    {

      //start a session
      return  TestCell::getInstance().
                        newTesterSession().
                        setModelFile(modelFile).
                        setWorkspace(ws[0]).
                        start();
    }

    return *allTS[0];
  }

};

//normal dut interface operations
TEST_F(DutInterfaceTest, read_write_id)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  DUTInterface& dutInterface = aSession.dutInterface();

  EXPECT_THROW(dutInterface.writeIdString(0,"test"), TCException);
  EXPECT_THROW(dutInterface.writeIdString("test"), TCException);
  dutInterface.readIdString(0);
  // [TODO] add detailed test schema to verify the function

  TRY_END_FAIL
}


