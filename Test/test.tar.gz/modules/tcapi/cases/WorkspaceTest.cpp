#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class WorkspaceTest : public ::testing::Test {

protected:

  // Per-test-case set-up.
  static void SetUpTestCase()
  {
  }

  // Per-test-case tear-down.
  static void TearDownTestCase()
  {
  }

  // Per-test set-up
  virtual void SetUp()
  {
  }

  // Per-test tear-down
  virtual void TearDown()
  {
  }

};

static string workspacePath = getenv("XOC_TEST_WORKSPACES")
    + string("/no_tplc_ws/workspace_8.3.0/");

//normal Workspace operations
TEST_F(WorkspaceTest, normalWsRun)
{
  TRY_BEGIN

  TestCell &tc = TestCell::getInstance();
  Workspace &ws = tc.workspace(workspacePath);
  vector<string> tps = ws.getTestPrograms();
  //There ara eight tps in this workspace
  ASSERT_EQ(tps.size(),1);
  vector<string> dbs = ws.getDutBoardFiles("example/src/exampleTests/Example.prog");
  //There are three dutboard files releated with tc_2_sites.prog
  ASSERT_EQ(dbs.size(),1);
  string defaultdb = ws.getDefaultDutBoardFile("example/src/exampleTests/Example.prog");
  ASSERT_EQ(defaultdb,"common/ExampleBoard.dbd");
  string version = ws.getSmarTestVersion();
  ASSERT_EQ(version,"8.3.0.0");
  bool isCompatible = ws.isCompatible("8.3.0.1");
  ASSERT_EQ(isCompatible,true);
  TRY_END_FAIL
}

TEST_F(WorkspaceTest, test_8_1_4) {
  TRY_BEGIN
  string workspacePath = getenv("XOC_TEST_WORKSPACES") + string("/no_tplc_ws/workspace_8.1.4/");
  TestCell &tc = TestCell::getInstance();
  Workspace &ws = tc.workspace(workspacePath);
  ASSERT_TRUE(ws.getSmarTestVersion() == "8.1.4.3.cs.1");
  vector<string> tps = ws.getTestPrograms();
  ASSERT_TRUE(tps.size()==3);
  ASSERT_TRUE(ws.isCompatible("8.1.4.x"));
  ASSERT_TRUE(!ws.isCompatible("8.2.0.x"));
  TRY_END_FAIL
}

TEST_F(WorkspaceTest, test_8_2_0) {
  TRY_BEGIN
  string workspacePath = getenv("XOC_TEST_WORKSPACES") + string("/no_tplc_ws/workspace_8.2.0/");
  TestCell &tc = TestCell::getInstance();
  Workspace &ws = tc.workspace(workspacePath);
  ASSERT_TRUE(ws.getSmarTestVersion() == "8.2.0.0");
  vector<string> tps = ws.getTestPrograms();
  ASSERT_TRUE(tps.size()==3);
  ASSERT_TRUE(!ws.isCompatible("8.1.4.x"));
  ASSERT_TRUE(ws.isCompatible("8.2.0.x"));

  string defaultdb = ws.getDefaultDutBoardFile("example/src/tp/TestProgram2.prog");
  vector<string> dutboardFiles = ws.getDutBoardFiles("example/src/tp/TestProgram2.prog");

  ASSERT_EQ(defaultdb,"common/dutboard2.dbd");

  ASSERT_EQ(dutboardFiles.size(),2);

  TRY_END_FAIL
}


//error use cases test
TEST_F(WorkspaceTest,errorWsRun)
{
  TRY_BEGIN

  string exceptionMessage;
  TestCell &tc = TestCell::getInstance();
  try
  {
    //case1 pass a  workpspace path which does not exist
    Workspace &ws = tc.workspace("xxxx");
  }
  catch(TCException e)
  {
    exceptionMessage = e.message;
  }
  ASSERT_EQ(exceptionMessage,"workspace path:\"xxxx/\" does not exist or is not a directory");

  try
  {
    //case2 pass a common directory path, in other words, the directory does not contain ".aproject" file
    Workspace &ws = tc.workspace("/tmp/");
  }
  catch(TCException e)
  {
    exceptionMessage = e.message;
    cout<<exceptionMessage<<endl;
  }
  ASSERT_EQ(exceptionMessage,"\"/tmp/\" does not contain \"projects.map\". Please enter a properly  workspace path. ");

  try
  {
    //case3 pass a test program which does not exist in workspace
    Workspace &ws = tc.workspace(workspacePath);
    ws.getDutBoardFiles("test/src/common/tc_2_sites.prog");
  }
  catch(TCException e)
  {
    exceptionMessage = e.message;
    cout<<exceptionMessage<<endl;
  }
  string errorMessage = "Test program \"test/src/common/tc_2_sites.prog\" does not exist in workspace \"" +workspacePath +"\"";
  ASSERT_EQ(exceptionMessage,errorMessage);

  TRY_END_FAIL
}

TEST_F(WorkspaceTest, testWorkspaceVersionAfterSmartTestStartup) {
   TRY_BEGIN
   //start a session
   string workspacePath = getenv("XOC_TEST_WORKSPACES") + string("/no_tplc_ws/workspace_8.1.4");
   TesterSession &aSession = TestCell::getInstance().newTesterSession();
   aSession.setWorkspace(workspacePath).start();

   string rWS = aSession.getWorkspace().workspacePath;
   string version = aSession.getVersion().version;

   std::vector<std::string> tps = aSession.getWorkspace().testProgramPaths;
   if(version.compare(0, strlen("x.x.x"), "8.2.0") >= 0) {
     ASSERT_TRUE(tps.size() == 0);
   } else {
     ASSERT_TRUE(tps.size() == 3);
   }
   ASSERT_EQ(rWS, workspacePath);
   TRY_END_FAIL
}
