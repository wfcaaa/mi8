
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class PHSessionTest : public ::testing::Test
{

protected:

  // Per-test-case set-up.
  static void SetUpTestCase()
  {
  }

  // Per-test-case tear-down.
  static void TearDownTestCase()
  {
  }

  // Per-test set-up
  virtual void SetUp()
  {
    string sysPath = getenv("XOC_SYSTEM");
    string killCmd = sysPath + "/bin/killPH";
    system(killCmd.c_str());
  }

  // Per-test tear-down
  virtual void TearDown()
  {
    // Shut down all SmarTest sessions
    vector<TesterSession *> allSessions = TestCell::getInstance().getTesterSessions();
    for(unsigned int i = 0; i < allSessions.size(); i++ )
    {
      allSessions[i]->stop();
    }

    // Shut down all PH sessions
    vector<PHSession *> allPHSessions = TestCell::getInstance().getPHSessions();
    for(unsigned int i = 0; i < allPHSessions.size(); i++ )
    {
      allPHSessions[i]->stop();
    }
  }
};


void inline startPHSession(PHSession &aSession){
  map<string, string> aMap;
  aMap["KEY"] = "VALUE";
  aSession.setEnvVariables(aMap);

  string sysPath = getenv("XOC_SYSTEM");
  string testModulePath = getenv("XOC_TEST_MODULE");
  string driverPath = testModulePath + "/testbed/drivers/GenericProber/TEL";
  string driverConfig = testModulePath + "/testbed/drivers/GenericProber/TEL/config/P8-GPIB-Prober-4-die-offline.cfg";
  aSession.setDriverPath(driverPath).setDriverType(PHSession::GENERIC_93K_DRIVER).setConfigPath(driverConfig).start();
}

//start and then shutdown single session
TEST_F(PHSessionTest, startShutdown)
{
  string rSId = "";
  PHSession::State rState = PHSession::UNDEFINED;


  TRY_BEGIN

  //start a session
  PHSession &aSession = TestCell::getInstance().newPHSession();
  startPHSession(aSession);

  rSId = aSession.getSessionId();
  rState = aSession.getState();
  ASSERT_EQ(rSId, "PHControl_1");
  ASSERT_EQ(rState, PHSession::READY);

  //shut down a session
  aSession.stop();
  rSId = aSession.getSessionId();
  rState = aSession.getState();
  ASSERT_EQ(rSId, "");
  ASSERT_EQ(rState, PHSession::UNDEFINED);

  TRY_END_FAIL
}

//start and shutdown multiple sessions
TEST_F(PHSessionTest, startShutdownMultipleSessions)
{
  TRY_BEGIN

  //start session one
  PHSession &session_1 = TestCell::getInstance().newPHSession();
  startPHSession(session_1);

  //start session two
  PHSession &session_2 = TestCell::getInstance().newPHSession();
  startPHSession(session_2);

  vector<PHSession*> phSessions = TestCell::getInstance().getPHSessions();
  ASSERT_EQ(phSessions.size(), 2);
  ASSERT_EQ(phSessions[0]->getSessionId(), "PHControl_1");
  ASSERT_EQ(phSessions[0]->getState(), PHSession::READY);
  ASSERT_EQ(phSessions[1]->getSessionId(), "PHControl_2");
  ASSERT_EQ(phSessions[1]->getState(), PHSession::READY);

  //even there are several ph sessions but the version should be 1
  vector<SoftwareVersion> phVersions = TestCell::getInstance().getPHVersions();
  ASSERT_EQ(phVersions.size(), 1);

  session_1.stop();
  session_2.stop();
  TRY_END_FAIL
}


//start and then shutdown single session with killPH script
TEST_F(PHSessionTest, shutdownByScript)
{
  string rSId = "";
  PHSession::State rState = PHSession::UNDEFINED;

  TRY_BEGIN

  //start a session
  //start a session
  PHSession &aSession = TestCell::getInstance().newPHSession();
  startPHSession(aSession);
  rState = aSession.getState();
  ASSERT_EQ(rState, PHSession::READY);

  string script= string(getenv("XOC_SYSTEM")) + "/bin/killPH";
  int ret = system(script.c_str());

  if(ret == -1 || WEXITSTATUS(ret) != 0)
  {
    FAIL() << "Failed to execute the killPH script to kill PH session";
  }

  sleep(1);

  ASSERT_TRUE(TestCell::getInstance().getPHSessions().size() == 0);

  TRY_END_FAIL
}

TEST_F(PHSessionTest, driverInfo)
{
  TRY_BEGIN

  //start a session
  PHSession &aSession = TestCell::getInstance().newPHSession();
  startPHSession(aSession);

  aSession.connect();

  cout << "getDriverPath : " << aSession.getDriverPath() << endl;
  cout << "getDriverType : " << (int)aSession.getDriverType() << endl;
  cout << "getConfigPath : " << aSession.getConfigPath() << endl;
  cout << "getConfigParam: " << aSession.getConfigParam("debug_level") << endl;
  cout << "getSteppingPatternFile: " << aSession.getSteppingPatternFile() << endl;
  cout << "getEnabledSites: " << aSession.getEnabledSites().size() << endl;
  cout << "getEquipmentEnabledSites: " << aSession.getEquipmentEnabledSites().size() << endl;
  cout << "getDeviceIds: " << aSession.getDeviceIds().size() << endl;
  cout << "getIdentification: " << aSession.getIdentification("driver") << endl << endl;

  aSession.setConfigParam("debug_level", "4");
  cout << "getConfigParam: " << aSession.getConfigParam("debug_level") << endl;

  //aSession.executeDriverFunction()

  aSession.setPHVariable("PH_VAR_1", "PH_VALUE_1");
  MultiSiteString PH_VALUE_2;
  aSession.setPHVariable("PH_VAR_2", PH_VALUE_2);
  aSession.getPHVariableString("PH_VAR_1");
  aSession.getPHVariables();

  EXPECT_THROW(aSession.getPHVariableString(""),TCException);  
  EXPECT_THROW(aSession.setPHVariable("",PH_VALUE_2),TCException);
  EXPECT_THROW(aSession.setPHVariable("",""),TCException); 
  EXPECT_THROW(aSession.getPHVariableString("NOT_EXIST_VAR"),TCException);

  aSession.readSTB();

  //shut down a session
  aSession.disconnect();
  aSession.stop();
  TRY_END_FAIL
}

TEST_F(PHSessionTest,normalProduction)
{
    TRY_BEGIN

     // Get the TestCell instance
    TestCell &tc = TestCell::getInstance();

    string workspacePath = string(getenv("XOC_TEST_MODULE")) + "/testbed/workspaces/ws/";
    string modelFile = string(getenv("XOC_TEST_HOME") )+ "/resources/models/model.tc_test_device" ; 
    TesterSession &ts = tc.newTesterSession();
    ts.setModelFile(modelFile).setWorkspace(workspacePath).start();

     // Activate and bind the test program
    TestProgram &tp = ts.testProgram();
    tp.activate("tc_test_device/src/common/tc_test_4_sites.prog").load().bind().run();

    PHSession &aSession = TestCell::getInstance().newPHSession();
    string SteppingPatternFile = string(getenv("XOC_TEST_MODULE")) + "/testbed/drivers/16x16wafer";
    aSession.setSteppingPatternFile(SteppingPatternFile);
    startPHSession(aSession);
    aSession.connect();
      
    aSession.loadLot();
    string lotId = string("lot_") + aSession.getIdentification("lot");
    tp.setTPVariable("STDF.LOT_ID", lotId);
    aSession.loadCassette();
    aSession.loadWafer();
    string waferId = lotId + string("_wafer_") + aSession.getIdentification("wafer");
    tp.setTPVariable("STDF.WAFER_ID", waferId);

    {
      aSession.loadDevice();
      MultiSiteLong diex, diey;
      diex.setCommon(-9999);
      diey.setCommon(-9999);
      // Query the x/y coordinate values from the PH session
      vector<PHDeviceId> deviceIds = aSession.getDeviceIds();

      // Assign the queried x/y coordinates to the variable
      for(unsigned int i = 0; i < deviceIds.size(); i++)
      {
        diex.set(deviceIds[i].site, deviceIds[i].xCoord);
        diey.set(deviceIds[i].site, deviceIds[i].yCoord);
      }

      // Set the x/y coordinate variable
      tp.setTPVariable("STDF.X_COORD", diex);
      tp.setTPVariable("STDF.Y_COORD", diey);

      // Run the test flow
      TestResults results = tp.testflow().setEnabledSites(aSession.getEnabledSites()).execute();

      // Bin the device
      aSession.setTestResults(results).binDevice();
    }

    aSession.executeProtocolCommand("ID?",false);
    aSession.executeDriverFunction("ph_get_status","id?");
    //aSession.readStausByte();
    aSession.send("Dummy");
   // aSession.receive();
    // Unload the wafer
    aSession.unloadWafer();
    // Unload the Casstte
    aSession.unloadCassette();
    // Unload the lot
    aSession.unloadLot();
    aSession.pause().resume();
    tp.stop();
    aSession.interrupt();
    // Disconnect the PH session from the prober
    aSession.disconnect();
    aSession.getAlarms();
    aSession.hasAlarm();
    aSession.clearAlarms();
    aSession.newSystemOutput();
    aSession.stop();
    cout<<"will clean up"<<endl;

    TRY_END_FAIL
}

TEST_F(PHSessionTest, otherInterface)
{
  TRY_BEGIN

  PHSession &aSession = TestCell::getInstance().newPHSession();
  startPHSession(aSession);

  EXPECT_THROW(aSession.readStausByte(vector<ushort>()), TCException);
  EXPECT_THROW(aSession.receive(0), TCException);

  TRY_END_FAIL
}
