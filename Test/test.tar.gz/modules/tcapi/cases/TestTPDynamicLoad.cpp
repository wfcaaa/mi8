#include "xoc/tcapi/tcapi.hpp"
#include "TokenLicense.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TestTPDynamicLoad : public AbstractTCAPITest {
protected:

  TesterSession &startTesterSession()
  {
    vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
    if (allTS.size() == 0) {

      //start a session
      return TestCell::getInstance().newTesterSession().setModelFile(modelFile).setWorkspace(
          ws[0]).start();
    }

    return *allTS[0];
  }
};

TEST_F(TestTPDynamicLoad, testDynamicGenerationFailed)
{
  TRY_BEGIN
  TesterSession &aSession = startTesterSession();
  aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog");
  map<TestProgramConfigName, string> kvMap;
  kvMap.insert(make_pair<TestProgramConfigName, string>(ENABLE_SETUP_GENERATION_ALLOWED, "true"));
  kvMap.insert(make_pair<TestProgramConfigName, string>(TOKEN_MESSAGE, "abc"));
  EXPECT_THROW(aSession.testProgram().loadWithConfig(kvMap), TCException);
  TRY_END_FAIL
}

TEST_F(TestTPDynamicLoad, testDynamicGenerationPassed)
{
  TRY_BEGIN
  TesterSession &aSession = startTesterSession();
  aSession.testProgram().activate("tc_test_device/src/common/tc_test_4_sites.prog");
  int durationInSec=60;
  TokenLicense::createTokenFile(durationInSec, "abcd");
  map<TestProgramConfigName, string> kvMap;
  kvMap.insert(make_pair<TestProgramConfigName, string>(ENABLE_SETUP_GENERATION_ALLOWED, "true"));
  kvMap.insert(make_pair<TestProgramConfigName, string>(TOKEN_MESSAGE, "abcd"));
  EXPECT_NO_THROW(aSession.testProgram().loadWithConfig(kvMap));
  TRY_END_FAIL
}

