
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TestDatalogFile : public AbstractTCAPITest
{
protected:

  TesterSession &startTesterSession()
  {
    vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
    if(allTS.size() == 0)
    {

      //start a session
      return  TestCell::getInstance().
                        newTesterSession().
                        setModelFile(modelFile).
                        setWorkspace(ws[0]).
                        start();
    }

    return *allTS[0];
  }
};

TEST_F(TestDatalogFile, openCloseDatalogFile)
{
  const string TEXT_DATALOG_PATH = "/tmp/text_datalog";
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  DatalogFile& aDatalogFile = aSession.datalog().newDatalogFile(TEXT_DATALOG_PATH);
  TestProgram& aTestProgram = aSession.testProgram();

  ASSERT_EQ(aDatalogFile.getPath(), TEXT_DATALOG_PATH);
  aDatalogFile.setFormatterType(DatalogFile::ASCII);
  ASSERT_EQ(aDatalogFile.getFormatterType(), DatalogFile::ASCII);

  aDatalogFile.open();
  ASSERT_EQ(aDatalogFile.getState(), DatalogFile::OPENED);

  aTestProgram.activate("tc_test_device/src/common/tc_test_4_sites.prog");
  aTestProgram.load().bind().run().testflow("Main").execute();

  aDatalogFile.pause();
  ASSERT_EQ(aDatalogFile.getState(), DatalogFile::PAUSED);
  aDatalogFile.resume();
  ASSERT_EQ(aDatalogFile.getState(), DatalogFile::OPENED);

  aDatalogFile.flush();

  aTestProgram.stop();
  aDatalogFile.close();
  ASSERT_EQ(aDatalogFile.getState(), DatalogFile::CLOSED);

  TRY_END_FAIL
}

TEST_F(TestDatalogFile, setDatalogConfig)
{
  const string TEXT_DATALOG_PATH = "/tmp/text_datalog";
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  DatalogFile& aDatalogFile = aSession.datalog().newDatalogFile(TEXT_DATALOG_PATH);

  aDatalogFile.setFormatterType(DatalogFile::ASCII).setConfigParam("datalogFilePath", "/tmp");
  ASSERT_EQ(aDatalogFile.getConfigParam("datalogFilePath"),"/tmp");

  TRY_END_FAIL
}

TEST_F(TestDatalogFile, customFormatter)
{
  const string CUSTOM_FORMATTER_PATH = "/tmp/custom_formatter.so";
  const string CUSTOM_DATALOG_PATH = "/tmp/custom_datalog";
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  DatalogFile& aDatalogFile = aSession.datalog().newDatalogFile(CUSTOM_DATALOG_PATH);

  aDatalogFile.setFormatterType(DatalogFile::CUSTOM);
  aDatalogFile.setCustomFormatterPath(CUSTOM_FORMATTER_PATH);
  ASSERT_EQ(aDatalogFile.getCustomFormatterPath(), CUSTOM_FORMATTER_PATH);

  TRY_END_FAIL
}

TEST_F(TestDatalogFile, notImplementedInerface)
{
  const string TEXT_DATALOG_PATH = "/tmp/text_datalog";
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  DatalogFile& aDatalogFile = aSession.datalog().newDatalogFile(TEXT_DATALOG_PATH);

  EXPECT_NO_THROW(aDatalogFile.clear());

  TRY_END_FAIL
}
