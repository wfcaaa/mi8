
#include "xoc/tcapi/tcapi.hpp"
#include "gtest/gtest.h"
#include "AbstractTCAPITest.hpp"
#include "exception_handling.hpp"
#include <stdlib.h>
#include <unistd.h>
#include <string>
#include <sstream>
#include <exception>

using namespace xoc::tcapi;
using namespace std;

class TestDatalog : public AbstractTCAPITest
{
protected:

  TesterSession &startTesterSession()
  {
    vector<TesterSession *> allTS = TestCell::getInstance().getTesterSessions();
    if(allTS.size() == 0)
    {

      //start a session
      return  TestCell::getInstance().
                        newTesterSession().
                        setModelFile(modelFile).
                        setWorkspace(ws[0]).
                        start();
    }

    return *allTS[0];
  }

  void buildEdlGenericDataEvent(EdlGenericDataEvent& aEvent)
  {
    // build data for test
    unsigned char unsignedCharArray[4] = {'1','2','3','4'};
    vector<unsigned char> unsignedCharCol(unsignedCharArray, unsignedCharArray + 4);

    char charArray[4] = {'5','6','7','8'};
    vector<char> charCol(charArray, charArray + 4);

    unsigned short unsignedShortArray[4] = {9, 10, 11, 12};
    vector<unsigned short> unsignedShortCol(unsignedShortArray, unsignedShortArray + 4);

    short shortArray[4] = {13, 14, 15, 16};
    vector<short> shortArrayCol(shortArray, shortArray + 4);

    unsigned int unsignedIntArray[4] = {17, 18, 19, 20};
    vector<unsigned int> unsignedIntCol(unsignedIntArray, unsignedIntArray + 4);

    int intArray[4] = {21, 22, 23, 24};
    vector<int> intCol(intArray, intArray + 4);

    unsigned long unsignedLongArray[4] = {25, 26, 27, 28};
    vector<unsigned long> unsignedLongCol(unsignedLongArray, unsignedLongArray + 4);

    long longArray[4] = {29, 30, 31, 32};
    vector<long> longCol(longArray, longArray + 4);

    float floatArray[4] = {33.0, 34.0, 35.0, 36.0};
    vector<float> floatCol(floatArray, floatArray + 4);

    double doubleArray[4] = {37.0, 38.0, 39.0, 40.0};
    vector<double> doubleCol(doubleArray, doubleArray + 4);

    // Add vector to the event
    aEvent.add(unsignedCharCol);
    aEvent.add(charCol);
    aEvent.add(unsignedShortCol);
    aEvent.add(shortArrayCol);
    aEvent.add(unsignedIntCol);
    aEvent.add(intCol);
    aEvent.add(unsignedLongCol);
    aEvent.add(longCol);
    aEvent.add(floatCol);
    aEvent.add(doubleCol);

    // Add single value to the event
    aEvent.add(unsignedCharCol[0]);
    aEvent.add(charCol[0]);
    aEvent.add(unsignedShortCol[0]);
    aEvent.add(shortArrayCol[0]);
    aEvent.add(unsignedIntCol[0]);
    aEvent.add(intCol[0]);
    aEvent.add(unsignedLongCol[0]);
    aEvent.add(longCol[0]);
    aEvent.add(floatCol[0]);
    aEvent.add(doubleCol[0]);
    aEvent.add("TEST_VALUE_STRING");
  }

  void buildTestCellEvent(EdlTestCellEvent& aTestCellEvent)
  {
    aTestCellEvent.type = "TEST_CELL_EVENT";
    map<string, string> properties;
    properties["PROPERTY_1"] = "VALUE_1";
    properties["PROPERTY_2"] = "VALUE_2";
    properties["PROPERTY_3"] = "VALUE_3";
    aTestCellEvent.properties = properties;
  }
};

TEST_F(TestDatalog, statistics)
{
  TRY_BEGIN
  long enabledSitesA[4] = {1,2,3,4};
  vector<long> enabledSites(enabledSitesA, enabledSitesA + 4);

  TesterSession &aSession = startTesterSession();
  Statistics &statistics = aSession.datalog().newStatistics().start();
  TestProgram& aTestProgram = aSession.testProgram();

  aTestProgram.activate("tc_test_device/src/common/tc_test_4_sites.prog").load()
              .bind().run().testflow("Main").setEnabledSites(enabledSites).execute();

  statistics.stop();

  /*
  AllSiteBinSummary summary =  statistics.getAllSiteBinSummary();
  cout << "all tested devices " << summary.testedDevices << endl;
  for(int i = 0; i < summary.summary.size(); i++)
   {
     cout << "  Site " << summary.summary[i].site << ", tested devices " << summary.summary[i].testedDevices << endl;
     cout << "  Software bin summary" << endl;
     for(int j = 0; j < summary.summary[i].softBinSummary.size(); j++)
     {
        cout << "    binid " << summary.summary[i].softBinSummary[j].binId << ", tested devices " << summary.summary[i].softBinSummary[j].    testedDevices << endl;
     }

      cout << "  Hardware bin summary" << endl;
     for(int j = 0; j < summary.summary[i].hardBinSummary.size(); j++)
     {
        cout << "    binid " << summary.summary[i].hardBinSummary[j].binId << ", tested devices " << summary.summary[i].hardBinSummary[j].    testedDevices << endl;
     }
   }
*/
  aTestProgram.stop();
  TRY_END_FAIL
}

TEST_F(TestDatalog, configParams)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  Datalog &aDatalog = aSession.datalog();
  TestProgram& aTestProgram = aSession.testProgram();


  map< string, string > params;
  params["testNameWidth"] = "48";
  params["testNumberWidth"] = "10";
  aDatalog.setConfigParams(DatalogFile::ASCII, params);

  ASSERT_EQ(aDatalog.getConfigParam(DatalogFile::ASCII, "testNameWidth"), "48");
  ASSERT_EQ(aDatalog.getConfigParam(DatalogFile::ASCII, "testNumberWidth"), "10");


      aTestProgram.activate("tc_test_device/src/common/tc_test_4_sites.prog").load()
                  .bind().run().testflow("Main").execute();



  aTestProgram.stop();
  TRY_END_FAIL
}

TEST_F(TestDatalog, edlGenericDataEvent)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  Datalog &aDatalog = aSession.datalog();
  TestProgram& aTestProgram = aSession.testProgram();

  EdlGenericDataEvent& aEdlEvent = aDatalog.newEdlGenericDataEvent();
  buildEdlGenericDataEvent(aEdlEvent);
  EdlTestCellEvent aTestCellEvent;
  buildTestCellEvent(aTestCellEvent);

  aDatalog.writeEdlEvent("TEST_EVENT");
  aDatalog.writeEdlEvent(aEdlEvent);
  aDatalog.writeEdlEvent(aTestCellEvent);

  aEdlEvent.clear();
  TRY_END_FAIL
}


TEST_F(TestDatalog, notImplementedInerface)
{
  TRY_BEGIN

  TesterSession &aSession = startTesterSession();
  {
    Statistics &statistics = aSession.datalog().newStatistics();
    vector<Statistics*> statisticsCol = aSession.datalog().getStatistics();
    ASSERT_EQ(statisticsCol.size(), 0);
  }

  TRY_END_FAIL
}

