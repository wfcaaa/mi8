#include<iostream>  
#include<memory>
using namespace std;

int main()
{
    shared_ptr<string> p;
    p=make_shared<string>("hi");
   // if(p && p->empty())
        //*p="hi";
    cout<<*p<<endl;
}
