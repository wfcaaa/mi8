#include<iostream> 
#include<cstdio>
using namespace std;

int main()
{
    int a[]={1,2,3};
    cout<<a<<" "<<&a[0]<<" "<<&a<<" "<<a[0]<<endl;
    char b[]="abc";
    cout<<b<<" "<<&b<<" "<<&b[0]<<" "<<b[0]<<endl;
    printf("%p %p %p\n",b,&b,&b[0]);

    cout<<"**********************poniter"<<endl;
     const char *c="abc";
    cout<<c<<" "<<&c<<" "<<&c[0]<<" "<<c[0]<<endl;
    printf("%p %p %p\n",c,&c,&c[0]);
}
