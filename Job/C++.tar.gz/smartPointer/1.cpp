#include<iostream> 
#include<cstdio>
#include<memory>
#include<cstring>
using namespace std;

int main0()
{
    shared_ptr<int> p1=make_shared<int>(9);
    cout<<p1<<endl;
    cout<<*p1<<endl;
    shared_ptr<string> p2=make_shared<string>("abced");
    cout<<p2<<endl;
    cout<<*p2<<endl;
    shared_ptr<string> p3=make_shared<string>(9,'9');
    cout<<p3<<endl;
    cout<<*p3<<endl;
    shared_ptr<char> p4=make_shared<char>('a');
    cout<<p4<<endl;
    cout<<*p4<<endl;

   


}


int main1()
{
    int b=3;
    int *p2=&b;
    cout<<p2<<endl;
    char a[5]={'a','b','c'};
    cout<<a<<endl;
    char *p=&a[0];
    cout<<p<<endl;
    printf("the addr of a is :%p,a+1:%p\n",&a,&a+1);
    for(int i;i < 5; ++i)
    {
        cout<<a[i]<<"\t";
        cout<<&a[i]<<"\t";
        printf("%c,%d,%p\t",a[i],a[i],a[i]);
        printf("%c,%d,%p\n",&a[i],&a[i],&a[i]);
    }
}

int main2()
{
    string s="fdsa";
    cout<<s<<" "<<&s[0]<<" "<<&s<<endl;
    printf("%p, %p,%s %c\n",&s[0],&s,&s[0],&s[0]);

    const char *p="qwer";
    cout<<p<<" "<<&p[0]<<" "<<&p<<endl;
     printf("%p, %p,%p %s\n",&p[0],p,&p,&p[0]);

    const char **p2=&p;
    cout<<p2<<" "<<*p2<<" "<<&(*p2[0])<<endl;
    int c[4]={1,2,3,4};
     printf("%p, %p,%s %c\n",&c[0],&c,&c[0],&c[0]);
    int *q=c;
    cout<<q[1]<<" "<<q<<" "<<&c[1]<<endl;
}

int main()
{
    const char *p="abc";
    cout<<sizeof(p)<<" "<<strlen(p)<<endl;
}
