#include<stdio.h>
#include<dlfcn.h>
#include<string.h>

#define LIB_ALGORITHM_PATH "/home/jaxwu/c++code/Exer/algorithem/myAlgorithm.so"

typedef int (*mySort)(int,int*);
int main(int argc,char* argv[])
{
    char arr[1024] = "";
    char *p =arr;
    int i = 0;
    printf("%d %d\n",strlen(p),sizeof(arr));
    strcpy(p,"ABCD");
    //p[4] = 'E';
   // for(;i<10;++i)
     //   p[i]='i';
    for(i = 0 ; i<10;++i)
        printf("%d\t",p[i]);
    printf("%d\n",strlen(p));
    void * handle =NULL;
    char * error = NULL;
    
    handle = dlopen(LIB_ALGORITHM_PATH,RTLD_NOW);
    
    if(!handle)
    {
        printf("%s %s\n",dlerror(),"open fail");
        return -1;
    }
    
    dlerror();
    mySort sort;
    
    sort = (mySort)dlsym(handle,"Sort");
    
//    printf("%d\n",sort(3,arr));
    if(sort)
    {
        printf("please input key:\n");
        int key = 0;
        scanf("%d",&key);
        printf("the key in arr index is:%d\n",sort(key,p));
    }
    else
    {
        printf("%s\n","there is no fun in lib");
        
        return -1;
    }
    return 0;
}
