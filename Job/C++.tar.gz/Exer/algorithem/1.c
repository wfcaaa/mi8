#include<stdio.h>
#include<string.h>
#define LEN(x) sizeof(x)/sizeof(x[0])
void reserval(char arr[],int len)
{
    int i =0;
    for(;i<len/2;++i)
    {
        char ch=arr[i];
        arr[i]=arr[len-1-i];
        arr[len-1-i]=ch;
    }
    printf("%s\n",arr);
}


int main()
{
    printf("%d %d %d  %d\n",'0','A','a','\77');
    int arr[10] ={1,2,3,4,5};
    int i =0;
    printf("%d \n" ,arr[i++] );
    char ar[]="this is a test";
    printf("%s %d\n",ar,strlen(ar));
    reserval(ar,strlen(ar));

}
