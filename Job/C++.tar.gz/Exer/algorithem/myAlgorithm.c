#include<stdio.h>
#include<string.h>


int  Sort(int key,char *arr)
{
    if(arr)
    {
        if(strlen(arr)>1)
        {
            if(key>=*arr&&key<=arr[strlen(arr)-1])
            {
                int lindex=0,rindex=strlen(arr)-1,mindex=lindex+(rindex-lindex)/2;
                while(lindex<rindex)
                {
                    if(key<arr[mindex])rindex=mindex-1;
                    else if(key >arr[mindex]) lindex=mindex+1;
                    else
                        return mindex;
                }
            }
            else
            {
                for(int i = 0; i<strlen(arr); ++i)
                    printf("%d\t",arr[i]);
                return -4;
            }
        }
        else
        {
            if(key == *arr)
                return 0;
            else
                return -2;
        }
    }
}
