#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;

bool IsOdd(int i)
{
    return i%2 == 1;
}
void Find(void)
{
    vector<int> v1{10,21,33,45};
    auto it = find(v1.cbegin(),v1.cend(),21);
    if(it != v1.cend())
        cout<<*it<<endl;
    sort(v1.begin(),v1.end());
    for(auto p:v1)
        cout<<p<<endl;
}
void Find_if(void)
{
    vector<int> v1{10,26,40,41};
    auto it = find_if(v1.cbegin(),v1.cend(),[](int i){return i%2 == 1;});
    cout<<*it<<endl;
}

void For_each(void)
{
    vector<string> v1;
    string line;
    cout<<"please input";
    while(getline(cin,line))
        v1.push_back(line);
     for(auto p :v1)
        cout<<p<<"\t";
    cout<<endl;
     for_each(v1.begin(),v1.end(),[](string &s){cout<<"the size of "<<s<<" is "<<s.size()<<" "<<endl;});
    sort(v1.begin(),v1.end());
    for(auto p :v1)
        cout<<p<<"\t";
    cout<<endl;
   
}

void Count_if()
{
    vector<string> v1;
    string word;
    cout<<"plese input"<<endl;
    while(cin>>word)
        v1.push_back(word);
    bool abortFlag = false;
    while(!abortFlag)
    {
        cout<<"please input the number of the word you want to checkout"<<endl;
        int num = 0;
        cin.clear();
        cin>>num;
        cout<<"the number of word which lenth greater than "<<num<<" is: "<<count_if(v1.begin(),v1.end(),[num](string& s){return s.size()>num;})<<endl;
        if(num == 0)
            abortFlag = true;
    }
}

int main()
{
    //Find();
    //Find_if();
    For_each();
    //Count_if();
}
