#ifndef _PERSON_
#define _PERSON_

#include<iostream>
using namespace std;

class Person
{
    public:
        Person(const string&,const string&,int age);
        const string getName()const;
        const int getAge()const;
    private:
        string name;
        string address;
        int age;
};
#endif
