#include"Person.hpp"

using namespace std;

Person::Person(const string& name,const string& ar,int age):name(name),address(ar),age(age){}
const string Person::getName()const
{
    return this->name;
}
const int Person::getAge()const
{
    return age;
}

