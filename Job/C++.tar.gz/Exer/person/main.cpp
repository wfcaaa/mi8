#include"Person.hpp"

int main()
{
    Person p1("a","asd",20);
    cout<<p1.getName()<<" "<<p1.getAge()<<endl;
}
