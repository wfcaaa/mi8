#include<iostream>

using namespace std;

class Base
{
    public:
     Base(string s);
     string getName() const;
    private:
     string name;
};

Base::Base(string s):name(s)
{

}

string Base::getName() const
{
     return name;
}

class Test: public Base
{
    public:
      Test(int i,string );
      int getID() const;
    private:
      int id;
};

Test::Test(int i,string s):id(i),Base(s)
{

}

int Test::getID() const
{
    return id;
}
int main()
{
    Test t(1,"test");
    Base * p = &t;
    Test * p1 = p;
    cout<<"id:"<<p1->getID()<<" name:"<<p->getName()<<endl;
    
    return 0;
}
