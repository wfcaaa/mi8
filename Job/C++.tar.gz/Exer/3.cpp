#include<iostream>
#include<stdio.h>
using namespace std;

int main()
{
    string str = "97";
    for(int i=0;i<str.size();++i)
      printf("%d ",str[i]);
    printf("\n");
    char arr[10] = "";
    int num = 570;
    sprintf(arr,"%d",num);
    printf("%s\n",arr);
    cout<<str<<endl;

    str.clear();
    cout<<"print str:"<<str<<endl;

    string s1;
    if(s1[s1.size()-1] == '\n')
        cout<<"the last character is new line"<<endl;
    else
        cout<<"the last character is not new line"<<endl;

    cout<<"capacity:"<<s1.capacity()<<endl;
}
