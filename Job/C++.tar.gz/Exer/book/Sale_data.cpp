#include<iostream>

using namespace std;

class Sale_data
{
    public:
        bool isbn()const;
        Sale_data& combine(const Sale_data& s1);
    private:
        string 
        
};
