#include<iostream>
#include<cstdio>
using namespace std;

class Base1
{
    private:
      virtual  void f(){cout<<"Base1::f()"<<endl;};
      virtual void g(){cout<<"Base1::g()"<<endl;};
      virtual  void h(){cout<<"Base1::h()"<<endl;};
};

/*class Derive:public Base1
{
    void f(){cout<<"Derive::f()"<<endl;}
};*/

typedef void (*vpFun)(void);
int main()
{
    Base1 b;
    int a = 0;
    vpFun pfun=NULL;
    cout<<sizeof(pfun)<<endl;
    cout<<"vtable address:"<<(int*)*(int*)&b<<endl;
    cout<<"fisrt vir fun address:"<<(int*)*(int*)&b<<endl;
    pfun=(vpFun)( *( (int*)*(int*)(&b)+2) );
    pfun();
    //*( (int*)*(int*)(&b)+4) 
        
        
}

