#ifndef __BOOKSHOP__
#define __BOOKSHOP__

#include<iostream>

using namespace std;
class Quote
{
    public:
        Quote() = default;
        Quote(const string & name,const double & sale_price) : bookNo(name), price(sale_price);
    public:
        virtual net_price(size_t n);
        virtual ~Quote() = default;
}

#endif
