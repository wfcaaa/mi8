#include<iostream>

using namespace std;


void test()
{
    string s = "abcdcba";
    string s1,s2;
    int len = s.size();
    if(len%2 == 0)
    {
        s1 = string(s,0,len/2);
        s2 = string(s,len/2,len/2);
    }
    else
    {
        s1 = string(s,0,len/2);
        s2 = string(s,len/2+1,len/2);
    }

    cout<<"s:"<<s<<". s1:"<<s1<<" . s2:"<<s2<<endl;
}
bool isPalinDrome(const string& str)
{
    int len =  str.size();
    int i = 0,j=len-1;
    while(i<j)
    {
        if(str[i] != str[j])
        {
          cout<<str<<" is not palinDrome string"<<endl;
          return false;
        }
        ++i;
        --j;
    }
    cout<<str<<" is palinDrome string"<<endl;
    return true;
}

void testForString(const string& str)
{
    size_t pos = str.find("=");
    if(pos!= string::npos)
    {
        string keyName = str.substr(0,pos);
        cout<<"key name:"<<keyName<<endl;
        string value = str.substr(pos+1);
        cout<<"value:"<<value<<endl;
    }
}
int main()
{
    test();
    isPalinDrome("abcba");
    isPalinDrome("abc");
    testForString("fail-go-on=false");
    string lot_id = "abc";
    cout<<lot_id<<endl;
    const char *p = "bac";
    lot_id = p;
     cout<<lot_id<<endl;
}
