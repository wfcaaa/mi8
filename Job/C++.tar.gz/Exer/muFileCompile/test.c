#include<stdio.h>
#include<string.h>
int main()
{
    char a[1024]= "abc";
    char b[1024]= "";
    printf("%s %s\n",a,b);
    strncpy(a,b,sizeof(b));
    printf("%s %s\n",a,b);
}
