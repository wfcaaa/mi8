#ifndef _1_H
#define _1_H
#include<iostream>

using namespace std;

extern string name;
extern const int id;

#endif
