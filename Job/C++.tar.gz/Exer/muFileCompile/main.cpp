#include"1.hpp"

int main()
{
    //extern string name;
//    extern const int id;
    cout<<"id is "<<id<<"  name is: "<<name<<endl;
}
