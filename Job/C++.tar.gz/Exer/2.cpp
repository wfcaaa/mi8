#include<iostream>

using namespace std;
#define MAX 10
int main()
{
    int num = 15;
    cout<<hex<<"0x"<<num<<dec<<endl;
    cout<<num<<endl;
    cout<<MAX<<endl;
}



