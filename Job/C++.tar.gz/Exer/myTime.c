#include<stdio.h>
#include<sys/time.h>
#include<time.h>
 char *gettimeString(void)
{
     char theTimeString[64];
    struct tm theLocaltime;
    time_t theTime;
    struct timeval gettime;
    
    gettimeofday(&gettime, NULL);
    theTime = (time_t) gettime.tv_sec;
    localtime_r(&theTime, &theLocaltime);
    sprintf(theTimeString, "%4d/%02d/%02d %02d:%02d:%02d.%04d",
	theLocaltime.tm_year + 1900,
	theLocaltime.tm_mon + 1,
	theLocaltime.tm_mday,
	theLocaltime.tm_hour,
	theLocaltime.tm_min,
	theLocaltime.tm_sec,
/* Begin of Huatek Modification, Donnie Tu, 12/05/2001 */
/* Issue Number: 318 */
	(int)(gettime.tv_usec/100));
/* End of Huatek Modification */

    return theTimeString;	
}

int main()
{
    char *time = gettimeString();
    printf("%s\n",time);

}
