#ifndef __UTILITY__
#define __UTILITY__

#include<iostream>
#include<boost/timer.hpp>
#include<boost/noncopyable.hpp>
#include<boost/utility.hpp>

#endif
