#include"utility.hpp"

using namespace std;

typedef void (*FUN)();

void fun1()
{
    cout<<"hello world"<<endl;
}

class Counter: public boost::noncopyable
{
    public:
        Counter():value(0){}
    private:
        int value;
};
int main()
{
    FUN f = NULL;
    f = fun1;
    f();
}
