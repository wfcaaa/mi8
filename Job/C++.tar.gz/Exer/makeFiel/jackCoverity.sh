#!/bin/sh
# @file    runCoverity.sh shell script for automizing Coverity runs
# @brief   Runs Coverity for IFX Aurix test method projects' source code
# @details Only few modules checked yet, add further modules directory to module[] array
#          Usage in special Coverity available environment:
#          - Load device and fully re-compile testmethods to create makefiles
#          - ./runCoverity.sh
#          - This creates <module_name>_html.tar.gz archives which includes 
#            <module_name>_html/index.html file with the Coverity logs
# @note    Requires Coverity to be installed
# @author  Thomas Hellmund - Advantest Europe GmbH
# @date    15th Mar 2017

# Test few modules only
# ADC/  AGBT/  CONT/  Common/  DEVCFG/  DTS/  EVR/  EVROFF/  FLASH/  FUNC/  HSCT/  IDD/  IDDQ/  IO/  OSC/  PERF/  PLL/  ROM/  SCAN/  SDADC/  SRAM/  STRESS/
  make clean
  cov-build --dir coverity-data make
  cov-analyze --all --dir coverity-data
  cov-format-errors --html-output html --dir coverity-data
