#include<iostream>
using namespace std;

class Signleton
{
    public:
     static    Signleton* getInstance();
     ~Signleton();
    private:
        Signleton(){cout<<"ctor enter"<<endl;};
        Signleton(const Signleton&);
        Signleton& operator=(const Signleton&);

        static Signleton* instance;
};
Signleton* Signleton::instance= new Signleton();
Signleton::~Signleton()
{   
    cout<<"dtor enter"<<endl;
    if(instance)
    {
        delete instance;
        instance=NULL;
    }

}
Signleton* Signleton::getInstance()
{
    if(instance==NULL)
    {
        cout<<"create instance"<<endl;
        instance=new Signleton();
    }
    else
    cout<<"instance has existed"<<endl;
    return instance;
}

void test()
{
    Signleton* i1 = Signleton::getInstance();
}
int main()
{
    test();
    return 0;
}

