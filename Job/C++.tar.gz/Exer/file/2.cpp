#include <sys/stat.h>
#include<iostream>

#include <boost/filesystem.hpp>
namespace filesys = boost::filesystem;
using namespace std;
int main() {
	struct stat buffer;
    std::string str = "/tmp/Hello/abc.svc";
    filesys::path fobj(str);

    if( filesys::exists(fobj) )
      cout<<str<<" exist"<<endl;
    else
    {
      cout<<str<<" does not exist"<<endl;
      size_t pos = str.find_last_of("/");
      string tmpFolder = str.substr(0,pos);
      cout<<"try to create "<<tmpFolder<<endl;
      filesys::create_directory(tmpFolder);
    }

}
