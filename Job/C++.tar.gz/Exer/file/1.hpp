

class Test
{
    void disPlay(const char name);
};
