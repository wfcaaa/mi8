// basic file operations
#include <iostream>
#include <fstream>
using namespace std;
ifstream myfile;

void write(ofstream& fd,string& str)
{
    fd<<str;
    fd<<"hello world\n";
}

int initLog()
{
    string str="/opt/hp93000/testcell/phcontrol/drivers/Generic_93K_Driver/GenericHandler/Seiko-Epson/config/NS5000-GPIB-4.cfg";
    myfile.open (str.c_str());
    cout<<"exit initLog"<<endl;
    return 0;
}
int main () {
  
  initLog();
  
  if(myfile.is_open())
  {
    cout << "Writing this to a file!\n";
    string str("123");
    if(str.empty())
      cout<<"str is null"<<endl;
    else
      cout<<str<<endl;
    str="";
    if(str.empty())
      cout<<"str is null"<<endl;

    getline(myfile,str);
    cout<<str<<endl;
    getline(myfile,str);
    cout<<str<<endl;
  }
  else
  {
    cout<<"open failed!"<<endl;
     myfile.close();
    return 0;
  }
   myfile.close();
  return 0;
#if 0
  string str="#############\n";
  write(myfile,str);
  myfile << "close this file.\n";
  myfile.close();
#endif
  return 0;
}
