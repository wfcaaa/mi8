#include"utility.h"

using namespace std;

template<typename T>

T factorial(T t)
{
    if(t > 1)
        return factorial(t-1) * t;
    return 1;
}

template<typename T>

void dis(const vector<T>& v1,int len)
{
    /*static int ix = 0;
    if(ix < len)
    {
        cout<<v1[ix++]<<endl;
        dis(v1,len);
    }*/

    if(len == 1)
    {    
        cout<<v1[0]<<endl;
        return;
    }
    cout<<v1[--len]<<endl;
    dis(v1,len);
    
    
    
}
int main()
{
    vector<string> v{"hello","world","this","is","a","test"};
    auto size = v.size();
    cout<<size<<endl;
    dis(v,size);
    
}
