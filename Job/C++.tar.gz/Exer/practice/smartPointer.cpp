#include<iostream>
#include<memory>

using namespace std;

void fun()
{
    shared_ptr<int> p1 = make_shared<int>(9999);
    cout<<p1.use_count()<<endl;
}

int main()
{
    fun();
}
