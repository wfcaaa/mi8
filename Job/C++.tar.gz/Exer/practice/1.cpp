#include<iostream>
#include<cstdio>
#include<ctype.h>
using namespace std;

typedef void (*FUN)();
void fun1()
{
    for(int i = 1025; i <=2048;++i)
        printf("\"%d\" ",i);
    cout<<endl;
}

void fun2()
{
    int count = 0;
    for(int i = 6,j=124 ; i <20 && count<1024;++j)
    {
        if(j>149)
        {
            j = 0;
            ++i;
        }
        printf("[%d %d] ",i,j);
        ++count;
    }
    printf("\n%d\n",count);
}

void fun3(const char*s)
{
    while(s && isxdigit(*s))
    {
        printf("%c\n",*s);
        ++s;
    }
}

char& test(string& s1,string::size_type ix)
{
    if (ix<0 || ix >s1.size()-1)
        return s1[0];
    return s1[ix];
}
void fun4()
{
    string s = "a word";
    test(s,0) = 'A';
    cout<<s<<endl;
    
}

void fun5()
{
    unsigned char a ;
    a = -1;
    printf("%d\n",a);
    char b = 356;
    printf("%d\n",b);
}
int main()
{
    FUN f= NULL;
    f = fun5;
    f();
    return 0;
}
