#include<iostream>
#include<vector>
using namespace std;

class Stu
{
    public:
         
        
        Stu(int a,string n):age(a),name(n){ cout<<"call normal constrction"<<endl;}
        Stu():Stu(0,""){cout<<"call no parameter con"<<endl;}
        ~Stu(){cout<<"call destruction"<<endl;}
        static double getRate(){return rate;}
    private:
        int age;
        string name;
    public: static double rate;
};
double Stu::rate= 0.1;
struct test
{
    Stu s;
};
void fun()
{
    
    //Stu s1(1,"ll");
    cout<<"test default construction"<<endl;
    Stu s2;
}

class NoDefault
{
    public:
        NoDefault(int n=0):age(n){}
    
        int age=0;
        int a=9 ;
};

class C
{
    public:
    C(int n=0):noDefault(n),name(""){}
    private:
    NoDefault noDefault;
    string name;
    
};
int main()
{
    cout<<Stu::rate<<" "<<Stu::getRate()<<endl;
   
}
