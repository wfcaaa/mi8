#include<iostream>
#include<algorithm>
#include<numeric>
#include<vector>

using namespace std;



void test_Count()
{
    vector<int> v1;
    int key = 0;
    while(cin>>key)
        v1.push_back(key);
    cin.clear();
    cin>>key;
    cout<<count(v1.cbegin(),v1.cend(),key)<<endl;
}

void test_Accumulate()
{
    vector<string> v1;
    string word;
    while(cin>>word)
        v1.push_back(word);
    string sum = accumulate(v1.cbegin(),v1.cend(),string(""));
    cout<<sum<<endl;
}

void testSort()
{
    vector<string> v1;
    string word;
    while(cin>>word)
        v1.push_back(word);
    sort(v1.begin(),v1.end());
    cout<<"after---------- sort"<<endl;
    for(auto p:v1)
        cout<<p<<endl;
    cout<<"after----------- unique"<<endl;
    auto end = unique(v1.begin(),v1.end());
     for(auto p:v1)
        cout<<p<<endl;
     v1.erase(end,v1.end());
     cout<<"final---------"<<endl;
      for(auto p:v1)
        cout<<p<<endl;


    
}
int main()
{
    
    //test_Count();
   // test_Accumulate();
    testSort();
    return 0;
}
