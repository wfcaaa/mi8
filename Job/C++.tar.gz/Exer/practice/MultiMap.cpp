#include<iostream>
#include<map>

using namespace std;

typedef void(*FUN)();

void fun1()
{
    multimap<string,string> m1;
    string name = "jax";
    m1.insert({name,"hi"});
    m1.insert({name,"world"});

    //m1[name] = "hi";
    //m1[name] = "world";
    auto count = m1.count("jax");
    auto it = m1.find("jax");
    while(count)
    {
        cout<<it->second<<endl;
        ++it;
        --count;
    }
}

void fun2()
{
    multimap<string,string> m1;
    m1.insert({"jax","hello"});
    m1.insert({"jax","world"});
    m1.insert({"jax","US"});
    auto it = m1.lower_bound("jax");
    auto ed = m1.upper_bound("jax");
    while(it!=ed)
    {
        cout<<it->first<<": "<<it->second<<endl;
        ++it;
    }
}
int main()
{
    FUN f = fun2;
    f();
    return 0;
}
