#include<iostream>
#include<cstdio>
#include<fstream>
#include<vector>
#include<sstream>
using namespace std;

int main1(int argc,char * argv[])
{
    cout<<argc<<endl;
    for(int i = 0 ; i<argc; ++i)
        cout<<argv[i]<<endl;
  const  char*p = "hello world" ;
   string s(p);
   cout<<s<<endl;
   for(auto p = argv+1; p != argv+argc; ++p)
       cout<<*p<<endl;
   const char* a[10] = {"this is test"};
   cout<<a[0]<<endl;
   char b[] = "asdfg";
   cout<<b<<endl;
   int c = 1;
   int *q = &c;
   cout<<c<<" "<<*q<<" "<<q<<" "<<&c<<endl;
   return 0;
}

int main2()
{
    int a = 10;
    int *p = &a;
    int **q = &p;
    cout<<a<<" "<<*p<<" "<<**q<<endl;
    cout<<&a<<" "<<p<<" "<<*q<<endl;

    cout<<"-------------"<<endl;
    char b[] = "hi world!";
    printf("%p %p %p %p %p %p\n",b,&b[0],&b,b+1,&b[0]+1,&b+1);
    printf("%s %s\n",b,&b[0]);
    
    return 0;
}

int main()
{
    ifstream in("/home/jaxwu/c++code/Exer/practice/dataStructure.cpp",ifstream::in);
    if(in)
    {
        vector<string> v1;
        string line;
        while(getline(in,line))
            v1.push_back(line);
       
        
        for(auto p:v1)
        {
             stringstream record(p);
            //record.str(p);
            string word;
            while(record>>word)
                cout<<word<<endl;
        }

    }
    else
        cout<<"open fail"<<endl;
}
