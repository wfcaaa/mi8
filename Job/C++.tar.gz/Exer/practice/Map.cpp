#include<iostream>
#include<map>
#include<set>
#include<vector>
using namespace std;

typedef void (*fun)();
void checkNum()
{
    map<string,size_t> m1;
    string word;
    set<string> s1{"hi","the"};
    bool isContinue = true;
    while(isContinue)
    {
        cout<<"please input word: ";
        isContinue = (cin>>word);
        if(s1.find(word) == s1.end())
            ++m1[word];
        
    }
    cin.clear();
    cout<<"receive EOF end counting"<<endl;
    for(auto p:m1)
        cout<<p.first<<" occurs "<<p.second<<( (p.second > 1)?" times":" time")<<endl;
}

void familyMenu()
{
    map<string,vector<string>> m1;
    string word,name;
    
    bool flag = true;
    while(flag)
    {
        vector<string> v1;
        cout<<"pleae input :";
        flag = cin>>word;
        flag = cin>>name;
        v1.push_back(name);
        m1[word]=v1;
    }
    for(auto p:m1)
    {
        cout<<p.first<<": "<<endl;
        for(auto q:p.second)
            cout<<q<<" ";

    }
    cout<<endl;
}

void Map()
{
    map<string,int> m1 = {{"aa",1},{"bb",2},{"cc",3} };
    auto it = m1.find("aa");
    if(it != m1.end())
        cout<<it->first<<" "<<it->second<<endl;
    else
        cout<<"element dost not exist"<<endl;
}
void Exer()
{
    map<string,vector<int>> m1;
    vector<int> v1{3};
    m1.insert({"word",vector<int>{4}});
    auto it = m1.find("word");
    if(it != m1.end())
    {
        for(auto p :it->second)
            cout<<p<<endl;
    }
    
}

void test()
{
    map<string,int> m1;
    m1["henan"] = 1;
    m1["shanghai"] = 2;
    map<string,int> m2(m1);
    m1["henan"] = 3;
    auto it = m2.find("henan");
    if(it != m2.end())
        cout<<it->first<<": "<<it->second<<endl;
    else
        cout<<"there is not exist"<<endl;
}
int main()
{
    
    fun f1= test;
    f1();
}
