#include<stdio.h>

 struct Node
{
    int age;
    char *name;
    struct Node* next;
};
typedef struct Node* listNode;

int main()
{
    struct Node list={"aa",NULL};
    int flag = 1;
    string name;
    while(flag)
    {
        cout<<"please input name"<<endl;
        cin>> name;
        cout<<"please input age:"<<endl;
        cin>>age;
        struct Node n ={age,name,NULL};
        while(list.next)
    }
}
