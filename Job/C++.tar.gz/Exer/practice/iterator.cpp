#include<iostream>
#include<vector>
#include<list>
#include<deque>
using namespace std;

void exerVector()
{
    vector<int> v;
    int i = 0;
    while(cin>>i)
        v.push_back(i);
    cout<<"please input key:"<<endl;
    cin.clear();
    cin>>i;
    for(auto it = v.cbegin(); it != v.cend(); ++it)
    {
        if(*it == i)
        {    cout<<i<<" is in"<<endl;
            break;
        }
    }
    
    v.erase(v.begin(),v.end()-2);
    for(auto it= v.begin(); it!=v.end(); ++it)
    {
        cout<<*it<<endl;
    }
}

void exerList()
{
    list<string> l1;
    string word;
    auto it = l1.begin();
    while(getline(cin,word))
        it = l1.insert(it,word);
    for(auto p:l1)
        cout<<p<<endl;
    vector<string> v1(l1.begin(),l1.end());
    cout<<"***********"<<endl;
    for(auto p:v1)
        cout<<p<<endl;
    
}


void exerDeque()
{
    deque<string> d1;
    string word;
    while(getline(cin,word))
        d1.push_back(word);
    for(auto p:d1)
        cout<<p<<endl;
    cout<<d1.size()<<endl;

}

void exerInsert()
{
    vector<int> v1{1,2,3,4};
    auto it = v1.begin();
    cout<<*(it+1)<<endl;
    v1.insert(it+1,9);
    for(auto p:v1)
        cout<<p<<endl;
}
int main()
{
   
    exerInsert();
    //exerVector();
    //exerList();
    //exerDeque();

}
