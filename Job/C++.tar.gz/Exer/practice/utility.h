#ifndef __UTILITY__
#define __UTILITY__

//############system head file#########

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<vector>
#include<map>

//#############system head file#########
#endif
