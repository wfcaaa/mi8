#include<iostream>

using namespace std;

class Stu
{
    public:
        Stu()=default;
        Stu(int a):age(a){}
        ~Stu(){}
     //  virtual  string getAge()const{};
    private:
        //string name="ll";
        int age=10;
        int a = 0; 
        char n='F';
};
int main()
{
    Stu s1;
    string s="llll";
    cout<<sizeof(s1)<<" "<<sizeof(s)<<endl;
    const char *p = "lll";
    printf("char:%d short:%d int:%d long:%d pointer:%d \n",sizeof(char),sizeof(short),sizeof(int),sizeof(long),sizeof(p));
}


