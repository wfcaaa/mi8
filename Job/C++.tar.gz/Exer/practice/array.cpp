#include<iostream>

using namespace std;

int main()
{
    int a[10]={};
    for(size_t i = 0;i<10;++i)
        a[i] = i;
    int b[10]={};

    for(auto p:a)
    {
        b[p] = p;
    }
    for(int * p=begin(a); p!=end(a); ++p)
        cout<<*p<<endl;
    for(auto p:b)
        cout<<p<<endl;
}   
