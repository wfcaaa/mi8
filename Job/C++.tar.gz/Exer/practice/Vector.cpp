#include<iostream>
#include<vector>
#include<string>
using namespace  std;

void Test()
{
    vector<int> v1;
    cout<<"size:"<<v1.size()<<" capacity:"<<v1.capacity()<<endl;
    v1.reserve(9);
    cout<<"size:"<<v1.size()<<" capacity:"<<v1.capacity()<<endl;
    for(int i = 0; i < 10; ++i)
        v1.push_back(i);
    cout<<"size:"<<v1.size()<<" capacity:"<<v1.capacity()<<endl;

}

void TestString()
{
    string s("hello world");
    string s1 = s.substr(0,5);
    string s2 = s.substr(1,7);
    //string s3 = s.substr(12);
    cout<<s1<<" "<<s2<<endl;
    //cout<<s3<<endl;
    int i = 42;
    string s3 = to_string(i);
    cout<<s3<<" "<<stoi(s3)<<endl;
}

int main()
{
    //Test();
    TestString();
}
