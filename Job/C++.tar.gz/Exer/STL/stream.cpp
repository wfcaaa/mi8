#include<iostream>

using namespace std;

void test()
{
    int a;
    cin>>a;
    cout<<(cin.fail()?"one IO operation fail":"other case")<<endl;
    if(!cin.bad())
        cin.clear();
    int b;
    
    cin>>b;
    cout<<a<<b<<endl;
}

int main()
{
    test();
    return 0;
}
