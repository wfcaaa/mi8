#include"utility.hpp"
#include<sstream>
#include<chrono>

using namespace std;
typedef long (*FUN)(long *);
long disTime(long *time)
{
    struct timeval tc;
    struct timezone tz;
    int ret = gettimeofday(&tc,&tz);
    if(ret != 0)
        cout<<"error occurs when gettimeofday"<<endl;
    else
    {
      *time = tc.tv_usec;
      return tc.tv_sec;
    }
}
long testChrono()
{
    using namespace std::chrono;
    system_clock::time_point tp = system_clock::now();
    system_clock::duration dtn = tp.time_since_epoch();
    cout<<dtn.count()<<endl;
    return dtn.count();
    
}
int main()
{
    using namespace std::chrono;
    FUN f =NULL;
    long t1 = 0,t2 = 0;
    long t3 = disTime(&t1);
    long t4 = disTime(&t2);
    cout<<t3<<"."<<t1<<"\n"<<t4<<"."<<t2<<endl;
    int a = 123456789;
    int a1 = a/10;
    cout<<a1<<"\t"<<a/10%10<<"\t"<<a%1000<<endl;
    
   
    
}
