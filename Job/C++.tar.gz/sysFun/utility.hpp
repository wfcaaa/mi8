#ifndef __UTILITY__
#define __UTILITY__

#include<iostream>
#include<sys/time.h>

#endif
