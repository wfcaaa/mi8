#include<iostream>
#include<boost/lexical_cast.hpp>

using namespace std;

int main()
{
    int id = 100;
    string id_str = boost::lexical_cast<string>(id);
    cout<<id_str<<endl;
}
