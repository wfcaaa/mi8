#include<iostream>
#include <boost/assign/list_of.hpp>
#include<vector>
using namespace std;
using namespace boost::assign;
int main()
{
    vector<int> v1 = list_of(1)(2)(3);
    for(auto p:v1)
        cout<<p<<endl;
    vector<string> v2 = list_of("hello")("world");
    for(auto p:v2)
        cout<<p<<endl;
    return 0;
}


