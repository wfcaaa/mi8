#include<iostream>
#include<dlfcn.h>
#include<map>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
using namespace std;

typedef int (*FUNC)(int,int);

int main()
{
    FUNC func=NULL;
    map<string,void *> m1;
    void *handle=NULL;
    char *error=NULL;
    for(int i=1;i<6;++i)
    {
        switch(i)
        {
            case 1:
                    handle=dlopen("./lib_test1.so",RTLD_LAZY);
                    if(handle)
                    {
                        m1["./lib_test1.so"]=handle;

                    }
                    break;
            case 2:
                    handle=dlopen("./lib_test2.so",RTLD_LAZY);
                    if(handle)
                    {
                        m1["./lib_test2.so"]=handle;
                    }
                    break;
            case 3:
                    handle=dlopen("./lib_test3.so",RTLD_LAZY);
                    if(handle)
                    {
                        m1["./lib_test3.so"]=handle;
                    }
                    break;
            case 4:
                    handle=dlopen("./lib_test4.so",RTLD_LAZY);
                    if(handle)
                    {
                        m1["./lib_test4.so"]=handle;
                    }
                    break;
            case 5:
                    handle=dlopen("./lib_test5.so",RTLD_LAZY);
                    if(handle)
                    {
                        m1["./lib_test5.so"]=handle;
                    }
                    break;
            default:
                    break;
        }    
        
    }

    map<string,void *>::iterator it=m1.begin();
    
    static int istatic = 1;
        char* tmpAdd;
    while(1)
    {
        it=m1.begin();
        
        func=(FUNC)dlsym(it->second,"addd");
        //cout<<"the result is:"<<func(8,2)<<endl;
        ++it;
        tmpAdd = dlerror();
        printf("the error message is %s\n", tmpAdd);
        //if(istatic == 1)
            free(tmpAdd);
        //if(tmpAdd != NULL)
         //   printf(tmpAdd);
       
        func=(FUNC)dlsym(it->second,"sub");
        cout<<"the result is:"<<func(8,2)<<endl;
        ++it;
        //char* tmpSub = dlerror();
        //if(tmpSub != NULL)
         //   printf(tmpSub);

        func=(FUNC)dlsym(it->second,"mul");
        cout<<"the result is:"<<func(8,2)<<endl;
        ++it;

        func=(FUNC)dlsym(it->second,"div");
        cout<<"the result is:"<<func(8,2)<<endl;
        ++it;

        func=(FUNC)dlsym(it->second,"mol");
        cout<<"the result is:"<<func(8,2)<<endl;
        sleep(1);
        istatic++;
    }
}
