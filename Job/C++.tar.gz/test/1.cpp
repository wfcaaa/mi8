#include<iostream>
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
using namespace std;


void test1()
{
   
    char ret[1024] = "barcode:communcation error occured when waiting for SRQ";
    char *p = strchr(ret,':');
    if(p)
      cout<<p+1<<endl;
}

void test2()
{
    int a = 1,b=1;
    switch(a)
    {
        case 0:
          cout<<0<<endl;
          break;
        case 1:
          if(b>0)
          {
            cout<<"b>0"<<endl;
            break;
          }
          cout<<"b<=0"<<endl;
          break;
        default:
          break;
    }
}

void test3()
{
    char a = '1';
    cout<<a<<","<<hex<<a<<endl;
    printf("%c,%02d,%02x\n",a,a,a);
    string s = "abcd";
    string tmp = string(s,0,2);
    cout<<tmp<<endl;

    char* p  = NULL;
    printf("the result:%s\n",p);
    cout<<"test:"<<*p<<endl;
}
void myCopy(char* arr,const char*src,int len)
{
    for(int i=0; i<len;++i)
      arr[i] = src[i];
}
void test4()
{
    char arr[] = {0,0,0,0xA,0xff,0xff,0,0,0,0x05, 0,0,0,0};
    string msg(arr,14);
    cout<<"msg size:"<<msg.size()<<endl;
    for(int i=0; i < msg.size();++i)
      printf("0x%.02x ",msg[i]&0xff);
    cout<<endl;
    char a1[64] = "";
    myCopy(a1,msg.c_str(),msg.size());
    for(int i=0; i<14;++i)
      printf("0x%.02x ",a1[i]&0xff);
    cout<<endl;
}

int main()
{
   test4();
}


