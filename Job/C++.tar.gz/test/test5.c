#include<stdio.h>

int mol(int a,int b)
{
    return (a % b);
}
