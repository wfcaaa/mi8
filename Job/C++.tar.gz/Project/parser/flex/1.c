#include<stdio.h>

const char * fun(const char *s)
{
    if(*s)
        return s;
    else
        printf("pointer is null\n");
}

static const char *findHexadecimalDigit(const char *s)
{
    while( *s && !isxdigit(*s) )
    {
        ++s;
    }

    return s;
}
int main()
{
    const char *p = "ghjk";
    const char *s = findHexadecimalDigit(p);
    if(s &&*s)
        printf("%s\n",s);
    else
        printf("not equal\n");
}
