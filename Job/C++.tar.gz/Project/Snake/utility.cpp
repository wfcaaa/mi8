#include"utility.h"

using namespace std;
void beginDisplay()
{
    deque<string> 
}
