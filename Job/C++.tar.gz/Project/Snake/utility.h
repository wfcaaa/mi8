#ifndef _UTILITY_
#define _UTILITY_

#************head file *************
#include<window.h>

#include<iostream>
#include<deque>
#include<vector>


#**************fun defination*********
void beginDisplay();

#endif

