#include<iostream>
#include<cstring>
#include<fstream>
using namespace std;

int main(int argc, char* argv[])
{
    cout<<"the lenth of string: "<<argv[1]<<" is:"<<endl;
    cout<<strlen(argv[1])<<endl;
}

int main0(int argc, char* argv[])
{
    if(argc>1)
    {
        string path = argv[1];
        ifstream in(path);
        int num =0,tmp=0;
        string line;
        while(getline(in,line))
        {
            tmp = line.size();
            num+=tmp;
        }
        cout<<"string len:"<<num<<endl;
        in.close();
    }
    else
    {
        cout<<"there is no inpout"<<endl;
    }
}
