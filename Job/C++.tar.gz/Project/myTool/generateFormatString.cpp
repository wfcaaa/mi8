#include<iostream>
#include<cstdio>

using namespace std;

static int num=72;

typedef void (*FUN)();
void handlerSite()
{
    for(int i = 1; i<=num; ++i)
        printf("\"%d\" ",i);
    cout<<endl;
}

void testerSite()
{
    for(int i = 1; i<=num; ++i)
        printf("%d ",i);
    cout<<endl;
}
void siteMask()
{
    for(int i = 0 ; i<num;++i)
        printf("1 ");
    printf("\n");
}
void offset()
{
    int count = 0;
    for(int i = 0,j=0;count<num;++j,++count)
    {
#if 0
        if(j == 511)
        {
            printf("[%d %d] ",i,j);
            ++i;
            j=-1;
            continue;
        }
#endif
        printf("[%d %d] ",i,j);
    }
    printf("\n%d\n",count);
}
 void dutboad()
{
    int count = 0;
    int first = 1,tmp =0,j = 0;
    for(int i = 401;count < 4096; ++i )
    {
        if(first)
        {
            tmp = i;
            first = 0;
        }
        if(i - tmp == 64)
        {
            i = tmp + 99;
            first = 1;
            continue;
        }
        j = i*100;
        for(int k = 1; k<= 16 &&count <4096 ; ++k)
        {
            ++count;
            printf("site %d { pogo=%d; }\n",count,j+k);
        }
        
    }
    printf("%d\n",count);
}
int main(int argc,char* argv[])
{
    
    FUN f = siteMask;
    f();
}
