#include<stdio.h>

void fun()
{
    printf("hello world\n");
}

int main()
{
    int n=0;
    int count = 0;
    for(n= 1 ; n<10;++n)
        ++count;
    printf("%d\n",count);
    int a = -5;
    int b = !a;
    printf("%d\n",b);
    fun();
     b = !b;
    printf("%d\n",b);
    
}
