#include<stdio.h>

int main(int argc, char* argv[])
{
    printf("the count of arg:%d\n",argc);
    char arr[] = "PP-SELECT";
    for(int i=0; i < strlen(arr);++i)
      printf("0x%x,",arr[i]);
    printf("\n");
    
    return 0;
}
