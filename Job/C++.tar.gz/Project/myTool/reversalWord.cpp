#include<iostream>
using namespace std;
int main(int argc,char* argv[])
{
    string s="this is a test";
    cout<<s<<endl;
     int i =0;
     for(i=0; i < s.size()/2;++i )
     {
        char a = s[i];
        s[i]=s[s.size()-i-1];
        s[s.size()-i-1] = a;
     }
     cout<<s<<endl;
     return 0;
}
