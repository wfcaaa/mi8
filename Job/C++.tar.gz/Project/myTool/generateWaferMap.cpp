#include<iostream>
#include<cstdlib>
using namespace std;

int main(int argc,char* argv[])
{
    if(argc>=3)
    {
        int xMax = strtol(argv[1],NULL,10);
        int xMin  = -xMax;
        int yMax = strtol(argv[2],NULL,10);
        int yMin = -yMax;
        int x =0 ,y = 0 ;
       for(y=yMin;y<yMax;y++)
       {
            x = xMax;
            while(x>=xMin)
            {
                cout<<x<<","<<y<<endl;
                --x;
            }

       }
    }

    return 0;
}
