#include<iostream>
#include<cstdlib>
using namespace std;

int main(int argc,char* argv[])
{
    int sum=0,num=0;
    

    for(int i =1; i < argc;++i)
    {
        
        num = atoi(argv[i]);
          
        sum+=num;
        
    }


    cout<<"average is "<<sum/(argc-1)<<endl;

}
