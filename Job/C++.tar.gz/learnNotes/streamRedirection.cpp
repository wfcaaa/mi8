#include<iostream>
#include<fstream>
using namespace std;

int main()
{
    fstream file;
    file.open("/home/jaxwu/test.txt");
    if(file)
        cout<<"file has been open"<<ends;
    else
    {
        cout<<"file open fail"<<endl;
        return -1;
    }

    streambuf * buf = file.rdbuf();
    cout.rdbuf(buf);
    cout<<"this line will output to file"<<ends;
    return 0;
}
