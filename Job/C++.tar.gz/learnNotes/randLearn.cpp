#include<iostream>
#include<cstdlib>

using namespace std;
typedef void (*PFun)(int);

void fun(int n)
{
    cout<<rand()%n<<endl;
    cout<<rand()%n<<endl;
    cout<<rand()%n<<endl;
}

int main()
{
    PFun p = fun;
    p(100);
}
