#include<iostream>

using namespace std;

void getSubString()
{
    string s("GUILib.customizedDialog.hello,wold");
    string test(s,1);
   
    cout<<test<<endl;
    string::size_type pos =  s.find_first_of(".");
    string t2(s.c_str(),pos);
     string t3(s,pos+1);
    cout<<t2<<" "<<t3<<endl;
    string name;
    if(pos != string::npos)
        name = s.substr(0,pos);
    cout<<name<<endl;
}
int main()
{
    getSubString();
    return 0;
}
