#include<iostream>

using namespace std;

class Base
{
    public:
        void loop();
    private:
        int num;
};

void Base::loop()
{
    cout<<"step in loop"<<endl;
    static int n = 1;
    cout<<n<<endl;
    ++n;
}

class Base1:public Base
{
    public:
        Base1(){}
};

class Base2:public Base
{
    public:
        Base2(){}
};

int  main()
{
    Base b1;
    Base1 b2;
    Base2 b3;

    b1.loop();
    b2.loop();
    b3.loop();
}
