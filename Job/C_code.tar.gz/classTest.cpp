#include<iostream>

using namespace std;

class Base
{
    public:
        Base()
        {
            cout<<"Base ctr enter"<<endl;
        }
        ~Base()
        {
            cout<<"Base:: dtr enter"<<endl;
        }
        virtual void  get()const{
            
            cout<<"Base get"<<endl;}
        virtual void handle()
        {
            cout<<"Base::handle"<<endl;
            this->get();
        }
    private:
        int a;
    
        
};

class Base1
{
    public:
        
         Base1()
        {
            cout<<"Base1 ctr enter"<<endl;
        }
        ~Base1()
        {
            cout<<"Base1:: dtr enter"<<endl;
        }
        virtual void dis(){};
         void  get()const{
            cout<<"Base1 get"<<endl;}
    private:
         int b;
    
        
};
class Derived:public Base1,public Base
{
    public:
         Derived()
        {
            cout<<"Derived ctr enter"<<endl;
        }
        ~Derived()
        {
            cout<<"Derived:: dtr enter"<<endl;
        }
        virtual void set(){};
     void get()const
     {cout<<"Derived get "<<endl;}
    private:
     int c;
    
};

void fun()
{
     Derived d1;
    Base *b1 = &d1;
    b1->handle();
    
}
typedef struct re{
    struct re *pre;
    struct re *next;
    long num;
    unsigned char map[5];
}STR;
int main()
{
    fun();
    cout<<sizeof(Derived)<<endl;
    cout<<sizeof(unsigned char)<<endl;
    cout<<sizeof(STR)<<endl;
    int a = 0x4321;
    int b= ((a & 0x0F) <<4);
    cout<<b<<endl;
    
}
