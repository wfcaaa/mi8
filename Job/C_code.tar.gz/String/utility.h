#ifndef _UTILITY_
#define _UTILITY_

/*******system head file */
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdarg.h>
#endif

