#include<stdio.h>
#include<string.h>

int main()
{
    char a[64] = "abced";
    printf("\"%s\" %d %d\n",a,strlen(a),sizeof(a));
    char *p = "abced";
     printf("\"%s\" %d %d\n",p,strlen(p),sizeof(p));
     strcpy(a,"");
     printf("\"%s\" %d %d\n",a,strlen(a),sizeof(a));
     sprintf(a," reason: the current height:4 over maximum height:5");
     printf("%s\n",a);
}
