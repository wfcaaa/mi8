#include<stdio.h>
#include<string.h>
#include<cstdlib>

int parseXYCoordinateFromPara(int *x,int *y, char* para)
{
    if(para)
    {
        printf("para:%s\n",para);
        char *p = strchr(para,'x');
        if(p)
        {
            char xArr[20] = "",yArr[20] = "";
            strcpy(yArr,p+1);
            printf("yarr:%s\n",yArr);
            strncpy(xArr,para,strlen(para)-strlen(yArr)-1);
            printf("xarr:%s\n",xArr);
            *x = strtol(xArr,NULL,10);
            *y = strtol(yArr,NULL,10);
            return 0;
        }
        else
            return -1;
    }
    else
        return -1;
}

int parseZParameter(int *incremental,int *zMaxHeight, char* para)
{
    printf("enter: %s,para:%s\n",__FUNCTION__,para);
    char *token = strtok(para,",");
    if(token)
        *incremental = strtol(token,NULL,10);
    else
        return -1;
    token = strtok(NULL,",");
    if(token)
        *zMaxHeight = strtol(token,NULL,10);
    else
        return -1;
    return 0;
}

int main()
{
    char str[] = "AUTOZ_index1 3x4";
    char *p = strstr(str,"AUTOZ_");
    if(p )
    {    
        printf("%s\n",p);
        p = strchr(str,'_');
        if(p)
        {
            printf("%s\n",p+1);
            printf("%s\n",str);
            strcpy(str,p+1);
            printf("%s\n",str);
        }
    }
    else
        printf("not found key\n");
    int x,y;
     char param[] = "31x49";
    parseXYCoordinateFromPara(&x,&y,param);
    printf("x:%d,y:%d\n",x,y);
    char s[64] = "FULLSITE 0011,1#001,2#002";
    int num = 0;
    char *token = strtok(s,",");
    int tokenNum = 0;
    while(token)
    {
        ++tokenNum;
        if(tokenNum == 1 )
        {
            char *p = strchr(token,':');
            if(p)
                sscanf(token,"FULLSITE: %lx",&num);
            else
                sscanf(token,"FULLSITE %lx",&num);
            printf("population is:%lx\n",num);
        }
        else
        {
            printf("%s\n",token);
        }
        token = strtok(NULL,",");
    }
    printf("++++++++\n");
    int incremental = 0, zMaxHeight =0;
    char para[] = "2,10";
    if(parseZParameter(&incremental,&zMaxHeight,para) == 0 )
        printf("incremental:%d zMaxHeight:%d\n",incremental,zMaxHeight);
    else
        printf("parse error\n");

}


