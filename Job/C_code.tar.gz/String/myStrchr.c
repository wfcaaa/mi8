#include"utility.h"

int main()
{
    const char * s = "heAllo world";
    char *p = NULL;
    int n =97;
    p = strchr(s,n);
    if(p)
        printf("%s\n",p);
    else
        printf("character '%c' is not exist in \"%s\"\n",n,s);
}
