#include"utility.h"

void fun(const char* fmt,...)
{
    va_list ap;
    va_start(ap,fmt);
    char *s =NULL;
    char c = 0;
    int d = 0;
   /* while(*fmt)
    {
        switch(*fmt++)
        {
            case 's':
                s = va_arg(ap,char *);
                printf("%s\n",s);
                break;
            case 'd':
                d = va_arg(ap,int);
                printf("%s\n",d);
                break;
            case 'c':
                c = (char)va_arg(ap,int);
                printf("%c\n",c);
                break;
            default:
                break;
        }
    }*/
  
    va_list aq;
    va_copy(aq,ap);
    //vprintf(fmt,ap);
    int *ptr = va_arg(aq,int* );
    printf("%d\n",*ptr);
    *ptr = 87;
    //vsscanf("this is ",fmt,ap);
    //printf("%d\n",d);

    va_end(ap);
}
int getMax(int n,...)
{
    va_list ap;
    va_start(ap,n);
    int max = 0 , tmp =0;
    
    for(int i = 0; i < n; ++i)
    {
        tmp = va_arg(ap,int);
        if(tmp > max)
            max = tmp;
    }
    char * p = va_arg(ap,char*);
    tmp = va_arg(ap,int);
    printf("%s %d\n",p,tmp);
    va_end(ap);
    return max;
}
int main()
{
     char p[] = "hi world";
     int tmp =0;
     char q[20]="I am Jax!";
     int te = 88;
    //fun("%s  %s %d %c\n",p,q,99,'a');
    fun("%d\n",&te);
    printf("%d\n",te);
    //int n = 4,a = 5,b=6,c=7,d=8;
    //int max = getMax(n,a,b,c,d,p,11);
    
    
}
