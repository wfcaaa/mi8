#include<stdio.h>
#include<string.h>
static char*Barcode[1024];
void fun(int i)
{
    printf("aa******************\n");
     int j = 0;
    for(j = 0 ; j < i; ++j)
        printf("%d:\t%s\n",j+1,Barcode[j]);
        
}
int main()
{
    char p[] =",aaa,bbb,ccc,";
    char *q=NULL;
    char *ptr = p ;
    
    int i = 0;
 //   printf("%s\n",strtok(p,","));
    while( q = strtok(ptr,",")  )
    {
        printf("in %s :%s\n",__FUNCTION__,q);
        Barcode[i++] = q;
        ptr =NULL;
    }
     fun(i);
    
    return 0;
}
