#!/bin/bash

rm -f a.out

gcc 1.c -I . -L . -Wl,-rpath=/home/jaxwu/C_code/dynamic_lib_learn -ltest
