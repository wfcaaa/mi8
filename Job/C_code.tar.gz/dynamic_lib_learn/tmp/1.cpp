#include<iostream>

using namespace std;

int main()
{
    string s = "abcbad";
    string s1 = string(s,1);
    string s2 = string(s,0,s.size()/2);
    string s3 = string(s,s.size()/2);
    cout<<s1<<" "<<s2<<endl;
    cout<<s3<<endl;
    string s4 =s;
    if(s == s4)
      cout<<"="<<endl;
    else
      cout<<"!="<<endl;
}
