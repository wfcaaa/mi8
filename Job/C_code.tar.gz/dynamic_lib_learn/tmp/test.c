#include<stdio.h>

void print()
{
    printf("Hello world\n");
}

int add(int a,int b)
{
    int c = a+b;
    return c;
}
int main()
{
    print();
  //  int a = 1,b =2;
    int num = add(3,4);
    printf("%d\n",num);
    return 0;
}
