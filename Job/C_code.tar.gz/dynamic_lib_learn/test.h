#ifndef __TEST_H__
#define __TEST_H__

typedef struct Flag
{
   // struct Flag(int n ):flag(n){}
    int flag;
}F;
int add(int a,int b);
int sub(int a,int b);
int mul(int a,int b);

#endif 
