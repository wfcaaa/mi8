#include<stdio.h>
//#include<test.h>

int main()
{
    int a = add(3,4);
    printf("%d\n",add(1,2));
     printf("%d\n",sub(1,2));
    return 0;
}
