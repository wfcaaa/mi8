#include<stdio.h>
#include<stdlib.h>
#include<dlfcn.h>
#include"test.h"
//dynamic link library path
#define LIB_CACULATE_PATH "./libtest.so"

//function pointer
typedef int (*CAC_FUNC)(int,int);

int main()
{
    void * num_lib_addr=NULL, *num_memory_addr=NULL;;
    void * flag_addr = NULL;
    void *handle=NULL;
    char *error=NULL;
    CAC_FUNC cac_func=NULL;

    //open the dynamic link library,if success,return a handle,if fail,return NULL
    handle=dlopen(LIB_CACULATE_PATH,RTLD_NOW);
    if(!handle)
    {
        fprintf(stderr,"%s\n",dlerror());
        exit(EXIT_FAILURE);
    }
    
    //clear the previous error
    dlerror();
    num_memory_addr = dlsym(handle,"num");
    if((error=dlerror()) !=NULL)
    {
        fprintf(stderr,"%s\n",error);
        exit(EXIT_FAILURE);
    }
    cac_func=(CAC_FUNC)dlsym(handle,"add");
    printf("add:%d\n",cac_func(1,2));
    //int *p = (int*)num_memory_addr;
    printf("before assign addr:%p\nvalue:%d\n",num_memory_addr,*(int*)num_memory_addr);
    *(int*)num_memory_addr=1;
    printf("after assgin:%p %d\n",(int*)num_memory_addr,*(int*)num_memory_addr);
    dlerror();
    char szPopen[100] = "0";
    printf("befor sprint\n");
    sprintf(szPopen,"nm %s|grep num|awk '{print $1}'",LIB_CACULATE_PATH);
     printf("after sprint\n");
    FILE* pshell=popen(szPopen,"r");
     printf("after popen\n");
    char buff[1024]="";
    if(pshell !=NULL)
    {
        printf("befor fgets\n");
        fgets(buff,1024,pshell);
         printf("befor strtol\n");
        int n=strtol(buff,(char**)NULL,16);
        printf("num in lib addr is:%0x\n",n);
    }
    else
        printf("popen fail\n");
    
#if 0
    //cac_func=(CAC_FUNC)dlsym(handle,"add");
    *(void **)(&cac_func)=dlsym(handle,"add");//confuse: why the pointer has been transformed into a void-type pointers,but also continute to use: cac_func= (CAC_FUNC) dlsym(handle,"sub");
    if((error=dlerror()) !=NULL)
    {
        fprintf(stderr,"%s\n",error);
        exit(EXIT_FAILURE);
    }

    printf("add 2+7 result is: %d\n",cac_func(2,7));

    cac_func= (CAC_FUNC) dlsym(handle,"sub");
    printf("sub: %d\n",cac_func(9,2));
    int *num = (int *) dlsym(handle,"num");
    printf("num is %d\n",*num);
    void *tmp = dlsym(handle,"mul");
    cac_func = (CAC_FUNC) tmp;
    printf("%d\n",cac_func(3,3));
#endif
    

}

/*complie command: gcc -rdynamic -o main libso_learn.c -ldl*/
// genetate dynamic library command:gcc -fPIC -shared caculate.c -o libcaculate.so
// dlopen opens the specified dynamic link library file in the specified mode and return a handle to the call process
// the mode has two: RTLD_LAZY    suspension decision ,and  so on when necessary ,solve the symbol
//                   RELD_NOW     immediately decide to lift all undecided symbols before returning
