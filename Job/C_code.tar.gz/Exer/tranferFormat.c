#include<stdio.h>

char* transfer(int num,int format)
{
    static char result[64] = "";
    memset(result,0,sizeof(result));
    int i = 0;
    while(num)
    {
        int ret = num%format;
        char tmp[12] = "";
        if(ret>10)
            sprintf(tmp,"%x",ret);
        else
          sprintf(tmp,"%d",ret);
        strcat(result,tmp);
        num= num/format;
    }
    int len = strlen(result);
    for(i=0; i<len/2;++i)
    {
        char k = result[i];
        result[i] = result[len-1-i];
        result[len-1-i] = k;
    }
    return result;
}

int main()
{
    printf("%s\n",transfer(111,16));
}
