#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include <regex.h>
#include<ctype.h>
 static char a[24] = ""; //= system("lsb_release -a|grep Release|awk '{print $2}'");

#define CheckHandlerAnswer(x) \
    { \
        if ( strlen(x) <4) \
        { \
            printf("handler answer error\n"); \
        } \
        else \
             printf("handler answer ok\n"); \
    } 

#define SUCCESS 1
#define error_info(id,des) {id,#id,des}
#define debug 1
typedef struct _error
{
    int id;
    const char* pid;
    const char* des;
}m_error_info;
void fun2(int **p)
{
    *p = (int *)malloc(sizeof(int));
}
void test()
{
    static char arr[64] = "hello world!";
    printf("%s\t%d\n",arr,strlen(arr));

    strcpy(arr,"true");
    printf("%s\t%d\n",arr,strlen(arr));
    strcpy(arr,"false");
    printf("%s\t%d\n",arr,strlen(arr));
}
void test1()
{
    char str[] = "Set StartTest \"strip0001\" 3,A1,2,B1 1,C1 GPIB_OK";
    char tmp1[12] = "";char tmp2[12] = "";char stripID[24] = "";char buf[64] = "";
    if(sscanf(str,"%s%s%s%s",tmp1,tmp2,stripID,buf) != 4)
      printf("scanf error\n" );
    else
    {
        printf("stripid:%s\nsiteinfo:%s\n",stripID,buf);
    }
}
static char coordinate[24][12] = {""};

void parseSiteInfo(char *p)
{
    int siteNum = atoi(&p[0]);
     printf("in parseSiteInfo: siteNum:%d\n",siteNum);
                                                                 
    if(siteNum-- >= 10 )
    strcpy(coordinate[siteNum] , &p[3]);
    else
    strcpy(coordinate[siteNum] , &p[2]);

     
}
void test2()
{
    char str[] = "Set StartTest \"tfff\" 1,O3 5,P3 9,Q3 13,R3 17,S3 21,T3 2,O6 6,P6 10,Q6 14,R6 18,S6 22,T6 3,O9 7,P9 11,Q9 15,R9 19,S9 23,T9 4,O12 8,P12 12,Q12 16,R12 20,S12 24,T12";
    int index[12] = {0}; 
    char *token =  strtok(str," ");
    printf("first token:%s\n",token);
    token = strtok(NULL," ");
    token = strtok(NULL," ");
    token = strtok(NULL," ");
    int i = 0;
    while(token)
    {
       // CheckHandlerAnswer(token);
        parseSiteInfo(token);
        token = strtok(NULL," ");
        i++;
    }
    char *p = NULL;
    int ireverse = i,loop = i-1;
    
    for(i=0; i<ireverse; ++i )
      printf("site%d:%s\n",i+1,coordinate[i]);
    printf("after strtok:%s\n",str);
    char test[23] = "";
    sprintf(test,"Set Bin \"strip123\" 3,1");
    printf("test:%s\n",test);
    int arr[] = {5,4,3,2,1};
    int len = 5;
    for(int i=0;i<5/2;++i,len--)
    {
        int tmp = arr[i];
        arr[i] = arr[len-1];
        arr[len-1] = tmp;
    }

    for(int i = 0;i<5;++i)
      printf("%d ",arr[i]);

    char a1[] = "BARCODE:NOBARCODE,NOBARCODE";
    p = strstr(a1,"NOBARCODE");
    if(p)
      printf("%s\n",p);
}

int phToolsMatch(const char *string, const char *pattern)
{
    int i;
    regex_t re;
    regmatch_t pmatch[2];

    i = regcomp(&re, pattern, REG_EXTENDED);
    if (i) 
	return 0;                       /* report error */
    i = regexec(&re, string, 1, pmatch, 0);
    regfree(&re);
    if (i || pmatch[0].rm_so != 0 || pmatch[0].rm_eo != strlen(string)) 
	return 0;                       /* report error */

    return 1;
}

void test3(const char* str)
{
    if(phToolsMatch(str,"heat\\?.*"))
        printf("equal:%s\n",str);
    else
        printf("not equal\n");
}

void test4()
{
    int srqmask = 0;
    printf("%d\n",srqmask);
    char * msg = "srqmask ff";
    if(strstr(msg,"0x"))
      printf("find 0x\n");
    else
      printf("not find 0x\n");
   int ret =  sscanf(msg,"srqmask %lx",&srqmask);
     printf("%d,ret:%d\n",srqmask,ret);
}

void test5()
{
    char arr[12] = "AA1";
    for(int i =0 ;i<strlen(arr);++i)
    {
        if(isdigit(arr[i]))
          printf("is digit\n");
        else
          printf("is not digit\n");
    }
}

void test6()
{
    m_error_info arr[] = {error_info(SUCCESS,"first success"),
                          error_info(SUCCESS,"second success")};
    printf("%d %s %s\n",arr[0].id,arr[0].pid,arr[0].des);
}

void test7()
{
    char * msg = "srqmask ff";
    int srqMask = -1;
    printf("%d\n",srqMask);
    if ( sscanf(msg,"srqmask %x",&srqMask) != 1 )
    {
        
        printf("unable to interpret \"%s\" with sscanf expected format \"srqmask n\"",msg);
    }
    else
    printf("srqmask:%03lx\n",srqMask);

}

int getLine(char* line)
{
    char c='0';
    int len = 0;
    while((c=getchar()) != EOF)
    {
        line[len++] = c;
        if(c == '\n')
          break;
    }
    line[len] = '\0';
    return len;
}

void test8(const char* p)
{
    
    if(p)
    printf("string:%s,len:%d\n",p,strlen(p));
    char* str = "hello world";
    printf("%s,len=%d\n",str,sizeof(str)/sizeof(char));
    //printf("%d\n",str);
    int isContinue = 1;
    char arr[64] = "";
    while(isContinue)
    {
        printf("is continue ?\n");
        getLine(arr);
        if(strncmp(arr,"y",1) == 0 )
          printf("result is:%s",arr);
        else
        {
          printf("arr:%s",arr);
          isContinue = 0;
        }
    }
}

void test9()
{
    printf("test 9\n");
#if debug
    printf("hello world\n");
#endif

    char arr[] = "qwer";
    printf("arr:%p,&arr:%p . arr+1:%p,&arr+1:%p\n",arr,&arr,arr+1,&arr+1);
}
int main(int argc,char*argv[])
{
    char arr[21] = "";
    
    test6();
    return 0;

}
