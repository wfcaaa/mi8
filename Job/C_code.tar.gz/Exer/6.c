#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void getStr(char**p)
{
    static char arr[] = "hello world qwre";
    *p = arr;
}
void passIt(char* p)
{
    printf("pass pointer to a function, content:%s\n",p);
}
int main()
{
    char * des = (char*) malloc(7);
    memset(des,0,7);
    *des = '\0';
    strncat(des,"hello world",6);

    printf("length of sizeof(des):%d,%s\n",sizeof(des),des);

    int a[5] = {1,2,3,4,5};
    int *p1 = (int*)(&a+1);
    int *p2 = (int*)(a);
    printf("p1:%d,p2:%d\n",*(p1-1),*(p2+1));

    struct A
    {
        char a;
        int b;
        char c;
    };
    printf("struct A size:%d\n",sizeof(struct A));

    char* p3 = "abc";
    printf("p1:%p,++p:%p,sizeof p:%p,%d\n",p1,p1+1,sizeof(p1),sizeof(p3));
     printf("char:p3:%p,++p:%p,sizeof p3:%p,%d\n",p3,p3+1,sizeof(p3),sizeof(p3));

     printf("%o,%d,%d\n",111,014,0x11);
     char* p4 = NULL;
     getStr(&p4);
     printf("get string from function:%s\n",p4);
     passIt(p4);

}
