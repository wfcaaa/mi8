#ifndef __UTILITY_H__
#define __UTILITY_H__

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#endif
