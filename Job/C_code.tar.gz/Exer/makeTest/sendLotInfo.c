#include"utility.h"

void send(const char **msg)
{
    static char info[24]="";
    *msg = info;
    char * tmp =NULL;
    strcpy(info,"Vlot1");
    printf("before remove \"V\":%s\n",*msg);
    if( (tmp = strchr(info,'V')) )
        *msg = tmp+1;
}

