#ifndef __PRINT_H__
#define __PRINT_H__

#include"utility.h"

void printHello();


#endif
