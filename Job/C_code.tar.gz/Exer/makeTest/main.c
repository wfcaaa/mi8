#include"utility.h"
#include"gio.h"
int main()
{
    //printHello();
    char *p =NULL;
    send(&p);
    printf("after remove \"V\":%s\n",p);
#ifndef RH7
    GIO_GPIO_STAT_VALUE v1 = GIO_GPIO_STAT_STI0;
    printf("v1 is :%x\n",v1);
    gio_open("vxi11/atslxws605/gpib0");
#endif
    return 0;
}
