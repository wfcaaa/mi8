#include"print.h"

void printHello()
{
    printf("hello world\n");
}
