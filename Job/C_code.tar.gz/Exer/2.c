#include<stdio.h>
#include<string.h>
void test1(char**p)
{
    printf("exec test1\n");
    int flag = 1;
    for(int i=0;i<5;++i)
    {
        printf("current:%d\n",i);
        if(i == 3 && flag == 1)
        {
            printf("it is 3, will repeat again\n");
            --i;
            flag = 0;
            continue;
        }
    }
}

int main()
{
    char * p =NULL;
    test1(&p);
    
}
