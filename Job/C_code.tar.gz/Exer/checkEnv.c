#include<stdio.h>
#include<stdlib.h>

int main(int argc,char* argv[])
{
    printf("argument count:%d\n",argc);
    char* p = NULL;
    if(argc>1)
        p = getenv(argv[1]);
    if(p)
      printf("find:%s",p);
    else
      printf("there is no %s variable\n",argv[1]);
    return 0;
}
