#include<stdio.h>
#include<string.h>
void test(char** p)
{
    static char arr[] = "asdgh";
    *p = arr;
}
void getContent(char** p)
{
    static char arr[] = "hello asf";
    test(p);
}

void setup(char* str)
{
    for(int i=0;i<4;++i)
      str[i] = 'a';
}
int main(int argc,char* argv[])
{
    printf("arguments conunt:%d\n",argc);
    if(argc>1)
    {
        int num = atoi(argv[1]);
        printf("num:%d\n",num);
        printf("%x %x\n",0xff&(num>>8),0xff&num);
    }
    char* p = NULL;
    getContent(&p);
    
    if(p)
    {
      char arr[12] = "";
      strcpy(arr,p);
      printf("arr:%s\n",arr);
    }

    char str[12] = "123";
    printf("before set:%s\n",str);
    setup(str);
    printf("after setup:%s\n",str);

    int number[] = {-8,1,2,-4,5,7,-9,10,-32};
    for(int i=0; i<sizeof(number)/sizeof(int);++i)
        printf("%d ",number[i]);
    printf("\n");
    for(int i=0; i<sizeof(number)/sizeof(int);++i)
    {
        if(0x80000000&number[i])
        {
          printf("negative number:%x:",number[i]);
          printf("-%d\n",0xffffffff-number[i]+1);
        }
        else
          printf("positive number:%x\n",number[i]);
    }

    if(0xff|0xff000000)
      printf("condition true\n");
    else
      printf("condition false\n");
    return 0;
}
