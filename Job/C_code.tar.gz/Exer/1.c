#include<stdio.h>
#include<string.h>


typedef void (*FUNC)(void);

void testForPrintFloat()
{
    int a = 3,b = 2;
    float c = (float)a/b;
    printf("result:%.03f\n",c);

}

void testForPrintAdress()
{
    int a = 12;
    char b[12] = "hello";
    printf("the address of variable a:%p\t%#x\n",&a,&a);
    printf("the address of arr b:%p\t%#x\n",&b,&b);
}

void addNumbers(int a,int b,char** output)
{
    static char result[64] = "";
    *output = result;
    if(a+b%2 == 0)
      sprintf(result,"%d+%d is even number",a,b);
    else
      sprintf(result,"%d+%d is odd number",a,b);
}

void addNumbers_1(int a,int b,char* output)
{
    static char result[64] = "";
    output = result;
    if(a+b%2 == 0)
      sprintf(result,"%d+%d is even number",a,b);
    else
      sprintf(result,"%d+%d is odd number",a,b);
}

void Sort(int *arr,int len)
{
    if(len <= 0)
      return;
    
    for(int i=0; i < len;++i)
    {
        for(int j=i;j<len-1;++j)
        {
            if(arr[j+1] < arr[j])
            {
                int temp = arr[j+1];
                arr[j+1] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

void SortForChar(char* arr,int len)
{
   strncpy(arr,"hhhhhhhhhhhhhhhhhhhh",len);
}

void dprint()
{
    char arr[64] = "";
    char barcodes[] = "CCD1,1D,2D;2,7D,2D;";
    memset(arr,0,sizeof(arr));
    strcat(arr,barcodes+3);
    printf("barcodes:%s\n",arr);
    char index[] = "2,";
    char* token = strstr(barcodes,index);
    if(token)
    {
        int skip = strlen(index);
        int inum = strcspn(token+skip,";");
        char tem[64] = "";
        strncpy(tem,token+skip,inum);
        printf("site 2 barcode:%s\n",tem);
    }
   printf("barcodes:%s\n",barcodes);
   sprintf(barcodes,"hello %d",4);
   printf("%s\n",barcodes);
}

void testForBreak()
{
  char * str = "Barcode:abcef";
  char * p = strchr(str,':');
  if(p)
  {
    printf("%s\n",p);
    ++p;
    printf("%s\n",p);
  }
  char arr[64] = "";
  printf("sizeof:%d,strlen:%d\n",sizeof(arr),strlen(arr));
  sprintf(arr,"%s","hello");
  printf("sizeof:%d,strlen:%d\n",sizeof(arr),strlen(arr));
}
int main()
{
  FUNC f = testForBreak;
 
  f();
  


}
