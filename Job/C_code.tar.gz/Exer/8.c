#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
    char arr[] = "gpib0";
    char* token = strtok(arr,",");
    if(token)
        printf("%s\n",token);
    else
        printf("the string %s doestn't contain '",token);

    char arrs[] = {1,1,1,1};
    int num  = 0;

    for(int i=0; i <sizeof(arrs);++i)
    {
      num|=(arrs[i]<<(8*i));
      printf("i:%d,%d\n",i,arrs[i]);
    }
    printf("num:%d\n",num);

    int flag = 1;
    int index = 0;
    if(flag && (++index))
      printf("success,index:%d\n",index);

    flag = 0;

    if(flag && (++index))
      printf("");   
    else
      printf("failed,index:%d\n",index);

    printf("hello world\r?");


}
