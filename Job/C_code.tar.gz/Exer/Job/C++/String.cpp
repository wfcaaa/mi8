#include"String.hpp"
#include<cstring>
String::String(const char* str)
{
    cout<<"enter char* ctr"<<endl;
    if(!str)
    {
        data=new char[1];
        data[0]='\0';
        len=0;
    }
    else
    {
        len=strlen(str);
        data= new char[len+1];
        strcpy(data,str);
    }
}

String::String(const String& s)
{
    cout<<"enter copy construcor function";
    if(s.len==0)
    {
        data=new char[1];
        data[0]='\0';
        len=0;
    }
    else
    {
        len = s.len;
        data= new char[len+1];
        strcpy(data,s.data);
    }
}
String::~String()
{
    cout<<"enter destructor"<<endl;
    if(data)
    {
        delete[]data;
        data=NULL;
        len=0;
    }
}

String& String::operator=(const String& s)
{
    cout<<"enter operaor="<<endl;
    if(this != &s){
     if(data)
     {   delete[] data;
         len=0;
     }
    len =strlen(s.data);
    data=new char[len+1];
    strcpy(data,s.data);
    }
    return *this;
   
}
String String::operator+(const String& s)
{
    cout<<"enter +"<<endl;
    if(len+s.len==0)
        return String();
}
const char* String::getData()const
{
    return data;
}
 int String::getLen()const
{
    return len;
}

void test()
{
   String s1("hello world!");
   cout<<s1.getData()<<" "<<s1.getLen()<<endl; 
   String s2;
   s2=s1;
    cout<<s2.getData()<<" "<<s2.getLen()<<endl; 
    String s3,s4;
    s3+s4;
}
int main()
{
    test();
    
}

