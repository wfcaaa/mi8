#ifndef __STRING__
#define __STRING__

#include<iostream>
using namespace std;
class String
{
    public:
        
        String(const char*str=NULL);
        String(const String& );
        ~String();
    public:
         String& operator=(const String&);
        String operator+(const String&);
        const char* getData()const;
         int   getLen()const;
    private:
        char* data;
        size_t len;
};
#endif
