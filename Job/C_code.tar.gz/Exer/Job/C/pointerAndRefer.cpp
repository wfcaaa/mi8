#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;

void fun(int arr[])
{
    cout<<sizeof(arr)/sizeof(arr[0])<<endl;
}

void bar(int (&arr)[3])
{
    cout<<sizeof(arr)<<endl;
}

typedef union{long i;int k[5];char c;} DATE;
struct data
{
    int cat;
    DATE t;
    double dog;
};

void foo(int *p1,int *p2)
{
   
    int a,b,c,d;
    a=10;
    b=a++;
    c=++a;
    d=10*++a;
    printf("b c d:%d %d %d\n",b,c,d);
}
int main()
{
    int arr[3]={0};
    //cout<<sizeof(arr)/sizeof(arr[0])<<endl;
    //fun(arr);
 /*   bar(arr);
    char str[]="hello";
    cout<<sizeof(str)<<"long:"<<sizeof(long)<<endl;
    cout<<"DATE:"<<sizeof(DATE)<<endl;
    cout<<sizeof(struct data)<<endl;
    char c[10]="";
    strcpy(c,"0123456789");
    printf("%s\n",c);*/
    int a=1,b=2;
    printf("%d %d\n",a,b);
    foo(&a,&b);
    printf("%d %d\n",a,b);
}

