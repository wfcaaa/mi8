#include<stdio.h>

#define LEN(arr) sizeof(arr)/sizeof(arr[0])
void part(int *arr,int len)
{
    if (arr==NULL)
        return ;
    for(int i = 0;i<len-1;++i)
    {
        int minIndex = i;
        for(int j=i;j<len-i;++j)
        {
            if(arr[j]<arr[minIndex])
                minIndex=j;
        }
        if(minIndex!=i)
        {
            int tmp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = tmp;
        }
    }
    
}

int main()
{
    int arr[] = {5,4,3,2,1};
    part(arr,5);
    for(int i = 0 ; i<5;++i)
        printf("%d\n",arr[i]);
}
