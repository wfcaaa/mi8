#include<stdio.h>
#include<string.h>
#include<ctype.h>
void fun(char *arr)
{
    int len=strlen(arr),newLen=0,spaceCount=0,tmp =0;
    printf("in fun:%s %d %d\n",arr,len,newLen);
    for(int i=0;i<len;++i)
    {
        if(isspace(*(arr+i)))
            ++spaceCount;
    }
    newLen = len+2*spaceCount;
    char *p1 = arr+len-1;
    char *p2 = arr+newLen-1;
    *(p2+1) = '\0';
    *(p1+1)=' ';
    
    for(;len>0;--len)
    {
        if(isspace(*(arr+len-1)))
        {
            /*++tmp;
            if(tmp==spaceCount)
                break;*/
            printf("in space case:%s\n",p2);
            p2=p2-3;
             printf("after move:%s\n",p2);
            continue;
        }
        else
        {
            //printf("%s ",(arr+len-1));
            (*p2)=(*(arr+len-1));
            //*(arr+len-1) = ' ';
            printf("%s\n",p2);
            --p2;
        }
    }
    printf(" %d %d %s\n",newLen,strlen(arr),arr);

}

int main()
{
    char arr[64]="Hi to HP";
    printf("%s %p\n",arr,arr);
    fun(arr);

     printf(" %s %p\n",arr,arr);
}
