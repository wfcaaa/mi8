#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<signal.h>

static void signal_handler(int signal)
{
    printf("caught signal %d\n",signal);
    exit(EXIT_SUCCESS);
}

int main()
{
    if(signal(SIGINT,signal_handler)==SIG_ERR)
    {
        perror("can not caught SIGINT");
        exit(EXIT_FAILURE);
    }

    for(;;)
        pause();
    return 0;
}
