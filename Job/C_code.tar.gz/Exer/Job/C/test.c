#include<stdio.h>

int main()
{
     
    printf("%d\n",sizeof(double));
    char arr[] = "hi";
    char * p  =arr;
    printf("%s %p %p\n",p,p ,p+1);
    int *q = (int *)p;
    printf("%p %p\n",q,q+1);
}
