#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<stdlib.h>
#include<strings.h>

#define BUFF_SIZE 1024

int main()
{
    struct sockaddr_in server_addr,client_addr;
    bzero(&server_addr,sizeof(server_addr));
    bzero(&client_addr,sizeof(client_addr));
    server_addr.sin_family=AF_INET;
    server_addr.sin_addr.s_addr=htons(INADDR_ANY);//inet_addr("10.150.115.105");
    server_addr.sin_port=htons(999);

    // create a socket
    int server_fd=socket(AF_INET,SOCK_STREAM,0);
    if(server_fd==-1)
    {
        perror("create socket fail");
        exit(EXIT_FAILURE);
    }

    //set socket option SO_REUSEADDR
    {
        int enable=1;
        if(setsockopt(server_fd,SOL_SOCKET,SO_REUSEADDR,&enable,sizeof(enable)) == -1)
        {
            perror("set reuse port option fail");
            
        }
    }
    
        printf("before bind");


    //bind socket to socket address
    if(bind(server_fd,(struct sockaddr*)&server_addr,sizeof(struct sockaddr)) == -1)
    {
        perror("bind error");
        exit(1);
    }

    // listen
    if(listen(server_fd,100) == -1)
    {
        perror("listen error");
        exit(1);
    }

    // loop to accept the connection from client
    static int count = 0;
    while(1)
    {
        printf("wait for connectation");

        socklen_t len=sizeof(client_addr);
        int new_server_fd=accept(server_fd,(struct sockaddr*)&client_addr,&len);
        if(new_server_fd<0)
        {
            perror("accept error");
            break;
        }

        char buffer[BUFF_SIZE];
        bzero(buffer,BUFF_SIZE);
        len = recv(new_server_fd,buffer,BUFF_SIZE,0);
        if(len<0)
        {
            perror("receive message error");
            break;
        }
        ++count;
        printf("the data from client is:%s\n",buffer);
        char clientBuff[BUFF_SIZE];
        bzero(clientBuff,BUFF_SIZE);
        sprintf(clientBuff,"this is %d time connection from client",count);
        if(send(new_server_fd,clientBuff,BUFF_SIZE,0)<0)
        {
            perror("send data to client error");
            break;
        }
        close(new_server_fd);
    }
    close(server_fd);
    return 0 ;
}
