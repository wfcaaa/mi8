#include<stdio.h>
#include<string.h>
#define H hello world
int main()
{
    char *p = strdup("hello");
    if(p)
        printf(" %s\n",p);
    printf("hello world\n");
}
