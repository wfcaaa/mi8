#include<stdio.h>

char* strcp(char *des,const char *src)
{
    if(!des||!src)
        return NULL;
    if(des==src)
        return des;
    char *tmp = des;
    while((*des++=*src++)!='\0')
        ;
    return tmp;
}

int main()
{
    char arr1[]="hello world!";
    char arr2[]="hi world!";
    printf("%s %s\n",arr1,arr2);
    strcp(arr1,arr2);
    printf("%s %s\n",arr1,arr2);
}   
