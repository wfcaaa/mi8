#include<stdio.h>
#include<string.h>
#include<stdlib.h>

static char szSeparateBarcodes[1024] = "";
static char szBarcode[1024] = "";
static char* szBarcodePerSite[1024] = {NULL};
typedef struct siteCoordinate
{
    int isValid ;
    int x ;
    int y ;
}SiteCoordinate;

static SiteCoordinate perSiteCoordinate[64];
static int getCheckSum( char* buf,int size)
{
    int sum = 0;
    for(int i=0; i<size;++i )
      sum+=buf[i];
    return sum;
}

void testForChecksum()
{
     char answer[64] = "122";
    int population = 0;
    if(sscanf(answer,"%d",&population) !=1)
      printf("handler answer not correct\n");
    else
    {
      printf("site info:0x%x\n",population);
      for(int i=0; i<8; ++i)
      {
        if(population & (1<<i))
          printf("device at site:%d\n",i+1);
      }
    }
    char arr[128] = "BARCODEDISABLED";
    int num = getCheckSum(arr,strlen(arr));
    int i = num/128;
    int res = num - i*128;
    printf("%03d:0x%x\n",res,res);

    strcpy(arr,"(GETBARCODENUMBER");
    num = getCheckSum(arr,strlen(arr));
     i = num/128;
     res = num - i*128;
    printf("%03d:0x%x\n",res,res);

     strcpy(arr,"D12345678,D23456789,NA,NA");
    num = getCheckSum(arr,strlen(arr));
     i = num/128;
     res = num - i*128;
    printf("%03d:0x%x\n",res,res);

     strcpy(arr,"D12345678,DECODEFAIL,NA,NA");
    num = getCheckSum(arr,strlen(arr));
     i = num/128;
     res = num - i*128;
    printf("%03d:0x%x\n",res,res);

     strcpy(arr,"BARCODEDISABLED");
    num = getCheckSum(arr,strlen(arr));
     i = num/128;
     res = num - i*128;
    printf("%03d:0x%x\n",res,res);
}
int sep(const char* str)
{
    strcpy(szSeparateBarcodes,str);
    strcpy(szBarcode,str);
    char * pBarcodes = strchr(szSeparateBarcodes, ':') + 1;
    if(pBarcodes == NULL)
    {
        /* means we got unexpected answer */
        return -1;
    }
    char * savePtr = NULL;
    char * pBuff = pBarcodes;
    int iLoop = 0;
    int iSiteCount = 0;     /* site count */
    int iReverse = 0;       /* reverse control */

    /* seperated the barcodes by ',', the barcodes will be stored in the char** array */
    while((pBuff = strtok_r(pBuff, ",", &savePtr)) != NULL)
    {
        szBarcodePerSite[iLoop++] = pBuff;
        pBuff = NULL;
    }

   
    return 0;
}
void parseSiteinfo(char* sites)
{
    
    char tmp[128] = "";
    if( sscanf(sites,"D%s",tmp) != 1)
      printf("format error\n");
    printf("site info:%s\n",tmp);
    char* token = tmp;
    int siteNum = 0,x=0,y=0;
    for(int i=0; i<8;i++)
      perSiteCoordinate[i].isValid = 0;
    while( (token = strtok(token,",")) != NULL)
    {
        printf("current token:%s\n",token);
        char arr[3] = "";
        strncpy(arr,token,3);
        siteNum = atoi(arr);
        SiteCoordinate ac;
        strncpy(arr,token+3,3);
        ac.x = atoi(arr);
        strncpy(arr,token+6,3);
        ac.y = atoi(arr);
        ac.isValid = 1;
        printf("site:%d,x:%d,y:%d!\n",siteNum,ac.x,ac.y);
        perSiteCoordinate[siteNum-1] = ac;
        token = NULL;
    }
    printf("$$$$$$$$$$$$$$$$$$$\n");
}
char* getBarcode(int num)
{
    if(num >=1)
    return szBarcodePerSite[num-1];
    else
      return NULL;
}

int main(int argc,char* argv[])
{
    int num = 1;
    if(argc > 1)
      num = atoi(argv[1]);
    printf("num:%d\n",num);
    sep("BARCODE:D12345678,D23456789,NA,NA");
    printf("%s\n",getBarcode(num) );
    sep("barcode:D12345678,DECODEFAIL,NA,NA");
    printf("%s\n",getBarcode(num) );

    char* strArr[12] = {"D008003001,006006004,004001002,003002001","D007002001,005003004,004001002,00!002001"};
    char*p = strArr[0];
    parseSiteinfo(p);
    printf("start to get corrdinates:\n");
    for(int i=0;i<8;++i)
    {
        if(perSiteCoordinate[i].isValid)
          printf("site%d xy:%d,%d\t",i+1,perSiteCoordinate[i].x,perSiteCoordinate[i].y);
    }
    printf("\n");
    p = strArr[1];
    parseSiteinfo(p);
    printf("start to get corrdinates:\n");
    for(int i=0;i<8;++i)
    {
        if(perSiteCoordinate[i].isValid)
          printf("site%d xy:%d,%d\t",i+1,perSiteCoordinate[i].x,perSiteCoordinate[i].y);
    }
    printf("\n");

    long binNumber = 9;
    char binCode[12] ;
    sprintf(binCode,"%d",binNumber);
    printf("bincode:%s\n",binCode);
    printf("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");
    char binInfo[] = "S00800,00600,00400,00300,00201,00101Q";
    char *token =  binInfo;
     while( (token=strtok(token,",")) != NULL)
      {
        char arr[12] = "";
        strcpy(arr,token);
        int index = 0;
        int binId =0;
        
        if(strchr(arr,'S') == NULL)
        {
          char tmp[3] = "";
          strncpy(tmp,arr,3);
          index = atoi(tmp);
          strcpy(tmp,arr+3);
          binId = atoi(tmp);
        }
        else
        {
          char tmp[3] = "";
          strncpy(tmp,arr+1,3);
          index = atoi(tmp);
          strcpy(tmp,arr+4);
          binId = atoi(tmp);
        }
        printf("Send device on site %d to bin %d\n",index,binId);
        token = NULL;
      }


    
}
