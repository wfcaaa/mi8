#include<stdio.h>
#include<assert.h>
#define LEN(x) sizeof(x)/sizeof(x[0])
extern int partSort(int *,int,int);
void quickSort(int *arr,int left,int right)
{
    assert(arr);
    if(left>=right)
        return;
    int index=partSort(arr,left,right);
    quickSort(arr,left,index-1);
    quickSort(arr,index+1,right);
}

int partSort(int *arr,int left,int right)
{
    int key =right;
    while(left<right)
    {
        while(left<right&& arr[left]<=arr[key])
            ++left;
        while(left<right && arr[right]>=arr[key])
            --right;
        int tmp = arr[left];
        arr[left] = arr[right];
        arr[right]= tmp;
    }
    int tmp = arr[key];
    arr[key] = arr[left];
    arr[left] = tmp;
    return left;
}

int main(int argc,char* argv[])
{
    int i=0;
    int arr[]={4 ,1, 7, 6, 9 ,2, 8 };
    
    printf("xxxxxxbefore convert %d\n",argc);
    for(i=0;i<LEN(arr);++i)
        printf("%d ",arr[i]);
    printf("\n");
    quickSort(arr,0,LEN(arr)-1);
      printf("after convert %d:\n",LEN(arr));
    for(i=0;i<LEN(arr);++i)
        printf("%d ",arr[i]);
    printf("\n");
    
}
