#include<stdio.h>
#include<stdlib.h>
//method_1
void method_1()
{
    int arr[8]={0};
    
    printf("please input bad number:\n");
    
    int badNum=3;
    int alive=8;
    int number=0;
    int index=0;
    while(alive>0)
    {
        number+=1-arr[index];
        if(number==badNum)
        {
            if(alive==1)
                printf("the index of last one is:%d\n",index);
            --alive;
            arr[index]=1;
            number=0;
        }
        index=(index+1)%8;
    }

}

void method_2(int count,int doomNumber)
{
    int *cricle= (int*)calloc(sizeof(int),count);
    int alive=count;
    int curNum=0;
    int index=0;
    while(alive>0)
    {
        curNum+=1-cricle[index];
        if(curNum==doomNumber)
        {
            if(alive==1)
                printf("the index of the last number is %d\n",index);
            --alive;
            cricle[index]=1;
            curNum=0;
        }
        index=(index+1)%count;
    }
}

int main()
{
    //method_1();
    printf("please input people number:");
    int num=0;
    scanf("%d",&num);
    printf("please input doom number:");
    int doom=0;
    scanf("%d",&doom);
    method_2(num,doom);
}
