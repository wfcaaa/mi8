#include<stdio.h>
#define LEN(x) sizeof(x)/sizeof(x[0])
int insertSort(int arr[],int len)
{
    if(!arr||len<1)
        return -1;
    int i=0;
    for(i=1;i<len;++i)
    {
        int j=i;
        while(j>0&&arr[j]<arr[j-1])
        {
            int tmp = arr[j];
            arr[j]=arr[j-1];
            arr[j-1]=tmp;
            --j;
        }
    }
    return 0;
}

int main()
{
    int arr[] = {3,5,9,8,2,20,10,45};
    printf("befor sort:\n");
    int i = 0;
    for(i=0; i<LEN(arr);++i)
        printf("%d ",arr[i]);
    printf("\n");
    insertSort(arr,LEN(arr));
     printf("after sort:\n");  
      for(i=0; i<LEN(arr);++i)
        printf("%d ",arr[i]);
      printf("\n");
}
