#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 10
#define LEN(x) sizeof(x) / sizeof(x[0])
void bubble(int *arr,int len)
{
    int i=0,j=0;
    int exitFlag = 1;
    for( i=0;i<len-1;++i)
    {
        for( j=0;j<len-1-i;++j)
        {
            if(arr[j]>arr[j+1])
            {
                int tmp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=tmp;
                exitFlag=0;
            }
        }
        if(exitFlag)
            break;
    }
}

int main(int argc,char*argv[])
{
    printf("the input parameter lenth is %d\n",argc);
    int i=0;
    int arr[MAX]={0};
    
    for(i=1;i<argc;++i)
    {
        arr[i-1]=strtol(argv[i],NULL,10);
    }
    printf("xxxxxxbefore convert %d:\n",LEN(arr));
    for(i=0;i<LEN(arr);++i)
        printf("%d ",arr[i]);
    printf("\n");
    bubble(arr,argc-1);
      printf("after convert %d:\n",LEN(arr));
    for(i=0;i<LEN(arr);++i)
        printf("%d ",arr[i]);
    printf("\n");
    bubble(arr,argc-1);
}
