#include<stdio.h>


// binary search

int binarySearch(int key, int arr[],int len)
{
    if(arr && len>=1){
        if(key == arr[0])
            return 0;
    int low = 0;
    int high = len -1;

        
        while(low <= high)
        {
            int mid = low + (high-low)/2;
            if(key == arr[mid])
                return mid;
            else if(key < arr[mid])
            {
                high = mid -1;
            }
            else
            {
                low = mid +1;
            }
        }
        return -1;
    
    }
    else{
        printf("parater error\n");
        return -1;
    }
}
int recSearch(int key, int arr[],int low,int high)
{
    if(low > high)
        return -1;
    int mid = low + (high-low)/2;
    if(key < arr[mid])   return recSearch(key,arr,low,mid-1);
    else if(key > arr[mid])  return recSearch(key,arr,mid+1,high);
    else return mid;
}
//recursive search
int binarySearchRec(int key,int arr[],int len)
{

    return recSearch(key,arr,0,len-1);
}
int main()
{
    int arr[10];
    for(int i =0; i < sizeof(arr)/sizeof(int);++i)
        arr[i] = i;
    printf("in main %d\n",sizeof(arr)/sizeof(int));
   printf("the 6 index is %d\n", binarySearch(6,arr,sizeof(arr)/sizeof(int)));
     printf("the 9 index is %d\n", binarySearchRec(9,arr,sizeof(arr)/sizeof(int)));
   
    
}
