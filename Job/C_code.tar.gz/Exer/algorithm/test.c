#include<stdio.h>

int main()
{
    int arr[] = {1,2,3,4,5};
    int index =0;
    printf("%d\n",arr[++index]);
}
