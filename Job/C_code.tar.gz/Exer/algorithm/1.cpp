#include<iostream>
#include<stdlib.h>
using namespace std;
class A
{
    public:
    int i;
    int b;
};


class B
{
    bool a;
    
    int b;
    bool c;
};

class C:public B
{
    void foo1();
    static int ab;
    long lb;
};
int main()
{
    A a;
    cout<<sizeof(B)<<endl;
    cout<<sizeof(C)<<endl;
    cout<<&a<<" "<<&(a.i)<<" "<<&(a.b)<<endl;
    system("echo this is a test >./test");
}
