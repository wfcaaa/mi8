#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define MAX_COORDINATE_LENGTH 1024
static char* Coordinate[MAX_COORDINATE_LENGTH] ;
void fun1()
{
    char arr[1024] = "fullsites?";
    printf("arr:%s len:%d\n",arr,strlen(arr));
    for(int i = 10;i<1024;++i)
      arr[i]= 'q';
    char * p = strstr(arr,"fullsites");
    if(p)
      printf("fullsites found\n");
    printf("arr:%s len:%d size:%d\n",arr,strlen(arr),sizeof(arr));
}

void fun2()
{
    char arr[105] = "FULLSITES?";
    printf("arr:%s len:%d\n",arr,strlen(arr));
    for(int i=10; i < 104; ++i)
      arr[i]= 'q';
     printf("arr:%s len:%d\n",arr,strlen(arr));
}
 
void fun3()
{
    int i = 0,pos=0;
    unsigned long ret = 0;
    for(i=0;i<31;i++,++pos)
    {
        printf("%d[P]",i+1);
        ret|=(1<<pos);
    }
    printf("\nFULLSITES %lx\n",ret);
}

void fun4()
{
   char arr[128] = "";
   unsigned long num =0 ;

   for(int i = 0; i<36;++i)
   {
        num |= (1<<i);
   }
   sprintf(arr,"FULLSITE? %.8lx",num);

    printf("%s\n",arr);
}

static void parseSiteInfo(char* siteInfo)
{
        
    int siteNum = atoi(&siteInfo[0]);
    
    if(siteNum >= 10 )
        Coordinate[siteNum] = &siteInfo[3];
    else
        Coordinate[siteNum] = &siteInfo[2];

    
    printf("site:%d,coordinate:%s\n",siteNum,Coordinate[siteNum]);
    
    return;
}

void fun5()
{
    char* token = NULL;
    char arr[1024] = "Set StartTest \"tfff\" 1,O3 5,P3 9,Q3 13,R3 17,S3 21,T3 2,O6 6,P6 10,Q6 14,R6 18,S6 22,T6 3,O9 7,P9 11,Q9 15,R9 19,S9 23,T9 4,O12 8,P12 12,Q12 16,R12 20,S12 24,T12";
    token = strtok(arr," ");
    if(token && strcmp(token,"Set") == 0)
    {
      token = strtok(NULL," ");
      token = strtok(NULL," ");
      printf("strip id parse from hander is :%s\n",token);
      //the other part is site info, parse it.
      token = strtok(NULL," ");
      
      int i = 0,indexNum=0;
      while(token)
      {
        
        ++i;
        parseSiteInfo(token);
        token = strtok(NULL," ");
      }
    }
    else
      printf("unexpeted format\n");

    strcpy(arr,"BARCODE");
    if(strcasestr(arr,"barcode"))
      printf("strcasestr works\n");
    else
      printf("strcasestr doesn't works\n");
}
int main()
{
    fun5();
    return 0;
}
