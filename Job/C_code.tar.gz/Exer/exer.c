#include <stdio.h>
#include <stdlib.h>
#include <string.h>




int phSplitStringByDelimiter(
   const char * str,   
   char delim,   
   char **ppResultArray,
   int maxSize,
   int *sizeOfResultArray
 )
 {
   if( str==NULL || ppResultArray==NULL ) {
     return -1;
   }

   const char *p = str;
   char buf[129] = {0};
   int j = 0;
   int index = 0;

   

   while(*p) {
     char ch = *p;
          
     if( ch == delim ) {

       if( index == maxSize ) {
         return -1;
       }
       
       buf[j] = '\0';
       ppResultArray[index] = malloc(128); 
       strcpy(ppResultArray[index], buf);
       
       buf[0] = 0;
       j=0;
       index++;
     } else {
       buf[j++] = ch;
     }
     
     p++;
   }

   if( index == maxSize ) {
     return -1;
   }

   //collect the last substring
   buf[j] = '\0';

   ppResultArray[index] = malloc(128); 
   strcpy(ppResultArray[index], buf);

   
   *sizeOfResultArray = index+1;

   return 0;
 }
static int extractContactSiteForInFlip( const char *handlerAnswer)
{
  /*
   * analyze the site contact value 
   *  
   * the contact site value fomrate: 
   *  "strip_ID;Contact_Site_number,row,col;Contact_Site_number,row,col;...
   *  
   *  Example 1:   "mStripID1;1,9,29;2,8,29;3,7,29;4,6,29"  (site 1,2,3,4 have devices)
   *  Example 2:   "mStripID2;1,1,1;2,2,1;9,9,1"           (site 1,2,9 have devices; 3-8 no device)
   *  
   *  Note: there might be 72 site in parral!
   */

  char *ppArray[4];
  int length = 0;
  printf("before phSplitStringByDelimiter\n");
  if(phSplitStringByDelimiter(handlerAnswer, ';', ppArray, 4, &length) == 0 ) {
     printf("after phSplitStringByDelimiter,len:%d\n",length);
    //loop from 1 because the first one is the strip ID
    int i = 1;
    char strSiteNum[8];
    for(; i<length; i++ ) {
      //The following line only works for sites 1-9 because it only handles one numeric character
      //BUG   int siteNumber = ppArray[i][0] - 48; //convert the "1" to 1, i.e Site 1
      int j=0;
      while( (ppArray[i][j] != ',') && (ppArray[i][j] != '\0') && (j < 8) ){
         strSiteNum[j] = ppArray[i][j];
         j++;
      }
      printf("str:%s\n",strSiteNum);
      int siteNumber = atoi(strSiteNum);        //convert the first part of xx,xx,xx to site number

      //site 1 is stored in the position of 0!
      siteNumber--;
      
      printf( "new device present at site \"%d\" (SRQ)", 
                       siteNumber);                      
    }                  
  } else {
    printf( "The format of Contact Site Value is invalid; unable to parse it\n");
  }

  //FREE THE MEMORY USED BY phSplitStringByDelimiter
  int k = 0;
  for(k=0; k < length; k++ ) {
    free(ppArray[k]);
  }


  return 0;
}

int main()
{
    extractContactSiteForInFlip("stripid19900 00303;13,1,3");
    printf("atoi:%d\n",atoi("9"));
     printf("atoi:%d\n",atoi("10"));
      printf("atoi:%d\n",atoi("11"));
      printf("atoi:%d\n",atoi("3"));
    char buf[64] = "qwer";
    printf("buf:%s,len:%d\n",buf,strlen(buf));
    return 0;
}
