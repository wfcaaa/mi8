#include<stdio.h>

#define PRINT(x) printf("%d\n",x)
#define foo(x,y) do{PRINT(x);PRINT(y);}while(0)
#define RIDE(X,Y) X*Y

#define phCheck(x) \
{ \
  if(x>0) \
  {\
    printf("%d > 0\n",x);\
  }\
  \
}
union data
{
    int n;
    char ch;
    short m;
};
void testForcomma()
{
   int x=1,y=2;
    int *p = NULL;
    if(!p)
      foo(x,y);
    else
      printf("step in else\n"); 
    int c = RIDE(1+2,3);
    printf("%d\n",c);
}

void testForUnion()
{
  union data a;
  printf("\t%d %d\n",sizeof(a),sizeof(union data));
  a.n = 0x43;
  printf("\t%X,%c,%hX\n",a.n,a.ch,a.m);
  a.ch = '9';
  printf("\t%X,%c,%hX\n",a.n,a.ch,a.m);
  a.m = 0x3142;
  printf("\t%X,%c,%hX\n",a.n,a.ch,a.m);
  a.n=0x4e5d7f41;
  printf("\t%X,%c,%hX\n",a.n,a.ch,a.m);
    
}

void testSomeFunc()
{
    char arr[] = "abcdr1234";
    char *p = arr;
    while(p && *p != 0)
    {
        if(isdigit(*p))
          printf("%c is digit:%d\n",*p,*p);
        else
          printf("%c is not digit\n",*p);
        ++p;
    }
}
int main()
{
   
    testSomeFunc();
}
