#include"doubleList.h"
#include<stdlib.h>
static node* phead=NULL;
static int count=0;

static node* create_node(void *p)
{
    node* pnode=(node*)malloc(sizeof(node));
    if(!pnode)
        return NULL;
    pnode->pre=pnode->next=pnode;
    pnode->data=p;
    return pnode;
}

int create_dlink()
{
    phead=create_node(NULL);
    if(!phead)
        return -1;
    count=0;
    return 0;
}

int dlink_is_empty()
{
    return count==0;
}

int dlink_size()
{
    return count;
}

static node* get_node(int index)
{
    if(index<=1 ||index>=count)
        return NULL;
    if(index < count/2)
    {
        int i=1;
        node* pnode=phead->next;
        while(++i<index)
            pnode=pnode->next;
        return pnode;
    }
    else
    {
        int i = count-1;
        node* rnode=phead->pre;
    }
}
int main()
{
    int num =10;
    node* head=create_node(&num);
    if(head)
        printf("the node data is %d\n",*(int*)head->data);
}
