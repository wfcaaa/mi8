#ifndef __DOUBLELIST__
#define __DOUBLELIST__
#include<stdio.h>

typedef struct Node
{
    void* data;
    struct Node* pre;
    struct Node* next;
}node;

extern int create_dlink();
extern int destory_dlink();

extern int dlink_is_empty();
extern int dlink_size();

extern void* dlink_get(int index);
extern void* dlink_get_first();
extern void* dlink_get_last();

extern int dlink_insert(int index,void* p);
extern int dlink_insert_first(void*p);
extern int dlink_insert_last(void*p);

extern int dlink_delete(int index);
extern int dlink_delete_first(int index);
extern int dlink_delete_first(int index);




#endif
