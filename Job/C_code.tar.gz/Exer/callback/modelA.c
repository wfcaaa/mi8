#include"modelA.h"

void ball1()
{
    printf("play ball1\n");
}

void ball2()
{
    printf("play ball2\n");
}

void ball3()
{
    printf("play ball3\n");
}
