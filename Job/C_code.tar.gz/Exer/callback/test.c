#include"modelA.h"

void basketball()
{
    printf("play basketball\n");
}

void football()
{
    printf("play football\n");
}

void select(void (*call)())
{
    call();
}

int main()
{
    select(basketball);
    select(football);
    select(ball1);
    return 0;
}
