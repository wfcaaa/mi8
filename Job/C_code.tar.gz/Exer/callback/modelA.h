#ifndef __MODELA__
#define __MODELA__

#include<stdio.h>

 void ball1();
 void ball2();
 void ball3();

#endif 
