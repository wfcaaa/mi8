#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
static char Coordinate[1048][10] ;
void fun()
{
    static int a = 0,b =0 ;
    ++a,++b;
    printf("cur a:%d,cur b:%d\n",a,b);
}

static void parseSiteInfo(char* siteInfo)
{
    int siteNum = atoi(&siteInfo[0]);

    if(siteNum-- >= 10 )
        strcpy(Coordinate[siteNum] , &siteInfo[3]);
    else
        strcpy(Coordinate[siteNum] , &siteInfo[2]);

    printf("device present at site \"%d\" (polled), corrdinate:%s\n", siteNum,Coordinate[siteNum]);
    return;
}

void pollParts()
{
    char tmpHandlerAnswer[2048] = "Set StartTest \"tfff\" 1,AO3 5,Pa3 9,Q3 13,R3 17,S3 21,T322 2,O6 6,P6 10,Q6 14,R6 18,S6 22,T6 3,O9 7,P9 11,Q9 15,R9 19,S9 23,T9 4,O12 8,P12 12,AQ12 16,R12 20,S12 24,AD12";
    char *token = strtok(tmpHandlerAnswer," ");
    if(token && strcmp(token,"Set") == 0)
    {
      token = strtok(NULL," ");
      token = strtok(NULL," ");
      printf("strip id parse from hander is :%s\n",token);
      //the other part is site info, parse it.
      token = strtok(NULL," ");
      
      int i = 0,indexNum=0;
      while(token)
      {
        ++i;
        parseSiteInfo(token);
        token = strtok(NULL," ");
      }
      indexNum = i;
    
    }
}

void parseCoordinate(int index,char*response)
{
    char arr[10] = "";
    char xarr[10] = "";
    char yarr[10] = "";
    
        strcpy(arr,Coordinate[index-1]);
        printf("cur str:%s,len:%d\n",arr,strlen(arr));
        int x_index = 0,y_index=0;
        for(int j=0; j < strlen(arr); ++j)
        {
            
            if( isgraph(arr[j]) && !isdigit(arr[j]) )
            {
              xarr[x_index++] = arr[j];
              xarr[x_index] = '\0';
            }

            else if( isdigit(arr[j]) && arr[j] != '\0')
            {
              //yarr[y_index++] = arr[j];
              //yarr[y_index] = '\0';
             // printf("cur char:%c:%d,str:%s\n",arr[j],arr[j],&arr[j]);
              strcpy(yarr,&arr[j]);
              break;
            }
        }
        int x_num = 0;
        for(int i=0; i < strlen(xarr) ;++i)
            x_num = 26*i + (xarr[i] - 64);
        int y_num = atoi(yarr);
        sprintf(response,"site:%d,x:%s:%d,y:%s:%d\n",index,xarr,x_num,yarr,y_num);
}

void printAll()
{
    char arr[10] = "";
    char xarr[10] = "";
    char yarr[10] = "";
    
    for(int i=0; i < 24;++i)
    {
        strcpy(arr,Coordinate[i]);
        printf("cur str:%s,len:%d\n",arr,strlen(arr));
        int x_index = 0,y_index=0;
        for(int j=0; j < strlen(arr); ++j)
        {
            
            if( isgraph(arr[j]) && !isdigit(arr[j]) )
            {
              xarr[x_index++] = arr[j];
              xarr[x_index] = '\0';
            }

            else if( isdigit(arr[j]) && arr[j] != '\0')
            {
              yarr[y_index++] = arr[j];
              yarr[y_index] = '\0';
              //strcpy(yarr,&arr[j]);
            }
        }
        int x_num = 0;
        for(int i=0; i < strlen(xarr) ;++i)
            x_num = 26*i + (xarr[i] - 64);
        int y_num = atoi(yarr);
        printf("site:%d,x:%s:%d,y:%s:%d\n",i+1,xarr,x_num,yarr,y_num);
    }
}
int main()
{
    fun();
    fun();
    fun();
    fun();
    pollParts();
    printf("sizeof two arr:%d\n",sizeof(Coordinate[1]));

    printAll();
    printf("#########\n");
    char arr[128] = "";
    parseCoordinate(24,arr);
    printf("in main: %s",arr);
}
