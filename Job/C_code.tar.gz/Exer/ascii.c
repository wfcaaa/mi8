#include <stdio.h>
#include <stdlib.h>

void test(char* arr)
{
  arr[0] = 48;
    
}

void setSerialNum (unsigned char* buf,int num)
{
    if(num <=255)
      buf[13] = num & 0xff;
    else if(num <=65536)
    {
        buf[12] = num >> 8;
        buf[13] = num & 0xff;
    }
    else if(num <= 16777215)
    {
          buf[11] = num >> 16;
      buf[12] = (num >> 8) & 0xff;
      buf[13] = num & 0xff;
    }
    else
    {
      buf[10] = num >> 24;
      buf[11] = (num >> 16) & 0xff;
      buf[12] = (num >> 8) & 0xff;
      buf[13] = num & 0xff;
    }

    for(int i=0; i < 14;++i)
    {
        if(i<10)
          printf("%d ",buf[i]);
        else
          printf("0x%.02x ",buf[i]);
    }
    printf("\n");
}
void main()
{
#if 0
  int x;
  for (x = 0; x< 128; x++)
    if (x < 32)
      printf("^%-3c \\x%.03x \\%.03o %.03d\n", x+64, x, x, x);
    else
      printf("\x20%-3c \\x%2.2x \\%3.3o %3d\n", x, x, x, x);
#endif

   int num = 0x121f;
  char arr[28] = "";
  for(int i=0; i <sizeof(arr); ++i)
    arr[i] = i;
  printf("before\n");
  for(int i=0; i <sizeof(arr); ++i)
    printf("%d:%d ",i+1,arr[i]);
 
  
   test(arr+14);
   printf("after\n");
  for(int i=0; i <sizeof(arr); ++i)
    printf("%d:%d ",i+1,arr[i]);
  printf("\n");

  unsigned char test[14] = {0,0};
  test[1] = 0;
  test[2] = '0';
  test[3] = '\0';
  for(int i=0;i<4;++i)
    printf("%d:%c|%d\n",i,test[i],test[i]);

 
  
  printf("##################\n");
  setSerialNum(test,200);
  setSerialNum(test,9999);
  setSerialNum(test,16777199);
   setSerialNum(test,167779999);
} 
