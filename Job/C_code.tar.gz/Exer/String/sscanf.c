#include<stdio.h>
#include<string.h>

void fun(const char* s)
{
    char siteinfo[1024] = "";
    int ret =sscanf(s,"%*[^=]=%[^\x03]",siteinfo);
    printf("%s %d\n",siteinfo,ret);
}

void fun1(const char* s)
{
    char a[64] = "";
    int ret = sscanf(s,"=%s",a);
    printf("%s %d\n",a,ret);
    
}
int main()
{
    fun("3|testsites=1_+1_+X_\x03");
    fun1("=hello world!");
}
