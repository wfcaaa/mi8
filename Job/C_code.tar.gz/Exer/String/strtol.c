#include<stdio.h>
#include<string.h>

void test(const char* s)
{
    long int ret = strtol(s,(char**)NULL,10);
    printf("%d\n",ret);
}

int main()
{
    test("18");
    char arr[10] = "";
    sprintf(arr,"%lx",16);
    printf("0x%s\n",arr);
    return 0;
}
