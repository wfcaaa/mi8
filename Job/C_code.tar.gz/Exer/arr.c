#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main1()
{
    int a[][3] = {{1,2,3},{2,3,4},{5,6,7}};
    printf("%d\n",a[0][2]);
}


void fun(const char* num)
{
    char message[2048] = "";
    int c = atoi(num);
    strcat(message,"O");
    for(int i = 0 ; i < (c-1)/4+2;++i)
        strcat(message,"A");
    printf("%d %s\n",c,message);
}
int main(int argc,char *argv[])
{
    fun(argv[1]);
}
