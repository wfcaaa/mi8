#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct a
{
    int a;
    short b;
    char c;
};

struct b
{
    
    short b;
    int a;
    char c;
}; 

struct c
{
    int a;
   
    char c;
     short b;
};

void fun(char str[100])
{
     printf("%d\n",sizeof(str));
}

void test()
{
    char str[10]="";
    char str2[11]="";
    int i=0;
    for(i=0;i<10;++i)
        str[i]='a'+i;
    str[i-1]='\0';
    strcpy(str2,str);
    printf("%s\n",str2);
}

void test1()
{
    int i=0;
    while(i==0)
        printf("%d\n",i);
}
int main1()
{
    printf("%d\n",sizeof(struct a));
     printf("%d\n",sizeof(struct b));
      printf("%d\n",sizeof(struct c));
      struct a arr[5];
     printf("%d\n",sizeof(arr));
     char str[] ="hello";
     char *p = str;
     int n=10;
    printf("%d\n",sizeof(str));
    printf("%d\n",sizeof(p));
    printf("%d\n",sizeof(n));
    printf("%d\n",strlen(str));
     printf("%d\n",strlen(p));
     fun(str);
     test();
     test1();
    return 0;
}


int main2()
{
    char arr[]= "http://www.kingstarfintech.com/";
    char *p =arr;
    int n= 10;

     void *p1 = malloc(100);
    printf("%d %d %d %d %d\n",sizeof(arr),sizeof(p),sizeof(n),sizeof(p1),sizeof(p1));
    int i=10 ,j=10, k=3;
    k*=i+j;
    printf("%d\n",k);
    for(int a=0;a<10;++a)
    printf("%d%4=%d\n",a,a%4);
   
    return 0;
}

int main()
{
    char arr[] = "hello world,1#cat,2#pig,3#fox";
    char tmp[] = "fox";
    char *token = strtok(arr,",");
    int num = 0;
    char barcode[128] = "";
    char *persite[1024];
    int i = 0;
    while(token)
    {
        ++num;
        if(1 == num)
          printf("%s\n",token);
        else
        {
            
            char *p = strchr(token,'#');
            if(p)
            {
              persite[i++] = p+1;
              strcat(barcode,p+1);
            }
        }
        token = strtok(NULL,",");
        if(token && num!=1)
          strcat(barcode,",");
    }
    printf("all barcode:%s !site2 barcode:%s\n",barcode,persite[1]);
    for(int i=0;i<num-1;++i)
      printf("site%d barcode:%s\n",i+1,persite[i]);

}




















