#include<stdio.h>
#include<string.h>

int main()
{
    
   int day, year;
   char weekday[20], month[20], dtm[100];

   strcpy( dtm, "Saturday March 25 1989" );
   sscanf( dtm, "%s %s %d  %d", weekday, month, &day, &year );

   printf("%s %d, %d = %s\n", month, day, year, weekday );
    char arr[20] = "26";
    sprintf(arr,"%.08lx\n",122);
    long num = 0;
    int ret = sscanf(arr,"%lx",&num);
    printf("ret:%d,num=%d\n",ret,num);
    for(int i=0; i < 8; ++i)
    {
        if(num & (1L<<i))
          printf("device at site %d\n",i+1);
    }
}
