#include<stdio.h>
#include<string.h>



void sscanfTest()
{
    char *p = "china  beijing 999";
    int d = 0;
    char ret1[64]= "",ret2[64]= "";
    int ret = 0;
    ret = sscanf(p,"%s %s %d",ret1,ret2,&d);
    printf("%s %s %d %d\n",ret1,ret2,d,ret);
}
int main()
{
    
    sscanfTest();

    char a[64] = "";
    char b[64] = "";
    char *p = "thisis\f";
    sscanf(p,"%s",a);
    strcpy(b,p);
    printf("%s %d %d\n",a,strlen(a),strlen(b));

    char *ptr = "fullsite  \r\n\t\v1\r\n2";
    int dig = 0;
    int ret = sscanf(ptr,"fullsite%i",&dig);
        printf("%i ret:%d\n",dig,ret);
   
}
