#include<stdio.h>
#include<string.h>
void rhombus()
{
    int n=3;
    printf("please input a number to set the line of rhombus,the input number must be prime number\n");
    scanf("%d",&n);
    while(1)
    {
        if(n%2 == 1)
            break;
        else
        {
            printf("the input number is not prime number,please input again\n");
            scanf("%d",&n);
        }
    }
    for(int i = 0;i < n/2+1;++i)
    {
        for(int k = 0;k < n/2-i;++k)
        {
            printf(" ");
        }


        for(int j = 0;j < 2*i+1;++j)
        {
            printf("*");
        }
        printf("\n");
    }

    for(int i = 0;i < n/2;++i)
    {
        for(int k = 0;k < i+1;++k)
        {
            printf(" ");
        }


        for(int j = 0;j < 2*(n/2-i)-1;++j)
        {
            printf("*");
        }
        printf("\n");
    }

    

}


int main()
{
//    rhombus();
    char *p =NULL;//"Hello world!";
    char arr[64]="";
    p = ":0";
    strcpy(arr,p);
    printf("%s\n",arr);
    return 0;
}
