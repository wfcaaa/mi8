#include<stdio.h>

int caclu()
{
    char a=3,b=3;
    int i;
    for( i=1;i<=8;i++)
    {
        a*=2;
        b=b<<1;
        printf("the %d times: a=%d b=%d\n",i,a,b);
    }
}
