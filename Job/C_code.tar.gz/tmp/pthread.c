#include<stdio.h>
#include<pthread.h>
#include<time.h>

int flag=1;
pthread_t tid;
struct stu
{
    int id;
    int age;
};
void * start_routine(void *a)
{
    tid=pthread_self();
    struct stu *s=((struct stu *)a);
    printf("this is a test thread,tid=%d id=%d age=%d \n",pthread_self(),s->id,s->age);
    sleep(5);
    printf("after exit\n");
    flag=0;
    return NULL;
}

int main()
{
    pthread_t pth;
    struct stu s1={1001,12};
    struct stu *p1=&s1;
    printf("in main thread id=%d age=%d\n",p1->id,p1->age);
    int ret=pthread_create(&pth,NULL,start_routine,(void*)p1);
    printf("pth=%d ret=%d\n",pth,ret);
    if(0!=ret)
        printf("create thread failed\n");
    time_t begin,end;
    begin=time(NULL);
    end=begin+10;
    printf("the current time:%s",ctime(&begin));
    while(begin<end)
    {
        if(flag==0)
            break;
        begin=time(NULL);
    }
    printf("the current time:%s tid=%d",ctime(&begin),tid);
   return 0; 

}

