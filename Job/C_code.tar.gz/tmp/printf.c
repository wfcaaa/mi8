#include<stdio.h>
#include<string.h>
int main1()
{
    char *p = "this is a test";
    printf("%-20s\n",p);

    int a =15;
    printf("%o %X %u\n",a,a,a);
    printf("%10d %010d\n",2018,2018);
    printf("%d %ld\n",2019,2019l);
    printf("%#x %#o %#d",100,100,99);
}

int main()
{
    const char *p = "this is a test\r\n";
    char a[64] = "";
    sprintf(a,"%s",p);
    printf("%s %d\n",a,strlen(a));
}
