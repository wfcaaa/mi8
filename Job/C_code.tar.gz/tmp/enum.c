#include<stdio.h>
#include<string.h>
    enum week
{
    MON,
    TUE,
    WED,
    THU,
    FRI,
    STA,
};

int main()
{

enum week w1=WED;
    printf("%d\n",w1);

    char arr[] = "vt123";
    char *p = strchr(arr,'v');
    if( p && *p == arr[0] )
        printf("find\n");
    else
        printf("not find\n");
    return 0; 
}
