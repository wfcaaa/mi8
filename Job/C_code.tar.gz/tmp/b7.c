phPFuncError_t privateBinDie(
    phPFuncId_t proberID     /* driver plugin ID */,
    long *perSiteBinMap      /* binning information or NULL, if
                                sub-die probing is active */,
    long *perSitePassed      /* pass/fail information (0=fail,
                                true=pass) on a per site basis or
                                NULL, if sub-die probing is active */
)
{
    static int srq1 = 0;
    static int srq2 = 0;

    char binCode[4*(1+(PHESTATE_MAX_SITES-1)/4)][9];
    char pfCode[1+(PHESTATE_MAX_SITES-1)/4] = {0};
    char command[4*(1+(PHESTATE_MAX_SITES-1)/4)*9+4];
    long theBin;
    int passed;
    int empty;
    phEstateSiteUsage_t *population;
    phEstateSiteUsage_t newPopulation[PHESTATE_MAX_SITES];
    int entries;
    int site;
    phPFuncError_t retVal = PHPFUNC_ERR_OK;

    if (phPFuncTaAskAbort(proberID))
        return PHPFUNC_ERR_ABORTED;

    if (!perSiteBinMap)
    {
        phLogFuncMessage(proberID->myLogger, PHLOG_TYPE_WARNING, 
            "no binning data available, not sending anything to the prober");
        return PHPFUNC_ERR_OK;
    }

    if (!proberID->p.dieProbed)
    {
        phLogFuncMessage(proberID->myLogger, PHLOG_TYPE_WARNING, 
            "no die currently probed, due to wafer abort");
        return PHPFUNC_ERR_OK;        
    }

    if (!proberID->p.dontBinDies)
    {
        /* prepare empty binning string */
        for (site = 0; site < proberID->noOfSites; site++)
        {
            switch (proberID->model)
            {
              case PHPFUNC_MOD_TEL_20S:
                strcpy(binCode[site], "00000000");
                if (site%4 == 0)
                    pfCode[site/4] = '0';
                break;
        case PHPFUNC_MOD_TEL_P8:
        case PHPFUNC_MOD_TEL_P12:
        case PHPFUNC_MOD_TEL_F12:
              case PHPFUNC_MOD_TEL_78S:
                strcpy(binCode[site], "@@@@@@@@");
                if (site%4 == 0)
                    pfCode[site/4] = '@';
                break;
/* Begin of Huatek Modification, Donnie Tu, 12/12/2001 */
/* Issue Number: 326 */
              default: break;
/* End of Huatek Modification */
            }
        }

        /* compose the binning information string */
        phEstateAGetSiteInfo(proberID->myEstate, &population, &entries);
        for (site = 0; site < proberID->noOfSites; site++)
        {
            /* get bin data or empty status */
            theBin = perSiteBinMap[site];
            passed = perSitePassed[site];
            empty = 0;

            switch (population[site])
            {
              case PHESTATE_SITE_POPULATED:
                newPopulation[site] = PHESTATE_SITE_EMPTY;
                break;
              case PHESTATE_SITE_POPDEACT:
                newPopulation[site] = PHESTATE_SITE_DEACTIVATED;
                break;
              case PHESTATE_SITE_EMPTY:
              case PHESTATE_SITE_DEACTIVATED:
              case PHESTATE_SITE_POPREPROBED:
                empty = 1;
                break;
            }

            if (theBin == -1)
                empty = 1;

      if(!empty && (theBin < 0 || 
                    theBin > ((proberID->p.binningMethod==BINARY_BINNING_METHOD)?255:31))) {
        phLogFuncMessage(proberID->myLogger, PHLOG_TYPE_ERROR,
                         "invalid binning data\n"
                         "could not bin to bin index %ld at prober site \"%s\"",
                         theBin, proberID->siteIds[site]);
        return PHPFUNC_ERR_BINNING;
      }

      /* 
      * fill in data into binning string
      *
      * now support P12/F12 "binary" binning-method: LSB(4bits) in Byte0, MSB(4bits) in Byte1,
      *     use (MSB+LSB) to represent 256 bins. CR 15358
      */
      if(!empty) {
        if(proberID->p.reversedBinning) {
          if( proberID->p.binningMethod == PARITY_BINNING_METHOD ) {
            binCode[proberID->noOfSites - site - 1][theBin>>2] |= (char) (1 << theBin%4);
          } else if( proberID->p.binningMethod == BINARY_BINNING_METHOD ) {
            /* binary binning-method, supported by P12/F12 with 256 bins */
            binCode[proberID->noOfSites - site - 1][0] |= (char) (theBin&0x0F);
            binCode[proberID->noOfSites - site - 1][1] |= (char) ((theBin>>4)&0x0F);
          } else {
            phLogFuncMessage(proberID->myLogger, PHLOG_TYPE_FATAL,
                             "internal error at line: %d, file :%s\n"
                             "the value of \"binnningMethod\" is %d!", __LINE__, 
                             __FILE__, proberID->p.binningMethod);
          }

          if(!passed)
            pfCode[(proberID->noOfSites - site - 1)/4] |= (1 << (proberID->noOfSites - site - 1)%4);
        } else {
          if( proberID->p.binningMethod == PARITY_BINNING_METHOD ) {
            binCode[site][theBin>>2] |= (char) (1 << theBin%4);
          } else if( proberID->p.binningMethod == BINARY_BINNING_METHOD ){
            /* binary binning-method, supported by P12/F12 with 256 bins */
            binCode[site][0] |= (char) (theBin&0x0F);
            binCode[site][1] |= (char) ((theBin>>4)&0x0F);
          } else {
            phLogFuncMessage(proberID->myLogger, PHLOG_TYPE_FATAL,
                             "internal error at line: %d, file :%s\n"
                             "the value of \"binnningMethod\" is %d!", __LINE__, 
                             __FILE__, proberID->p.binningMethod);
          }

          if(!passed)
            pfCode[site/4] |= (1 << site%4);
        }
      }
    }

        /* compose complete bin command */
        strcpy(command, "C");
        for (site = 0; site < proberID->noOfSites; site++)
        {
            if (site%4 == 0)
                strncat(command, &pfCode[site/4], 1);
            strcat(command, binCode[site]);
        }
        strcat(command, MY_EOC);
    }

    /* send the binning to the prober, wait for ackowledge and step */
    phPFuncTaStart(proberID);
    if (!proberID->p.dontBinDies)
    {
        /* only bin, if not configured not to bin */
        PhPFuncTaCheck(phPFuncTaSend(proberID, command));
        PhPFuncTaCheck(phPFuncTaGetSRQ(proberID, &srq1, 2, 0x59, 0x4d));
        if (srq1 == 0x4d)
        {
            /* handle continous fails, the prober is paused, need to wait
               for an unpause */
            phLogFuncMessage(proberID->myLogger, PHLOG_TYPE_WARNING,
                "prober has reported a continuous fail problem");
            phPFuncTaRemoveStep(proberID);
            return PHPFUNC_ERR_WAITING;
        }
    }

    if (! proberID->p.stIsMaster)
    {
        /* changed at TEL, recommendation: always send Q to perform
           the auto step, never use r. This would be difficult anyway
           in case of multi site probing */
        PhPFuncTaCheck(phPFuncTaSend(proberID, "Q%s", MY_EOC));
        do
        {
            PhPFuncTaCheck(phPFuncTaGetSRQ(proberID, &srq2, 4, 0x47, 0x4b, 0x48, 0x62));
            if (srq2 == 0x62)
            {
                /* prober pause detected */
                phEstateASetPauseInfo(proberID->myEstate, 1);
                phPFuncTaRemoveStep(proberID);
                return PHPFUNC_ERR_WAITING;
            }
            else
                phEstateASetPauseInfo(proberID->myEstate, 0);
        } while (srq2 == 0x62);
    }
    else
        retVal = PHPFUNC_ERR_OK;
    phPFuncTaStop(proberID);


    /* correct status */
    if (proberID->p.stIsMaster)
        proberID->p.dieProbed = 0;
    else
    {
        switch (srq2)
        {
          case 0x47:
            /* next die probed */
            proberID->p.dieProbed = 1;
            break;
          case 0x4b:
            /* wafer end */
            proberID->p.dieProbed = 0;
            retVal = PHPFUNC_ERR_PAT_DONE;
            break;
          case 0x48:
            /* this is an unexpected cassette end here. We deal with this
               problem by sending a pattern done here and also doing
               this on the upcoming unload wafer call */
            proberID->p.dieProbed = 0;
            phEstateASetICassInfo(proberID->myEstate, PHESTATE_CASS_NOTLOADED);
            phEstateASetLotInfo(proberID->myEstate, 0);
            retVal = PHPFUNC_ERR_PAT_DONE;
            break;
        }
    }

    /* by default not implemented */
    return retVal;
}
#endif
