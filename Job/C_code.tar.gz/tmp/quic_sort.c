#include<stdio.h>


void swap(int arr[],int a,int b)
{
	int tmp=arr[a];
	arr[a]=arr[b];
	arr[b]=tmp;
}



void quic_sort(int arr[],int left,int right)
{
	int low=left,high=right,flag=0;
	if(left>=right)
		return;
	while(left<right)
	{
		if(arr[left]>=arr[right])
		{	swap(arr,left,right);
			flag=~flag;
		}
		if(flag>0)
			--right;
		else
			++left;
	}
	quic_sort(arr,low,left-1);
	quic_sort(arr,left+1,high);
}


int main()
{
	int i=0,j=0;
	int arr[100]={0};
	printf("please input the number of the arr:\n");
	scanf("%d",&j);
	while(j--)
	{
		printf("please input a number:\n");
		scanf("%d,",arr+i);
		++i;
		
	}
	
	quic_sort(arr,0,i-1);
	for(j=0;j<i;j++)
	{
		printf("%d ",arr[j]);
	}
	printf("\n");
}
