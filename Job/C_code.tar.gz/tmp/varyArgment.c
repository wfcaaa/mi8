#include<stdio.h>
#include<stdarg.h>
#include<string.h>
void foo(const char *format, ...)
{
    va_list ap;
    va_start(ap,format);
    int d = 0;
    char c,*s=NULL;
    while(format && *format != '\0')
    {
        switch(*format)
        {
            case 's':
                s = va_arg(ap,char *);
                printf("%s\n",s);
                break;
            case 'd':
                d= va_arg(ap,int);
                printf("%d\n",d);
                break;
            case 'c':
                c = (char) va_arg(ap,int);
                printf("%c\n",c);
                break;
            default:
                break;
        }
        ++format;
    }
    va_end(ap);
}

void test(const char *p,int num,...)
{
    va_list ap;
    va_start(ap,num);
    int i = 0 ;
    int tmp = 0,sum = 0;
    for(i = 0 ; i < num ; ++i)
    {
        tmp = va_arg(ap,int);
        printf("%d\n",sum);
        sum+=tmp;
         printf("after %d times add the sum is %d\n",i+1,sum);
    }
    printf("the sum is %d\n",sum);
    va_end(ap);
}

void test2(const char *format, ...)
{
    va_list ap;
    va_start(ap,format);
    int d = 0;
    char c,*s=NULL;
    
    vsscanf("hello world",format,ap);
    va_end(ap);
}
int main()
{
    char s[64]="aaaaa";
    char p[64]="bbbb";
    int d = 2018;
    char c= 'a';
   
   
    test2("%s        %s",s,p);
    printf("%s %s %d\n",s,p,strlen(s));
    printf("%d\n",strlen(s));
    //test2("%s %s ",s,p);
   // printf("%s %s %d %d\n",s,p,strlen(s),strlen(p));
   
   
    return 0;
}
