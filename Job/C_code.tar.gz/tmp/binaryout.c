#include<stdio.h>
#include<stdlib.h>


int main()
{
    int a=3;
    char b[100]={0};
    printf("%s\n",itoa(a,b,2));
}
