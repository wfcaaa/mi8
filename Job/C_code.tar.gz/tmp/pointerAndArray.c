#include<stdio.h>
#include<string.h>

int main1()
{
    char a[64] = "";
    char *p =a;

    printf("%d %d %d\n",sizeof(a),strlen(a),sizeof(p));
    memset(a,0,64);
     printf("%d %d %d\n",sizeof(a),strlen(a),strlen(p));
    
    int i = 10;
    int j = 0;
    for( i =65; i<70 ;++ i ,++j)
        a[j] = i;
    printf("%d\n",strlen(a));
    for(i = 0 ;i<strlen(a); ++i)
        printf("%c ", a[i]);


}

void fun(char *p)
{
    memset(p,0,strlen(p));
    strcat(p,"5 ");
    strcat(p,"a");
}
int main()
{
    char a[10] ;
    memset(a,0,strlen(a));
    char *p ="A";
    strcat(a,"\40");
    strcat(a,p);
    printf("%s\n",a);
}
