#include<stdio.h>
#include<stdarg.h>

void myvar(const char *format,...)
{
    
    va_list ap;
    va_start(ap,format);
    char *ptr=NULL;
    ptr=va_arg(ap,char *);
    printf("format:%p  ap:%p\n",&format,ap);
    while(ptr)
    {
        printf("%s\n",ptr);
        ptr=va_arg(ap,char *);
    }
    //printf("%s\n",ptr);
    va_end(ap);
}

int main5()
{
    myvar("this is my var function","hello","world!","how","are","you");
    return 0;
}
