#include<stdio.h>
#include<ctype.h>
#include<string.h>
void setStrUpper(char *s1)
{
    int i=0;

    while ( s1[i] )
    {
        s1[i]=toupper( s1[i] );
        ++i;
    }

    return;
}
int  main()
{
    char arr[]="abcde";
    char *p = arr;
    int *q = (int *)p;
    printf("%c %c\n",*(p+1),*(q+1));
    float a = 3.1415927;
    printf("%3.3f\n",a);
    int b = 12;
    printf("%03d\n",b);

    char c[] = "fullSITES: 00000012,1#025NTA,2#026NTA;";
    p = strchr(c,',');
    char barcode[64] = {0};
    if( p )
    {
        strcpy(barcode,p+1);
    }
    printf("barcode:%s\n",barcode);
    long num = 0;
    sscanf(c,"fullSITES: %lx",&num);
    printf("%0x\n",num);
     printf("%s\n",c);
    setStrUpper(c);
    printf("%s\n",c);
    char * token = strtok(c,",");
    int tokenNum = 0;
    char siteInfo[64] = {0};
    char *barcodes[32] = {0};
    int i =0;
    while(token)
    {
        ++tokenNum;
        if(tokenNum == 1)
        {
            //strcpy(siteInfo,token);
            printf("%s\n",token);
            sscanf(token,"FULLSITES: %lx",&num);
            printf("%0x\n",num);
            
        }
        else
        {
           barcodes[i++] = token; 
        }
        token = strtok(NULL,",");
    }
   // printf("%s\n",siteInfo);
    printf("#######barcode:\n");
    for(int j = 0; j< i ;++j )
        printf("%s\n",barcodes[j]);
 
}
