#include<stdio.h>

void test(int* p)
{
    printf("enter test\n");
    printf("the num is:%d\n",*p);
    sleep(30);
    printf("%s\n",*p);
}
int main()
{
    int arr[][3] = {{1,2,3},{4,5,6}};
    printf("%d %d\n",arr[0][2],arr[1][2]);
    int num = 2;
    test(&num );
    printf("%d\n",num);
    return 0;
}
