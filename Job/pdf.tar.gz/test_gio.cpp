 
////////////////////////////////////////
///
///  Copyright Advantest 2015
///
///  P.Gauthier Global Software Solutions
///
///
///  Keysight E5810A/B LAN/GPIB communication
///  using libgio
///
////////////////////////////////////////

#include <string>
#include <iostream>

#include "gio.h"

using namespace std;

void onsrq(IDID myid) {

  printf("SRQ received...\n");

}


int main(int argc, char* argv[]) {  
 
   IDID mydevice;
   size_t actual;
   int reason;
   char buffer[256]; 
   uint8_t stb=0;

   cout << "trying to open device with gio..." << endl;
 
   string lan_gpib_device = "vxi11/192.168.0.103/gpib0,6"; 
   mydevice = gio_open(lan_gpib_device.c_str());
   
   //cout << "Setting srq handler" << endl;
   //gio_set_SRQ_handler(mydevice,onsrq);
 
   if(mydevice == 0) {
      cerr << "Error opening device" << endl; 
      exit(-1);
   } 
 
   gio_set_timeout(mydevice, 4000);
   gio_clear(mydevice); 
 
   cout << "writing command identify?..." << endl;
   string command ="identify?\n";
   gio_write(mydevice,command.c_str(),command.size(),1,&actual); 
   
   if(actual == 0) {
     cerr << "cannot write to device" << endl; 
        exit(-1);
   } 
   
   gio_read(mydevice,buffer,256,&reason,&actual);  
   
   if(actual == 0) {
      cerr << "cannot read from device" << endl; 
      exit(-1); 
   } else {
      buffer[actual] = '\0';
   }
   
   cout << "Command reply:" << buffer << endl; 
   
   gio_read_status_byte(mydevice,&stb);
   cout << "status byte=" << (int)stb << endl;
   
   // if a command is sent and need to wait for a SRQ
   // gio_wait_event() is the function to call
   // with a timeout parameter specified in milliseconds
   //gio_wait_event(10000); 
   
   gio_close(mydevice);
   
   return 0;
 
}
   
   
