#ifndef __MSG_H
#define __MSG_H

typedef struct msg_head
{
    int type;
    int len;
} msg_head_t;

#endif
