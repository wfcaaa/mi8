#include<iostream>
#include<queue>
using namespace std;

class TreeNode
{
  public:
    TreeNode* left;
    TreeNode* right;
    int val;
    TreeNode(char n):val(n),left(NULL),right(NULL){}
    virtual ~TreeNode();
   
};
void preFree(TreeNode* root)
{
    if(root == NULL)
    {
        cout<<"node is null ,return"<<endl;
        return;
    }
    if(root->left == NULL && root->right== NULL)
    {
        cout<<"will delete:"<<root->val<<" node"<<endl;
        delete root;
    }
    preFree(root->left);
    preFree(root->right);
}
TreeNode::~TreeNode()
{
   cout<<"step in deconstruct"<<endl;
    if(this->left)
    {
        preFree(left);
    }
    if(this->right)
    {
        preFree(right);
    }
}
TreeNode* constructTree1()
{
     TreeNode* root = new TreeNode(1);
     root->left = new TreeNode(3);
     root->left->left = new TreeNode(5);
      root->left->right = new TreeNode(4);

     root->right = new TreeNode(2);
     root->right->left = new TreeNode(7);
      root->right->right = new TreeNode(9);
      return root;

}

TreeNode* constructTree2()
{
     TreeNode* root = new TreeNode(2);
     root->left = new TreeNode(1);
     root->left->right = new TreeNode(4);
    

     root->right = new TreeNode(3);
     root->right->right = new TreeNode(7);
     
      return root;

}

void preOrder(TreeNode* root)
{
    if(root == NULL)
      return;
    cout<<root->val<<endl;
    preOrder(root->left);
    preOrder(root->right);
}

void preOrder(const TreeNode* root )
{
    cout<<"enter const preOrder"<<endl;
    queue<const TreeNode*> nodes;
    if(root == NULL)
      return;
    nodes.push(root);
    while(!nodes.empty())
    {
        const TreeNode* now = nodes.front();
        nodes.pop();
        cout<<now->val<<endl;
        if(now->left)
            nodes.push(now->left);
        if(now->right)
          nodes.push(now->right);
    }

}

void inOrder(TreeNode* root)
{
    if(root == NULL )
      return ;
    inOrder(root->left);
    cout<<root->val<<endl;
    inOrder(root->right);
}

void afOrder(TreeNode* root)
{
    if(root == NULL)
      return;
    afOrder(root->left);
    afOrder(root->right);
    cout<<root->val<<endl;
}
int getMaxDepth(TreeNode* root)
{
    if(root == NULL)
      return 0;
    return max(getMaxDepth(root->left),getMaxDepth(root->right)) +1;
}

void invert(TreeNode* root)
{
    if(root == NULL) return;

    TreeNode * tmp = root->left;
    root->left = root->right;
    root->right =tmp;
    invert(root->left);
    invert(root->right);
}

TreeNode* invertTree(TreeNode* root)
{
    invert(root);
    return root;
}

bool isSameTree(TreeNode* root1,TreeNode* root2)
{
    if(root1 == NULL && root2 == NULL) return true;
    if(root1 == NULL || root2 == NULL) return false;
    if(root1->val == root2->val )
    {
        return ( isSameTree(root1->left,root2->left) && isSameTree(root1->right,root2->right) );
    }
    else
        return false;
}

TreeNode* mergeTree(TreeNode* root1,TreeNode* root2)
{
    if(root1 != NULL && root2 != NULL)
    {
        TreeNode *tmp = new TreeNode(root1->val+root2->val);
        tmp->left = mergeTree(root1->left,root2->left);
        tmp->right = mergeTree(root1->right,root2->right);
        return tmp;
    }
    else if(root1 != NULL)
    {
        TreeNode* tmp = new TreeNode(root1->val);
        tmp->left = mergeTree(root1->left,NULL);
        tmp->right = mergeTree(root1->right,NULL);
        return tmp;
    }
    else if(root2 != NULL)
    {
        TreeNode* tmp = new TreeNode(root2->val);
        tmp->left = mergeTree(root2->left,NULL);
        tmp->right = mergeTree(root2->right,NULL);
        return tmp;
    }
    else
      return NULL;
}
void test()
{
    cout<<"step in test"<<endl;
    TreeNode * root1 = constructTree1();
    TreeNode * root2 = constructTree2();
    cout<<"display root1,preorder:"<<endl;
    preOrder(root1);
    const TreeNode* root3 = root1;
    preOrder(root3);
    cout<<" is same:"<<( isSameTree(root1,root2)?"true":"false" )<<endl;
    cout<<"depth:"<<getMaxDepth(root1)<<endl;
    TreeNode* root = mergeTree(root1,root2);
    cout<<"pre:"<<endl;
    preOrder(root);
    cout<<"display root1,ineorder:"<<endl;
    inOrder(root);
    cout<<"display after:"<<endl;
    afOrder(root);
    

}



int main()
{
    test();
    
}
