#include<iostream>
#include<algorithm>
#include<map>
#include<vector>
#include<fstream>
#include<stdlib.h>
using namespace std;


int main()
{
    ifstream in("/home/jaxwu/Job/Algorithm/5GSetup/tmp.txt");
    string line;
    int num = 0;
    if(in.is_open())
    {
        while(getline(in,line))
        {
            size_t pos = line.find(",");
            ++num;

        }
    }
    cout<<"line number:"<<num<<endl;
}
