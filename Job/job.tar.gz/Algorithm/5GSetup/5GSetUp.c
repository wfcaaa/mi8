#include<iostream>
#include<algorithm>
#include<map>
#include<vector>
using namespace std;
#define LEN 8
typedef struct Point{
	int x;
	int y;
    Point(int i=0,int j=0):x(i),y(j)
    {}
} Point;
bool compareForLess(Point a,Point b) {return a.x<b.x;}
//bool compareForGreater(Point a,Point b) {return a.x>b.x;}
Point** getMinStations(Point* places, int size, int* returnSize)
{
     for(int i=0;i<size;++i)
    {
      cout<<"x:"<<places[i].x<<",y:"<<places[i].y<<endl;
    }
    map<int,vector<int>> sortByRows;
    for(int i=0; i < size;++i)
        sortByRows[places[i].y].push_back(places[i].x);
    cout<<"#################"<<endl;
    const int Len = size;
    Point ret[Len][2];
    int index = 0;
   
    for(auto p:sortByRows)
    {
        vector<int>& currentRow = p.second;
        sort(currentRow.begin(),currentRow.end());
        int preVal = 0;
        bool isConsumeTwoPoints = false;
        for(int i = 0; i < currentRow.size();++i)
        {
            if(i == 0)
            {
              if(currentRow.size() == 1)
              {
                ret[index][0] = Point(currentRow[i],p.first);
                ret[index++][1] = Point(0,0);
              }
              else
                preVal = currentRow[i];
            }
            else
            {
                int curVal = 0;
                if(isConsumeTwoPoints && i+1 < currentRow.size())
                     curVal = currentRow[i+1];
                else
                    curVal = currentRow[i];
                if(abs(curVal-preVal) == 1)
                {
                    ret[index][0] = Point(preVal,p.first);
                    ret[index++][1] = Point(curVal,p.first);
                    if(i+1 < currentRow.size())
                      preVal = currentRow[i+1];
                    isConsumeTwoPoints = true;
                }
                else
                {
                    ret[index][0] = Point(preVal,p.first);
                    ret[index++][1] = Point(0,0);
                    preVal = curVal;
                    isConsumeTwoPoints = false;
                }
            }
        }
    }
    
 
    *returnSize = index;
    static Point *p[2] ;
    for(int i=0;i<index;++i)
      p[i] = ret[i];
    return p;
}

int main()
{
    
    Point arr[LEN] = {{1,1},{1,3},{2,1},{2,2},{2,3},{2,4},{3,2},{3,3}} ;
    
    int ret =0 ;
    Point** p = getMinStations(arr,LEN,&ret);
    cout<<ret<<endl;
    for(int i=0;i<ret;++i)
    {
        cout<<p[i][0].x<<","<<p[i][0].y<<";"<<p[i][1].x<<","<<p[i][1].y<<endl;
    }
    
}
