#include<iostream>
#include<algorithm>
#include<map>
#include<vector>
using namespace std;
#define LEN 8
typedef struct Point{
	int x;
	int y;
    Point(int i=0,int j=0):x(i),y(j)
    {}
} Point;
bool compareForLess(Point a,Point b) {return a.x<b.x;}
//bool compareForGreater(Point a,Point b) {return a.x>b.x;}

void sortByRow( vector<vector<Point>>& stations,vector<Point>& places)
{
     map<int,vector<int>> sortByRows;
    for(int i=0; i < places.size();++i)
        sortByRows[places[i].y].push_back(places[i].x);
    int index = 0;
    for(auto p:sortByRows)
    {
        vector<int>& currentRow = p.second;
        sort(currentRow.begin(),currentRow.end());
        int preVal = 0;
        bool isConsumeTwoPoints = false;
        for(int i = 0; i < currentRow.size();++i)
        {
            vector<Point> tmp;
            Point p1;
            if(i == 0)
            {
              if(currentRow.size() == 1)
              {
                p1.x = currentRow[i];
                p1.y = p.first;
                tmp.push_back( p1);
              }
              else
                preVal = currentRow[i];
            }
            else
            {
                int curVal = 0;
                if(isConsumeTwoPoints && i+1 < currentRow.size())
                     curVal = currentRow[i+1];
                else
                    curVal = currentRow[i];
                if(abs(curVal-preVal) == 1)
                {
                     p1.x = preVal;
                     p1.y = p.first;
                    tmp.push_back(p1);
                     p1.x = curVal;
                     p1.y = p.first;
                    tmp.push_back( p1 );
                    if(i+1 < currentRow.size())
                      preVal = currentRow[i+1];
                    isConsumeTwoPoints = true;
                }
                else
                {
                    p1.x = preVal;
                    p1.y = p.first;
                    tmp.push_back( p1 );
                    preVal = curVal;
                    isConsumeTwoPoints = false;
                }
            }
            if(!tmp.empty())
            {
              stations.push_back(tmp);
              ++index;
            }
        }
    }
 
}

void sortByCol( vector<vector<Point>>& stations,vector<Point>& places)
{
     map<int,vector<int>> sortByCols;
    for(int i=0; i < places.size();++i)
        sortByCols[places[i].x].push_back(places[i].y);
    int index = 0;
    for(auto p:sortByCols)
    {
        vector<int>& currentCol = p.second;
        sort(currentCol.begin(),currentCol.end());
        int preVal = 0;
        bool isConsumeTwoPoints = false;
        for(int i = 0; i < currentCol.size();++i)
        {
            vector<Point> tmp;
            Point p1;
            if(i == 0)
            {
              if(currentCol.size() == 1)
              {
                 p1.x = p.first;
                 p1.y = currentCol[i];
                tmp.push_back( p1 );
              }
              else
                preVal = currentCol[i];
            }
            else
            {
                int curVal = 0;
                if(isConsumeTwoPoints && i+1 < currentCol.size())
                     curVal = currentCol[i+1];
                else
                    curVal = currentCol[i];
                if(abs(curVal-preVal) == 1)
                {
                    
                    p1.x = p.first;
                    p1.y = preVal;
                    tmp.push_back( p1 );
                    p1.x = p.first;
                    p1.y = curVal;
                    tmp.push_back( p1 );
                    if(i+1 < currentCol.size())
                      preVal = currentCol[i+1];
                    isConsumeTwoPoints = true;
                }
                else
                {
                    p1.x = p.first;
                    p1.y = preVal;
                    tmp.push_back( p1);
                    preVal = curVal;
                    isConsumeTwoPoints = false;
                }
            }
            if(!tmp.empty())
            {
              stations.push_back(tmp);
              ++index;
            }
        }
    }
    
}



vector<vector<Point>> getMinStations(vector<Point> places)
{
    vector<vector<Point>> sortByCols,sortByRows;
    sortByCol(sortByCols,places);
    
    if(places.size()/2 == sortByCols.size())
    {
      cout<<"sort by clo is best way"<<endl;
      return sortByCols;
    }
    else
       sortByRow(sortByRows,places); 
    if(sortByRows.size() <= sortByCols.size())
    {
      cout<<"sort by row"<<endl;
      return sortByRows;
    }
    else
    {
      cout<<"sort by col"<<endl;
      return sortByCols;
    }
}

int main()
{
    //{{1,1},{1,3},{2,1},{2,2},{2,3},{2,4},{3,2},{3,3}} 
    vector<Point> arr = {{1,1},{1,2},{2,1},{2,2},{3,1},{3,2}} ;
    ifstream in("/home/jaxwu/Job/Algorithm/5GSetup/2.in");

    vector<vector<Point>> p = getMinStations(arr);
    cout<<p.size()<<endl;
    for(auto it: p)
    {
        for(auto e:it)
            cout<<e.x<<","<<e.y<<";";
        cout<<endl;
    }
    
}
