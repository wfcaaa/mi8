#include<iostream>
#include<vector>
#include<map>
#include<algorithm>
#include<boost/lexical_cast.hpp>
using namespace std; 
using boost::lexical_cast;
#define N 100
#define MAX(a,b) a < b ? b : a
int getMinNum(int days,vector<int>& v1)
{
    sort(v1.begin(),v1.end());
    int num = 0;
    for(int i=0; i <v1.size();++i)
    {
        if(v1[i] > days)
            return -1;
        num+=v1[i];
    }
    return num%days == 0 ? num/days:num/days+1;
}
void removeTask(vector<int>&tasks,vector<int> bestGrop)
{
    for(auto p:bestGrop)
    {
        auto it = find(tasks.begin(),tasks.end(),p);
        if(it !=tasks.end())
            tasks.erase(it);
    }
}
vector<int> getBestGrop(int days,vector<int>& tasks)
{
    int size = tasks.size();
    if(size == 1)
    {
        vector<int> ret = {tasks[0]};
        removeTask(tasks,ret);
        return ret;
    }
    int num  = tasks[size-1];
    vector<int> ret = {num};
    for(int j= size-2;j>=0;--j)
    {
        num+=tasks[j];
        if(num < days)
            ret.push_back(tasks[j]);
        else if(num == days)
        {
            ret.push_back(tasks[j]);
            removeTask(tasks,ret);
            return ret;
        }
        else
        {
            num-=tasks[j];
            
        }
            
    }
    removeTask(tasks,ret);
    return ret;
}
 vector<int> getCurBestGrop(int days,vector<int>& tasks)
{
    
     int V[N][N+1];
     int x[N]={0};
    for(int i = 0; i <= tasks.size(); i++)//????0?
        V[i][0] = 0;
    for(int j = 0; j <= days; j++)//????0?
        V[0][j] = 0;
    for(int i = 1; i <= tasks.size(); i++)
        for(int j = 1; j <= days; j++)
        if(j < tasks[i-1])
            V[i][j] = V[i-1][j];
        else
            V[i][j] = MAX(V[i-1][j],V[i-1][j-tasks[i-1]] + tasks[i-1]);
 
    for(int i = tasks.size(),j = days; i > 0; i--)
    {
        if(V[i][j] > V[i-1][j])
        {
            x[i-1] = 1;
            j = j - tasks[i-1];
        }
        else
            x[i-1] = 0;
    }
    vector<int> v;
    for(int i=0; i < tasks.size();++i)
    {
        if(x[i]==1)
            v.push_back(tasks[i]);
    }
    removeTask(tasks,v);
    for(int i=0;i<tasks.size();++i)
        cout<<x[i]<<" ";
    cout<<endl;
    cout<<"cur max:"<< V[tasks.size()][days]<<endl;;
    return v;
}
int doWork(int days,vector<int>& tasks)
{
    int minNUm = getMinNum(days,tasks);
    cout<< minNUm<<endl;
    if(minNUm < 0 )
        return -1;
    int taskSize = tasks.size();
    vector<vector<int>> grop;
    while(tasks.size() != 0 )
    {
        grop.push_back(getCurBestGrop(days,tasks));   
    }

    cout<<"real num: "<<grop.size()<<" tasks size: "<< taskSize<<endl;
    
         for(auto p :grop)
        {
            for(auto q:p)
                cout<<q<<" ";
            cout<<endl;
        }
        return grop.size();
        
    
   
    
              
    
}
int main(int argc,char *argv[])
{

    
    int days = 0;
    cout<<"please input max day: ";
    cin>>days;
    vector<int> tasks ;
    for(int i = 1 ;i<argc;++i)
        tasks.push_back(lexical_cast<int>(argv[i]));
    doWork(days , tasks);
}


