#include<iostream>

using namespace std;

int factorial(int depth)
{
    if(depth < 0)
    {
      cerr<<"the input parameter is illegal"<<endl;
      return 0;
    }

    if(depth == 1)
      return 1;
    return depth * factorial(depth -1);
    
}

int main()
{
    cout<<"the factorial of 4 is:"<<factorial(4)<<endl;
    return 0;
}
