#include<iostream>
#include<vector>
using namespace std;
int findM(int N,int K,int G[],int W[])
{    int *M=new int[N+1],i,j,k;   
      for(i=0;i<N+2;i++)
          M[i]=0;
      for(i=0;i<K;i++)
      {        
          for(j=N;j>=G[i];j--)
               {            
                   for(k=1;j-k*G[i]>=0;k++)
                       {
                          M[j]=M[j]>k*W[i]+M[j-k*G[i]]?M[j]:k*W[i]+M[j-k*G[i]];   
                        }    
               } 
       }  
           return M[N];
}
struct People
{
    int id;
    string name;
};
int main(){
     People p1={1,"jax"},p2={2,"colin"};

    vector< People*> v1;
    v1.push_back(&p1);
    v1.push_back(&p2);
    for(auto p:v1)
        cout<<p->id<<": "<<p->name<<endl;
     return 0;
}
