   #include<iostream>
#include<vector>
#include<map>
#include<algorithm>
using namespace std; 
#define MAX(a,b ) ((a)>(b)?(a):(b));
int version1() 
{ 
    int nArr[6][13] = {{0}}; 
    int nCost[6] = {0 , 2 , 5 , 3 , 10 , 4}; 
       
    int wig[6] = {0 , 1 , 3 , 2 , 6 , 2}; 
       
    int bagW = 12;
       for( int i = 1; i< sizeof(nCost)/sizeof(int); i++) 
       { 
           for( int j = 1; j<=bagW; j++) 
           {
               if(j<wig[i]) 
                   nArr[i][j] = nArr[i-1][j]; 
               else 
                   nArr[i][j] = max(nArr[i-1][j] , nArr[i-1][j-wig[i]] + nCost[i]);
               cout<<nArr[i][j]<<' ';
           
           }
           cout<<endl; 
       } 
       cout<<nArr[5][12]<<endl;
       return 0;
}
int max(int i,int v1,int v2,vector<int>& wig,vector<int>& ret)
{
    if(v1<v2)
        ret.push_back(wig[i]);
    return v1>v2?v1:v2;
}
int ver2(int i,int j,vector<int>& val,vector<int>& wig,vector<int>& ret)
{
    
    if(i < 0 ||j==0)
        return 0;
    if(j- wig[i] < 0 )
        return ver2(i-1,j,val,wig,ret);
    else
        return max(i,ver2(i-1,j,val,wig,ret),ver2(i-1,j-wig[i],val,wig,ret)+val[i],wig,ret);

}
int maxweight(int C,int n,vector<int> weight,vector<int> value)
{
    cout<<"before create vector"<<endl;
    int V[100][100];
    for(int i=0; i<=n  ;++i)
        v[i][0] = 0;
    for(int i=0; i<= C ;++i)
        v[0][i] = 0;
    cout<<"before main loop"<<endl;
    for(int i= 1; i<=n;++i)
    {
        for(int j=1;j<=C;++j)
        {
            if(weight[j-1]>i)
                v[j][i]=v[j-1][i];
            else
                v[j][i] = MAX(v[j-1][i],v[j-1][i-weight[j-1]]+value[ j]);
        }
    }
    return v[n][m];
}
int main()
{
    int tmp = 0;
   
    // vector<int> val={6,4,5,3,6},wig={4,5,6,2,2};
 //  vector<int> val = {2,3,4,6,10,15},wig{2,3,4,6,10,15};
  vector<int> val={0,1,2,3},wig={0,1,2,3};
#if 0
    cout<<"please input value"<<endl;
    while(cin>>tmp)
        val.push_back(tmp);
    cout<<"please input wight"<<endl;
    cin.clear();
    while(cin>>tmp)
        wig.push_back(tmp);
    sort(val.begin(),val.end());
    sort(wig.begin(),wig.end());

    cin.clear();
#endif
    
    cout<<"please input max wight"<<endl;
    cin>>tmp;
    vector<int> ret;
    cout<<"max is: "<<maxweight(tmp,val.size(),wig,val)<<endl;
    

  
}


