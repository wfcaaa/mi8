#include<boost/lexical_cast.hpp>

using namespace std;

int main()
{
    int a = 123;
    //string b = boost::lexical_cast<string>(a);
    string b ;
    b+=a;
    cout<<b<<endl;
}
