#include<iostream>
#include<boost/algorithm/string.hpp>
#include<string.h>
using namespace std;

vector<string> testSplit(const string& s)
{
    vector<string> ret;
    boost::split(ret,s,boost::is_any_of(","));
    return ret;
}
int main()
{
    string dieList = "mode=fail-go-on,someBinPass,planarityCheck=12,value=10";
    vector<string> dies = testSplit(dieList);
    for(auto p:dies)
        cout<<p<<endl;
    string s = dies[0];
    cout<<"s:"<<s<<endl;
    string mode(s,5);
    cout<<"mode:"<<mode<<endl;
    string s1= dies[1];
    cout<<"s1:"<<s1<<endl;
    string s2 = "planarityCheck=12,value=10";
    cout<<"s2:"<<s2<<endl;
    size_t pos = s2.find("=");
    if(pos != string::npos)
    {
        s2 = string(s2,s2.find("=")+1);
        cout<<"s3:"<<s2<<endl;
        if(s2[0] == 49)
        {
          cout<<"flag is true"<<endl;
          string value = string(s2,s2.find("=")+1);
          cout<<"limit value:"<<value<<endl;
        }
        string dieStep  = "100";
        int num = atoi(dieStep.c_str());
        cout<<"num:"<<num<<endl;
    }
}
