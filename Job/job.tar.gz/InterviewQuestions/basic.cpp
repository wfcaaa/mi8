#include<iostream>
#include<vector>

using namespace std;

int ret1Number(int num)
{
    int conunt = 0;
    while(num)
    {
        ++conunt;
        num=num&(num-1);
    }
    return conunt;
}

void testVector()
{
    vector<int> nums;
    vector<int>::iterator it;
    it = nums.begin();
    nums.insert(it,100);
    it= nums.begin();
    nums.insert(it,200);
    for(int i=0;i<nums.size();++i)
      cout<<nums[i]<<" ";
    cout<<endl;
}

int main()
{
   cout<<"9999 has "<< ret1Number(9999)<<" 1"<<endl;
   testVector();
}
