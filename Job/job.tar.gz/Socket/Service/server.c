#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include <arpa/inet.h>
#include<errno.h>
#include<string.h>
#include<stdlib.h>
#define MAX_QUEUE 100
#define PORT 6666

static char ipAddress[] = "10.150.115.105"; 


void replyRunCommand(int clientSock)
{
    char buf[128] = "";
    static int endFlag = 0;
    static int flag = 1 ;
    
    if(flag == 1)
    {
      strcpy(buf,"START RANGE 0 3\r\n");
      ++flag;
    }
    else if(flag == 2)
    {
      strcpy(buf,"START RANGE \"stripId123\" AA0,AA1,AA2,AA3\r\n");
      ++flag ;
    }
    else if(flag == 3)
    {
      strcpy(buf,"START RANGE \"\" AA0,AA1,AA2,AA3\r\n");
      ++flag ;
    }
    else if(flag == 4)
    {
      strcpy(buf,"START RANGE  AA0,AA1,AA2,AA3\r\n");
      ++flag ;
    }
    else if(flag == 5)
    {
        strcpy(buf,"START EXPLICIT 0,3,1");
        ++flag ;
    }
    else if(flag == 6)
    {
        strcpy(buf,"RESTART EXPLICIT 0,3,1");
        flag = 1;
    }
    ++endFlag;
    if(endFlag == 20)
    {
      strcpy(buf,"END_OF_LOT\r\n");
      endFlag = 0;
    }
    printf("will send msg:%s\n",buf);
    send(clientSock,buf,strlen(buf),0);
    
}
int main(int argc,char* argv[])
{
    int i = 0;
    for( i=1;i<argc;++i)
    {
        if(strcmp(argv[i],"-ip") == 0)
        {
            if(i+1<argc)
            {
              strcpy(ipAddress,argv[i+1]);
              printf("Listening to IP address:%s\n",ipAddress);
            }
            else
              printf("Missing ip address. Will use default IP address:%s\n",ipAddress);
        }
    }
    //first step create a socket
    int sockServer = socket(AF_INET,SOCK_STREAM,0);
    int opt = 1;
    if(sockServer <0)
    {
      perror("socket");
      return 1;
    }
    printf("create socket successfully\n");

    /*int setsockopt(int sockfd, int level, int optname,  const void *optval, socklen_t optlen);
     This helps in manipulating options for the socket referred by the file descriptor sockfd. This is completely optional, but it helps in reuse of address and port.
     Prevents error such as: “address already in use”.
    */
    // Forcefully attaching socket to the port 6666 
    if (setsockopt(sockServer, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,&opt, sizeof(opt))) 
    { 
        perror("setsockopt"); 
        exit(EXIT_FAILURE); 
    }

    unsigned optVal;
    int optLen = sizeof(int);
    getsockopt(sockServer,SOL_SOCKET,SO_SNDBUF,(char*)&optVal,&optLen);
    printf("socket buffer length:%d,%dk\n",optVal,optVal/1024);

    //ip address can identify a unique host, transmission protocol and port can identify a unique program,this is the base of network communcation
    //struct sckaddr is common interface which contain ip address and port, strcut sockaddr_in is for ipv4
    struct sockaddr_in serInfo;
    memset(&serInfo,0,sizeof(serInfo));
    int addr_len = sizeof(serInfo);
    serInfo.sin_family = AF_INET;
    serInfo.sin_port = htons(PORT);
    serInfo.sin_addr.s_addr = inet_addr(ipAddress);
    //inet_pton(AF_INET,ipAddress,&(serInfo.sin_addr));

    //bind,this step will bind socket to a specify AF adress
    //int bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
    if(bind(sockServer,(struct sockaddr*)&serInfo,(socklen_t)addr_len ) <0 )
    {
      perror("bind");
      return 1;
    }
    char str[128] = "";
   // inet_ntop(AF_INET,&(serInfo.sin_addr),str,127);
    printf("bind socket ,ip:%s,port:%d successful\n",inet_ntoa(serInfo.sin_addr),ntohs(serInfo.sin_port));
    //listen,change the status of socket from active to passive.
    if( listen(sockServer,MAX_QUEUE) < 0)
    {
        perror("listen");
        return 1;
    }
    printf("listen successful,max connect queue is %d\n",MAX_QUEUE);

   //main wokr,polling to wait conecttion from client
   struct sockaddr_in clientInfo;
   memset(&clientInfo,0,sizeof(clientInfo));
   int client;
   while(1)
   {
        //not change tyep to socklen_t *,will occurs segmentation fault
        //int new_socket= accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen);
        printf("Waiting connection\n");
        client= accept(sockServer,(struct sockaddr*)(&clientInfo),(socklen_t*)&addr_len);
        if(client < 0)
        {
          perror("accept");
          return 1;
        }
        inet_ntop(AF_INET,&(clientInfo.sin_addr),str,127);
        printf("connect a client,ip:%s,port:%d\n",str,ntohs(clientInfo.sin_port));
        //printf("use inet_ntoa:ip:%s,port:%d\n",inet_ntoa(clientInfo.sin_addr),ntohs(clientInfo.sin_port)); 
        char buf[128] = "";
        char buf_send[] = "hi client";
        while(1)
        {
          ssize_t s = read(client,buf,sizeof(buf)-1);
          
          if(s)
          {
            buf[s] = 0;
            printf("\033[1;32m");
            printf("receive from client:%s\n",buf);
            printf("\033[0m");
           // write(client,buf_send,strlen(buf_send));
            if(strstr(buf,"RUN"))
                replyRunCommand(client);
            else
              write(client,"ACK",3);

          }
          else
          {
            printf("client disconnected\n");
            break;
          }
        }
        
   }
   //if use close/closesocket,will lose data which in input buffer.
   shutdown(sockServer,SHUT_RDWR);
   close(sockServer);
   return 0;
}
