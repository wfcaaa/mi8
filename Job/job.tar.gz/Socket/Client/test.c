#include<stdio.h>
#include<string.h>
int main()
{
    char p[] = "START RANGE  AA0,AA1,AA2,AA3";
    char site[64][5] = {""};
    char *token = strtok(p," ");
    strtok(NULL," ");
    token = strtok(NULL," ");
    if(token)
    {
        if(strstr(token,"\""))
        {
            printf("%s\n",token);
        }
        else
        {
            printf("%s!\n",token);
            char tmp[64] = "";
            strcpy(tmp,token);
            token = strtok(tmp,",");
            int i = 0;
            while(token)
            {
                printf("%s\n",token);
                strcpy(site[i++],token);
                token = strtok(NULL,",");
            }

            for(int j=0; j < i;++j)
              printf("%s\n",site[j]);
        }
    }


}
