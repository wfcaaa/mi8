#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<errno.h>
#include<string.h>

#define PORT 6666
static int localDelay_us(long microseconds)
{
    long seconds;
    struct timeval delay;

    /* us must be converted to seconds and microseconds ** for use by select(2) */
    if (microseconds >= 1000000L)
    {
        seconds = microseconds / 1000000L;
        microseconds = microseconds % 1000000L;
    }
    else
    {
        seconds = 0;
    }

    delay.tv_sec = seconds;
    delay.tv_usec = microseconds;

    /* return 0, if select was interrupted, 1 otherwise */
    if (select(0, NULL, NULL, NULL, &delay) == -1 && errno == EINTR)
        return 0;
    else
        return 1;
}

int main()
{
    int sockClient = socket(AF_INET,SOCK_STREAM,0);

    struct sockaddr_in serInfo;
    int addr_len = sizeof(serInfo);
    serInfo.sin_family = AF_INET;
    serInfo.sin_port = htons(PORT);
    serInfo.sin_addr.s_addr = inet_addr("10.150.115.105");
    
    // int connect(int sockfd, const struct sockaddr *addr,socklen_t addrlen);
    connect(sockClient,(struct sockaddr*)&serInfo,(socklen_t)addr_len);
    printf("connect server successful\n");
    int i = 0;
    char buf_send[128] = "";
    char buf_rec[128] = "";
    while(i <= 10)
    {
      if(i==10)
        sprintf(buf_send,"this %d times,will exit",i++);
      else
        sprintf(buf_send,"hello,site:%d",i++);
      send(sockClient,buf_send,strlen(buf_send),0);
      memset(buf_rec,0,sizeof(buf_rec));
      char *p =NULL;
      int num = recv(sockClient,buf_rec,sizeof(buf_rec)-1,0);
      //set output to green
      printf("\033[1;32m");
      printf("receive from server:%s,%d\n",buf_rec,num);
      //set output to default
      printf("\033[0m");
    }
   
   
    close(sockClient);
}
