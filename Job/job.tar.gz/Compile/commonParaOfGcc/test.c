#include<stdio.h>

void hello();
void main()
{
    printf("%d:%s %s \n",__LINE__,__FILE__,__TIME__);
    hello();
}
