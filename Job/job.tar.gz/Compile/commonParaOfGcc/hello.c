#include<stdio.h>

void world();
void hello()
{
    printf("hello ");
    world();
}
