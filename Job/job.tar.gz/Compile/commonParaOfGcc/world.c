#include<stdio.h>

void world()
{
    printf("world\n");
}
