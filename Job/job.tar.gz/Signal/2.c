#include<stdio.h>
#include<signal.h>

int quitLoop = 0;
void quitHandler(int sig)
{
    printf("receive signal:%d\n",sig);
    quitLoop = 1;
}

int main()
{
    signal(SIGQUIT,quitHandler);
    printf("will step in while loop\n");
    while(quitLoop == 0);
    printf("exit loop\n");
}
