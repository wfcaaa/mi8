#include<stdio.h>

int main()
{
    printf("hello world\n");
    char* p =NULL;
    *p = 10;
    return 0;
}
