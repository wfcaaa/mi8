#ifndef __UTILITY__
#define __UTILITY__
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<sys/ipc.h>

#define MY_SHARE_MEMORY "my_share_memory"
#define PROJ_ID 56

#endif
