#include<stdio.h>
#include<stdlib.h>

int main()

{

    printf("hello world\n");
    char buf[128] = "";
    
    FILE* fp = popen("/home/jaxwu/Job/IPC/src/Pipe/test","w");
    if(fp)
    {
        while(fgets(buf,sizeof(buf),fp))
          printf("%s",buf);
    }
    else
      printf("there is no out stream\n");
 
}
