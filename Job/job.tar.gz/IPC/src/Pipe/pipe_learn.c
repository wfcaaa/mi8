#include"utility.h"
int global = 6;
char buf[100] = "a write to std\n";
void my_exit1()
{
    printf("first exit handler called\n");
}
void my_exit2()
{
    printf("second exit handler called\n");
}
extern char ** environ;
#if 0
int main()
{
    if(atexit(my_exit1) != 0 )
        perror("my_exit1");
    if(atexit(my_exit2) != 0 )
        perror("my_exit2");
    if(atexit(my_exit1) != 0 )
        perror("my_exit1");
    if(write(STDOUT_FILENO,buf,sizeof(buf)-1 ) != sizeof(buf)-1 )
        perror("write call error\n");
    int fd[2];
    pid_t pid;
    int var = 10;
    if(pipe(fd)< 0)
        perror("create pipe fail\n");
    if( (pid=fork()) < 0 )
        perror("fork error");
    if(pid > 0)
    {
        close(fd[0]); //close read 
        write(fd[1],"a message from parent process\n",50);
        sleep(2);
    }
    else if(pid == 0)
    {
        close(fd[1]);
        read(fd[0],buf,50);
        printf("%s",buf);
        ++global;
        ++var;
    }
    printf("pid=%ld,glo=%d,var=%d\n",(long)getpid(),global,var);
    char *home=getenv("HOME");
    if(home)
        printf("%s\n",home);
    putenv("HOME=/home/coline");
    home=getenv("HOME");
    if(home)
        printf("%s\n",home);
    else
        printf("home is null\n");
#if 0
    char **envir = environ ;
    int i = 1;
    while(*envir)
    {
        printf("%d: %s\n",i,*envir);
        ++envir;
        ++i;
    }
#endif 


    return 0;
}
#endif
