#include<semaphore.h>
#include<stdio.h>
sem_t m_sem;

void init()
{
    sem_init(&m_sem,0,1);
}
int main()
{
    init();
    int num = 0;
    sem_getvalue(&m_sem,&num);
    printf("sem value:%d\n",num);
}
