#include"utility.h"




int setContent(const char* pathName,const char* message)
{
    key_t key = ftok(pathName,PROJ_ID);
    int shmid = shmget(key,4096,0666|IPC_CREAT);
    if(shmid == -1)
    {
        perror("shmget");
        return -1;
    }
    char* str = (char*)shmat(shmid,0,0);
    strcpy(str,message);
    shmdt(str);
    return 0;
}
int main()
{
    char* msg = "hello world!!!!!!";
    setContent(MY_SHARE_MEMORY,msg);
    printf("have send msg \n");
    
    //problem: if we do not know the exact size of memory segment, how do we use shmget to get identifier of shm? the following sentence is used to get the id and then remove the share memory segment
    key_t key = ftok(MY_SHARE_MEMORY,PROJ_ID);
    int shmid = shmget(key,0,0666|IPC_CREAT);
    printf("have got shmid\n");
    
    sleep(3);
    shmctl(shmid,IPC_RMID,NULL);
    printf("have destory segment\n");
    
   // char* str = "hhhhhhhhiiiiiiii!!!";
   // setContent(MY_SHARE_MEMORY,str);
    
    return 0;
}


