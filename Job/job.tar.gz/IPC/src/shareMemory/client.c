#include"utility.h"



char* getContent(const char* pathName)
{
    key_t key = ftok(pathName,PROJ_ID);
    int shmid = shmget(key,4096,0666|IPC_CREAT);
    if(shmid == -1)
    {
        perror("shmget");
        return NULL;
    }
    char* str = shmat(shmid,0,0);
    return str;
}


int main()
{
    printf("msg receive from share memory:%s\n",getContent(MY_SHARE_MEMORY));
    sleep(1);
     printf("msg receive from share memory:%s\n",getContent(MY_SHARE_MEMORY));
    return 0;
}


