#include <stdio.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <fcntl.h>
#include <errno.h>
#define MAX 88 
#define PORT 8080 
#define SA struct sockaddr 

static int make_socket_non_blocking(int sfd)
{
    //make the socket unblocking
    int flags = -1;
    int iRet = -1;
    flags = fcntl(sfd, F_GETFL, 0);
    if(flags == -1)
        return -1;
    flags |= O_NONBLOCK;
    iRet = fcntl(sfd, F_SETFL, flags);
    if(iRet == -1)
        return -1;
    return 0;
}

void printMsg( unsigned char* data,int len)
{
    int i = 0;
    for(; i < len; ++i)
      printf("0x%x ",data[i]);
    printf("\n");
}
// Function designed for chat between client and server. 
int func(int sockfd) 
{ 
	unsigned char buff[MAX]; 
	int n; 
	// infinite loop for chat 
	 { 
		bzero(buff, MAX); 

		// read the message from client and copy it in buffer 
        int ret = 0;
		if( (ret=recv(sockfd, buff, sizeof(buff),0)) <= 0)
        {
            if( ret==0)
            {
                printf("the client socket has been closed\n");
                return 1;
            }
            if(ret == -1)
            {
                printf("error occurs:%s",strerror(errno));
                return 1;
            }
        }
		// print buffer which contains the client contents 
		printf("From client,length:%d\n ",ret);
        printMsg(buff,ret);
	
		n = ret; 
		// copy server message in the buffer 
	//	while ((buff[n++] = getchar()) != '\n') ; 

		// and send that buffer to client 
         printf(" send msg to client:");
         printMsg(buff,n);
		 ret =send(sockfd, buff, n,0); 
         printf("act send length:%d,errno:%d\n",ret,errno);
         bzero(buff, MAX); 
		// if msg contains "Exit" then server exit and chat ended. 
		if (strncmp("exit", buff, 4) == 0) { 
			printf("Server Exit...\n"); 
			return 0; 
		} 
	} 

    return 0;
} 

// Driver function 
int main() 
{ 
	int sockfd, connfd, len; 
	struct sockaddr_in servaddr, cli; 

	// socket create and verification 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1) { 
		printf("socket creation failed...\n"); 
		exit(0); 
	} 
	else
		printf("Socket successfully created..\n"); 
	bzero(&servaddr, sizeof(servaddr)); 

	// assign IP, PORT 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
	servaddr.sin_port = htons(PORT); 

	// Binding newly created socket to given IP and verification 
	if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) { 
		printf("socket bind failed: %s...\n",strerror(errno)); 
		exit(0); 
	} 
	else
		printf("Socket successfully binded..\n"); 

	// Now server is ready to listen and verification 
	if ((listen(sockfd, 5)) != 0) { 
		printf("Listen failed...\n"); 
		exit(0); 
	} 
	else
		printf("Server listening..\n"); 
	len = sizeof(cli); 

	// Accept the data packet from client and verification 
	connfd = accept(sockfd, (SA*)&cli, &len); 
	if (connfd < 0) { 
		printf("server acccept failed...\n"); 
		exit(0); 
	} 
	else
		printf("server acccept the client...\n"); 

   
    func(connfd);
#if 0
	// Function for chatting between client and server 
    if (func(connfd) == 1)
    {
      printf("try to wait the reconnect from client\n");
      connfd = accept(sockfd, (SA*)&cli, &len); 
      if (connfd < 0) { 
        printf("server acccept failed...\n"); 
        exit(0); 
      } 
      else
        printf("server acccept the client...\n");
      func(connfd);
    }
#endif
	// After chatting close the socket 
	close(sockfd); 
} 

