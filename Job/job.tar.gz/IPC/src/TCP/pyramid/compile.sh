#!/bin/bash
rm -f a.out
g++ -I /usr/include/libxml2/ -I /home/jaxwu/Download/secstwo-1.0.1/ -g   server.cpp  -L. -Wl,-rpath=/usr/local/lib/:/home/jaxwu/Download/secstwo-1.0.1  -lsecstwo -liconv -lxml2
