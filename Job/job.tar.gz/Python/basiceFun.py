#!/usr/bin/env python
#coding=utf-8
import csv

def fun(x):
    return x**2
print map(fun,[1,2,3])

i = 0
seq = ['one','two','three']

for element in seq:
    print element
   
for i,element in enumerate(seq):
    print i,element


with open("/data/datalog/recipe/indextime.csv","r") as file:
    reader=csv.reader(file)
    for index,line in enumerate(reader):
        print index,":",line
    print "############################"
with open("/data/datalog/recipe/indextime.csv","r") as file:
    r=csv.reader(file)
    for row in r:
        print(r.line_num,row)
num=13
print num.round(6)
