#!/usr/bin/env bash
function addComments
{
    echo "not support addComments"
}

function removeComments
{
    echo "start to remove #"
    grep '#' ./python.py | grep '^print' |sed 's/#//g' > 1
    
}

function enter
{
    echo "enter $PWD "
    echo "start execute$0"
}

echo "hello"
enter
while getopts "yn" x
    do
        case $x in 
            ("y")
                addComments
                ;;
            ("n")
                removeComments
                ;;
        esac
    done


