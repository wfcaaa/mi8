#!/usr/bin/env python3

def load_recipe_slg(slg_path, key_list):
    map = collections.OrderedDict()
    try:
        with open(slg_path, 'r', encoding='utf-8') as f1:
            for num, value in enumerate(f1):
                for key in key_list:
                    if value.find(key) != -1:
                        map[num] = value
    except Exception as e:
        print("read csv error", e)
        return None
    return map

def calculate_time(map, start_key, end_key, item_name):
    total_item_time = 0
    start_item_time = ''
    loop_num = 0
    output_list = []
    for key, value in map.items():
        if value.find(start_key) != -1:
            start_item_time = re.search('\d{2}:\d{2}:\d{2},\d{3}', value).group(0)
            loop_num += 1
        elif value.find(end_key) != -1:
            end_item_time = re.search('\d{2}:\d{2}:\d{2},\d{3}', value).group(0)
            if start_item_time is '':
                print('Previous starting time do not exist')
            else:
                row_list = []
                item_time_delta = time_differ(start_item_time, end_item_time)
                if loop_num > 1:
                    total_item_time += item_time_delta
                row_list.append(item_name)
                row_list.append(',')
                row_list.append(item_time_delta)
                row_list.append(',')
                row_list.append(loop_num)
                row_list.append('\n')
                output_list.append(row_list)
                start_item_time = -1
    avg_item_time = -1
    if loop_num == 0:
        print("No item " + item_name + " find in log")
        return output_list, avg_item_time
    elif loop_num == 1:
        print("Cannot do computing for the item " + item_name + " loop count must larger than 1")
        return output_list, avg_item_time
    # remove the first one
    avg_item_time = round(total_item_time / (len(output_list) - 1), 4)
    return output_list, avg_item_time
