#!/usr/bin/env python
#coding=utf-8
print "hello world!!!";


x="jax"
import sys
sys.stdout.write(x + "\n")
a=1;b=2
print a, b
# the use case of string
str="indexstring"

print str #"output the entir string"
print str[2:4] #,"output the string whihc the index from 2 to 3"
print str[2:]  #,"output the substring which from the inddex 2"
print str * 2  #,"output the two times of the string"
print str + "test" #,"output the composited string"
print str[-2]

#the use case of LIST
print "start pratice LIST"
list = [ 'hello','world',2019,05,23,'!!!' ]
tinylist=[ 'hello','jax']
print list
print list[0]
print list[1:3]
print list[1:]
print tinylist * 2
print list + tinylist
list[0]='hi'
print list

#the use case of dictionary
print "start to pratice dictionary"

dict1={}
dict1[1] = 'one'
dict1['two'] = 2
print dict1
print dict1[1]
print dict1['two']
print dict1.keys()
print dict1.values()

a = b=20


if( a is b ):
    print "a and b is the same element"
else:
    print "a and b is not the same element","a is : ",a,"b is : ",b

#the use case of for
for num in range(2,5):
    print 'current num is:',num

for num in range(10,20):
    for i in range(2,num):
        if num%i == 0:
            j=num/i
            print '%d equal %d * %d' % (num,i,j)
            break
        
    if i == num-1:
        print num,'is  a even'

num = 3
while 1:
    print num
    num-=1
    if num == 0:
        break
    

