#include<iostream>

using namespace std;

int main()
{
    string s = "hello";
    s += "world"+"!" ;
    cout<<s<<endl;
}
