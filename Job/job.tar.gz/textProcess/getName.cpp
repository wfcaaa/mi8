#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<vector>
#include<unistd.h>
#include<fstream>
#include<cstring>
#include<map>
using namespace std;

vector<string> process( string& command)
{

   // string command = "grep 'name' " + path; //+ "|sed 's/^\s*//g'|awk -F\\> '{print $2}'|awk -F\\< '{print $1}'" ;
    cout<<"will execute command:\n "<<command<<endl;
    FILE *fp = popen(command.c_str(),"r");
    char buf[1024]= {0};
    int size = sizeof(buf) -1;
    vector<string> ret;
    if(fp)
    {
       
        cout<<"fp is not null"<<endl;;
        while( fgets(buf,size,fp) != 0 )
        {
            cout<<"in while: "<<buf<<endl;
            ret.push_back(buf);
        }
    }
    else
        cout<<"can not execute shell command";
    pclose(fp);
    return ret;
}

void executeShellCommand(const std::string & command,vector<string>&   cmdResults) 
  {
      FILE *pInfo = popen(command.c_str(), "r");
      cout<<"In " << __FUNCTION__ << " command : " << command<<endl;;

      if(NULL == pInfo)
      {
          
          cout<< "Cannot execute shell command";
      }

      char cmdResultBuff[1024] = {0};
      int  bufSize = sizeof(cmdResultBuff) - 1;
      while(fgets(cmdResultBuff, bufSize, pInfo) != 0)
      {
          //remove the newline character
          char *pNewline = strrchr(cmdResultBuff, '\n');
          if(pNewline)
              *pNewline = '\0';
          
          cout<<"In " << __FUNCTION__ << "popen() results : " << cmdResultBuff<<endl;
          cmdResults.push_back(cmdResultBuff);
      }

      pclose(pInfo);
      pInfo = NULL;
  }
vector<string> getProjectPath(const string& workSpacePath)
{
    string projectMap = workSpacePath + "projects.map";
    if(access(projectMap.c_str(),F_OK|R_OK) == 0 )
        cout<<projectMap<<" exist and have permission"<<endl;
    else
        cout<<projectMap<<" dose not exist"<<endl;
    vector<string> v1;
    ifstream in(projectMap);
    string line;
    int i = 1;
    if(in.is_open())
    {
        while(getline(in,line))
        {
            if(line.find("#") == string::npos)
            {
                if(!line.empty())
                {    
                    v1.push_back(line);
                }
            }
        }
    }
    return v1;
}
int main1(int argc,char* argv[])
{
    cout<<argc<<endl;
    vector<string> v;
    char s[100] = "hello=world";
    v = getProjectPath(argv[1]);
    map<string,string> m;
     for(auto p :v)
    {
        strncpy(s,p.c_str(),100);
        char * token = strtok(s,"=");
        string key = token;
        token = strtok(NULL,"=");
        string value = token;
        m[key] = value;
        
    }
     string project;
     vector<string> projectPaths;
    for(auto p:m)
    {
        if(p.first == p.second)
            project = string(argv[1]) + p.first;
        else
            project = p.second;
        projectPaths.push_back(project);

    } 
    vector<string> programs;
    for(auto e:projectPaths)
    {
        string command = "find " + e + " -path " + e + "/bin -prune -o -name '*.prog' | grep '.prog'";
        vector<string> tmp = process(command);
        for(auto entry:tmp)
        {
            size_t pos = entry.find_last_of("/");
            string s = entry.substr(0,pos);
            if(s != e)
                programs.push_back(entry);
        }
        //executeShellCommand(command,programs);
    }
    cout<<"the size is :"<<programs.size()<<endl;
    for(auto e:programs)
    {
      
       cout<<e;
    }
   
   
   
    
    
  
}


