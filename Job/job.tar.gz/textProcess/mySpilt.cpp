#include<iostream>
#include<vector>
#include<cstring>
using namespace std;

vector<string> Spilt(const string& str,const string& delim)
{
    vector<string> rets;
    if(str.empty())
        return rets;
    char * ps = new char[str.size()+1];
    if(ps)
        strcpy(ps,str.c_str());
    else
        perror("new");
     char * pde = new char[delim.size()+1];
    if(pde)
        strcpy(pde,delim.c_str());
    else
        perror("new");

    char *p = strtok(ps,pde);
    while(p)
    {
        string tmp = p;
        rets.push_back(tmp);
        p = strtok(NULL,pde);
    }
    return rets;

}
char sep[] = " ,\"\t\n";
int main(int argc,char* argv[])
{
    if(argc>1)
    {
        vector<string> v = Spilt(argv[1],argv[2]);
        for(auto p: v)
            cout<<p<<endl;
     }    
     else{
     vector<string> v = Spilt("<name>MI8_QA_Test_Program</name>","<name>");
        for(auto p: v)
            cout<<"else:"<<p<<endl;
     }

     string s = "<name>MI8_QA_Test_Program</name>";
     size_t pos = s.find_first_of(">");
     
     cout<<pos<<endl;
     size_t p2 = s.find_last_of("<");
     cout<<p2<<endl;
     string tmp = s.substr(pos+1,p2-pos-1);
     cout<<tmp<<endl;
     char str[64] = "start range stripid aa0,aa1 \t\n";
     char *p1 = strtok(str,sep);
     cout<< p1<<endl;
     if(p1)
     {
        while(p1)
        {
            cout<<p1<<endl;
            p1 = strtok(NULL,sep);
        }

     }
}
