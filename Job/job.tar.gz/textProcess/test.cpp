#include<iostream>
#include<fstream>
#include<cstring>
#include<boost/lexical_cast.hpp>
using namespace std;

struct Version
{
    int major;
    int minor;
    int feature;
    int patch;
};
int main()
{
    ifstream in("/home/jaxwu/smt8_simple/tc_device/.aproject");
    string line;
    Version version;
    while(getline(in,line))
    {
        size_t pos = line.find("SmartestBuildVersionFull");
        if(pos != string::npos)
        {
            pos = line.find("=");
            string sub = line.substr(pos+1);
            cout<<sub<<endl;
            pos = sub.find("_");
            sub = sub.substr(0,pos);
            cout<<sub<<endl;
            char a[1024] = {0};
            strcpy(a,sub.c_str());
            char * token = strtok(a,".");
            string fi ;
            while(token != NULL)
            {
                 fi+=token;
                 int i = boost::lexical_cast<int>(*token);
                 cout<<i<<endl;
                token = strtok(NULL,".");
               
            }
            cout<<fi<<endl;
           
            for(int i = 0 ; i<fi.size();++i)
            {
                
                 if(0 == i)
                    version.major = boost::lexical_cast<int>(fi[i]);
                if(1 == i)
                    version.minor = boost::lexical_cast<int>(fi[i]);
                if(2 == i)
                    version.feature = boost::lexical_cast<int>(fi[i]);
                if(3 == i)
                    version.patch = boost::lexical_cast<int>(fi[i]);
            }
            
        
        }
    }
       cout<<version.major<<": "<<version.minor<<": "<<version.feature<<": "<<version.patch<<endl; 
        string ver1="8.3.0.0",ver2="8.3.0.0.1.2.3";
        cout<<strlen("x.x.x")<<endl;
      cout<<"result: "<<  ver1.compare(0,strlen("x.x.x"),ver2,0,strlen("x.x.x"))<<endl;
      string s= "8.3.0.0_5076x3-bl-2844-IB_integration_20190620_0656_02f64f8182dc_C_BETA (T) hello world";
      size_t pos = s.find("_");
      if(pos != string:: npos )
          cout<<s.substr(0,pos);
      pos = s.find(" ");
      if(pos != string::npos)
          cout<<s.substr(0,pos)<<endl;
      else
          cout<<"not found space"<<endl;
      s = "/home/jaxwu/Job/textProcess/";
      if(s[s.size()-1] == '/')
          cout<<"ture"<<endl;
      else
          cout<<false<<endl;

     
      
     
}
