#include<unistd.h>
#include<stdio.h>
#include<errno.h>
int main()
{
    int ret = access("qwe/home/jaxwu/Job/textProcess/test.cpp",F_OK);

    if(ret != 0)
    {
      printf("error:%d,errno:%d\n",ret,errno);
      switch(errno)
      {
        case EACCES:
          printf("errno:EACCES\n");
          break;
        case ELOOP:
          printf("errno:ELOOP\n");
          break;
        case ENAMETOOLONG:
          printf("errno:ENAMETOOLONG\n");
          break;
        case ENOTDIR:
          printf("errno:ENOTDIR\n");
          break;
        case EROFS:
          printf("errno:EROFS\n");
          break;
        case EFAULT:
          printf("errno:EFAULT\n");
          break;
        case EIO:
          printf("errno:EIO\n");
          break;
        case EINVAL:
          printf("errno:EINVAL\n");
          break;
        case ENOMEM:
          printf("errno:ENOMEM\n");
          break;
        case ETXTBSY:
          printf("errno:ETXTBSY\n");
          break;
        default:
          printf("no match\n");
          break;
      }
    }
    else
      printf("request ok\n");
}
