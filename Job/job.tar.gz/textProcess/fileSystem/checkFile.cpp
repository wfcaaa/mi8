#include<iostream>
#include<boost/filesystem.hpp>
#include <cassert>
using namespace std;
namespace filesys = boost::filesystem;

bool checkIfDirectory(std::string filePath)
{
	try {
		// Create a Path object from given path string
		filesys::path pathObj(filePath);
		// Check if path exists and is of a directory file
		if (filesys::exists(pathObj) && filesys::is_directory(pathObj))
			return true;
	}
	catch (filesys::filesystem_error & e)
	{
		std::cerr << e.what() << std::endl;
	}
	return false;
}

int main()
{
    
 
    string path = "/home/jaxwu/Job/textProcess/fileSystem";
    bool flag = checkIfDirectory(path);
    if(flag)
        cout<<path<<" exist and is directory."<<endl;
    else
        cout<<path<<" doset not exist or is not a directory"<<endl;
}


//compile command : g++ -std=c++11 checkFile.cpp  -lboost_filesystem -lboost_system
