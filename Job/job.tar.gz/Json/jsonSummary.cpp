#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/foreach.hpp>
#include <cassert>
#include <exception>
#include <iostream>
#include <sstream>
#include <string>
#include<vector>
#include<boost/lexical_cast.hpp>

using namespace boost::property_tree;
using namespace std;

void dowork(string jstring)
{
    return;
}

int main1()
{
    //first we need to use read_json to convert json string to a tree struct
    // read_json(string/stringstream,ptree node), if you type a string at first parameter,it means you type a file path
    // if you just want to pass a json(javaScript Object notation) string,you can convert conten you want to pass to a stringstream object
    stringstream ss;
    ss<<"{\"teamMember\":[{\"name\":\"jax\",\"id\":1},{\"name\":\"colin|,i\"d\":2}]}";
}



void broken_input() {
    boost::property_tree::ptree pt;
    std::stringstream is("{\"statu\":\"ok\"}");
    cout<<"before read json"<<endl;
    read_json(is, pt);
    cout<<"after read json"<<endl;
    std::cout << "Root value is " << pt.get<string>("statu") << std::endl;
}

void normal_tree() {
    boost::property_tree::ptree pt;
    pt.put("first", "hello");
    pt.put("second", "world");
    pt.put("third", "bye");

    std::cout << pt.ordered_begin()->second.get_value<std::string>() << std::endl;

    write_json(std::cout, pt);
}


int main() {
    try {
        broken_input();
        normal_tree();
    }
    catch (std::exception const& e)
    {
        std::cerr << e.what() << std::endl;
    }
}
