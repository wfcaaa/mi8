#ifdef _MSC_VER
#include <boost/config/compiler/visualc.hpp>
#endif
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/foreach.hpp>
#include <cassert>
#include <exception>
#include <iostream>
#include <sstream>
#include <string>
#include<vector>
#include<boost/lexical_cast.hpp>
using namespace std;
using namespace ::boost::property_tree;


enum ColKeys
{
    executionId = 1,
    tiele,
    state,
    result,
    startTime,
    duration,
    taskCount,
    measResultCount,
    threshouldActive,
    threshold,
    storedResultCount,
    runCount,
    description,
    user,
    hostName,
    testerSerialNo,
    smarTestVersion,
    dataVersion,
    rhelVersion,
    postgreSQLVersion
};

enum State
{
        COMPLETE,
        RUNNING
};
enum RESULT 
{
        Passed,
        Failed,
        Aborted
};
struct MaintenanceActivityExecution
{
    
    long executionID;
    ::std::string tiele;
    State state;
    RESULT result;
    long startTime;
    long duration;
    long taskCount;
    long measResultCount;
    bool threshouldActive;
    float threshold;
    long storedResultCount;
    int  runCount;
    ::std::string description;
    ::std::string user;
    ::std::string hostName;
    ::std::string testerSerialNo;
    ::std::string smarTestVersion;
    ::std::string dataVersion;
    ::std::string rhelVersion;
    ::std::string postgreSQLVersion;

};
struct MaintenanceRunSummary
{
    std::vector<shared_ptr<MaintenanceActivityExecution> > activityExecutions;
};
void AssignValue(shared_ptr<MaintenanceActivityExecution> activityExectuon,string content,ColKeys colKey)
{
      size_t index;
    switch(colKey)
    {
        case executionId:
            activityExectuon->executionID = boost::lexical_cast<long>(content);
            break;
        case tiele:
            activityExectuon->tiele = content;
            break;
        case state:
            if(content == "Complete")
                activityExectuon->state = COMPLETE;
            else if(content == "Running")
                activityExectuon->state = RUNNING;
          
            break;
        case result:
            if(content == "P_")
                activityExectuon->result = Passed;
            else if(content == "*F")
                activityExectuon->result = Failed;
            else if(content == "!A")
                activityExectuon->result = Aborted;
           
            break;
        case startTime:
             index = content.find("-");
            if(index != string::npos)
                activityExectuon->startTime=0;
            else
            activityExectuon->startTime = boost::lexical_cast<long>(content);
            break;
        case duration:
            activityExectuon->duration = boost::lexical_cast<long>(content);
            break;
        case taskCount:
            activityExectuon->taskCount = boost::lexical_cast<long>(content);
            break;
        case measResultCount:
            activityExectuon->measResultCount = boost::lexical_cast<long>(content);
            break;
        case threshouldActive:
            if(content == "true")
                activityExectuon->threshouldActive = true;
            else if(content == "false")
                 activityExectuon->threshouldActive = false;
           
            break;
        case threshold:
            activityExectuon->threshold = boost::lexical_cast<float>(content);
            break;
        case storedResultCount:
            activityExectuon->storedResultCount = boost::lexical_cast<long>(content);
            break;
        case runCount:
            activityExectuon->runCount = boost::lexical_cast<int>(content);
            break;
        case description:
            activityExectuon->description = content;
            break;
        case user:
            activityExectuon->user = content;
            break;
        case hostName:
            activityExectuon->hostName = content;
            break;
        case testerSerialNo:
            activityExectuon->testerSerialNo = content;
            break;
        case smarTestVersion:
            activityExectuon->smarTestVersion = content;
            break;
        case dataVersion:
            activityExectuon->dataVersion = content;
            break;
        case rhelVersion:
            activityExectuon->rhelVersion = content;
            break;
        case postgreSQLVersion:
            activityExectuon->postgreSQLVersion = content;
            break;

        default:
            break;
    }
}
vector<string> generateKey(int rowCounts)
{
    vector<string> rowKeys;
    for(int i=1; i <= rowCounts; ++i)
    {
        string key = "r" +  boost::lexical_cast<string>(i);
        rowKeys.push_back(key);
    }
    return rowKeys;
}
void print(boost::property_tree::ptree const& pt)
{
    using boost::property_tree::ptree;
    ptree::const_iterator end = pt.end();
    for (ptree::const_iterator it = pt.begin(); it != end; ++it) {
        std::cout << it->first << ": " << it->second.get_value<std::string>() << std::endl;
      //  print(it->second);
    }
}

string getProbleString(boost::property_tree::ptree const& pt)
{
    cout<<"step in: "<<__FUNCTION__<<endl;
    string ret;
    using boost::property_tree::ptree;
    ptree::const_iterator end = pt.end();
    for (ptree::const_iterator it = pt.begin(); it != end; ++it) {
        if( string(it->first) == "$problem")
        {
            cout<<"find "<<it->first<<" value is: "<<   it->second.get_value<std::string>()<<endl ;
            ret =    it->second.get_value<std::string>() ;
            return ret;
        }
          
    }
    return ret;
}
int main(int argc,char *argv[])
{

    try
    {
       if(argc > 1)
       {
            for(int i=1; i <argc;++i)
            {
                cout<<argv[i]<<endl;
                if(string(argv[i]) == "JSonStringFroHvm.json")
                {
                    cout<<"start to parse normal json string"<<endl;
                    ptree pt;
                    read_json(argv[i],pt);
                    cout<<"cmdStatus: "<<pt.get<string>("$cmdStatus")<<endl;;
                    if(pt.get<string>("$cmdStatus") == "OK")
                    {
                        MaintenanceRunSummary summary;
                        int rowCounts = pt.get_child("MaintenanceExecutions.$tableRowCount").get_value<int>();
                        vector<string> rowKeys = generateKey(rowCounts);
                        int index = 0;
                        BOOST_FOREACH(ptree::value_type v,pt.get_child("MaintenanceExecutions.$tableRowValues"))
                        {
                            cout<<"table row first key : "<<v.first<<endl;
                            string currentKey = rowKeys[index++];
                            auto currentNode = v.second.get_child(currentKey);
                            int j = 1;
                            shared_ptr<MaintenanceActivityExecution> m1(new MaintenanceActivityExecution);
                            for(auto e:currentNode)
                            {
                                cout<<"r"<<j<<": "<<e.second.get_value<string>()<<endl;
                                ColKeys key = static_cast<ColKeys>(j++);
                                AssignValue(m1,e.second.get_value<string>(),key);
                            }
                            summary.activityExecutions.push_back(m1);
                        }
                        if( summary.activityExecutions.size() !=0)
                        {
                            BOOST_FOREACH(auto e,summary.activityExecutions)
                            {
                                cout<<e->rhelVersion<<endl;
                            }
                        }
                    }
                }
                else if(string(argv[i]) == "jsonError.json")
                {
                    ptree pt;
                    read_json(argv[i],pt);
                    cout<<"start to parse"<<endl;
                    cout<<pt.get_child("$cmdStatus").data()<<endl;
                    int i = 1;
                    auto p = pt.get_child("$cmdError");
                    
                  //  ptree::value_type v =  pt.get_child("$cmdError");
                    
                      print(pt);
                      //string ret = getProbleString(v);
                     //cout<<ret<<endl;
                     BOOST_FOREACH(ptree::value_type v,pt.get_child("$cmdError"))
                     {
                        print(v.second);
                         string ret = getProbleString(v.second);
                         if(!ret.empty())
                             break;

                     }
                    
                  
                }
                else
                {
                    ptree pt;
                    read_json("./JSonStringFroHvm.json",pt);
                    BOOST_FOREACH(ptree::value_type v,pt)
                    {
                        cout<<v.first<<endl;
                    }
                    cout<<"#####"<<endl;
                    print(pt);
                }
            }
       }
       
      

      
        return EXIT_SUCCESS;
    }
    catch (std::exception const& e)
    {
        std::cerr << e.what() << std::endl;
    }
    return EXIT_FAILURE;
}
