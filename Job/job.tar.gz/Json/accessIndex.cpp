
#include <boost/property_tree/json_parser.hpp>
#include <iostream>

using boost::property_tree::ptree;

template <typename T = std::string> 
T element_at(ptree const& pt, std::string name, size_t n) {
    return std::next(pt.get_child(name).find(""), n)->second.get_value<T>();
}

template <typename T = std::string> 
T element_at_checked(ptree const& pt, std::string name, size_t n) {
    auto r = pt.get_child(name).equal_range("");

    for (; r.first != r.second && n; --n) ++r.first;

    if (n || r.first==r.second)
        throw std::range_error("index out of bounds");

    return r.first->second.get_value<T>();
}

int main() {
    ptree pt;
    {
        std::istringstream iss("{\"a\":[1, 2, 3, 4, 5, 6]}");
        read_json(iss, pt);
    }

    write_json(std::cout, pt, false);

    // get the 4th element:
    std::cout << element_at_checked(pt, "a", 3) << "\n";
    
    // get it as int
    std::cout << element_at_checked<int>(pt, "a", 3) << "\n";

    // get non-existent array:
    try { std::cout << element_at_checked<int>(pt, "b", 0) << "\n"; } catch(std::exception const& e) { std::cout << e.what() << "\n"; }

    try { std::cout << element_at_checked<int>(pt, "a", 6) << "\n"; } catch(std::exception const& e) { std::cout << e.what() << "\n"; }
}
