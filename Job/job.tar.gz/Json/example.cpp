#ifdef _MSC_VER
#include <boost/config/compiler/visualc.hpp>
#endif
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/foreach.hpp>
#include <cassert>
#include <exception>
#include <iostream>
#include <sstream>
#include <string>
#include<iostream>
#include<boost/lexical_cast.hpp>
using namespace std;
using namespace ::boost::property_tree;
 
void print(boost::property_tree::ptree const& pt)
{
    using boost::property_tree::ptree;
    ptree::const_iterator end = pt.end();
    for (ptree::const_iterator it = pt.begin(); it != end; ++it) {
        std::cout << it->first << ": " << it->second.get_value<std::string>() << std::endl;
        print(it->second);
    }
}
string getJson()
{
    string ret = "  {\"$cmdStatus\":\"OK\",\"MaintenanceExecutions\":{\"$tableRowCount\":3,\"$tableColDefinition\":[{\"c1\":\"ExecutionId\"}    ,{\"c2\":\"Title\"},{\"c3\":\"Status\"},{\"c4\":\"Outcome\"},{\"c5\":\"StartTime\"},{\"c6\":\"Duration\"},{\"c7\":\"TaskCount\"},{\"c8\":\"MeasResultCount\"},{\"c9\":\"Th    resholdActive\"},{\"c10\":\"Threshold\"},{\"c11\":\"StoredResultCount\"},{\"c12\":\"RunCount\"},{\"c13\":\"Description\"},{\"c14\":\"User\"},{\"c15\":\"HostName\"},    {\"c16\":\"TesterSerialNo\"},{\"c17\":\"SmarTestVersion\"},{\"c18\":\"DataVersion\"},{\"c19\":\"RHELVersion\"},{\"c20\":\"PostgreSQLVersion\"}],\"$tableRowValues\":[{\"r1\":[154945752022068813,\"Digital and DPS Calibration\",\"Complete\",\"!A\",\"2019-03-07 14:54:03.000000+08\",16,0,4,false,0,4,1,\"Performs Di    gital and DPS calibration.\",\"alexguo []\",\"atslxws16.adv.advantest.com\",\"Unknown (Offline)\",\"8.2.4.0\",\"1.2\",\"7.4\",\"90221\"]},{\"r2\":[154945691    434440550,\"Digital and DPS Calibration\",\"Complete\",\"!A\",\"2019-03-07 14:50:07.000000+08\",26,0,17462,false,0,17461,1,\"Performs Digital and DPS calibration.\",\"alexguo []\",\"atslxws16.adv.advantest.com\",\"Unknown (Offline)\",\"8.2.4.0\",\"1.2\",\"7.4\",\"90221\"]},{\"r3\":[154945586455777978,\"D    igital and DPS Calibration\",\"Complete\",\"!A\",\"2019-03-07 14:43:17.000000+08\",64,0,58591,false,0,58591,1,\"Performs Digital and DPS calibratio    n.\",\"alexguo []\",\"atslxws16.adv.advantest.com\",\"Unknown (Offline)\",\"8.2.4.0\",\"1.2\",\"7.4\",\"90221\"]}]}} ";
    
    cout<<"###############################"<<endl;
    return ret;
}
int main(int argc,char* argv[])
{
    try
    {
        std::stringstream ss;
        // send your JSON above to the parser below, but populate ss first

        //ss << \"{ \\"test\\": [ { \\"electron\\": { \\"pos\\": [ 0, 0, 0 ], \\"vel\\": [ 0, 0, 0 ] }, \\"proton\\": { \\"pos\\": [ -1, 0, 0 ], \\"vel\\": [ 0, -0.1, -0.1 ] } }] }\";
        

       
     //   ss<< \"{ \\"info\\":[{ \\"person\\": [\\"jax\\",\\"colin\\"] } ] }\";
        boost::property_tree::ptree pt;
        if(argc >1 )
        {
            string path(argv[1]); 
            boost::property_tree::read_json(path, pt);
            boost::property_tree::ptree node = pt.get_child("MaintenanceExecutions");
            cout<<node.get<string>("$tableRowCount")<<endl;
            boost::property_tree::ptree rootNode = node.get_child("$tableColDefinition");
              BOOST_FOREACH(boost::property_tree::ptree::value_type &v,rootNode)
          {
            assert(v.first.empty()); // array elements have no names
            print(v.second);
          }
          
          cout<<"##############################"<<endl;
          boost::property_tree::ptree valueNode = node.get_child("$tableRowValues");
          for(auto entry : node.get_child("$tableRowValues"))
          {
            for (auto& property : entry.second){
                cout<<property.first<<endl;
                cout<<property.second.get_value<string>()<<" ";
            }
          }
          cout<<"+++++++++++"<<endl;
          int i=1;
          BOOST_FOREACH(boost::property_tree::ptree::value_type &v,valueNode)
          {
            assert(v.first.empty()); // array elements have no names
            cout<<"the "<<i++<<" element"<<endl;
            print(v.second);
          }
          cout<<"$$$$$$$$$$$$$$"<<endl;
          for(int i=0; i <valueNode.size() ; ++i)
          {
             cout<<i<<endl;
             
             
          }


        }
        else
        {
           ss<<getJson()<<endl;
           boost::property_tree::read_json(ss, pt);
           
           cout<<pt.get<string>("$cmdStatus") <<endl;
           boost::property_tree::ptree rootNode = pt.get_child("MaintenanceExecutions");
           boost::property_tree::ptree valueNode = pt.get_child("$tableColDefinition");
              BOOST_FOREACH(boost::property_tree::ptree::value_type &v,valueNode)
          {
            assert(v.first.empty()); // array elements have no names
            print(v.second);
          }
        }
       
        
        /*BOOST_FOREACH(boost::property_tree::ptree::value_type &v, pt.get_child(\"firstname\"))
        {
            assert(v.first.empty()); // array elements have no names
            print(v.second);
        }*/
        
        
        return EXIT_SUCCESS;
    }
    catch (std::exception const& e)
    {
        std::cerr << e.what() << std::endl;
    }
    return EXIT_FAILURE;
}
