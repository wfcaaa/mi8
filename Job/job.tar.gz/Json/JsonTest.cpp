#include <boost/property_tree/json_parser.hpp>
#include <fstream>
#include <iostream>
#include <map>
using namespace std;
namespace {
    using Element = std::map<std::string, int>;
    struct Array : std::vector<Element> { };

    Array read(std::string fname) {
        std::ifstream ifs(fname);
        Array into;

        using namespace boost::property_tree;
        ptree pt;
        read_json(ifs, pt);
#if 0   
        for (auto& entry : pt.get_child("values")) {
            Element e;
            for (auto& property : entry.second){
                e[property.first] = property.second.get_value(0);
                cout<<property.first<<" ";
                cout<<property.second.get_value(0)<<endl;;
            }
            into.push_back(std::move(e));
        }
#endif
       for( auto& en : pt.get_child("r3") )
       {
            for(auto e:en.second)
                cout<<e.second.data()<<endl;
       }
       
       
        return into;
    }
}

int main() {
    
        auto array = read("input.json");
#if 0
        std::cout << "Parsed " << array.size() << " elements:\n";

        for (auto& e : array) {
            std::cout << "--------------------\n{ ";
            for (auto& kv : e)
                std::cout << "\"" << kv.first << "\": " << kv.second << ", ";
            std::cout << " }\n";
        }
#endif

   

}
