#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<stdio.h>
#include<iostream>

using namespace std;
int globalVar = 6;
char buf[] = "a write to stdout";
int main()
{
    int count = 88;
    pid_t pid;
    if(write(STDOUT_FILENO,buf,sizeof(buf)-1) != sizeof(buf)-1)
      cerr<<"write error"<<endl;
    cout<<"\nbefore fork\n";
    pid = fork();
    if(pid< 0)
      cerr<<"fork error"<<endl;
    else if(pid == 0)
    {
        cout<<"I am child process, count:"<<count<<",address:"<<&count<<",pid:"<<getpid()<<endl;
        if((pid=fork()) < 0)
          cerr<<"fork error"<<endl;
        if(pid > 0)
          exit(0);
        sleep(2);
        globalVar++;
        ++count;
        printf("pid:%d,ppid:%d,var:%d,address:%p,glo:%d\n",getpid(),getppid(),count,&count,globalVar);
    }
    else
    {
       
        cout<<"I am parent process,count:"<<count<<",address:"<<&count<<",pid:"<<getpid()<<",my child pid:"<<pid<<endl;
        cout<<wait(NULL)<<endl;
        sleep(5);
    }
    printf("pid:%ld,glob:%d,address:%p,var:%d,address:%p\n",getpid(),globalVar,&globalVar,count,&count);
    return 0;

}
