#include<stdio.h>
#include<stdlib.h>

void output(char* str)
{
    int c = 0;
    setbuf(stdout,NULL);
    for(;(c= *str++) != 0;)
      putc(c,stdout);
}
int main()
{
    pid_t pid ;
    if((pid= fork()) < 0)
      printf("fork error\n");
    if(pid == 0) //child
    {
        output("output from child\n");
    }
    else
    output("output from parent\n");

    printf("hello\n");
    exit(0);
}
