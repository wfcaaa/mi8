#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

static char should_run = 0;
static pthread_mutex_t mtx;
static pthread_cond_t cv;

void* func(void* in_c)
{
    char c = *(char*)in_c;
    char cnt_run = c - 'A';

    int count = 0;
    while(count < 10)
    {
        pthread_mutex_lock(&mtx);
        while(cnt_run != should_run)
        {
            printf("will call pthread_cond_wait\n");
            pthread_cond_wait(&cv, &mtx);
            printf(" call pthread_cond_wait completed\n");
        }
        printf("%lu %c\n", pthread_self(), c);
        should_run = (cnt_run + 1) % 3;
        count++;
        pthread_cond_broadcast(&cv);
        pthread_mutex_unlock(&mtx);
    }
}

int main()
{
    int threadNum = 3;
    pthread_t* threadHandle = (pthread_t*)malloc(sizeof(pthread_t) * threadNum);
    char c[] = {'A','B','C'};
    pthread_mutex_init(&mtx, NULL);
    pthread_cond_init(&cv, NULL);
    int i=0;
    for( i = 0; i < threadNum; i++)
    {
        pthread_create(&threadHandle[i], 0, func, &c[i]);
    }

    for( i = 0; i < threadNum; i++)
    {
        pthread_join(threadHandle[i], 0);
    }

    free(threadHandle);
    return 0;
}
