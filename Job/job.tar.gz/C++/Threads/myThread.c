#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
pthread_mutex_t mux;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
#define Times 4
#define threadNum 4

static int should_run = 0;
void * routine(void * arg)
{
    char ch = *(char*) arg;
    int cur_run = ch -'A' ;
    int i=0;
    for(i = 0; i< Times; ++i)
    {
        pthread_mutex_lock(&mux);
        while(cur_run!=should_run)
        {
          pthread_cond_wait(&cond,&mux);
        }
        
        printf("thread id:%ld,%c\n",pthread_self(),ch);
        should_run = (cur_run+1)%threadNum;
        //pthread_cond_signal(&cond);
        pthread_cond_broadcast(&cond);
        pthread_mutex_unlock(&mux);
    }
}


int main()
{
    pthread_mutex_init(&mux,NULL);
    pthread_t* pHandle =(pthread_t*) malloc(sizeof(pthread_t)*threadNum);
    char msgs[] = {'A','B','C','D'};
   
    
    int i = 0;
    for( i=0;i<threadNum;++i)
    {
        if( pthread_create(&pHandle[i],NULL,routine,&msgs[i]) < 0 )
        {
          printf("%s",strerror());
          exit(-1);
        }
    }
   
   // printf("the the pid:%ld,the main thread id:%ld\n",getpid(),pthread_self());
    for(i=0; i<threadNum;++i)
        pthread_join(pHandle[i],NULL);
  
   

    printf("all thread has been completed\n");
    free(pHandle);
    return 0;
}
