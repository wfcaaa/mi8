//??????????
#include <thread>
#include <iostream>
#include <chrono>
//#include <windows.h>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include <memory>
#include <vector>
#include <algorithm>
 
#define repeat_time 3 //??????
#define thread_num 5  //???
 
using namespace std;
 
mutex mylock;
condition_variable_any cv;
char ch;
 
void fun(char output)
{
	int tmp = output - 'a';
	for (auto i = 0; i < repeat_time; i++) 
	{
     //   cout<<"thread id:"<<this_thread::get_id()<<", current char:"<<output<<endl;
		lock_guard<mutex> locker(mylock);
		cv.wait(mylock, [tmp] {return tmp == ch; }); //???
		cout << output << endl;
		ch = (ch + 1) % thread_num;
		this_thread::sleep_for(chrono::seconds(1));
		//locker.unlock();
		cv.notify_all();
	}
}
 
int main()
{	
	ch = 0;
    cout<<"main thread id:"<<this_thread::get_id()<<", call system fun id:"<<pthread_self()<<endl;
	vector<thread> t;
	for (auto i = 0; i < thread_num; i++)
		t.emplace_back(thread(fun, 'a' + i));
	for_each(t.begin(), t.end(), mem_fn(&std::thread::join));
 
	cout<<"all threads has been executed completed"<<endl;
	return 0;
}
