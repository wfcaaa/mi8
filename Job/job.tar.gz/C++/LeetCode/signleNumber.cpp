#include<iostream>
#include<vector>
using namespace std;

vector<int> signleNumbers(vector<int>& nums)
{
    vector<int> ret;
    map<int,int> counts;
    for(int num:nums)
      ++counts[num];
    for(auto num:counts)
    {
        if(num.second == 1)
          ret.push_back(num.first);
    }
    return ret;
}
int main(int argc,char* argv[])
{
    vector<int> v1;
    if(argc>1)
    {
        for(int i=1; i< argc;++i)
          v1.push_back(atoi(argv[i]));
    }

    vector<int> v2 = signleNumbers(v1);
    for(int num:v2)
      cout<<num<<endl;    
   
}
