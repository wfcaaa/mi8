#include<iostream>
#include<vector>
using namespace std;

vector<int> signleNumbers(vector<int>& nums)
{
    int s = 0;
    for(int num:nums)
      s^=num;
    
    int k = s & (-s);
    vector<int> ret(2,0);
    for(int num:nums)
    {
        if(num & k)
          ret[0] ^= num;
        else
          ret[1] ^= num;
    }
    return ret;
}
int main(int argc,char* argv[])
{
    vector<int> v1;
    if(argc>1)
    {
        for(int i=1; i< argc;++i)
          v1.push_back(atoi(argv[i]));
    }

    vector<int> v2 = signleNumbers(v1);
    for(int num:v2)
      cout<<num<<endl;    
   
}
