#include<iostream>

using namespace std;

int main()
{
    string s1 = "hello world";
    for(size_t i=0;i<s1.size();++i)
    {
        string s(s1,i,1);
        cout<<s<<endl;
    }
}


