#include<iostream>
#include<algorithm>
#include<vector>
#include<cstdlib>
using namespace std;

void Sort(vector<int>::iterator begin,vector<int>::iterator end)
{
    sort(begin,end);
}
int main(int argc,char* argv[])
{
    cout<<"Enter "<<__PRETTY_FUNCTION__<<endl;
    vector<int> v1;
    for(int i=1;i<argc;++i)
        v1.push_back(atoi(argv[i]));
    cout<<"before sort"<<endl;
    for(auto p:v1)
        cout<<p<<"\t";
    cout<<endl;
    Sort(v1.begin(),v1.end());
    cout<<"after sort"<<endl;
    for(auto p:v1)
        cout<<p<<"\t";
    cout<<endl;
}

