#include<iostream>
#include<vector>
#include <algorithm>
using namespace std;

void testVector()
{
    vector<int> names = {1,2,3};
    auto it  = find(names.begin(),names.end(),2);
    if(it!=names.end())
      cout<<"find 2"<<endl;
    else
      cout<<"not find 2"<<endl;

    for(size_t i=0;i<names.size();++i)
    {
        if(3 == names[i])
          cout<<i<<endl;
    }

    vector<string> v1;
    v1.push_back("s3");
    v1.push_back("s1");
    v1.push_back("s2");
    v1.push_back("s4");
    vector<string>::iterator ite = v1.begin();
    for(;ite!= v1.end();++ite)
    {
        cout<<*ite<<endl;
    }
    for(ite = v1.begin();ite!=v1.end();++)
    {
        if(*ite == "s2")
          break;
    }
    if(ite!= v1.end())
      v1.erase(ite);


}

int main()
{
    testVector();
    return 0;
}
