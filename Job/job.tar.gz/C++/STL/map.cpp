#include<iostream>
#include<map>
#include<vector>
#include<deque>

using namespace std;
typedef map<string,vector<int> > Buf ;
int main()
{
    vector<int> data = {1,2,3,4};
    Buf buf;
    buf["event1"].insert(buf["event1"].end(),data.begin(),data.end());
    cout<<"map size:"<<buf.size()<<endl;
    for(auto p:buf)
    {
        cout<<"event name:"<<p.first<<endl;
        for(auto p1:p.second)
        {
            cout<<"data:"<<p1<<" ";
        }
        cout<<endl;
    }
    deque<int> d1;
    
    deque<int>::iterator it = d1.end();
    d1.insert(it,data.begin(),data.end());
    for(auto p:d1)
      cout<<p<<" ";
    cout<<endl;
    while(!d1.empty())
    {
      auto front = d1.front();
      auto back = d1.back();
      if(front == back)
      {
        cout<<"it is a null or only on element deque"<<endl;
        d1.pop_front();
        continue;
      }
      else
        cout<<"there are elements in deque"<<endl;
      d1.pop_front();

    }
    return 0;
}
