#include<iostream>

using namespace std;

// overload:in the same scope, the function name is same, the parametes are different(parameters type,number,and order are different), the overload does not care the return type
class overLoad
{
    public:
      overLoad(int i=0):num(i){}
      void fun(int i) {cout<<"type:int"<<endl;}
      void fun(char* p) {cout<<"type: pointer"<<endl;}
      void fun( const char* p) {cout<<"type: pointe to const varible"<<endl;} //low-level const --> a poniter point to a const variable, it can be used in overload
     // void fun( char*const p) {cout<<"type: pointe to const varible"<<endl;} // top-level const --> the pointer itself is a const, can not be used in overload

      int  getID() const {cout<<"I cann't change class member"<<endl; return num;}  // const act on function itself, it can also be overload, this function is used by const class obj.
      int  getID()  {cout<<"I  can change class member"<<endl; return num;}
    private:
      int num;
};

class Base
{
    public:
      int testForHidden(char a,int b ) {cout<<"testForHidden in Base"<<endl;}
      virtual void testForOverWrite() {cout<<"testForOverWrite in Base"<<endl;}
};

class Derive: public Base
{
    public:
      void testForHidden(int a) {cout<<"testForHidden in Derive "<<endl;}
      void testForOverWrite() {cout<<"testForOverWrite in Derive"<<endl;}
};

// overwrite: in the inheritance relationship,
// 1.if the function name in Derive  is same with the function name in Base but the parameters between them are not same, then not matter this function with "virtual" or not,the function in Base will be hidden
// 2.if the function between base and derive are exactly same, but the function without "virtual" , then this function will be hidden 
// override:in the inheritance relationship, the function with "virtual" , the function are exactly same,
int main()
{
    overLoad o1 ;
    int i = 2;
    o1.fun(i);
    char a = 1;
    const char b = 2;
    o1.fun(&a);
    o1.fun(&b);

    const overLoad o2;
    o2.getID();

    Derive d1;
    d1.testForHidden(i);
    d1.testForHidden(a); // it will still print testForHidden in Derive
    // d1.testForHidden(a,i) // error, as the int testForHidden(char a,int b ) has been hidden by Derive

    Base b1;
    Base* p = &b1;
    p->testForOverWrite();
    p = &d1;
    p->testForOverWrite();


    return 0;
}
