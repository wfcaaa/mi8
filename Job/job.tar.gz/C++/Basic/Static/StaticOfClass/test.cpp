#include"test.hpp"

int Test::b = 0;
const int Test::c = 0;

int main()
{
    Test t1(9);
    t1.dis();
}
