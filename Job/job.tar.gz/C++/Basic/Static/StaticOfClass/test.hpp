#ifndef __ABC__
#define __ABC__

#include<iostream>


using namespace std;

class Test
{
    public:
      Test(int num):a(num){}
      void dis(){cout<<"a:"<<a<<" b:"<<b<<",c:"<<c<<endl;}
    private:
      const int a;
      static int b;
      const static int c;
};

#endif
