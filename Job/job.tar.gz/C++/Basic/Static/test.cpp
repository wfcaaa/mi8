#include"test.hpp"

void fun1()
{
    cout<<"i:"<<i<<endl;
}

