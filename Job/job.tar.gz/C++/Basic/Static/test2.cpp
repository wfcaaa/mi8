#include"test.hpp"

int main()
{
    cout<<"i:"<<i<<endl;
    fun1();
}
