#include<iostream>
using namespace std;

static int i = 1;

static void fun1();

