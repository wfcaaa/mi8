#include<iostream>

using namespace std;

// the format of operator overload:
// "return type" operator "operator name" (argument list) {}
// tips: in c++, how to overload i++ and ++i? 
// int oprator ++(){ i+=1; return i} --> ++i
// int operator ++(int){int tmp = i; i+=1; return tmp;} --> i++;
// the list of operator that can not be overlad: "." |"::"| ".*" "->* or .*" | "?:" | "sizeof" 
