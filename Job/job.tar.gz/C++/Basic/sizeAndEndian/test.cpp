#include"test.hpp"
#include<cstdio>

//#pragma pack(4)
struct node1
{
    
    int a;
    short b;
    int c;
};

struct node2
{
    
    int a;
    short b;
    int d;
    double c;
};

struct node3
{
    
    int a;
    char b;
    char d;
    short c;
    char e;
};

struct node4
{
    
    char a;
    char d;
    short b;
    //char d;
    long c;
};

void test1()
{
  cout<<"sizeA:"<<sizeof(A)<<endl;
  cout<<"sizeB:"<<sizeof(B)<<endl;
  cout<<"sizeC:"<<sizeof(C)<<endl;
  cout<<"sizeD:"<<sizeof(D)<<endl;
  cout<<"size of DerivedFromOne:"<<sizeof(DerivedFromOne)<<endl;
  cout<<"size of DerivedFromTwo:"<<sizeof(DerivedFromTwo)<<endl;
  DerivedFromTwo d1;
  d1.fun1();
  printf("address of &d1:%p\n",&d1);
  d1.printAddress();
}

void test2()
{
  int* p1 = NULL;
  char* p2 = NULL;
  cout<<"size of p1(int*):"<<sizeof(p1)<<", p2(char*):"<<sizeof(p2)<<endl;
  cout<<"size of char:"<<sizeof(char)<<", short:"<<sizeof(short)<<", int:"<<sizeof(int)
    <<", long:"<<sizeof(long)<<", longlong:"<<sizeof(long long)<<",float:"<<sizeof(float)
    <<", double:"<<sizeof(double)<<", unsigned long:"<<sizeof(unsigned long)<<endl;
}

void test3()
{
    cout<<"size of node1:"<<sizeof(node1)<<endl;
    cout<<"size of node2:"<<sizeof(node2)<<endl;
    cout<<"size of node3:"<<sizeof(node3)<<endl;
    cout<<"size of node4:"<<sizeof(node4)<<endl;
}
void test4()
{
    int i = 10;
    while(i--)
    {
        Base1 b1;
        b1.fun1();
    }
}

union Data
{
    short a;
    char arr[2];
};

// the numerber:0x1020, left is high right is low, so, 0x10 is hight byte, 0x20 is low byte, 
// one memory like a arry: char arr[2], the arr[0] is the low address, arr[1] is high address
// then, the little endian: the low byte stored in low address, the hight byte stored in high address
void TestEndian()
{
     union Data data;
     data.a=0x0102;
     if(sizeof(short) == 2)
     {
       if(data.arr[0]==2 && data.arr[1]==1)
         cout<<"little endian"<<endl;
       else if(data.arr[0]==1 && data.arr[1]==2)
         cout<<"big endian"<<endl;
       else
         cout<<"unknown"<<endl;
     }
     else
       cout<<"sizeof of short:"<<sizeof(short)<<endl;
}

void test5()
{
    struct node1 n1;
    n1.a = 1;
    n1.b = 2;
    n1.c = 3;
    cout<<"sizeof n1:"<<sizeof(n1)<<endl;
    node1* p1 =&n1;
    ++p1;
    int* p= ((int*)p1 -1) ;
    cout<<"value:"<<*p<<endl;
}
int A::n1 = 1;
int main()
{
 
    test5();
    TestEndian();
  
}
