#ifndef __TEST_HPP__
#define __TEST_HPP__
#include<iostream>


using namespace std;

class A
{
    public:
      A(int n):num(n){}
      int getNum() {return this->num;}
      static void setNum(){}
    private:
      int num;
      char a1;
      char a2;
      static int n1;
};

class B
{
    public:
      B(int n):num1(n){}
      int getNum() {return num1;}
      virtual void disply(){cout<<num1<<endl;}
     
    private:
      long num1;
};

class C
{

};

class D
{
    virtual ~D(){}
};

class Base1
{
   public:
     Base1() {cout<<"step in construct of Base1"<<endl;}
    ~Base1(){cout<<"step in Base1 destructoy"<<endl;}
    virtual void fun1(){cout<<__FUNCTION__<<" of base1"<<endl;}
};

class Base2
{
    public:
      Base2() {cout<<"step in construct of Base2"<<endl;}
    ~Base2(){cout<<"step in Base2 destructoy"<<endl;}
    virtual void fun1(){cout<<__FUNCTION__<<" of base2"<<endl;}
    virtual void fun2(){cout<<__FUNCTION__<<" of base2"<<endl;}
};

class DerivedFromOne:public Base1
{
    public:
    virtual void fun1(){cout<<__FUNCTION__<<" of DerivedFromOne"<<endl;}
};

class DerivedFromTwo:public Base1,public Base2
{
    public:
    virtual void fun1(){cout<<__FUNCTION__<<" of DerivedFromTwo"<<endl;}
    void printAddress() {cout<<"address of this:"<<this<<endl;}
};

#endif
