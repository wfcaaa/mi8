#include<iostream>
#include<stdio.h>
using namespace std;

typedef void (*Vptr)();
class Basic
{
    public:
      static int getNum()
      {
         printf("this is static func\n");
         return num;
      }
      virtual void fun1()
      {
        cout<<__FUNCTION__<<" in basic"<<endl;
      }

       virtual void fun2()
      {
        cout<<__FUNCTION__<<" in basic"<<endl;
      }
      
        virtual void fun3()
      {
        cout<<__FUNCTION__<<" in basic"<<endl;
      }
    private:
      static  int num;
      
};

int Basic::num = 2;

class Derived: public Basic
{
    public:
     

      virtual void fun1()
      {
          cout<<__FUNCTION__<<" in Derived"<<endl;
      }
      
      virtual void fun2()
      {
          cout<<__FUNCTION__<<" in Derived"<<endl;
      }
        
      virtual void fun3()
      {
          cout<<__FUNCTION__<<" in Derived"<<endl;
      }
       virtual void fun4()
      {
          cout<<__FUNCTION__<<" in Derived"<<endl;
      }
};

class A
{
    public:
      virtual void print()=0;
};

class B:public A
{
    public:
      void print(){cout<<"this is class B"<<endl;}
};
void printVptr(Basic& b,const string& s)
{
    cout<<s<<endl;
    Vptr* vptr = (Vptr*)(*(int*)&b);
    char arr[] = "hello";
    unsigned long addr1 = 0,addr2=0,total=0;
    bool isContinue = true;
    while(isContinue)
    {
        addr1 = *( unsigned long*)vptr;
        (*vptr)();
        ++vptr;
        addr2 = *(unsigned long*)vptr;
        if(total == 0)
          total = addr2 - addr1;
        else
        {
            if(total != (addr2 - addr1))
            isContinue =  false;
        }
        
    }
    cout<<endl;
}
int main()
{
    Basic b1;
    Derived d1;
    printVptr(b1,"Basic vptr:");
    printVptr(d1,"Derived vptr:");
    int num = Basic::getNum();
    cout<<"num:"<<num<<endl;

    A*p = new B();
    A& a= *p;
    p->print();
    a.print();
}
