
#include<iostream>
using namespace std;

void forConst()
{
    double d1 = 3.14;
    const int& num1 = d1;
    cout<<num1<<endl;
    //int& num2 = d1; this will caused error, the step is: int temp = d1 -> int& num2 = temp, num2 will reference to a temporary, not d1,if we use not const reference, but we can not change d1 by changing num2, this is not the original purpose(reference to d1)
    
}
