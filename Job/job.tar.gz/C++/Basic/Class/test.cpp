#include<iostream>
#include<deque>
using namespace std;

class B
{
    public:
      B() {cout<<"default constructor"<<endl;}

      B(int i):data(i)
      {
        cout<<"constructed by parameter"<<data<<endl;
      }

      B(const B& b ):data(b.data) // three case will call copy contructed func: 1. pass parameter by copy way. 2. return by copy way   3. on element to init other one. tips: className elementName = elementName will call copy costurcted function   
      {
        cout<<"constructed by class B:"<<b.data<<endl;
      }
      B& operator=(const B& b)
      {
        cout<<"assign function,"<<b.data<<endl;
        this->data=b.data;
        return *this;
      }
      void set(int i) { data=i;}
      ~B() {cout<<"destructed,data:"<<data<<endl;}
    private:
      int data;
};

B play(B b)
{
    cout<<"exit play"<<endl;
    return b;
}


class Basic
{
    public:
      Basic(int x):num(x){};
      int getNum() const{return num;}
    private:
      int num;
      void setNum(int x)
      {
        cout<<"set num to:"<<x<<endl;
        num=x;
      }
};

class Der:public Basic
{
  public:
    Der(int x):Basic(x) {}

      
};
void test()
{
    B t1 = play(5);
    cout<<"#############"<<endl;
    t1.set(6);
    B t2 = play(t1);
    cout<<"#############"<<endl;
    B t3(7);
    cout<<"#############"<<endl;
    play(t3);
    B t4(t3);
    B t5;
    t5 = t4;
    cout<<"exit test"<<endl;
}
int main()
{
    deque<int> d1;
    cout<<"d1 size:"<<d1.size()<<endl;
    int num = d1.front();
    cout<<num<<endl;
    d1.pop_front();
    return 0;
}
