#include<iostream>

using namespace std;

void fun1(int a,int b,int c=99)
{
    cout<<"a:"<<a<<"\nb:"<<b<<"\nc:"<<c<<endl;
}

void fun2(int a,int b=88,int c = 99)
{
    cout<<"###################"<<endl;
    cout<<"a:"<<a<<"\nb:"<<b<<"\nc:"<<c<<endl;
}

void fun3(string a,string b="",string c="hi")
{
    cout<<"###################"<<endl;
    cout<<"a:"<<a<<"\nb:"<<b<<"\nc:"<<c<<endl;
}


int main()
{
    fun1(10,20,30);
    fun2(10,20,30);
    fun2(10);
    fun3("a","b","c");
    fun3("qwer");
    return 0;
}
  
