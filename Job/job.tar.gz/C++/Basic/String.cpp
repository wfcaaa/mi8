#include<iostream>
#include<vector>
using namespace std;

int main()
{
    string str="aab";
    string s2 = "bac";
    vector<string> strs = {"aab","bac","ccd"};
    while(str[str.size()-1] == s2[0])
    {
        str.erase(--str.end());
        s2.erase(s2.begin());
    }

    string s3 = str+s2;
    cout<<s3<<endl;
}
