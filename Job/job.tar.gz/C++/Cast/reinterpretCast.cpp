#include<iostream>

using namespace std;

unsigned long Hash(void* p)
{
    unsigned long val = reinterpret_cast<unsigned long>(p);
    return (unsigned long)(val^(val >> 16));
}

int main()
{
    int a[20] = {2} ;
    for(int i=0;i<20;++i)
      cout<< Hash(a+i)<<endl;
    return 0 ;
}
