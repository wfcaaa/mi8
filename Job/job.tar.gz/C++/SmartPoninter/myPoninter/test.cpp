#include"objetPtr.hpp"
#include"objectImpl.hpp"
#include"logEvent.hpp"

void test()
{
   cout<<"step in test"<<endl; 
    ObjectPtrT<LoggingEvent> ptr(new LoggingEvent(99,"jax"));
    cout<<"after call ObjectPtrT"<<endl;
    //ptr->p->getMessage();
}
int main()
{
    test();
}
