#include"objectImpl.hpp"

using namespace std;

ObjectImpl::ObjectImpl() : ref( 0 )
{
    cout<<"step in "<<__FUNCTION__<<endl; 
}

ObjectImpl::~ObjectImpl()
{
  
     cout<<"step in "<<__FUNCTION__<<endl; 
}

void ObjectImpl::addRef() const
{
   cout<<"step in ObjectImpl::"<<__FUNCTION__<<endl;
  ++ref;
}

void ObjectImpl::releaseRef() const
{
   cout<<"step in ObjectImpl::"<<__FUNCTION__<<endl;
  if ( --ref == 0 )
  {
    delete this;
  }
}
