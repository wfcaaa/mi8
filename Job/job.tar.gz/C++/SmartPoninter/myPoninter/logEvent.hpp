#ifndef __LOGEVENT__HPP
#define __LOGEVENT__HPP
#include"objectImpl.hpp"
#include<cstring>
using namespace std;
class  LoggingEvent :public virtual ObjectImpl
{
    public:

     LoggingEvent(int id,const char* name)
     {
        cout<<"step in LoggingEvent construct"<<endl;
        this->id = id;
        this->name = new char[24];
        strcpy(this->name,name);
     }
     ~LoggingEvent()
     {
        cout<<"step in"<<__FUNCTION__<<endl;
        if(name)
          delete name;
     }
     string getMessage()const
     {
        cout<<"id:"<<id<<",name:"<<name<<endl;
     }
    private:
     int id;
     char* name;
};

#endif
