#ifndef _LOG4CXX_HELPERS_OBJECT_PTR_H
#define _LOG4CXX_HELPERS_OBJECT_PTR_H

#include<iostream>
using namespace std;


      /** smart pointer to a Object descendant */
        template<typename T> class ObjectPtrT 
        {
        public:
         ObjectPtrT(T * p1):p(p1)
          {
                cout<<"step in "<<__FUNCTION__<<endl; 
                if(this->p != 0)
                  this->p->addRef();
          }
                
         ~ObjectPtrT()
         {
             cout<<"step in "<<__FUNCTION__<<endl;
          //  if(this->p != 0)
              //this->p->releaseRef();
         }
      private:
         T* p ;
        };

#endif
         
