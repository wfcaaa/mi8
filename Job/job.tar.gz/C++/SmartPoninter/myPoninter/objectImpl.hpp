#ifndef _LOG4CXX_HELPERS_OBJECT_IMPL_H
#define _LOG4CXX_HELPERS_OBJECT_IMPL_H

#include <iostream>

      /** Implementation class for Object.*/
      class  ObjectImpl 
      {
      public:
         ObjectImpl();
         virtual ~ObjectImpl();
         void addRef() const;
         void releaseRef() const;

      protected:
         mutable unsigned int volatile ref;

        private:
                        //
            //   prevent object copy and assignment
            //
            ObjectImpl(const ObjectImpl&);
            ObjectImpl& operator=(const ObjectImpl&);
      };

#endif //_LOG4CXX_HELPERS_OBJECT_IMPL_H
