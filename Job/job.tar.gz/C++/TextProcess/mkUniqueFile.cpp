#include <fstream>
#include<iostream>
#include<stdlib.h>
#include<unistd.h>
using namespace std;

int main()
{
    char tempGlobalConfigFile[100] = "/tmp/.Global-config-file.XXXXXX";
    int tempfd;
    ofstream tempGlobalConfigInput;
    tempfd = mkstemp(tempGlobalConfigFile);
    if(tempfd == -1)
    {
       cout<<"call mkstemp failed"<<endl;
    }
    else
    {
      close(tempfd);
    }

    //write the info to the temp file
    tempGlobalConfigInput.open(tempGlobalConfigFile);
    if(tempGlobalConfigInput.is_open())
    {
      tempGlobalConfigInput << "driver_plugin: \"" << "/opt/hp93000/soc/PH_libs" << "\"" <<endl;
      tempGlobalConfigInput << "configuration: \"" << "/home/jaxwu/recipe/AutoZ/GenericProber/TEL/config/20S-GPIB-Prober-1-die.cfg" << "\"" << endl;
      tempGlobalConfigInput.close();
    }
    cout<<"the tmp file is:"<<tempGlobalConfigFile<<endl;
    return 0;
}
