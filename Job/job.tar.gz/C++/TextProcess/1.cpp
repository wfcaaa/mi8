#include <iostream>     // std::cerr
#include <fstream>      // std::ifstream

using namespace std;
int main () {
  std::ifstream file;
  file.exceptions ( std::ifstream::failbit | std::ifstream::badbit );
  try {
    file.open ("qwe/home/jaxwu/test.txt");
    cout<<"eof:"<<file.eof()<<endl;
    while (!file.eof()) file.get();
    file.close();
  }
  catch (std::ifstream::failure e) {
    std::cerr << "Exception opening/reading/closing file\n";
  }

  return 0;
}
