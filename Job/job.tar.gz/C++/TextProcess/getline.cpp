#include<iostream>
#include<vector>
#include<sstream>
using namespace std;

void getline1()
{
  cin.clear();
  vector<string> names;
  string name;
  while(cin)
  {
    cout<<"please the name:"<<endl;
    getline(cin,name);
    if(cin)
      names.push_back(name);
  }
  cout<<"#########"<<endl;
  for(auto name:names)
    cout<<name<<endl;
  cout<<"the number of MI members is: "<<names.size()<<endl;
}

void getline2()
{
  cin.clear();
  vector<string> names;
  string name,tmp;
  cout<<"please input names:"<<endl;
  getline(cin,tmp);
  stringstream X(tmp);
  while(getline(X,name,' '))
  {
    names.push_back(name);
  }
  cout<<"#########"<<endl;
  for(auto name:names)
    cout<<name<<endl;
  cout<<"the number of MI members is: "<<names.size()<<endl;
}


int main()
{
  // getline1();
   getline2();
}
