/* strerror example : error list */
#include <stdio.h>
#include <string.h>
#include <errno.h>

int main ()
{
  FILE * pFile;
  pFile = fopen ("qwe/home/jaxwu/Job/C++/TextProcess/unexist.ent","w");
  if (pFile == NULL)
  {
    printf ("Error opening file unexist.ent: %s\n",strerror(errno));
    return -1;
  }
  else
    printf("unexist.ent exitst\n");
  fclose(pFile);
  return 0;
}
