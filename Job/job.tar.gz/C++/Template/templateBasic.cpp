#include<iostream>

using namespace std;

template<typename type>

void Swap(type& arg1,type& arg2 )
{
    type tmp = arg1;
    arg1 = arg2;
    arg2 = tmp;

}

int main()
{
    int a = 1,b=2;
    cout<<a<<" "<<b<<endl;
    Swap(a,b);
    cout<<a<<" "<<b<<endl;

    double a1 = 1,b1=2;
    cout<<a1<<" "<<b1<<endl;
    Swap(a1,b1);
    cout<<a1<<" "<<b1<<endl;

    char a2 = 1,b2=2;
    cout<<a2<<" "<<b2<<endl;
    Swap(a2,b2);
    cout<<a2<<" "<<b2<<endl;



}
