#include<stdio.h>
#include<string.h>

void test1()
{

    char spes[] = " ";
    char str[64] = "STRAT RANGE 1 7";
    printf("%d\n",strlen(str));
    char *p = strstr(str,"RANGE");
    if(p)
    {
      printf("%s\n",p);
      int a = atoi(p+6);
      printf("%d\n",a);
      int b = atoi(p+8);
      printf("%d\n",b)  ;
    }
    else
      printf("not found\n");
    char s[] = "STRAT RANGE \"\"  AA0,AA1,AA2,AA3 \r\n";
    char *ptr = strtok(s,spes);
    ptr = strtok(NULL,spes);
    ptr = strtok(NULL,spes);
    if(strstr(ptr,"\""))
    printf("strip id is:%s\n",ptr);
    int i=1;
    while(ptr)
    {
        printf("%d times:%s\n",i++,ptr);
        if(strstr(ptr,"AA"))
        {
            //printf("the second character:%c,the last:%d\n",ptr[1],ptr[2]-48);
        }
        ptr = strtok(NULL,",");
    }
    char test[128] = "STRAT RANGE  AA0,AA1,AA2,AA3 \r\n";;
    char *tmp = strchr(test,',');
    printf("%s\n",tmp);
    char buffer[128] = "";
    strcpy(buffer,tmp-3);
    printf("%s",buffer);
    char a = 'X';
    char b = 'Q';
    unsigned int c = b-a;
    printf("%d\n",c);
    char d = '3';
    printf("%d\n",atoi(&d));
    printf("%d\n",strlen("START EXPLICIT"));

    char arr[] = "STRAT RANGE \"stripid123\" AA0,AA1,AA2,AA3 \r\n";
    strtok(arr," ");
    strtok(NULL," " );
    char *token = strtok(NULL," ");
    if(token)
      printf("%s\n",token);
    token = strtok(NULL,",");
    if(token)
      printf("%s\n",token);
    else
      printf("NULL\n");
}


int main()
{
    char arr[128] = "hpib2";
    char *p = strchr(arr,'/');
    if(p)
      printf("find /\n");
    else
      printf("not find /\n");
}
