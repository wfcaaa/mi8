#include<stdio.h>
#include<stdarg.h>
#include<string.h>
#include<ctype.h>

void copyMsg(unsigned char* des,char* src,int len)
{
    int i = 0;
    for(;i < len;++i)
      des[i] = src[i];
}

void printMsg(char* data,int len)
{
    int i = 0;
    for(;i<len;++i)
      printf("0x%x,",data[i] & 0xff);
    printf("\n");
}
int myforat1(char* format,...)
{
    va_list list;
    
    if(strcmp(format,"%s") == 0)
    {
        char s[] = {0x0c,0,0,0x81,0x0d,0x80,0x01,0x40,0x5d,0x4a,0x9f,0x01,0};
        va_start(list,format);
        char* p = va_arg(list, char*);
        copyMsg(p,s,sizeof(s));
        va_end(list);
        return sizeof(s);
    }
    else
    {
        char s[] = "strip1\n";
        va_start(list,format);
        vsscanf(s, format, list);
        va_end(list);
        return 0;
    }
    
}

void getLine(const char*format,...)
{
  va_list vl;
  va_start(vl,format);
  int n = va_arg(vl,int);
  printf("in getLine,the len of msg is:%d\n",n);
  char *p =NULL;
  p = va_arg(vl,char*);
  if(p)
  {
    printf("argment :");
    printMsg(p,n);
    strcpy(p,"strip1\n");
  }
}
int FindMax (int n, ...)
{
  int i,val,largest;
  va_list vl;
  va_start(vl,n);
  largest=va_arg(vl,int);
  for (i=1;i<n;i++)
  {
    val=va_arg(vl,int);
    largest=(largest>val)?largest:val;
  }
  va_end(vl);
  return largest;
}
int main()
{
  int m;
  m= FindMax (7,702,422,631,834,892,104,772);
  printf ("The largest value is: %d\n",m);
  char answer[128] = "";
  int len = myforat1("%s",answer);
//  printf("%s size:%d\n",answer,strlen(answer));
  printMsg(answer,len);
  getLine("%d%s",len,answer);
  printf("%s size:%d\n",answer,strlen(answer));
  char *p = answer;
  while(*p != '\0')
  {  if(*p == '\n' || (*p == '\r') )
    {
          *p = '\0';
    }
    ++p;
  }
   printf("%s size:%d\n",answer,strlen(answer));


  
}
