#include<stdio.h>
#include<stdlib.h>

int main()
{
    printf("before raise abort signal\n");
    abort();
    printf("after\n");
    return 0;
}
