#include<stdio.h>
#include<string.h>
char* itos(int n)
{
    int num = n;
    static char b[100]="";
    int i=0;
    for(i=0;num>0;++i)
    {
        int tmp = num%10;
        char a = tmp + '0';
        b[i] = a;
        num = num/10;
    }
    printf("%d %s\n",i,b);
    num = i/2;
    for(int j=0;j<num;++j,--i)
    {
        char tmp = b[j];
        b[j] = b[i-1];
        b[i-1] = tmp;
    }
    printf("%s\n",b);
    return b;

}
int main()
{
   
    char format[20] = {0};
    strcpy(format, "b%03.03f |%03d%s\n");
    printf(format,2.3,3,"hi");

    printf("%s\n",itos(129));
    printf("%d\n",-4/(3));
}

