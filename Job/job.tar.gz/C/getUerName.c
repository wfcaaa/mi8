
/* whoami.c */
#define _PROGRAM_NAME "getUerName"
#include <stdlib.h>
#include <pwd.h>
#include <stdio.h>

const char *getUserName()
{
  uid_t uid = geteuid();
  struct passwd *pw = getpwuid(uid);
  if (pw)
  {
    return pw->pw_name;
  }

  return "";
}

void disUerName()
{
  register struct passwd *pw;
  register uid_t uid;
  int c;

  uid = geteuid ();
  pw = getpwuid (uid);
  if (pw)
  {
    puts (pw->pw_name);
    return;
  }
  fprintf (stderr,"%s: cannot find username for UID %u\n",
      _PROGRAM_NAME, (unsigned) uid);
  exit (EXIT_FAILURE);
}
int main(int argc, char *argv[])
{
    printf("user name:%s\n",getUserName());
    disUerName();
    if(getuid() == 0 || geteuid() == 0 || getgid() == 0 || getegid() == 0)
    {
        perror("current user is root:");
    }
    return 0;

}

