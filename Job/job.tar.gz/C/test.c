#include<stdio.h>

const int c = 12;

int main()
{
    printf("%d\n",10);
    printf("%d\n",010);
    printf("%d\n",0x10);

    const int a = 10;
    int *b = &a;
    *b = 11;
    printf("%d\n",a);
    b = &c;
    *b = 13;
    printf("%d\n",c);

}
