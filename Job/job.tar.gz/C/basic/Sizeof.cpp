#include<stdio.h>
#include<iostream>


using namespace std;

typedef union
{
    int i;
    int k[5];
    char c;
} DATE;

struct data
{
    int cat;
    double dog;
    DATE cow;
    
};

class A
{
    bool a;
    int b;
    bool c;
};

class B
{
  public:
    //virtual void func() {cout<<"my address:"<<this<<endl;};

    int i;
    char a;
    int  b;
    int  d;

};

class C:public B
{
    int b;
};
int main()
{
    DATE max;
    printf("union DATE:%d\n",sizeof(max));
    printf("struct data:%d\n",sizeof(struct data));
    cout<<"class A:"<<sizeof(A)<<endl;
    cout<<"class B:"<<sizeof(B)<<endl;
    cout<<"class C:"<<sizeof(C)<<endl;

    B b1;
 //   b1.func();
    cout<<&b1<<endl;
    printf("address:%p\n",&b1.i);
    return 0;
}
