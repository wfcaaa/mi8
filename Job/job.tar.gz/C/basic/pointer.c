#include<stdio.h>

typedef void (*pFun) ();

void test1()
{
    int a[5] = {1,2,3,4,5};
    int *p = (int*)(a+1);
    int *p1 =(int*) (&a+1);
    int *p2 = (int*) (&a+2);
    printf("address| a:%p,a+1:%p,&a+1:%p,&a+2:%p,a+4\n",a,p,p1,p2);
    printf("%d,%d,&a+1:%d|%p,a+4:%d:%p\n",*(a+1),*(p-1),*p1,p1,a[4],(a+4));
    printf("p1-1:%d,p2-6:%d\n",*(p1-1),*(p2-6));
}

int main()
{
    pFun fun=test1;
    fun();
}
