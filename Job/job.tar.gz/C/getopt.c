#include<stdio.h>
#include<getopt.h>

int main(int argc,char*argv[])
{
    char ch= '\0';
    int level = 0;
    int isOutput = 0;
   // extern char* optarg;
   // extern int optopt;
   // while ((ch = getopt(argc, argv, ":d:X:i:t:m:s:M:p:R:r:V:D:A:N:ISo:P:T:S:QZn:B:")) != -1)

    while ((ch = getopt(argc, argv, "d:Qopq")) != -1)
    {
        switch(ch)
        {
            case 'd':
                printf("receive -d\n");
                level = atoi(optarg);
                break;
            case 'Q':
                printf("receive -Q\n");
                isOutput = 1;
                break;
            case 'o':
                printf("receive -o\n");
                break;
            case 'p':
                printf("receive -p\n");
                break;
            case 'q':
                printf("receive -q\n");
                break;
            default:
                printf("unknown char:%c\n",ch);
                break;
        }
    }

    printf("debug level is:%d,is output:%d\n",level,isOutput);
    return 0;

}
