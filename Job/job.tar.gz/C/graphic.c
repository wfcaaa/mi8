    #include <stdio.h>
    #include <ctype.h>
    int main()
    {
        char c;
        int result;
        c = ' ';
        result = isgraph(c);
        printf("When %c is passed to isgraph() = %d\n", c, result);
        c = '\n';
        result = isgraph(c);
        printf("When %c is passed to isgraph() = %d\n", c, result);
        c = '9';
        result = isgraph(c);
        printf("When %c is passed to isgraph() = %d\n", c, result);  
    }
