#include<stdio.h>

int main()
{
    int a = 1;
    printf("0x%02x\n",a);
    char buf[128] = "";
    sprintf(buf,"$0x%02x",a);
    printf("%s\n",buf);
}
