#include"Base.hpp"
#include<exception>
#include<stdio.h>
using namespace std;
typedef void(*Vptr)();



#if 1
void Base::consume()
{
    consumeAevent();
    consumeBevent();
    //consumeCevent();
    
}
#endif

#if 0
void Base::consume()
{
    cout<<"in consume"<<endl;
    //Vptr* vptr = (Vptr*)(*(int*)&b);
   // Vptr* vptr = (Vptr*)(*( long*)this);
    Vptr pFun = (Vptr)*((long*)*(long*)this);
    cout<<"in base consume,address of this"<<this<<endl;
    unsigned long addr1 = 0,addr2=0,total=0;
    bool isContinue = true;
    
//     ++vptr;
     int i = 1;
    setNum(3);
    while(i<=getNum())
    {
        pFun =  (Vptr)*( (long*)*(long*)this +i);
        pFun();
        ++i;
    }

}
#endif

#if 0
void Base::consume()
{
    cout<<"in consume"<<endl;
    
    Vptr pFun = NULL;
    cout<<"in base consume,address of this"<<this<<endl;
    int i = 1;
    cout<<"virtual num:"<<getNum()<<endl;;
    while(i<=getNum())
    {
        pFun= (Vptr)*( (long*)*(long*)this +i);
      
        pFun();
      
        ++i;
    }

    pFun= (Vptr)*( (long*)*(long*)this +i);
    printf("%d,%p\n",pFun,pFun);
    cout<<"tail of vtable:"<<pFun<<endl;
    

}
#endif

void Base::consumeAevent()
{
    cout<<"consumeAevent in Base"<<endl;
}

void Base::consumeBevent()
{
    cout<<"consumeBevent in Base "<<endl;
}

#if 0
void Base::consumeCevent()
{
    cout<<"consumeCevent in Base "<<endl;
}
#endif














