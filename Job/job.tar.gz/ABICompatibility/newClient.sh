#!/bin/bash

rm -f a.out
g++ -g test.cpp -lBase -L /home/jaxwu/Job/ABICompatibility -Wl,-rpath=/home/jaxwu/Job/ABICompatibility

