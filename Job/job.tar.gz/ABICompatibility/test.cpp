#include"Base.hpp"

using namespace std;

typedef void (*pFunc)();
class mConsumer:public Base
{
    void consumeAevent() 
    {
        cout<<"consumeAevent in child haha"<<endl;
    }

  public:
   // virtual void f() {cout<<"f() in mConsumer"<<endl;}
  protected:
  //  virtual void g() {cout<<"g() in mConsumer"<<endl;}
};

int main()
{
    
    mConsumer consumer;
    Base* p = &consumer;
    //p->f();
   // pFunc pFun =  (pFunc) * ((long*)*(long*)p + p->getNum()+2); // we can not direct use p->f() as compiler will pop up error, but we can use vptr to access the virtual fun that son class have but base don't have
   // pFun();
    cout<<"start to consume event"<<endl;
    p->consume();
  //  cout<<"in test address of consumer"<<&consumer<<endl;
}
