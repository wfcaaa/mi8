#include<iostream>
#include<stddef.h>
using namespace std;
class Stu
{
    public:
      int b1;
      int b2;
      virtual void fun1(){};
      static void fun2(){cout<<"hello world"<<endl;}
};

class Base2
{
    public:
      virtual void base2_fun1();
};

class Base3
{
    public:
      virtual void base3_fun1();
};

class Derive:public Stu,public Base2,public Base3
{
    public:
      int d_b1;
};
int main()
{
    cout<<sizeof(Stu)<<endl;
    cout<<sizeof(Base2)<<endl;
    cout<<sizeof(Derive)<<endl;
    cout<<"*************"<<endl;
    cout<<offsetof(Derive,d_b1)<<endl;
    cout<<offsetof(Stu,b1)<<endl; // use this function to check the memory struct of class
    cout<<offsetof(Stu,b2)<<endl;
    Stu::fun2();
    return 0;
}
