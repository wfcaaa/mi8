#ifndef __BASEHPP__
#define __BASEHPP__
#include<iostream>

class Base
{
    public:
      Base() {num=5;} 
      virtual void consume();
      virtual void consumeAevent();
      virtual void consumeBevent();
     // virtual void consumeCevent();
     
      int getNum()const {return num;}
      void setNum(int i) {num=i;}
    protected:
      // virtual void consumeFevent();
    private:
      int num;
      
};
#endif
