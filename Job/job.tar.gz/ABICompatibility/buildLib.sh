#!/bin/bash

g++ -fPIC -shared Base.cpp -o libBase.so
