#include<iostream>
#include<deque>
#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<sys/time.h>

using namespace std;
static char *getTimeString(void)
{
    static char theTimeString[64];
    struct tm theLocaltime;
    time_t theTime;
    struct timeval getTime;
    
    gettimeofday(&getTime, NULL);
    theTime = (time_t) getTime.tv_sec;
    localtime_r(&theTime, &theLocaltime);
    sprintf(theTimeString, "%4d/%02d/%02d %02d:%02d:%02d.%04d",
	theLocaltime.tm_year + 1900,
	theLocaltime.tm_mon + 1,
	theLocaltime.tm_mday,
	theLocaltime.tm_hour,
	theLocaltime.tm_min,
	theLocaltime.tm_sec,
	(int)(getTime.tv_usec));

    return theTimeString;	
}

int main(int argc,char* argv[])
{
    int num = 1000;
    deque<string> d1;
    if(argc>1)
      num = atoi(argv[1]);
    for(int i = 0;i<num;++i)
      d1.push_back(getTimeString());
    while(!d1.empty())
    {
        string time = d1.front();
        d1.pop_front();
        cout<<"time: "<<time<<endl;
    }

}
