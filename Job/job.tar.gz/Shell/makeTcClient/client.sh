#!/bin/bash

echo "hello world"
echo $XOC_SYSTEM
