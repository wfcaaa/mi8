#!/bin/bash

vxi11s=$(pgrep vxi11)
echo "start to kill vxi11s"
for vxi11 in ${vxi11s[@]};
do
  kill -9 $vxi11 ;
done

mains=$(pgrep simulator)
echo "start to kill mains"
for main in ${mains[@]};
do
  kill -9 $main ;
done

ph_guis=$(pgrep guiProcess)
echo "start to kill guis"
for gui in ${ph_guis[@]};
do
  kill -9 $gui ;
done
echo "kill simulator completed"

echo "start to restart simulation"


cd /opt/hp93000/phcontrol/drivers/Generic_93K_Driver/GenericProber/TEL/bin
`/opt/hp93000/phcontrol/bin/run ./simulator -d 1 -C 4`



