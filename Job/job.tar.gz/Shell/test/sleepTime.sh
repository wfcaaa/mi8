#!/bin/bash

echo "will sleep 2 s"
sleep 2
echo "sleep completed"
