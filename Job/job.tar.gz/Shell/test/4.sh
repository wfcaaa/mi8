#!/bin/bash

arr="this is a test"
for i in $arr;
do 
  echo $i;
done
