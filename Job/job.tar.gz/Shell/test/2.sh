#!/bin/bash

path=$GLOBAL_PROBER_PLUGIN
ls
echo $path

  ME=$(basename $0)
  HERE=$(dirname $(readlink -f $0))
  XOC_SYSTEM=$(dirname $HERE)
 echo $ME
 echo $HERE
 echo $XOC_SYSTEM
 sleep 2
 ls

