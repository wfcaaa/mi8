#!/bin/bash

echo "before set global varible"
export GLOBAL_PROBER_PLUGIN=/home/jaxwu/driver
echo "set completed"

ulimit -c unlimited
id 
sudo -s <<EOF
echo Now i am root
id
echo "yes!"
EOF




