#!/bin/sh
find /var/opt/hp93000/soc_common/tmp/93k* -mtime +3 -type d -exec rm -rf {} ";" 2>/dev/null
find /var/opt/hp93000/soc_common/tmp/inquest/*.inquest  -mtime +3 -type f -exec rm -rf {} ";" 2>/dev/null
find /var/opt/hp93000/soc_common/tmp/inquest/*.zip  -mtime +3 -type f -exec rm -rf {} ";" 2>/dev/null
