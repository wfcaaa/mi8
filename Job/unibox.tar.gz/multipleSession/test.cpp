#include<iostream>

using namespace std;

int uds[32] = {-1};

int devOpen()
{
    cout<<"in devopen"<<endl;
}

int main()
{
    devOpen();
    return 0;
}
