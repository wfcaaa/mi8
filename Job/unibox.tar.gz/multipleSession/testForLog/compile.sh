#!/bin/bash

rm -f vxi11_server
gcc -DHAVE_CONFIG_H -I. -I..    -I../include -D_REENTRANT -g -O2   -c -o  vxi11_svc.o vxi11_svc.cpp
gcc -DHAVE_CONFIG_H -I. -I..    -I../include -D_REENTRANT -g -O2   -c -o  vxi11_xdr.o vxi11_xdr.cpp
g++ -I../include -D_REENTRANT -g -O2  vxi11_svc.o vxi11_xdr.o -o vxi11_server  ../lib/.libs/libgpib.so -lpthread
