#include<wiringPi.h>
#include<stdio.h>
#include<unistd.h>

#define REN     22
#define ATN     23
#define SRQ     24
#define IFC     25
#define EOI     26


#define DAV     27
#define NRFD    28
#define NDAC    29

void Interrupt_DAV(void)
{
     printf("DAV_Tirggered ");
     printf("DAV:%d,NRFD:%d,NDAC:%d,EOI:%d,IFC:%d,SRQ:%d,ATN:%d,REN:%d ",
              digitalRead(DAV),
              digitalRead(NRFD),
              digitalRead(NDAC),
              digitalRead(EOI),
              digitalRead(IFC),
              digitalRead(SRQ),
              digitalRead(ATN),
              digitalRead(REN));
     int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
     if(a<0)
        printf("Recevice:%d\n",a);
      else
        printf("Getting:%c,ascii=%d\n",a,a);  
}
void Interrupt_NRFD(void)
{
     printf("NRFD_Tirggered ");
     printf("DAV:%d,NRFD:%d,NDAC:%d,EOI:%d,IFC:%d,SRQ:%d,ATN:%d,REN:%d ",
              digitalRead(DAV),
              digitalRead(NRFD),
              digitalRead(NDAC),
              digitalRead(EOI),
              digitalRead(IFC),
              digitalRead(SRQ),
              digitalRead(ATN),
              digitalRead(REN));
     int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
     if(a<0)
        printf("Recevice:%d\n",a);
      else
        printf("Getting:%c,ascii=%d\n",a,a);  
}
void Interrupt_NDAC(void)
{
     printf("NDAC_Tirggered ");
     printf("DAV:%d,NRFD:%d,NDAC:%d,EOI:%d,IFC:%d,SRQ:%d,ATN:%d,REN:%d ",
              digitalRead(DAV),
              digitalRead(NRFD),
              digitalRead(NDAC),
              digitalRead(EOI),
              digitalRead(IFC),
              digitalRead(SRQ),
              digitalRead(ATN),
              digitalRead(REN));
     int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
     if(a<0)
        printf("Recevice:%d\n",a);
      else
        printf("Getting:%c,ascii=%d\n",a,a);  
}
void Interrupt_EOI(void)
{
     printf("EOI_Tirggered ");
     printf("DAV:%d,NRFD:%d,NDAC:%d,EOI:%d,IFC:%d,SRQ:%d,ATN:%d,REN:%d ",
              digitalRead(DAV),
              digitalRead(NRFD),
              digitalRead(NDAC),
              digitalRead(EOI),
              digitalRead(IFC),
              digitalRead(SRQ),
              digitalRead(ATN),
              digitalRead(REN));
     int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
     if(a<0)
        printf("Recevice:%d\n",a);
      else
        printf("Getting:%c,ascii=%d\n",a,a);  
}
void Interrupt_IFC(void)
{
     printf("IFC_Tirggered ");
     printf("DAV:%d,NRFD:%d,NDAC:%d,EOI:%d,IFC:%d,SRQ:%d,ATN:%d,REN:%d ",
              digitalRead(DAV),
              digitalRead(NRFD),
              digitalRead(NDAC),
              digitalRead(EOI),
              digitalRead(IFC),
              digitalRead(SRQ),
              digitalRead(ATN),
              digitalRead(REN));
     int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
     if(a<0)
        printf("Recevice:%d\n",a);
      else
        printf("Getting:%c,ascii=%d\n",a,a);  
}

void Interrupt_SRQ(void)
{
     printf("SRQ_Tirggered ");
     printf("DAV:%d,NRFD:%d,NDAC:%d,EOI:%d,IFC:%d,SRQ:%d,ATN:%d,REN:%d ",
              digitalRead(DAV),
              digitalRead(NRFD),
              digitalRead(NDAC),
              digitalRead(EOI),
              digitalRead(IFC),
              digitalRead(SRQ),
              digitalRead(ATN),
              digitalRead(REN));
     int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
     if(a<0)
        printf("Recevice:%d\n",a);
      else
        printf("Getting:%c,ascii=%d\n",a,a);  
}
void Interrupt_ATN(void)
{
     printf("ATN_Tirggered ");
     printf("DAV:%d,NRFD:%d,NDAC:%d,EOI:%d,IFC:%d,SRQ:%d,ATN:%d,REN:%d ",
              digitalRead(DAV),
              digitalRead(NRFD),
              digitalRead(NDAC),
              digitalRead(EOI),
              digitalRead(IFC),
              digitalRead(SRQ),
              digitalRead(ATN),
              digitalRead(REN));
     int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
     if(a<0)
        printf("Recevice:%d\n",a);
      else
        printf("Getting:%c,ascii=%d\n",a,a);  
}
void Interrupt_REN(void)
{
     printf("REN_Tirggered ");
     printf("DAV:%d,NRFD:%d,NDAC:%d,EOI:%d,IFC:%d,SRQ:%d,ATN:%d,REN:%d ",
              digitalRead(DAV),
              digitalRead(NRFD),
              digitalRead(NDAC),
              digitalRead(EOI),
              digitalRead(IFC),
              digitalRead(SRQ),
              digitalRead(ATN),
              digitalRead(REN));
     int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
     if(a<0)
        printf("Recevice:%d\n",a);
      else
        printf("Getting:%c,ascii=%d\n",a,a);  
}
void initHandShakePinMode()
{
    pinMode(DAV,INPUT);
    pinMode(NRFD,INPUT);
    pinMode(NDAC,INPUT);
    pinMode(EOI,INPUT);
    pinMode(IFC,INPUT);
    pinMode(SRQ,INPUT);
    pinMode(ATN,INPUT);
    pinMode(REN,INPUT);
}
void IO_Down()
{
   pullUpDnControl(0,PUD_DOWN);
   pullUpDnControl(1,PUD_DOWN);
   pullUpDnControl(2,PUD_DOWN);
   pullUpDnControl(3,PUD_DOWN);
   pullUpDnControl(4,PUD_DOWN);
   pullUpDnControl(5,PUD_DOWN);
   pullUpDnControl(6,PUD_DOWN);
   pullUpDnControl(7,PUD_DOWN);
}
void IO_Up()
{
   pullUpDnControl(0,PUD_UP);
   pullUpDnControl(1,PUD_UP);
   pullUpDnControl(2,PUD_UP);
   pullUpDnControl(3,PUD_UP);
   pullUpDnControl(4,PUD_UP);
   pullUpDnControl(5,PUD_UP);
   pullUpDnControl(6,PUD_UP);
   pullUpDnControl(7,PUD_UP);
}

void Control_Down()
{
   pullUpDnControl(22,PUD_DOWN);
   pullUpDnControl(23,PUD_DOWN);
   pullUpDnControl(24,PUD_DOWN);
   pullUpDnControl(25,PUD_DOWN);
   pullUpDnControl(26,PUD_DOWN);
   pullUpDnControl(27,PUD_DOWN);
   pullUpDnControl(28,PUD_DOWN);
   pullUpDnControl(29,PUD_DOWN);
}



int isConditionOccur(const int pin,const int value,const int timeout)
{
    int i = 0,isSuccess = 0;
    printf("step in isConditionOccur, timeout:%d\n",timeout);
    for(i=0;i<timeout;++i)
    {
        if(digitalRead(pin) == value)
        {
          isSuccess = 1;
          break;
        }
    }
    printf("isConditionOccur return:%d\n",isSuccess);
    return isSuccess;
}
int sendByteForMessageType(const char ch,const int timeout)
{
    
    // if the lasest byte data has been accepted and listener has not been read for data yet, 
  if(digitalRead(NRFD) == 1 && digitalRead(NDAC) == 0)
  {
    //Listener ready 
    printf("NRFD=%d , NDAC=%d\n",digitalRead(NRFD),digitalRead(NDAC)); 
    
    digitalWriteByte(ch); //put data 
    digitalWrite(DAV,1);  //DAV not readdy
    
    while(digitalRead(NRFD)==1);     //check listener again
    while(digitalRead(NDAC)==0);     //check listener again
    digitalWriteByte(ch);
    digitalWrite(DAV,0) ;//DAV set readdy
    printf("put data and set DAV to 0\n");    
    while(digitalRead(NDAC)==1);    
    printf(" listener is ready for data\n");   
    digitalWrite(DAV,1)   ;
    printf("set DAV to 1\n");
  }
  else
  {     
      printf("Listener not ready,cannot send");  
      printf("NRFD=%d , NDAC=%d\n",digitalRead(NRFD),digitalRead(NDAC)); 
  }
  return 0;
   
}

int receivemessage() 
{
      
            while(digitalRead(DAV)==1); //used as synchronizing
            digitalWrite(NRFD,0);
            //Thread.sleep(10);
            int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
            digitalWrite(NDAC,1);
            while(digitalRead(DAV)==0);//used as synchronizing
            digitalWrite(NDAC,0);
            digitalWrite(NRFD,1);
            return a; 
}

void initDataline(int flag)
{
    int i = 0 ;
    for(i=0;i<8;++i)
    {
      if(flag == 1)
        pinMode(i,OUTPUT);
      else if(flag == 0)
        pinMode(i,INPUT);
      else
        printf("flag:%d is invalid.plesae input:0(input mode) or 1(output mode)\n",flag);
    }
}
int main()
{   
    printf("will initial gpibo setup ...\n");
    if(wiringPiSetup() < 0)
      printf("pigpio initialisation failed\n");
    else
      printf(" pigpio initialised okay.\n");
   
   // Control_Down();
    //IO_Up();
    initHandShakePinMode();
    initDataline(0); // 0--> input mode, 1--> output mode
    int recInt;
    printf(" Interrupt start.\n");
    //wiringPiISR(REN,INT_EDGE_BOTH,&Interrupt_REN);
    //wiringPiISR(ATN,INT_EDGE_BOTH,&Interrupt_ATN);
    //wiringPiISR(SRQ,INT_EDGE_BOTH,&Interrupt_SRQ);
    //wiringPiISR(IFC,INT_EDGE_BOTH,&Interrupt_IFC);
   // wiringPiISR(EOI,INT_EDGE_BOTH,&Interrupt_EOI);
   // wiringPiISR(NDAC,INT_EDGE_BOTH,&Interrupt_NDAC);
   // wiringPiISR(NRFD,INT_EDGE_FALLING,&Interrupt_NRFD);
   // wiringPiISR(DAV,INT_EDGE_FALLING,&Interrupt_DAV);
    printf(" Interrupt end.\n");
    while(1)
    { 
     // initHandShakePinMode();
      recInt=receivemessage();
      if(recInt<0)
        printf("####Recevice:%d\n",recInt);
      else 
        printf("####Recevice:%c,ascii value=%d\n",recInt,recInt);

    }

    initDataline(1); // 0--> input mode, 1--> output mode
    pinMode(ATN,OUTPUT);
    pinMode(EOI,OUTPUT);
    digitalWrite(ATN,1);

    char ch = 'a';
     printf("Start to send message.\n");
    if(sendByteForMessageType(ch,1) == -1)
    {
        printf("sendByteForMessageType failed\n");
      //  return 0;
    }
    
    digitalWrite(EOI,1);
    digitalWrite(ATN,0);
    return 0;
}
