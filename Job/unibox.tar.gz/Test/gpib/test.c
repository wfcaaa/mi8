#include"GPIBDriver.h"

static int localDelay(long microseconds) 
{
    long seconds;
    struct timeval delay;
 
    /* us must be converted to seconds and microseconds ** for use by select(2) */
    if (microseconds >= 1000000L) 
    {
	seconds = microseconds / 1000000L;
	microseconds = microseconds % 1000000L;
    } 
    else 
    {
	seconds = 0;
    }
 
    delay.tv_sec = seconds; 
    delay.tv_usec = microseconds; 

    /* return 0, if select was interrupted, 1 otherwise */
    if (select(0, NULL, NULL, NULL, &delay) == -1 )
	return 0;
    else
	return 1;
}

int main()
{
    if(init() == -1)
    {
        printf("init gpib driver failed\n");
        return 0;
    }
    int num = 10;
    while(num--)
    {
      printf("wait handler send SRQ\n");
      printf("receive SRQ:%02x\n",readStb());
    //  while(isStartTouchDown==0);
    //  isStartTouchDown = 0;
      localDelay(199000);
      char arr[128] = "fullsites?\n";
      if(sendMessage(arr) == -1)
      {
        printf("send msg failed\n");
        return 0;
      }

      char* str = NULL;
      if(receiveMessage(&str) == -1)
      {
        printf("receive msg failed\n");
        return 0;
      }
      strcpy(arr,"BINON:00000000,00000000,00000000,00003311\n");
      if(sendMessage(arr) == -1)
      {
        printf("send msg failed\n");
        return 0;
      }
      if(receiveMessage(&str) == -1)
      {
        printf("receive msg failed\n");
        return 0;
      }
      strcpy(arr,"ECHOOK\n");
      if(sendMessage(arr) == -1)
      {
        printf("send msg failed\n");
        return 0;
      }
    }

    while(isStartTouchDown==0);
    isStartTouchDown = 0;
    printf("flash SRQ completed\n");
    destroy();
    printf("destroy finished\n");


    return 0;
}
