#ifndef __GPIBDRIVER_HPP
#define __GPIBDRIVER_HPP

#include<wiringPi.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<pthread.h>
#include<sys/select.h>
#include<sys/time.h>
#include<sys/types.h>

//############ Macro define###################
#define REN     22
#define ATN     23
#define SRQ     24
#define IFC     25
#define EOI     26


#define DAV     27
#define NRFD    28
#define NDAC    29

#define TALKER   1
#define LISTENER 0

//############ Macro define###################


//############ global varibale define###################
int isStartReceiveSRQ = 0;
int isContinueWaitSRQ = 1;

int addressOfTalker = 21;
int addressOfListener = 22;

int mID = 21;
int deviceId = 22;
int isStartTouchDown = 0;
int statu_byte = -1;
int isBlockSRQ = 0;
//############ global varibale define###################

int localDelay_us(long microseconds) ;
int init();
int sendMessage(const char* msg) ;
int receiveMessage(char** msg);
int readStb();
void setDeviceAddress(int id);
void setUniboxAddress(int id);
void blockSRQorNot(int value);
void destroy();





























































#endif
