#include<wiringPi.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<pthread.h>
#include<sys/select.h>
#include<sys/time.h>
#include<sys/types.h>

//############ Macro define###################
#define REN     22
#define ATN     23
#define SRQ     24
#define IFC     25
#define EOI     26


#define DAV     27
#define NRFD    28
#define NDAC    29

#define TALKER   1
#define LISTENER 0

//############ Macro define###################

//############ global varibale define###################
int isStartReceiveSRQ = 0;
int isContinueWaitSRQ = 1;

int addressOfTalker = 21;
int addressOfListener = 22;

int mID = 21;
int deviceId = 22;
//############ global varibale define###################

void initHandShakePinMode(int flag)
{
    if(flag == LISTENER) // when flag==0, it means we are listener,set DAV to be input mode
    {
      pinMode(DAV,INPUT);
      pinMode(NRFD,OUTPUT);
      pinMode(NDAC,OUTPUT);
      digitalWrite(NDAC,0);
      digitalWrite(NRFD,1);
    }
    else if(flag == TALKER) // it means we are going be talker, DAV need to be set out model
    {
      pinMode(DAV,OUTPUT);
      pinMode(NRFD,INPUT);
      pinMode(NDAC,INPUT);
    }
    
}




void initDatalineMode(int flag)
{
    int i = 0 ;
    for(i=0;i<8;++i)
    {
      if(flag == TALKER)
        pinMode(i,OUTPUT);
      else if(flag == LISTENER)
        pinMode(i,INPUT);
      else
        printf("flag:%d is invalid.plesae input:0(input mode) or 1(output mode)\n",flag);
    }
}
void initControlLineMode(int flag)
{
   pinMode(IFC,OUTPUT);
   pinMode(REN,OUTPUT);
   pinMode(SRQ,INPUT);
   pinMode(ATN,OUTPUT);
   if(flag == TALKER)
     pinMode(EOI,OUTPUT);
   else if(flag == LISTENER)
     pinMode(EOI,INPUT);

   else
     printf("the flag must 0 or 1\n");

}
void setup(int flag) // 0--> input mode, 1--> output mode
{
     initHandShakePinMode(flag); // init handshake line to be talker mode
     initDatalineMode(flag); // set data line to be output mode
     initControlLineMode(flag);
     static int isInit = 0;
     if(isInit == 0)
     {
       digitalWrite(REN,0); //set REN=0V(logic 1), enable remote control
       digitalWrite(IFC,0); //set IFC=0V(logic 1), clear all states
     //  sleep(2);
       digitalWrite(IFC,1);
       digitalWrite(ATN,0);//firstly, the control power must be charged by controler, set ATN=0V(logic 1)
       digitalWrite(EOI,1);
       digitalWrite(DAV,1);// set DAV=1V(logic 0), data is invalid 
       isInit = 1;
     }


}

int getLine(char* line)
{
    char c='0';
    int len = 0;
    while((c=getchar()) != EOF)
    {
        line[len++] = c;
        if(c == '\n')
          break;
    }
    line[len] = '\0';
    return len;
}
int sendcommand(const char c)
{
    int times = 0;
    
    while(times < 3)
    {
         if(digitalRead(ATN) == 0)
    {
#if debug
        printf("sendcommand:NRFD=%d,NDAC=%d\n",digitalRead(NRFD),digitalRead(NDAC));
#endif
        if(digitalRead(NRFD)==1 &&  digitalRead(NDAC) ==0)
        {
            digitalWriteByte(c);
            digitalWrite(DAV,0); //set DAV to 0v(logic 1) to allow listener to read data;

            while(digitalRead(NRFD) == 1); //before listener start to read data line, it should pull down NRFD,it means,not accepte other data before deal with this package completed
            while(digitalRead(NDAC) == 0); // it means that all listener has finish data accepted.
            
            digitalWrite(DAV,1); // set data invalid

            while(digitalRead(NDAC) == 1); 
           // while(digitalRead(NRFD) == 0); //when NRFD = 1v(logic 0), it means that listener want to accept next byte data.
#if debug
        printf("sendcommand:NRFD=%d,NDAC=%d, char:%d\n",digitalRead(NRFD),digitalRead(NDAC),c);
#endif
            return 0;
        }
      
    }
        ++times;
    }
    printf("sendcommand failed. ATN=%d,NRFD=%d,NDAC=%d\n",digitalRead(ATN),digitalRead(NRFD),digitalRead(NDAC)); 
    return -1;
}

int setlistenertalker(const char addressListen,const char addressTalk,const int role)
{
  digitalWrite(ATN,0); //set ATN line to voltage 0(logic 1),it means controler will take charge of control, set talker,listener
  if(addressListen>31 || addressTalk<0)
  {
    printf("listener address or talker address must less than 32 and more than 0\n");
    return -1;
  }
  initHandShakePinMode(TALKER);
  if(role == TALKER )
  {
    if(sendcommand((char)(255-(addressTalk+64))) != 0)//set talker 64-->0 10 0  0000 
      printf("setlinsenertalker:send byte:\'%c\', the last 5 bit vaule:%d\n",addressTalk+64,addressTalk);

    if(sendcommand((char)(255-'?')) != 0 )//set unlisten
      printf("setlinsenertalker:send byte:%c:%d\n",'?','?');
    
    if(sendcommand((char)(255-(addressListen+32))) != 0) //set listener, 32--> 0 01 0  0000
      printf("setlinsenertalker failed, byte:\'%c\',the last 5 bit value:%d\n",addressListen+32,addressListen);

  }
  else if(role == LISTENER)
  {
    if(sendcommand((char)(255-'?')) != 0 )//set unlisten
      printf("setlinsenertalker failed, byte:%c:%d\n",'?','?');
    
    if(sendcommand((char)(255-(addressListen+32))) != 0) //set listener, 32--> 0 01 0  0000
      printf("setlinsenertalker failed, byte:\'%c\',the last 5 bit value:%d\n",addressListen+32,addressListen);

    if(sendcommand((char)(255-(addressTalk+64))) != 0)//set talker 64-->0 10 0  0000 
      printf("setlinsenertalker failed, byte:\'%c\', the last 5 bit vaule:%d\n",addressTalk+64,addressTalk);
  }
  else
  {
    printf("role:%d is unexpected\n",role);
    return -1;
  }

  return 0;

}

int sendmessage(const char ch)
{
  if(digitalRead(ATN) == 1)
  {

    if(digitalRead(NRFD) == 1 )
    {
      //Listener ready 

      digitalWriteByte(ch); //put data 
      digitalWrite(DAV,0);  //set DAV=0V(logic 1),it means data is valid

      while(digitalRead(NRFD)==1);     //when NRFD:1v-->0v(logic 0-->1),it means that listener is accepting data
      while(digitalRead(NDAC)==0);     //when NDAC:0v-->1v(logic 1-->0), it means all listener has accepted data


      digitalWrite(DAV,1) ;//set DAV=1V(logic 0), it means data is invalid

      while(digitalRead(NDAC)==1); // when NDAC=0V(logic 1),    

    }
    else
    {
#if debug
      printf("Listener not ready,cannot send mesaage:%c:%d\t",ch,ch);  
      printf("NRFD=%d , NDAC=%d\n",digitalRead(NRFD),digitalRead(NDAC)); 
#endif
    }
  }
  else
    printf("the data is not message,ATN=%d\n",digitalRead(ATN));

  return 0;
   
}
void testForSendMessage(const char* data,const int addressOfListener,const int addressOfTalker,const int roler);
int receivemessage() 
{
      while(1)
      {
        if(digitalRead(DAV)==1)
        {
            digitalWrite(NRFD,1);
            //Thread.sleep(10);
#if debug
            printf("ATN:%d,wait for DAV valid,NRFD:%d,DAV:%d,SRQ:%d,EOI:%d\n",digitalRead(ATN),digitalRead(NRFD),digitalRead(DAV),digitalRead(SRQ),digitalRead(EOI));
#endif
            
            while(digitalRead(DAV)==1); //used as synchronizing
            digitalWrite(NRFD,0);
            //Thread.sleep(10);
            int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
            digitalWrite(NDAC,1);
            while(digitalRead(DAV)==0);//used as synchronizing
            digitalWrite(NDAC,0);
            // digitalWrite(NRFD,1);
            return a;
            //Gpio.digitalWrite(28,1);
        }
        else
        {
            printf("DAV:%d,sleep 1s to wati\n",digitalRead(DAV));
            sleep(1);
        }
      }
     
}

void setupForSRQ(const char addressListen,const char addressTalk)
{

  setup(TALKER);
  digitalWrite(ATN,0);
   
  if(sendcommand((char)(255-'?')) != 0 )//set unlisten
    printf("setlinsenertalker:ATN:%d,SRQ:%d,EOI:%d. send byte:%c:%d\n",digitalRead(ATN),digitalRead(SRQ),digitalRead(EOI),'?','?');

  if(sendcommand((char)(255-(addressListen+32))) != 0) //set listener, 32--> 0 01 0  0000
    printf("setlinsenertalker:ATN:%d,SRQ:%d,EOI:%d. send byte:\'%c\',the last 5 bit value:%d\n",digitalRead(ATN),digitalRead(SRQ),digitalRead(EOI),addressListen+32,addressListen);

  if(sendcommand((char)(255-24)) != 0 )
    printf("setlinsenertalker:ATN:%d,SRQ:%d,EOI:%d. send byte:%c:%d\n",digitalRead(ATN),digitalRead(SRQ),digitalRead(EOI),24,24);

  if(sendcommand((char)(255-(addressTalk+64))) != 0)//set talker 64-->0 10 0  0000 
    printf("setlinsenertalker:ATN:%d,SRQ:%d,EOI:%d. send byte:\'%c\', the last 5 bit vaule:%d\n",digitalRead(ATN),digitalRead(SRQ),digitalRead(EOI),addressTalk+64,addressTalk);

}

int receivesrq()
{
#if debug
     printf("try to receive SRQ,DAV:%d\n",digitalRead(DAV));
#endif
        digitalWrite(NRFD,1);
        while(digitalRead(DAV)==1); //used as synchronizing
            digitalWrite(NRFD,0);
            //Thread.sleep(10);
            int a=255-(digitalRead(0)+2*digitalRead(1)+4*digitalRead(2)
                    +8*digitalRead(3)+16*digitalRead(4)+32*digitalRead(5)
                    +64*digitalRead(6)+128*digitalRead(7));
            digitalWrite(NDAC,1);
            while(digitalRead(DAV)==0);//used as synchronizing
            digitalWrite(NDAC,0);
            //digitalWrite(NRFD,1);
           
    return a;
}
int receiveSRQ(const char addressListen,const char addressTalk)
{
    int isContinue = 1;
    char str[64] = "";
#if debug
         printf("wait for SRQ\n");
#endif
        if(digitalRead(SRQ) == 0)
            isStartReceiveSRQ = 1;
        while(isStartReceiveSRQ == 0);
        
        {
#if debug
            printf("isStartReceiveSRQ:%d\n",isStartReceiveSRQ);
#endif
            digitalWrite(EOI,1);
            setupForSRQ(addressListen,addressTalk);
            initHandShakePinMode(LISTENER);
            initDatalineMode(LISTENER);
            digitalWrite(ATN,1);
            int srq = receivesrq();
            printf("receive SRQ:0x%x:%d\n",srq,srq);
            initHandShakePinMode(TALKER);
            initDatalineMode(TALKER);
            digitalWrite(ATN,0);
            sendcommand((char)(255-25));
            
            sendcommand((char)(255-95));
          //  initHandShakePinMode(LISTENER);
            isStartReceiveSRQ = 0;
        }
     
       

    
}


int setupForListener(const int addressOfListener,const int addressOfTalker)
{
    if( setlistenertalker(addressOfListener,addressOfTalker,LISTENER) != 0 )
      return -1;
    setup(LISTENER);
#if debug
    printf("setup for listener finished\n"); 
#endif
    return 0;
}

int setupForTalker(const int addressOfListener,const int addressOfTalker)
{
    setup(TALKER);
    if( setlistenertalker(addressOfListener,addressOfTalker,TALKER) !=0 )
      return -1;
#if debug
    printf("setup for talker finished\n");
#endif
    return 0;
}
void testForReceiveMessage(const int addressOfListener,const int addressOfTalker,const int roler)
{
  
    if( setupForListener(addressOfListener,addressOfTalker) == -1)
    {
        printf("setupForListener failed\n");
        return;
    }
    
    digitalWrite(ATN,1);
    //sleep(1);
    
    int recInt = 3;
    int index = 0 ;
    char str[24] = "";
    int isContinue = 1;
    while(isContinue)
    {
    //  initHandShakePinMode(0);
      recInt=receivemessage();
      if(recInt<0)
      {
#if debug
    //    printf("Recevice:%d\n",recInt);
#endif
      }
      else 
      {
#if debug
        printf("isContinue:%d. Reevice: %c: %d\n",isContinue,recInt,recInt);
#endif
        if(recInt == 10)
          break;
        str[index++] = recInt;
      }

    }
    printf("receive string:%s\n",str); 
}

static int localDelay_us(long microseconds) 
{
    long seconds;
    struct timeval delay;
 
    /* us must be converted to seconds and microseconds ** for use by select(2) */
    if (microseconds >= 1000000L) 
    {
	seconds = microseconds / 1000000L;
	microseconds = microseconds % 1000000L;
    } 
    else 
    {
	seconds = 0;
    }
 
    delay.tv_sec = seconds; 
    delay.tv_usec = microseconds; 

    /* return 0, if select was interrupted, 1 otherwise */
    if (select(0, NULL, NULL, NULL, &delay) == -1 )
	return 0;
    else
	return 1;
}

void testForSendMessage(const char* data,const int addressOfListener,const int addressOfTalker,const int roler)
{

    
    if( setupForTalker(addressOfListener,addressOfTalker) == -1)
    {
        printf("setupForTalker failed\n");
        return ;
    }
    digitalWrite(ATN,1); // set ATN=1V(logic 0),it means taker will send message to listener
    localDelay_us(53000);
    
    int i = 0;
    for( i=0;i<strlen(data);++i)
        sendmessage((char)(255-data[i]));
    digitalWrite(EOI,0);
    sendmessage((char)(10));
    digitalWrite(EOI,1);
    printf("send message:%s\n",data);
}

void Interrupt_SRQ(void)
{
#if debug
     printf("SRQ_Tirggered ");
     printf("DAV:%d,NRFD:%d,NDAC:%d,EOI:%d,IFC:%d,SRQ:%d,ATN:%d,REN:%d\n",
              digitalRead(DAV),
              digitalRead(NRFD),
              digitalRead(NDAC),
              digitalRead(EOI),
              digitalRead(IFC),
              digitalRead(SRQ),
              digitalRead(ATN),
              digitalRead(REN)); 

#endif    
     isStartReceiveSRQ= 1;
}

void* wait_srq(void * p)
{
  
  while(isContinueWaitSRQ)
  {
     if(isStartReceiveSRQ||(digitalRead(SRQ)==0) )
     {
        addressOfListener = 21;
        addressOfTalker = 22;
        receiveSRQ(addressOfListener,addressOfTalker);
     }
  }
}
int main(int argc,char* argv[] )
{   
    printf("will initial gpibo setup ...\n");
    if(wiringPiSetup() < 0)
      printf("pigpio initialisation failed\n");
    else
      printf(" pigpio initialised okay.\n");
    
    
    char type[12] = "send";
    if(argc>=2)
      strcpy(type,argv[1]);
#if debug
    printf("type:%s\n",type);
#endif
    wiringPiISR(SRQ,INT_EDGE_FALLING,&Interrupt_SRQ);
#if debug
    printf("reigster SRQ edge failling call back finished\n");
#endif
  
    int  isContinue = 1;
    char buffer[128] = "";
    pthread_t thread_wait_srq;
    if(pthread_create(&thread_wait_srq,NULL,wait_srq,NULL) != 0)
    {
        printf("create thread fail\n");
        return 1;
    }
   
    if(strcmp(type,"test") == 0)
    {
      while(1)
      {
        printf("please select the role:s(send)/r(receive)/q(query):\n");
        getLine(buffer);
        if(strncmp(buffer,"s",1) == 0)
        {
          printf("please input data:\n");
          getLine(buffer);
          addressOfListener = 22;
          addressOfTalker = 21;
          testForSendMessage(buffer,addressOfListener,addressOfTalker,TALKER);
        }
        else if( strncmp(buffer,"r",1) == 0)
        {
          printf("to be a listener\n");
          addressOfListener = 21;
          addressOfTalker = 22;
          testForReceiveMessage(addressOfListener,addressOfTalker,TALKER);

        }
        else if( strncmp(buffer,"q",1) == 0)
        {
          printf("please input data:\n");
          getLine(buffer);
          addressOfListener = 22;
          addressOfTalker = 21;
          testForSendMessage(buffer,addressOfListener,addressOfTalker,TALKER);
          addressOfListener = 21;
          addressOfTalker = 22;
          testForReceiveMessage(addressOfListener,addressOfTalker,TALKER);

        }
        else
        {
          isContinueWaitSRQ = 0;
          break;
        }
      }

    }
    pthread_join(thread_wait_srq,NULL);
    return 0;
}
