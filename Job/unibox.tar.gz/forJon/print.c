#include<wiringPi.h>
#include<stdio.h>
#include<unistd.h>

#define EOI     26
#define ATN     23


#define DAV     27
#define NRFD    28
#define NDAC    29






void print()
{
    int i = 0 ;
    for(i=0;i<8;++i)
    {
        printf("%d ",digitalRead(i));
    }
    printf("\n");
}
int main()
{   
    printf("will initial gpibo setup ...\n");
    if(wiringPiSetup() < 0)
      printf("pigpio initialisation failed\n");
    else
      printf(" pigpio initialised okay.\n");
   
    print();
    return 0;
}
