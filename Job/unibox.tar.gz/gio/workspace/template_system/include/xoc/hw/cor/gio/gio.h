/* -*-C-*- */
/**
 * Generic interface to external instrument hardware.
 * ----------------------------------------------------------------------------
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 * ============================================================================
 * @file   gio.h
 * @author Jens Kilian
 * @date   Created:  Thu Mar 14 09:13:40 2002
 * @date   Modified: Tue Feb  2 14:47:11 2016 (Jens Kilian)
 *
 * Public interface to the GIO module, which provides a generic way
 * to handle external instrument hardware.
 * ----------------------------------------------------------------------------
 */

#ifndef H8A8C6288_285D_4736_BACC_DD47C205CC04_
#define H8A8C6288_285D_4736_BACC_DD47C205CC04_

/*
 * System includes.
 * ----------------------------------------------------------------------------
 */

/*
 * Officially, this should be <rpc/rpc.h>, but that pollutes the namespace
 * with symbols like 'SUCCESS', causing conflicts.
 */
#include <rpc/clnt.h>

#include <stdint.h>

/*
 * Type definitions.
 * ----------------------------------------------------------------------------
 */

/**
 * An opaque type; you don't want to know about it.
 *
 * The public API doesn't publish any information about this type.
 * Client applications may not make any assumptions about the internal
 * structure of a GIO session.
 */
struct generic_io_t;

/**
 * Interface or Device IDentifier - used to identify an open connection.
 *
 * Each session opened by a client application is represented by a unique
 * @c IDID.  The @c gio_open() and @c gio_get_interface() functions return such
 * a value, and almost all other functions in GIO take one as their first
 * argument.  The value @c (IDID)0 usually signals an error.
 *
 * There are two different session types:
 * - Device sessions are used to communicate with the actual instruments.
 * - Interface sessions are used to control the hardware that is used
 *   for the communication.
 *
 * Interface sessions are not supported for all types of interfaces.
 */
typedef struct generic_io_t *IDID;

/**
 * Error codes.
 *
 * Almost all functions in GIO return an error code of this type.
 * All of them, when they encounter an error, set an internal error state
 * which can be queried using the @c gio_get_errno() function.
 *
 * @attention
 * Client applications should normally not check for specific error codes,
 * because not all access methods will return the same set of errors.
 * Exceptions to this rule are codes like @c GIO_ERR_NO_ERROR (i.e., success)
 * and @c GIO_ERR_IO_TIMEOUT.
 *
 * @ingroup errors
 */
typedef enum {
  /* Errors defined by SICL and/or VXI-11 - DO NOT CHANGE THIS SECTION. */

  /**
   * No error occurred; the operation was successfully completed.
   */
  GIO_ERR_NO_ERROR                       = 0,   /* VXI-11 B.5.2 */
  GIO_ERR_SYNTAX_ERROR                   = 1,   /* VXI-11 B.5.2 */
  GIO_ERR_INVALID_SYMBOLIC_NAME          = 2,
  GIO_ERR_DEVICE_NOT_ACCESSIBLE          = 3,   /* VXI-11 B.5.2 */
  GIO_ERR_INVALID_ID                     = 4,   /* VXI-11 B.5.2 */
  GIO_ERR_PARAMETER_ERROR                = 5,   /* VXI-11 B.5.2 */
  GIO_ERR_CHANNEL_NOT_ESTABLISHED        = 6,   /* VXI-11 B.5.2 */
  GIO_ERR_PERMISSION_DENIED              = 7,
  GIO_ERR_OPERATION_NOT_SUPPORTED        = 8,   /* VXI-11 B.5.2 */
  GIO_ERR_OUT_OF_RESOURCES               = 9,   /* VXI-11 B.5.2 */
  GIO_ERR_INTERFACE_INACTIVE             = 10,
  /**
   * An attempt to lock a session failed because another client
   * currently holds a lock.
   */
  GIO_ERR_DEVICE_LOCKED                  = 11,  /* VXI-11 B.5.2 */
  GIO_ERR_NO_LOCK_HELD                   = 12,  /* VXI-11 B.5.2 */
  GIO_ERR_BAD_FORMAT                     = 13,
  GIO_ERR_DATA_INTEGRITY_VIOLATED        = 14,
  /**
   * An operation was aborted because it did not complete within the
   * timeout period.
   */
  GIO_ERR_IO_TIMEOUT                     = 15,  /* VXI-11 B.5.2 */
  GIO_ERR_OVERFLOW                       = 16,
  GIO_ERR_IO_ERROR                       = 17,  /* VXI-11 B.5.2 */
  GIO_ERR_OS_ERROR                       = 18,
  GIO_ERR_INVALID_MAP_REQUEST            = 19,
  GIO_ERR_DEVICE_INACTIVE                = 20,
  GIO_ERR_INVALID_ADDRESS                = 21,  /* VXI-11 B.5.2 */
  /**
   * The operation is not supported by the access method.
   */
  GIO_ERR_NOT_IMPLEMENTED                = 22,
  GIO_ERR_ABORT                          = 23,  /* VXI-11 B.5.2 */
  GIO_ERR_INVALID_CONFIGURATION          = 24,
  GIO_ERR_NOT_CMDR                       = 25,
  GIO_ERR_VERSION                        = 26,
  GIO_ERR_NESTED_IO                      = 27,
  GIO_ERR_BUSY                           = 28,
  GIO_ERR_CHANNEL_ALREADY_ESTABLISHED    = 29,  /* VXI-11 B.5.2 */
  GIO_ERR_BUS_ERROR                      = 30,
  GIO_ERR_BUS_ERROR_RETRY                = 31,
  GIO_ERR_INTERNAL                       = 128,
  GIO_ERR_INTERRUPT                      = 129,
  GIO_ERR_UNKNOWN                        = 130,

  /* Errors defined by RPC library - DO NOT CHANGE THIS SECTION. */

  GIO_ERR_CANNOT_ENCODE_ARGUMENTS        = 1000 + RPC_CANTENCODEARGS,
  GIO_ERR_CANNOT_DECODE_RESULTS          = 1000 + RPC_CANTDECODERES,
  GIO_ERR_CANNOT_SEND                    = 1000 + RPC_CANTSEND,
  GIO_ERR_CANNOT_RECEIVE                 = 1000 + RPC_CANTRECV,
  GIO_ERR_RPC_TIMEOUT                    = 1000 + RPC_TIMEDOUT,
  GIO_ERR_CALL_INTERRUPTED               = 1000 + RPC_INTR,
  GIO_ERR_RPC_UDERROR                    = 1000 + RPC_UDERROR,
  GIO_ERR_RPC_VERSION_MISMATCH           = 1000 + RPC_VERSMISMATCH,
  GIO_ERR_AUTHENTICATION_ERROR           = 1000 + RPC_AUTHERROR,
  GIO_ERR_PROGRAM_UNAVAILABLE            = 1000 + RPC_PROGUNAVAIL,
  GIO_ERR_PROGRAM_VERSION_MISMATCH       = 1000 + RPC_PROGVERSMISMATCH,
  GIO_ERR_PROCEDURE_UNAVAILABLE          = 1000 + RPC_PROCUNAVAIL,
  GIO_ERR_CANNOT_DECODE_ARGUMENTS        = 1000 + RPC_CANTDECODEARGS,
  GIO_ERR_SYSTEM_ERROR                   = 1000 + RPC_SYSTEMERROR,
  GIO_ERR_UNKNOWN_HOST                   = 1000 + RPC_UNKNOWNHOST,
  GIO_ERR_UNKNOWN_PROTOCOL               = 1000 + RPC_UNKNOWNPROTO,
  GIO_ERR_UNKNOWN_ADDRESS                = 1000 + RPC_UNKNOWNADDR,
  GIO_ERR_BROADCAST_NOT_SUPPORTED        = 1000 + RPC_NOBROADCAST,
  GIO_ERR_PORTMAPPER_FAILURE             = 1000 + RPC_PMAPFAILURE,
  GIO_ERR_PROGRAM_NOT_REGISTERED         = 1000 + RPC_PROGNOTREGISTERED,
  GIO_ERR_NAME_TRANSLATION_FAILURE       = 1000 + RPC_N2AXLATEFAILURE,
  GIO_ERR_TLI_ERROR                      = 1000 + RPC_TLIERROR,
  GIO_ERR_RPC_FAILED                     = 1000 + RPC_FAILED,
  GIO_ERR_RPC_IN_PROGRESS                = 1000 + RPC_INPROGRESS,
  GIO_ERR_STALE_HANDLE                   = 1000 + RPC_STALERACHANDLE,

  /* Errors defined by the GIO library. */

  /**
   * Client application specified a symbolic name without an access method
   * (but containing a / character).
   */
  GIO_ERR_NO_ACCESS_METHOD               = 4242,
  /**
   * Client application specified an access method which does not exist.
   */
  GIO_ERR_ACCESS_METHOD_NOT_FOUND

} GIO_ERROR;

/**
 * Reasons for returning from a read request.
 *
 * These values are returned by @c gio_read() to indicate different termination
 * conditions.
 *
 * @ingroup misc
 */
typedef enum {
  /* Must be identical to SICL and/or VXI-11 - DO NOT CHANGE THIS SECTION. */

  /** Requested number of bytes was read */
  GIO_REASON_REQCNT      = 1 << 0,
  /** Termination character encountered */
  GIO_REASON_CHR         = 1 << 1,
  /** END indicator encountered */
  GIO_REASON_END         = 1 << 2

} GIO_REASON;

/**
 * Parameters for GPIB Bus Status command.
 *
 * A value of this type is passed to @c gio_gpib_bus_status() to select one of
 * a number of status inquiries that can be made about a GPIB interface.
 *
 * @ingroup gpib
 */
typedef enum {
  /* Must be identical to SICL and/or VXI-11 - DO NOT CHANGE THIS SECTION. */

  /**
   * Checks if the GPIB interface is in remote state.
   */
  GIO_GPIB_STATUS_REMOTE               = 1,
  /**
   * Checks if the SRQ line is asserted, indicating a service request
   * is pending.
   */
  GIO_GPIB_STATUS_SRQ                  = 2,
  /**
   * Checks if the NDAC line is asserted.
   */
  GIO_GPIB_STATUS_NDAC                 = 3,
  /**
   * Checks if the interface is the system controller.
   */
  GIO_GPIB_STATUS_SYSTEM_CONTROLLER    = 4,
  /**
   * Checks if the interface is the active controller.
   */
  GIO_GPIB_STATUS_CONTROLLER_IN_CHARGE = 5,
  /**
   * Checks if the interface is addressed to talk.
   */
  GIO_GPIB_STATUS_TALKER               = 6,
  /**
   * Checks if the interface is addressed to listen.
   */
  GIO_GPIB_STATUS_LISTENER             = 7,
  /**
   * Returns the GPIB address of the interface.
   */
  GIO_GPIB_STATUS_BUS_ADDRESS          = 8

} GIO_GPIB_STATUS_REQUEST;

/**
 * Serial interface control & status.
 *
 * These values are used with @c gio_rs232_control to change communication
 * parameters of an RS-232 interface and with @c gio_rs232_status to inquire
 * the interface status.
 *
 * @ingroup rs232
 */
typedef enum {
  /* Must be identical to SICL - DO NOT CHANGE THIS SECTION. */

  /**
   * Baud rate of the interface.
   */
  GIO_RS232_BAUD             = 1,
  /**
   * Indicate whether a parity bit is transmitted.
   */
  GIO_RS232_PARITY           = 2,
  /**
   * Number of stop bits.
   */
  GIO_RS232_STOP_BITS        = 3,
  /**
   * Number of data bits.
   */
  GIO_RS232_WIDTH            = 4,
  /**
   * Flow control mode.
   */
  GIO_RS232_FLOW_CONTROL     = 5,
  /**
   * State of modem status signals.
   */
  GIO_RS232_MODEM_STATUS     = 6,
  /**
   * State of the RS-232 interface.
   */
  GIO_RS232_STATUS           = 7,
  /**
   * Reset the RS-232 interface.
   */
  GIO_RS232_RESET            = 9,
  /**
   * End-of-message indicator for read operations.
   */
  GIO_RS232_READ_EOI         = 10,
  /**
   * End-of-message indicator for write operations.
   */
  GIO_RS232_WRITE_EOI        = 11,
  /**
   * Number of data bytes available for reading.
   */
  GIO_RS232_READ_DAV         = 14,
  /**
   * Character signaling (re)start for XON/XOFF flow control.
   */
  GIO_RS232_XON_CHAR         = 17,
  /**
   * Character signaling pause for XON/XOFF flow control.
   */
  GIO_RS232_XOFF_CHAR        = 18

} GIO_RS232_REQUEST;

/**
 * Allowed values for the GIO_RS232_PARITY setting.
 *
 * @ingroup rs232
 */
typedef enum {
  /* Must be identical to SICL - DO NOT CHANGE THIS SECTION. */

  /**
   * No parity.
   */
  GIO_RS232_PARITY_NONE   = 0,
  /**
   * Even parity.
   */
  GIO_RS232_PARITY_EVEN   = 1,
  /**
   * Odd parity.
   */
  GIO_RS232_PARITY_ODD    = 2,
  /**
   * Parity bit is constantly '1'.
   */
  GIO_RS232_PARITY_MARK   = 3,
  /**
   * Parity bit is constantly '0'.
   */
  GIO_RS232_PARITY_SPACE  = 4

} GIO_RS232_PARITY_VALUE;

/**
 * Allowed values for the GIO_RS232_FLOW_CONTROL setting.
 *
 * @ingroup rs232
 */
typedef enum {
  /* Must be identical to SICL - DO NOT CHANGE THIS SECTION. */

  /**
   * No flow control.
   */
  GIO_RS232_FLOW_CONTROL_NONE     = 0,
  /**
   * XON/XOFF (in-band) flow control.
   */
  GIO_RS232_FLOW_CONTROL_XON_XOFF = 1,
  /**
   * RTS/CTS flow control.
   */
  GIO_RS232_FLOW_CONTROL_RTS_CTS  = 2

} GIO_RS232_FLOW_CONTROL_VALUE;

/**
 * Allowed values for the GIO_RS232_MODEM_STATUS setting.
 *
 * @ingroup rs232
 */
typedef enum {
  /* Must be identical to SICL - DO NOT CHANGE THIS SECTION. */

  /**
   * State of DCD (data carrier detect) line.
   */
  GIO_RS232_MODEM_STATUS_DCD   = 0x0001,
  /**
   * State of DSR (data set ready) line.
   */
  GIO_RS232_MODEM_STATUS_DSR   = 0x0002,
  /**
   * State of CTS (clear to send) line.
   */
  GIO_RS232_MODEM_STATUS_CTS   = 0x0004,
  /**
   * State of RI (ring indicator) line.
   */
  GIO_RS232_MODEM_STATUS_RI    = 0x0008

} GIO_RS232_MODEM_STATUS_VALUE;

/**
 * Allowed values for the GIO_RS232_STATUS setting.
 *
 * @ingroup rs232
 */
typedef enum {
  /* Must be identical to SICL - DO NOT CHANGE THIS SECTION. */

  /**
   * Data available for reading.
   */
  GIO_RS232_STATUS_DAV      = 0x0001,
  /**
   * Overflow error detected.
   */
  GIO_RS232_STATUS_OVERFLOW = 0x0002,
  /**
   * Parity error detected.
   */
  GIO_RS232_STATUS_PARERR   = 0x0004,
  /**
   * Framing error detected.
   */
  GIO_RS232_STATUS_FRAMING  = 0x0008,
  /**
   * Break detected.
   */
  GIO_RS232_STATUS_BREAK    = 0x0010,
  /**
   * Output queue empty.
   */
  GIO_RS232_STATUS_TEMT     = 0x0020

} GIO_RS232_STATUS_VALUE;

/**
 * Allowed values for the GIO_RS232_READ_EOI/GIO_RS232_WRITE_EOI settings.
 *
 * @ingroup rs232
 */
typedef enum {
  /* Must be identical to SICL - DO NOT CHANGE THIS SECTION. */

  /**
   * End-of-message indicator character.
   */
  GIO_RS232_EOI_CHR   = 0x100,
  /**
   * No end-of-message indicator.
   */
  GIO_RS232_EOI_NONE  = 0x200,
  /**
   * End-of-message indicated by data bit 8.
   */
  GIO_RS232_EOI_BIT8  = 0x400

} GIO_RS232_EOI_VALUE;

/**
 * Serial interface modem control.
 *
 * These values are used with @c gio_rs232_modem_control to control the
 * RTS and DTR lines of an RS-232 interface and with
 * @c gio_rs232_modem_control_status to inquire their status.
 *
 * @ingroup rs232
 */
typedef enum {
  /* Must be identical to SICL - DO NOT CHANGE THIS SECTION. */

  /**
   * State of RTS (request to send) line.
   */
  GIO_RS232_MODEM_CONTROL_RTS = 0x1000,
  /**
   * State of DTR (data terminal ready) line.
   */
  GIO_RS232_MODEM_CONTROL_DTR = 0x2000

} GIO_RS232_MODEM_CONTROL;

/*
 * Function prototypes.
 * ----------------------------------------------------------------------------
 */

#ifdef __cplusplus
extern "C" {
#endif

  /**
   * @defgroup openclose Opening and closing connections
   * @{
   */

  /**
   * Open an interface or device.
   *
   * The symbolic name @c pName must have the form
   *
   *    <access method>/<local name>
   *
   * The "<access method>" part selects a specific driver which determines
   * the form that the "<local name>" part takes.
   *
   * Currently the following access methods are supported with local names
   * of the indicated form:
   *
   * - GPIB (via a LAN-to-GPIB gateway using the VXI-11 protocol)
   *
   *     vxi11/<host>/gpib0[,<address>]
   *
   *     <host> is the hostname or IPv4 address of the gateway;
   *     <address> is the GPIB address of an instrument.
   *     If <address> is omitted, an interface session is created.
   *
   * - VXI-11 (for instruments connected via LAN and supporting this protocol)
   *
   *     vxi11/<host>/inst0
   *
   *     <host> is the hostname or IPv4 address of the instrument.
   *
   * - SCPI-over-TCP (for instruments connected via LAN and supporting it)
   *
   *     scpi/<host>[:<port>]
   *
   *     <host> is the hostname or IPv4 address of the instrument;
   *     <port> is the TCP port for transmitting SCPI commands.
   *     If <port> is omitted, an attempt is made to connect using
   *     some port numbers commonly used for SCPI-over-TCP connections.
   *
   * - RS-232
   *
   *     rs232/<device>[,488]
   *
   *     <device> is the name of a device file for a serial interface,
   *     e.g., "/dev/ttyS0".  If the suffix ",488" is present, a device
   *     session is created, otherwise an interface session.
   *
   * When @c gio_open() returns an @c IDID other than zero, a communication
   * session has been opened and can be accessed via the returned @c IDID.
   * If an error occurs, @c gio_open() returns @c (IDID)0; the client
   * application can find the error code using @c gio_get_errno().
   *
   * @return IDID
   * @retval 0     An error occurred.
   * @retval other Operation successfully completed.
   */
  IDID
  gio_open(
    /** Symbolic name of interface or device. */
    const char *pName);

  /**
   * Return an interface ID referring to the interface associated with
   * the given device ID.
   *
   * Some of the functions in the GIO layer do not work given an @c IDID which
   * refers to a device session.  Instead of always opening separate interface
   * and device sessions, a client application can use @c gio_get_interface()
   * to get access to the interface for a given device session.
   *
   * @attention
   * @c gio_get_interface() can return identical @c IDIDs when called
   * for different devices connected to the same interface.
   * Client applications should not call @c gio_close() on the returned
   * @c IDID.
   *
   * @return IDID
   * @retval 0     An error occurred.
   * @retval other Operation successfully completed.
   */
  IDID
  gio_get_interface(
    /** Device ID. */
    IDID id);

  /**
   * Close an interface or device.
   *
   * This function shuts down a connection opened by @c gio_open();
   * after it returns, the @c IDID passed to it must no longer be used.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_close(
    /** Interface or device ID. */
    IDID id);
   
  /**
   * Return the name of an interface or device (for diagnostic purposes).
   *
   * @c gio_get_name() returns the symbolic name that was used to open
   * the session whose @c IDID is passed in.
   *
   * @return const char *
   * @retval 0     An error occurred.
   * @retval other Name of the interface or device.
   */
  const char *
  gio_get_name(
    /** Interface or device ID. */
    IDID id);
  
  /**
   * @}
   * @defgroup misc Operations applicable to diverse interface or device types
   * @{
   */

  /**
   * Clear an interface or device.
   *
   * The exact behavior of this function depends on the interface type and on
   * the access method which is used.  For example, it will send an "SDC"
   * command to a GPIB device session.
   *
   * @attention
   * This function must not be used if the intent is to perform an "interface
   * clear" on a GPIB interface.  Use @c gio_gpib_send_IFC() instead.
   *
   * (The reason for this restriction is that access methods for different
   * types of GPIB interfaces behave differently when @c gio_clear() is given
   * the @c IDID of an interface session.  This is a protocol issue,
   * not a software bug.)
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_clear(
    /** Interface or device ID. */
    IDID id);

  /**
   * Write data.
   *
   * The function @c gio_write() sends a block of data to an interface
   * or device.  If no error occurs and the parameter @c pActual is not zero,
   * @c gio_write() returns the number of bytes written in @c *pActual.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_write(
    /** Interface or device ID. */
    IDID id,
    /** Buffer containing data to be written. */
    const void *pBuffer,
    /** Amount of data to be written. */
    size_t len,
    /** Send last byte with END indicator. */
    bool_t end,
    /** OUT: Actual number of bytes written. */
    size_t *pActual);

  /**
   * Read data.
   *
   * The function @c gio_read() reads a block of data from an interface
   * or device.  If no error occurs and the parameter @c pReasons is not zero,
   * @c gio_read() returns in @c *pReasons a value indicating the condition
   * (or conditions) which caused to operation to return; this value consists
   * of separate bits (values of the @c GIO_REASON enumeration type).
   * @c gio_read() also returns the number of bytes read in @c *pActual,
   * if @c pActual is non-zero.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_read(
    /** Interface or device ID. */
    IDID id,
    /** Buffer into which data should be read. */
    void *pBuffer,
    /** Size of buffer. */
    size_t len,
    /** OUT: Reasons for termination. */
    int *pReasons,
    /** OUT: Actual number of bytes read. */
    size_t *pActual);

  /**
   * Read status byte.
   *
   * The exact effect of @c gio_read_status_byte() depends on the interface
   * type; for a GPIB interface it performs a "serial poll".  It returns
   * a single byte in @c *pStb.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_read_status_byte(
    /** Interface or device ID. */
    IDID id,
    /** OUT: Status byte. */
    uint8_t *pStb);

  /**
   * Set status byte.
   *
   * On a GPIB interface, @c gio_set_status_byte() sets the status byte
   * which will be delivered to a controller performing a "serial poll".
   * If the SRQ bit in @c stb is set, the SRQ line on the GPIB bus will
   * be asserted.
   *
   * @attention
   * This function may not work on all access methods or interfaces.
   * Even when it works, restrictions may apply.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_set_status_byte(
    /** Interface or device ID. */
    IDID id,
    /** Status byte. */
    uint8_t stb);

  /**
   * Trigger device(s).
   *
   * This function performs an interface-specific triggering action
   * for a device @c IDID or, if an interface @c IDID is given,
   * for all devices on that interface.
   *
   * @attention
   * Behavior may differ between access methods.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_trigger(
    /** Interface or device ID. */
    IDID id);

  /**
   * Switch device to local operation.
   *
   * The device whose @c IDID is given will be put (according to some
   * interface-specific method) into local operation mode.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_local(
    /** Device ID. */
    IDID id);

  /**
   * Switch device to remote operation.
   *
   * The device whose @c IDID is given will be put (according to some
   * interface-specific method) into remote operation mode.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_remote(
    /** Device ID. */
    IDID id);

  /**
   * Lock an interface or device.
   *
   * @c gio_lock() places a device (or an entire interface) in a mode in
   * which access is granted only to the client which locked it.
   * Depending on the state of the lock waiting flag
   * (see @c gio_set_lock_wait() for more information), all other clients
   * will either hang or encounter errors (@c GIO_ERR_DEVICE_LOCKED)
   * when they attempt to access a locked device or interface.
   *
   * @attention
   * Behavior may differ between access methods when an attempt is made
   * to lock the same interface/device via different @c IDIDs, or to nest
   * calls to @c gio_lock() for a single @c IDID.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_lock(
    /** Interface or device ID. */
    IDID id);

  /**
   * Unlock an interface or device.
   *
   * @c gio_unlock() releases a client's lock on a device or interface.
   * The client must currently hold the lock on the given @c IDID.
   *
   * @attention
   * Behavior may differ between access methods (see @c gio_lock()).
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_unlock(
    /** Interface or device ID. */
    IDID id);

  /**
   * @}
   * @defgroup gpib Operations specific to GPIB devices
   * @{
   */

  /**
   * Send an IFC (interface clear) on a GPIB interface.
   *
   * After an IFC, the system controller is the active controller and
   * all devices on the GPIB bus are unaddressed.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_gpib_send_IFC(
    /** Interface ID. */
    IDID id);

  /**
   * Send a GPIB command.
   *
   * This function asserts the ATN line and writes a block of data
   * to a GPIB interface.  The data bytes are interpreted as GPIB commands.
   *
   * @attention
   * The ATN line may stay asserted after @c gio_gpib_send_cmd() returns.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_gpib_send_cmd(
    /** Interface ID. */
    IDID id,
    /** Command(s) to be sent. */
    const void *pCommand,
    /** Length of command data. */
    size_t len);

  /**
   * Inquire GPIB bus status.
   *
   * The parameter @c request selects one of a number of state variables
   * of the GPIB interface.  @c gio_gpib_bus_status() returns
   * the corresponding value in @c *pResult.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_gpib_bus_status(
    /** Interface ID. */
    IDID id,
    /** Request type. */
    GIO_GPIB_STATUS_REQUEST request,
    /** OUT: Value. */
    uint8_t *pResult);

  /**
   * Control the ATN (attention) line on a GPIB interface.
   *
   * The ATN line on the GPIB interface represented by @c id is set
   * to the value @c enable (asserted when @c enable is true,
   * deasserted when false).
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_gpib_ATN_control(
    /** Interface ID. */
    IDID id,
    /** New status of ATN line. */
    bool_t enable);

  /**
   * Control the REN (remote enable) line on a GPIB interface.
   *
   * The REN line on the GPIB interface represented by @c id is set
   * to the value @c enable (asserted when @c enable is true,
   * deasserted when false).
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_gpib_REN_control(
    /** Interface or device ID. */
    IDID id,
    /** New status of REN line. */
    bool_t enable);

  /**
   * Place all devices on a GPIB interface into local lockout mode.
   *
   * This utility function just sends the "LLO" command to the GPIB interface.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_gpib_local_lockout(
    /** Interface ID. */
    IDID id);

  /**
   * @}
   * @defgroup rs232 Operations specific to RS-232 devices
   * @{
   */

  /**
   * Send BREAK signal on an RS-232 interface.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_rs232_break(
    /** Interface ID. */
    IDID id);

  /**
   * Control communication parameters of an RS-232 interface.
   *
   * The parameter @c request selects a particular feature of the RS-232
   * interface.  @c gio_rs232_control() changes the feature's value
   * to the one passed in @c setting.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_rs232_control(
    /** Interface ID. */
    IDID id,
    /** Feature to be modified. */
    GIO_RS232_REQUEST request,
    /** New setting of feature. */
    uint32_t setting);

  /**
   * Inquire status of an RS-232 interface.
   *
   * The parameter @c request selects one of a number of state variables
   * of the RS-232 interface.  @c gio_rs232_status() returns
   * the corresponding value in @c *pResult.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_rs232_status(
    /** Interface ID. */
    IDID id,
    /** Type of status report. */
    GIO_RS232_REQUEST request,
    /** OUT: Current state. */
    uint32_t *pResult);

  /**
   * Control modem control lines of an RS-232 interface.
   *
   * The parameter @c line selects a particular modem control line;
   * the selected line on the RS-232 interface represented by @c id is set
   * to the value @c enable (asserted when @c enable is @c TRUE,
   * deasserted when @c FALSE).
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_rs232_modem_control(
    /** Interface ID. */
    IDID id,
    /** Modem control line to be modified. */
    GIO_RS232_MODEM_CONTROL line,
    /** New status of line. */
    bool_t enable);

  /**
   * Inquire modem control line status of an RS-232 interface.
   *
   * The parameter @c line selects a particular modem control line
   * of the RS-232 interface represented by @c id.  The status of the
   * selected line is returned via @c *pStatus.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_rs232_modem_control_status(
    /** Interface ID. */
    IDID id,
    /** Modem control line to check. */
    GIO_RS232_MODEM_CONTROL line,
    /** OUT: Status of line. */
    bool_t *pStatus);

  /**
   * @}
   * @defgroup events Asynchronous events
   * @{
   */

  /**
   * Type of SRQ handler functions.
   *
   * An SRQ handler is called when an external instrument signals a request
   * for service.  The only argument is the IDID of the session for which
   * the client application registered an SRQ handler.
   *
   * Note that a single SRQ may cause more than one handler to be called,
   * because interface hardware may not be able to identify the source of
   * the SRQ; the handler then needs to check (for GPIB, e.g., using a serial
   * poll via gio_read_status_byte()) if it must handle the request.
   *
   * @attention
   * Concurrent SRQs on GPIB interfaces cannot be handled safely inside
   * the GIO layer; the GPIB SRQ line is level triggered.
   * A client application which needs to handle multiple simultaneous SRQs
   * must use additional effort to avoid "losing" service requests.
   */
  typedef void
  (*gio_SRQ_handler_t)(
    /** Interface or device ID. */
    IDID id);

  /**
   * Install an SRQ handler.
   *
   * This functions installs @c handler as the handler for service requests
   * which are reported to the session @c id.  If a zero @c handler is given,
   * SRQs are disabled for that session.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_set_SRQ_handler(
    /** Interface or device ID. */
    IDID id,
    /** New handler. */
    gio_SRQ_handler_t handler);
  
  /**
   * Globally suspend all asynchronous events.
   *
   * This function disables @e all interrupts and SRQs, until either
   * - a call to @c gio_resume_events(), or
   * - a call to @c gio_wait_event().
   *
   * If asynchronous events arrive during the period in which events
   * are disabled, they will be delivered after they are enabled again,
   * and in the correct order.
   *
   * Calls to @c gio_suspend_events() can be nested; events are re-enabled
   * only after a corresponding number of calls to @c gio_resume_events().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_suspend_events(void);
  
  /**
   * Globally resume asynchronous events.
   *
   * This function re-enables @e all interrupts and SRQs after a prior call
   * to @c gio_suspend_events().  Events which occur between suspension
   * and resumption will not be lost, but delivered in the correct order
   * after resumption.
   *
   * When @c gio_suspend_events() was called more than once, events are
   * re-enabled only after a corresponding number of calls to
   * @c gio_resume_events().  It is an error to call @c gio_resume_events()
   * while events are enabled.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_resume_events(void);

  /**
   * Wait for an asynchronous event to occur (and to be handled).
   *
   * @c gio_wait_event() waits for at least one asynchronous event
   * to arrive and be handled, temporarily enabling events if they are
   * currently disabled.  If no event occurs before the given timeout
   * has elapsed, @c gio_wait_event() returns @c GIO_ERR_IO_TIMEOUT.
   *
   * If @c milliSeconds is zero, the timeout is infinite.
   *
   * @attention
   * There is no guarantee that the operation will time out after @e exactly
   * @c milliSeconds milliseconds.  Scheduling delays and timer granularities
   * (which depend on the operating system and/or the system configuration)
   * affect the timeout calculation.  It is however guaranteed that the
   * timeout will occur after @e at @e least the given interval.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR   Event occurred within specified time interval.
   * @retval GIO_ERR_IO_TIMEOUT Time interval expired.
   * @retval other              An error occurred.
   */
  GIO_ERROR
  gio_wait_event(
    /** Timeout in ms. */
    uint32_t milliSeconds);

  /**
   * @}
   * @defgroup params Session parameters
   * @{
   */

  /**
   * Set termination character.
   *
   * If @c termChar is non-negative, it becomes the termination character
   * for the session @c id.  The termination character is used to signal the
   * end of data for @c gio_read().
   *
   * If @c termChar is -1, subsequent @c gio_read() operations will not
   * look for a termination character.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_set_termchr(
    /** Interface or device ID. */
    IDID id,
    /** New termination character. */
    int termChar);

  /**
   * Inquire current termination character.
   *
   * @c gio_get_termchr() returns the current termination character for
   * the session @c id in @c *pTermChar.  If no termination character is
   * currently defined, @c *pTermChar is set to -1.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_get_termchr(
    /** Interface or device ID. */
    IDID id,
    /** OUT: Termination character. */
    int *pTermChar);

  /**
   * Set timeout.
   *
   * @c gio_set_timeout() sets the I/O timeout for the session @c id
   * to @c milliSeconds.  After this call, operations which don't complete
   * within @c milliSeconds milliseconds will be aborted and will return
   * @c GIO_ERR_IO_TIMEOUT.
   *
   * If @c milliSeconds is zero, timeouts are disabled (i.e., the timeout
   * interval becomes infinite).
   *
   * @attention
   * There is no guarantee that any operation will time out after @e exactly
   * @c milliSeconds milliseconds.  Scheduling delays and timer granularities
   * (which depend on the operating system and/or the system configuration)
   * affect the timeout calculation.  It is however guaranteed that a timeout
   * will occur after @e at @e least the given interval.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_set_timeout(
    /** Interface or device ID. */
    IDID id,
    /** New timeout. */
    uint32_t milliSeconds);

  /**
   * Inquire current timeout.
   *
   * @c gio_get_timeout() returns the current timeout (in milliseconds)
   * for the session @c id in @c *pMilliSeconds.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_get_timeout(
    /** Interface or device ID. */
    IDID id,
    /** OUT: Timeout. */
    uint32_t *pMilliSeconds);

  /**
   * Set lock waiting flag.
   *
   * The state of the lock waiting flag affects the behavior of sessions
   * which have been locked using @c gio_lock().  When @c flag is true,
   * operations which encounter a locked session will wait for the lock
   * to be released (or for a timeout); when @c flag is false, these
   * operations will return an error (@c GIO_ERR_DEVICE_LOCKED) instead.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_set_lock_wait(
    /** Interface or device ID. */
    IDID id,
    /** Lock waiting flag. */
    bool_t flag);

  /**
   * Inquire current lock waiting flag.
   *
   * @c gio_get_lock_wait() returns the current state of the lock waiting
   * flag in @c *pFlag.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_get_lock_wait(
    /** Interface or device ID. */
    IDID id,
    /** OUT: Lock waiting flag. */
    bool_t *pFlag);

  /**
   * @}
   * @defgroup errors Error handling
   * @{
   */

  /**
   * Inquire error code of last GIO function called.
   *
   * If the last GIO function called encountered an error, @c gio_get_errno()
   * returns the corresponding error code.  If the function was completed
   * successfully, the return value of @c gio_get_errno() is undefined(!).
   *
   * @return GIO_ERROR
   */
  GIO_ERROR
  gio_get_errno(void);

  /**
   * Pretend that a given error occurred.
   *
   * This function can be used to simulate a GIO error, or to reset the
   * value returned by @c gio_get_errno().  If the @c flag is true, and if
   * an error handler has been defined, the handler is called.
   *
   * @return void
   */
  void
  gio_cause_error(
    /** Interface or device ID. */
    IDID id,
    /** Error code. */
    GIO_ERROR errorCode,
    /** Should handler be called? */
    bool_t flag);

  /**
   * Inquire human-readable description of a given error code.
   *
   * @attention
   * @c gio_get_error_str() needs an IDID argument to determine the
   * correct access method.
   *
   * @return const char *
   * @retval NULL  Invalid error code given.
   * @retval other String describing the error (in static memory).
   */
  const char *
  gio_get_error_str(
    /** Interface or device ID. */
    IDID id,
    /** Error code. */
    GIO_ERROR error);

  /**
   * Type of error handler functions.
   *
   * An error handler is called when a GIO function encounters an error.
   * The first argument to the handler is the IDID of the
   * session which was passed to the failing operation (if any); the second
   * argument is the error code.
   *
   * There is only a single, global error handler.
   *
   * If an error handler returns to its caller, the client application
   * will be notified of the error via a returned error code (which is
   * identical to @c error).
   *
   * @attention
   * The @c id may be zero in some situations (e.g., when @c gio_open()
   * or @c gio_resume_events() encounter errors).
   */
  typedef void
  (*gio_error_handler_t)(
    /** Interface or device ID. */
    IDID id,
    /** Error code. */
    GIO_ERROR error);

  /**
   * Install an error handler.
   *
   * This functions installs @c handler as the global error handler.
   * If a zero @c handler is given, the current handler will be deinstalled.
   *
   * @return gio_error_handler_t
   * @retval 0     No error handler was previously installed.
   * @retval other Previous error handler.
   */
  gio_error_handler_t
  gio_set_error_handler(
    /** New error handler. */
    gio_error_handler_t handler);

  /**
   * Predefined error handler; prints error message and continues.
   *
   * This error handler prints a message to the standard error stream,
   * but otherwise ignores errors.
   *
   * @return void
   */
  void
  GIO_ERROR_NO_EXIT(
    /** Interface or device ID. */
    IDID id,
    /** Error code. */
    GIO_ERROR error);

  /**
   * Predefined error handler; prints error message and exits program.
   *
   * This error handler prints a message to the standard error stream
   * and then terminates the client application.
   *
   * @return void
   */
  void
  GIO_ERROR_EXIT(
    /** Interface or device ID. */
    IDID id,
    /** Error code. */
    GIO_ERROR error);

  /**
   * @}
   * @defgroup format Formatted I/O
   * @{
   */

  /**
   * Send a formatted string to a device or interface.
   *
   * @attention
   * Unlike SICL, this function doesn't buffer I/O.  The caller must
   * pass a buffer which is large enough to hold the formatted string.
   * The format string will be interpreted according to the rules for
   * @c printf(3), not according to SICL's formatting rules.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_printf(
    /** Interface or device ID. */
    IDID id,
    /** Formatting buffer. */
    char *pBuffer,
    /** Size of buffer. */
    size_t bufferSize,
    /** @c printf(3) style format. */
    const char *pFormat,
    /** Variable arguments. */
    ...);

  /**
   * Receive a string from a device or interface and interpret it according
   * to the given format.
   *
   * @attention
   * Unlike SICL, this function doesn't buffer I/O.  The caller must
   * pass a buffer which is large enough to hold the formatted string.
   * The format string will be interpreted according to the rules for
   * @c scanf(3), not according to SICL's formatting rules.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  gio_scanf(
    /** Interface or device ID. */
    IDID id,
    /** Receive buffer. */
    char *pBuffer,
    /** Size of buffer. */
    size_t bufferSize,
    /** @c scanf(3) style format. */
    const char *pFormat,
    /** Variable arguments. */
    ...);

  /** @} */

  /**
   * Dummy function.
   *
   * This function does absolutely nothing.  It is completely, utterly
   * devoid of usefulness except for internal testing purposes.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   */
  GIO_ERROR
  gio_do_nothing(
    /** Interface or device ID. */
    IDID id);
  
#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* H8A8C6288_285D_4736_BACC_DD47C205CC04_ */
