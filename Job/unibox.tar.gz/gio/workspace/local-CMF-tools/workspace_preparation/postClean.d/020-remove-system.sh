#!/bin/sh
me=$(basename $0)
when=$1
what=$2
status=$3

echo "$me $when $what $status"

# we are only working if things went well so far
if [[ $status -ne 0 ]]
then
  echo "bad status already - doing nothing"
  exit 0
fi
# just completely remove the system directory
echo -- "rm -vrf $XOC_SYSTEM"
rm -vrf $XOC_SYSTEM
status=$?

exit $status