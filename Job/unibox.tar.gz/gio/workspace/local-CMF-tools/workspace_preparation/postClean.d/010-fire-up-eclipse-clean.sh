#!/bin/sh
me=$(basename $0)
when=$1
what=$2
status=$3

echo "$me $when $what $status"

# we are only working if things went well so far
if [[ $status -ne 0 ]]
then
  echo "bad status already - doing nothing"
  exit 0
fi
# in principle all we have to do is to 'cd' into the eclipse development
# directory and call 'ant'
# but in a file included into the ant build script an absolute path
# name is used.
# the path is actually the path to the eclipse base directory
# $WORKSPACE/eclipse-development
# but unlike in CCase this is not a fixed path anymore!
# so, I (horstp) pre-process this 'include file' using sed.
# There is a better way! I am just not aware of it...
# feel free to repair this template processing fuss!

#cd $WORKSPACE/eclipse-development
#sed "s:@WORKSPACE@:$WORKSPACE:" all_include.xml.template > all_include.xml && \
#ant clean
#status=$?

exit $status
