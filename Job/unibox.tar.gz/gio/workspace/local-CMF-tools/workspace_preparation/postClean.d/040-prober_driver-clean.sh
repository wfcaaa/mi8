#!/bin/sh
me=$(basename $0)
when=$1
what=$2
status=$3

echo "$me $when $what $status"

# we are only working if things went well so far
if [[ $status -ne 0 ]]
then
  echo "bad status already - doing nothing"
  exit 0
fi

# Clean the 93K Generic driver
driver_directory=$WORKSPACE/development/drivers/Generic_93K_Driver/GenericProber/
if [[ -d $driver_directory ]]
then
  cd $driver_directory
  make clobber 
  status=$?
fi

exit $status
