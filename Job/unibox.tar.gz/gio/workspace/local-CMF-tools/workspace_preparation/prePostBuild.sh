#!/bin/sh
#set -x
# this script is called by zenith_build before and after the 'real'
# build job.
# it is called with different names, supported names
# are preBuildWorkspace and postBuildWorkspace
#
# this script should only be called when the full workspace build
# is done. It will not do unrecoverable harm when called on other
# events but we want to be fast on focussed builds.

# try to make the script a bit safer to use
set -u
unalias -a

# the WORKSPACE has to be defined
if [[ -z ${WORKSPACE:-} ]]
then
echo "Error: $0: environment variable WORKSPACE not defined!"
exit 1
fi

# restrict the PATH to 'save' places
PATH="$WORKSPACE/local-CMF-tools/bin:$WORKSPACE/CMF-tools/bin:/bin:/usr/bin"

# depending on context we call all the scriptlets in one of four places:
# preBuild.d, postBuild.d, preClean.d and - guess! - postClean.d
# they are called
# in lexicographic order with 3 arguments <when> <what> <state>
# <when> is either 'pre' or 'post'
# <what> is either 'build' or 'clean'
# <state> is the max exit code of all scriptlets done so far
# (the 'when' and 'what' are redundant; this is done for the case
#  of the super-script handling all and symlinked into all places)
# the CWD is the workspace
cd $WORKSPACE
me=$(basename $0)
realMe=$(readlink -f $0)

# 'here' (the place where this command is) is also save
PATH=$(dirname $realMe):$PATH

scriptDirBase="local-CMF-tools/workspace_preparation"
if [[ $me == "preBuildWorkspace" ]]
then
  bdWhen=pre
elif [[ $me == "postBuildWorkspace" ]]
then
  bdWhen=post
else
  echo "Error: valid names for me are preBuildWorkspace and postBuildWorkspace but not $me"
  exit 1
fi
bdWhat=$1
bdStat=${2:-0}

# now we know the 'when' and the 'what' - we can determine where to look for
# stuff, we check for legal 'what' on the go...
if [[ $bdWhat == "build" ]]
then
  if [[ $bdWhen == "pre" ]]
  then
    scriptDirTail="preBuild.d"
  else
    scriptDirTail="postBuild.d"
  fi
elif [[ $bdWhat == "clean" ]]
then
  if [[ $bdWhen == "pre" ]]
  then
    scriptDirTail="preClean.d"
  else
    scriptDirTail="postClean.d"
  fi
else
  echo "Error: valid reasons are \"build\" and \"clean\" but not $bdWhat"
  exit 1
fi
scriptDir=$scriptDirBase/$scriptDirTail
if [[ -d $scriptDir ]]
then
  echo "$me: Start executing scripts in $scriptDir"
  for s in ./$scriptDir/*
  do
      echo "-----------------------------------------------------------------------"
      echo "calling $s $bdWhen $bdWhat $bdStat"
      $s $bdWhen $bdWhat $bdStat
      thisStat=$?
      [[ $thisStat -gt 0 ]] && echo -e "\nError: $s exits with $thisStat\n"
      [[ $thisStat -gt $bdStat ]] && bdStat=$thisStat
  done
  echo "-----------------------------------------------------------------------"
  echo "$me: End executing scripts in $scriptDir, overall result: $bdStat"
fi
exit $bdStat
