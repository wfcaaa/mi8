#!/bin/sh
me=$(basename $0)
when=$1
what=$2
status=$3

echo "$me $when $what $status"

# we are only working if things went well so far
if [[ $status -ne 0 ]]
then
  echo "bad status already - doing nothing"
  exit 0
fi
# before the build we have to make sure the system directory
# is updated from the template
sysDir=$WORKSPACE/system
sysTemplate=$WORKSPACE/template_system
# we use rsync to update the system directory
echo -- "rsync -vca $sysTemplate/ $sysDir"
rsync -vca $sysTemplate/ $sysDir
status=$?

exit $status
