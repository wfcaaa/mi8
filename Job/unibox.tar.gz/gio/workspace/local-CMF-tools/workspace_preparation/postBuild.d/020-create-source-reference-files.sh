#!/bin/sh
me=$(basename $0)
when=$1
what=$2
status=$3
exitCode=0
# after a successful build we call we create small files under
# system/etc/ that contain the reference information for this
# git repository and for the ST8 repository we import stuff from
# the reference information is the sha1 of HEAD of the repositories

function printInfo
{
  # $1 is the directory from where the git info is to extract
  (
  cd $1
  sha=$(git rev-parse HEAD)
  repo=$(git remote show -n origin | grep Fetch | sed -e 's/^.*\///' -e 's/\.git$//')
  # git status --porcelain produces an empty list when the sandbox is clean
  cod="DIRTY!"
  if [[ $(git status --porcelain | wc -l) -eq 0 ]]
  then
    cod="clean"
  else
    # write a big warning to stdout
    echo -e "\n\nWARNING! unclean repo $repo ($PWD)\n" >&2
    git status >&2
  fi
  echo "$repo: $sha ($cod)"
  )
}

if [[ $status -eq 0 ]]
then
  mkdir -p system/etc
  {
  echo "# Git repository: sha1 (status)"
  printInfo .
  } > system/etc/${XOC_PRODUCT_NAME}-code-ref.txt
fi
exit $exitCode
