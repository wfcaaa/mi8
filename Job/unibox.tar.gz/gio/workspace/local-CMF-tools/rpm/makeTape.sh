#!/bin/sh
unalias -a
PATH=/bin:/usr/bin

me=$(readlink -f $0)
here=$(dirname $me)
specFile=$here/gio.spec
buildTopDir=/tmp/${XOC_PRODUCT_NAME}RpmbuildTopdir
Z_sha=$(git rev-parse --short HEAD)

# make the build directory structure
err=0
for a in BUILD  RPMS  SOURCES  SPECS  SRPMS
do
  echo "mkdir -p $buildTopDir/$a"
  mkdir -p $buildTopDir/$a || err=1
done

if [[ $err -ne 0 ]]
then
  echo "making rpmbuild _topdir structure failed"
  exit 1
fi

# find out which redhat release we are running on (we put
# that information into the RPM version)
Z_rhel='none'
vstring="$(cat /etc/redhat-release)" 
[[ "$vstring" =~ 'release 5.' ]] && Z_rhel='el5'
[[ "$vstring" =~ 'release 6.' ]] && Z_rhel='el6'
[[ "$vstring" =~ 'release 7.' ]] && Z_rhel='el7'
[[ "$vstring" =~ 'release 8.' ]] && Z_rhel='el8'

if [[ $Z_rhel == 'none' ]]
then
  echo "unable to identify RHEL version"
  exit 1
fi

# the %install scriptlet needs to kow what to bundle up.
# it is stuff out of the system directory; from here that is
export Z_CODE_ROOT=$(readlink -f $here/../../system)

echo "rpmbuild -bb --define \"_topdir $buildTopDir\" --define \"Z_sha $Z_sha\" --define \"Z_rhel $z_rhel\"  $specFile"
rpmbuild -bb --define "_topdir $buildTopDir" --define "Z_sha $Z_sha" --define "Z_rhel $Z_rhel" $specFile

