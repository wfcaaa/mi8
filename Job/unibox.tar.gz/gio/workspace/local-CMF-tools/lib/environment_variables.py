'''
Created on Dec 11, 2013

@author: horstp
'''
from exceptions import KeyError
import os

class EnvironmentValuesMap(object):
    '''
    consolidate the many build variables here.
    main interface is the 'q' (like 'query') method
    it takes a key argument and returns the associated value
    an unknown key either returns 'None' or throws a KeyError exception -
    depending on how the user constructed the thing
    The key format for the EnvironmentValuesMap is
      <key>.<context>
    <key> is the name of the environment variable, e.g. XOC_LD_PATH
    <context> denotes if the variable has to be defined in the build
    environment, the run-time environment, both or none.
      <B> only in build environment
      <R> only in run time
      <X> in all environments.
      <M> meta-variable, not to be put into any environment
    the value is either a string or a list of strings. if it is a list it
    is assumed that it is a PATH like variable and the list is
    concatenated on ':'. 
    Meta variables are reported, dumped, checked... but never put
    into an environment. they can be queried though.
    This is useful for 'general switches'. An example is
    ENV_PREREQUISITES.M that holds a list of environment variables
    that need to be specified already when the value provider is
    called like WORKSPACE, XOC_SYSTEM, ENV_DEVTOOLS_ROOT...
    '''


    def __init__(self):
        """define the value lookup map for environment variables here
        """
        # we start with the meta variable listing the environment
        # variables that must already be there when the value provider
        # is called.
        # This variables may be used in the definition of others
        self.values = {
            '__ENV_PREREQUISITES.M':('WORKSPACE',
                                     'XOC_SYSTEM',
                                     'XOC_ADDRESS_WIDTH=64',
                                     'ENV_USE_SCM=GIT',
                                     ),
            'XOC_PRODUCT_NAME.X':'v93000_gio',
                       }
        # some shorthands, first the base for all the zenith* extra stuff
        # that is part of the platform bundle
        _rt = '/opt/hp93000rt/el7/x86_64'
        # the home of the UNO stuff
        _uno = _rt + '/ure_udk_23_14'
        # we need Java 7
        _java = '/usr/lib/jvm/java-1.7.0'
        
        self.values.update({
            'CLASSPATH.X': (
                _uno + '/ure/share/java/juh.jar',
                _uno + '/ure/share/java/jurt.jar',
                _uno + '/ure/share/java/ridl.jar',
                _uno + '/ure/share/java/unoloader.jar',
                _java + '/rt.jar') ,
            'JAVA_HOME.D': _java,
            'JAVA_DIR.R': _java,
            'JAVA_PATH.R': _java + '/bin'})
        # the LD_LIBRARY_PATH is a special beast; there is a rather big
        # common part and some smaller but important development/runtime
        # differences, especially workspace stuff must *never* be in the
        # runtime path!
        _ldpCommon = (
                _rt + '/ace-tao_6.2.4/ACE/lib64',
                _rt + '/imkl_3',
                _rt + '/libftd2xx_1.1.0/x86_64',
                _rt + '/libstdf_0.4/lib',
                _rt + '/log4cxx_0.9.7/lib',
                _rt + '/ruby_1.8.6/lib',
                _uno + '/sdk/linux/lib',
                _uno + '/ure/lib')
        _ldpDevelopment = (
                '${WORKSPACE}/development/lib',
                '${WORKSPACE}/development/import/lib' )
        _ldpRuntime = (
                '${XOC_SYSTEM}/lib', )
        self.values.update({
            'LD_LIBRARY_PATH.D': _ldpCommon +_ldpDevelopment,
            'EXTERNAL_LIBRARY_PATH.R': _ldpCommon +_ldpRuntime,
            # ATTN! PATH is a recursive definition, so PATH is actually
            # extended when the shell code coming from this is 'eval'-ed
            # since there is an 'ant' tool installed but we need a newer one
            # so, the 'ant' stuff must come *before* the ${PATH} thing!
            'PATH.D': (
                '${PATH}',
                _rt + '/ruby_1.8.6/bin',
                _uno + '/sdk/linux/bin',
                _uno + '/ure/bin',
                _java + '/bin',
                '${WORKSPACE}/CMF-tools/bin'),
            # at run time we do care about ant and there is is no workspace
            # but there is the XOC_SYSTEM!
            'PATH.R': (
                '${XOC_SYSTEM}/bin',
                '${PATH}',
                _uno + '/sdk/linux/bin',
                _uno + '/ure/bin',
                _java + '/bin'),
            'UNO_JAVA_JFW_JREHOME.X':'file://' + _java + '/jre',
            'XOC_ACE_DIR.X':_rt + '/ace-tao_6.2.4/ACE',
            'XOC_ADDRESS_WIDTH.D':'64',
            'XOC_ASSERT_BEHAVIOR.X':'ABORT',
            'XOC_COMPILE_FLAG_32BIT.D':'',
            'XOC_COMPILE_FLAG_BIT.D':'-m64',
            'XOC_JAVA_HOME.X': _java,
            'XOC_OS_NAME.D':'linux',
            'XOC_OS_VERSION.D':'RHEL7',
            'XOC_RUBY_DIR.D':_rt + '/ruby_1.8.6',
            'XOC_UNO_JAVA_DIR.X':_uno + '/ure/share/java',
            'XOC_UNO_REGISTRY_DIR.X':_uno + '/ure/share/misc',
            'XOC_UNO_RE_BIN_DIR.X':_uno + '/ure/bin',
            'XOC_UNO_RE_DIR.X':_uno + '/ure',
            'XOC_UNO_RE_LIB_DIR.X':_uno + '/ure/lib',
            'XOC_UNO_SDK_BIN_DIR.X':_uno + '/sdk/linux/bin',
            'XOC_UNO_SDK_DIR.X':_uno + '/sdk',
            'XOC_UNO_SDK_LIB_DIR.X':_uno + '/sdk/linux/lib',
            })

    def getMap(self): return self.values

    def dump(self):
        '''
        return a list of strings with all key/val pairs from self.values
        '''
        thedump = []
        for x in self.values:
            thedump.append('%s - %s' % (x, self.values[x]))
        return thedump



if __name__ == '__main__':
    myValues = EnvironmentValuesMap()
    print '#key.scope.strength - value'
    print '\n'.join(sorted(myValues.dump()))

