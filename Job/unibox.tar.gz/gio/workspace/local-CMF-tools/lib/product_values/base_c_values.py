'''
Created on Jan 15, 2014

@author: horstp

this module provides the build variables for base C as dictionary

the keys all have the format
<key>.<context>.<strength>
<key> is the name of the build variable, e.g. CXXFLAGS
<context> is the build environment to add the key to, e.g. baseC
<strength> denotes if the keys value should:
  <D> set as default (only added if not there already)
  <A> appended to a pre-existing list
  <R> replace an existing entry
this maps to the scons methods env.Default, env.Append and env.Replace

the only public function is base_c_values which returns the map
'''

import os

# we need some environment variables for the base C stuff
_workspace = os.environ["WORKSPACE"]

def base_c_values(): return _v

# and now the big value map  
_v = {\
    # baseC is - surprise - the 'common stock' for all c-type stuff
    'LDFLAGS_XERCES.baseC.D': '-lxerces-c',
    # some xerces header files do careless int / uint compares - at least in 32 bit...
    'CXXFLAGS_XERCES.baseC.D': '-Wno-sign-compare',

    # We always link the SW with the 'tcmalloc' library (because the
    # GNU C library implementation of malloc can cause severe problems
    # due to memory fragmentation in multithreaded programs).  For the
    # 32-bit version, where 'tcmalloc' causes noticeable performance
    # degradation, the 'tcmalloc' library is normally disabled at
    # runtime by an entry in the LD_LIBRARY_PATH variable.  Customers
    # who run into the memory fragmentation issue can re-enable it,
    # but will incur the performance penalty.
    #
    # The '-Wl,--enable-new-dtags' is needed to allow the runtime switch
    # using LD_LIBRARY_PATH; it makes LD_LIBRARY_PATH take precedence over
    # the setting in RPATH.
    'PERFTOOL_HOME.baseC.D': '$XOC_RUNTIME_ROOT/gperftools_2.1',
    'LDFLAGS_PERFTOOLS.baseC.D': '-L$PERFTOOL_HOME/lib -ltcmalloc_minimal -Wl,--enable-new-dtags',


    'LOG4CXX_DIR.baseC.D': '$XOC_RUNTIME_ROOT/log4cxx_0.9.7',
    'LDFLAGS_SYSTEM_LOGGER.baseC.D': '-L$LOG4CXX_DIR/lib -llog4cxx',
    'CXXFLAGS_SYSTEM_LOGGER.baseC.D': '-I$LOG4CXX_DIR/include',

    'FTD2XX_DIR.baseC.D': '$XOC_RUNTIME_ROOT/libftd2xx_1.1.0',
    'LDFLAGS_FTD2XX.baseC.D': '-L$FTD2XX_DIR/x86_64 -lftd2xx',
    'INCLUDE_PATH_FTD2XX.baseC.D': '$FTD2XX_DIR',
    'CXXFLAGS_FTD2XX.baseC.D': '-I$FTD2XX_DIR',

    'LDFLAGS_ZRUBY.baseC.D': '-L$XOC_RUBY_DIR/lib -lzruby',
    'CXXFLAGS_ZRUBY.baseC.D': '-I$XOC_RUBY_DIR/lib/ruby/1.8/x86_64-linux',

    'LDFLAGS_ACE.baseC.D': '-L$XOC_ACE_DIR/lib64 -lACE',
    'CXXFLAGS_ACE.baseC.D': '-I$XOC_ACE_DIR/include',

    'STDF_HOME.baseC.D': '$XOC_RUNTIME_ROOT/libstdf_0.4',
    'LDFLAGS_STDF.baseC.D': '-L$STDF_HOME/lib -lstdf',
    'INCLUDE_PATH_STDF.baseC.D': '$STDF_HOME/include',
    'CXXFLAGS_STDF.baseC.D': '-I$INCLUDE_PATH_STDF',

    'LDFLAGS_OPENCV.baseC.D': (
                               '-lopencv_core',
                               '-lopencv_features2d'
                              ),

    'UNO_SDK_LIB_DIR.baseC.D': '$XOC_UNO_SDK_ROOT/linux/lib',
    'LDFLAGS_UNO.baseC.D': '-L$UNO_SDK_LIB_DIR -luno_cppuhelpergcc3',

    # this is for the UnoRuby stuff
    #'RUBY_INCLUDE_DIR.baseC.D': '$XOC_RUBY_DIR/lib/ruby/1.8/x86_64-linux',
    #'RUBY_LDFLAGS.baseC.D': '-L$XOC_RUBY_DIR/lib -Wl,-rpath,$XOC_RUBY_DIR/lib',


    # here is the set of compiler / linker options we put on every c-type
    # thing

    # the cpppath variable is used to tell the include file parser where
    # to look for #include files. it also implies that the directory is passed
    # to the compiler as -I option.
    # so, why there are -I options in the cxxflags? because scanning files takes
    # time. the assumption is that the include files in the other directories
    # change very rarely.
    'CPPPATH.baseC.A': [
        #'$SYSDIR/include' ,
        '$DEVDIR/include' ,
        '$XOC_VRA_DIR/include',
        '$WORKSPACE' ,
        #'$XOC_EMBEDDED_PUBLIC_BASE_DIR/include'
        ],

    'CXXFLAGS.baseC.A': [
        '-m$XOC_ADDRESS_WIDTH',
        '-I$XOC_UNO_SDK_DIR/include/stl', 
        '-I$XOC_ACE_DIR/include', 
        '-I$XOC_UNO_SDK_DIR/include', 
        '-I$LOG4CXX_DIR/include',
        '-I$XOC_JAVA_HOME/include', 
        '-I$XOC_JAVA_HOME/include/linux',
        '-fmessage-length=0',
        '-D_LARGEFILE64_SOURCE', 
        '-D_FILE_OFFSET_BITS=64', 
        '-DUNX', 
        '-DGCC', 
        '-DLINUX', 
        '-DCPPU_ENV=gcc3', 
        #'-DGXX_INCLUDE_PATH=/usr/include/c++/4.1.2',
        #'-DBUILD_MODE_IMAGE', 
        # the following is probably a typo-error of the two lines above
        '-DGXX_INCLUDE_PATH=/usr/include/c++/4.8.2 -DBUILD_MODE_IMAGE',
        '-DOS_LINUX',
        '-Wall', 
        '-Wno-non-virtual-dtor', 
        '-Wno-missing-braces', 
        '-pedantic', 
        '-Wsign-promo', 
        '-Wno-long-long', 
        # PSL_TODO: Task PSL-55:
        # On gcc-4.8.0 runtime environment, -Werror flag has been disabled to avoid the
        # compilation failure due to warnings related to third-party RPM header files.
        '-Werror', 
        '-fno-strict-aliasing',
        #'-Wno-variadic-macros',
        #gcc48 '-Wno-address',
        ],

    'LINKFLAGS.baseC.A': [
        '-m$XOC_ADDRESS_WIDTH',
        '-Wl,-fatal-warnings',
        # PSL_TODO: Task PSL-55:
        # Uncomment following line only while compiling Zenith part using gcc-4.8.0
        # Uncommenting this line for Zenith standard platform results into
        # compilation error as '-Wl,--copy-dt-needed-entries' is not supported by
        # ld which comes with gcc-4.1.2
        #gcc48 '-Wl,--copy-dt-needed-entries'
        ],
    }
        
  
            
