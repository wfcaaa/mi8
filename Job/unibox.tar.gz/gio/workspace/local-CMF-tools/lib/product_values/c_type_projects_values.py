'''
Created on Jan 22, 2014

@author: horstp

this module provides the build variables for c-type build projects

the keys all have the format
<key>.<context>.<strength>
<key> is the name of the build variable, e.g. CXXFLAGS
<context> is the build environment to add the key to, e.g. baseC
<strength> denotes if the keys value should:
  <D> set as default (only added if not there already)
  <A> appended to a pre-existing list
  <R> replace an existing entry
this maps to the scons methods env.Default, env.Append and env.Replace

the only public function is c_type_projects_values which returns the map
'''

def c_type_projects_values():
    theMap = {}
    theMap.update(_c_program)
    theMap.update(_cpp_component_exe)
    theMap.update(_cpp_component)
    theMap.update(_cpp_component_test)
    theMap.update(_utility_library)
    theMap.update(_shared_library)
    return theMap

# type c_program should not need anything special
# the RUN_DEST might be a bin directory
_c_program = {\
    'DEST.c_program.R': '$DEVDIR/bin',
    'RUN_DEST.c_program.R': '$SYSDIR/bin'
    }

# type cpp_component_exe should be comparable to components
# but we need a bunch of 'rpath' entries to make the linker happy
# executables are in 'bin' directories, of course
_cpp_component_exe = {\
    'LINKFLAGS.cpp_component_exe.A': [
        '-Wl,--export-dynamic',
        '-L$DEVDIR/lib',
        '-Wl,-rpath-link,$DEVDIR/lib',
        '-L$DEVDIR/import/lib',
        '-Wl,-rpath-link,$DEVDIR/import/lib',
        #'-L$XOC_VRA_DIR/lib',
        #'-Wl,-rpath-link,$XOC_VRA_DIR/lib',
        '-L$XOC_ACE_DIR/lib64',
        '-Wl,-rpath,$XOC_ACE_DIR/lib64',
        '-L$XOC_UNO_SDK_ROOT/linux/lib',
        '-Wl,-rpath,$XOC_UNO_SDK_ROOT/linux/lib',
        '-L$XOC_UNO_URE_ROOT/lib',
        '-Wl,-rpath,$XOC_UNO_URE_ROOT/lib',
        '-L$XOC_RUNTIME_ROOT/ruby_1.8.6/lib',
        '-Wl,-rpath,$XOC_RUNTIME_ROOT/ruby_1.8.6/lib',
        '-L$XOC_RUNTIME_ROOT/log4cxx_0.9.7/lib',
        '-Wl,-rpath,$XOC_RUNTIME_ROOT/log4cxx_0.9.7/lib',
        '-L$XOC_RUNTIME_ROOT/libstdf_0.4/lib',
        '-Wl,-rpath,$XOC_RUNTIME_ROOT/libstdf_0.4/lib',
        '-L$PERFTOOL_HOME/lib',
        '-Wl,-rpath,$PERFTOOL_HOME/lib',
        #'-lservices_zcoco',
        '-lservices_zcntxt',
        '-lACE',
        '-lthreads',
        '-luno_cppuhelpergcc3',
        '-luno_cppu',
        '-luno_sal',
        '-lsalcpprt',
        ],
    
    'DEST.cpp_component_exe.R': '$DEVDIR/bin',
    'RUN_DEST.cpp_component_exe.R': '$SYSDIR/bin'
    }

# project type cpp_component
# only addition to plainC is some linker option stuff
_cpp_component = {\
    'LINKFLAGS.cpp_component.A': [
        '-L$DEVDIR/lib',
        '-L$DEVDIR/import/lib',
        '-L$XOC_VRA_DIR/lib',
        #'-lservices_zcoco'
        '-lservices_zcntxt'
        ],
    'DEST.cpp_component.R': '..',
    'RUN_DEST.cpp_component.R': '$SYSDIR/complib'
    }
    
# project type cpp_component_test
# typically identical to cpp_component
_cpp_component_test = {\
    'LINKFLAGS.cpp_component_test.A': [
        '-L$DEVDIR/lib',
        '-L$DEVDIR/import/lib',
        #'-lservices_zcoco'
        '-lservices_zcntxt'
        ],
    'DEST.cpp_component_test.R': '..',
    'RUN_DEST.cpp_component_test.R': ''
    }
    
# utility_library is made very alike the components
_utility_library = {\
    'LINKFLAGS.utility_library.A': '-L$DEVDIR/lib',
    'DEST.utility_library.R': '$DEVDIR/lib',
    'RUN_DEST.utility_library.R': '$SYSDIR/lib'
    }
    
# project type shared library
_shared_library = {\
    'LINKFLAGS.shared_library.A':'-L$DEVDIR/lib',
    'DEST.shared_library.R': '$DEVDIR/lib',
    'RUN_DEST.shared_library.R': '$SYSDIR/lib'
    }
    
