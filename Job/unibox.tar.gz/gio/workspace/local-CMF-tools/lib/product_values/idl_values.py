'''
Created on Jan 16, 2014

@author: horstp

this module provides the build variables for project type idl as dictionary

the keys all have the format
<key>.<context>.<strength>
<key> is the name of the build variable, e.g. CXXFLAGS
<context> is the build environment to add the key to, e.g. baseC
<strength> denotes if the keys value should:
  <D> set as default (only added if not there already)
  <A> appended to a pre-existing list
  <R> replace an existing entry
this maps to the scons methods env.Default, env.Append and env.Replace

the only public function is idl_values which returns the map
'''

def idl_values(): return _v

# and now the big value map  
_v = {\
    #
    # IDL
    #
    
    # the IDL stuff needs not much variables 
    
    'SDK_IDL_DIR.idl.R': '$XOC_UNO_SDK_ROOT/idl',
    'ZENITH_IDL_DIR.idl.R': '$DEVDIR/idl',
    'DEST.idl.R': '',
    'RUN_DEST.idl.R': '$SYSDIR/idl'
    }
