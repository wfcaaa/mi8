'''
Created on Jan 16, 2014

@author: horstp

this module provides the build variables for project type java as dictionary

the keys all have the format
<key>.<context>.<strength>
<key> is the name of the build variable, e.g. CXXFLAGS
<context> is the build environment to add the key to, e.g. baseC
<strength> denotes if the keys value should:
  <D> set as default (only added if not there already)
  <A> appended to a pre-existing list
  <R> replace an existing entry
this maps to the scons methods env.Default, env.Append and env.Replace

the only public function is java_values which returns the map
'''
import os

# this is a bit special because we provide values for 3 contexts here.
# all parameters are the same exept, possibly, the RUN_DEST

def java_values(): 
    v = {}
    # we need the Linux level CLASSPATH
    _classpath = os.environ.get('CLASSPATH', '')
    for scope in ('java_component_exe','java_component_package','java_component_utility'):
        v['JAVAVERSION.'+scope+'.R'] = '1.6'
        v['JAVACLASSPATH.'+scope+'.A'] = _classpath + ':/usr/share/java/log4j.jar'
        #v['JAVACFLAGS.'+scope+'.A'] = ['-g','-source', '1.7','-target', '1.7']
        v['DEST.'+scope+'.R'] = '..'
    v['RUN_DEST.java_component_exe.R'] = '$WORKSPACE/system/bin'
    v['RUN_DEST.java_component_package.R'] = '$WORKSPACE/system/complib'
    v['RUN_DEST.java_component_utility.R'] = '$WORKSPACE/system/lib'
    return v

