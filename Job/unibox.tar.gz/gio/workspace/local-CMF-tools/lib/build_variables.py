'''
Created on Dec 11, 2013

@author: horstp
'''
from exceptions import KeyError
import os

# the values for the various build environments are stored in
# several modules to improve maintainability
from product_values.base_c_values import base_c_values
from product_values.c_type_projects_values import c_type_projects_values
from product_values.idl_values import idl_values
from product_values.java_values import java_values

class BuildValuesMap(object):
    '''
    consolidate the many build variables here.
    main interface is the 'q' (like 'query') method
    it takes a key argument and returns the associated value
    keys in the singular form return a string, keys in plural form
    return a list of strings.
    an unknown key either returns 'None' or throws a KeyError exception -
    depending on how the user constructed the thing
    the keys all have the format
    <key>.<context>.<strength>
    <key> is the name of the build variable, e.g. CXXFLAGS
    <context> is the build environment to add the key to, e.g. baseC
    <strength> denotes if the keys value should:
      <D> set as default (only added if not there already)
      <A> appended to a pre-existing list
      <R> replace an existing entry
    this maps to the scons methods env.Default, env.Append and env.Replace
    '''


    def __init__(self, strict=False):
        '''
        define the value lookup map here and remember how an
        unknown key should be handled
        '''
        self.strict = strict
        # Getting environment variables.
        # These varialbes will be used while setting the compiler options
        self.workspace = os.environ["WORKSPACE"]
        self.bitwidth = os.environ["XOC_ADDRESS_WIDTH"]
        self.values = {\
            'SYSDIR.plainBase.D':'$WORKSPACE/system',
            # for classic ST8 the development directory is the workspace
            'DEVDIR.plainBase.D':'$WORKSPACE/development',
            # default destination is the parent of 'Main', the
            # runtime destination is not used for classic ST8
            'DEST.plainBase.D': '..',
            'RUN_DEST.plainBase.D': ''}
        # the platform extensions are partly environment dependent
        self.values['XOC_RUNTIME_ROOT.plainBase.D'] = '/opt/hp93000rt/el7/x86_64'
        # the rest is pretty straightforward
        self.values.update({\
            'XOC_UNO_SDK_ROOT.plainBase.D':'$XOC_RUNTIME_ROOT/ure_udk_23_14/sdk',
            'XOC_UNO_URE_ROOT.plainBase.D':'$XOC_RUNTIME_ROOT/ure_udk_23_14/ure',
            })
        # the whole system should (to say it mildly) be based on the
        # same UNO type registries
        self.values.update({\
            'ZENITH_REGISTRY.plainBase.R': '$DEVDIR/IDL/uno_types.rdb',
            'UNO_REGISTRY.plainBase.R': '$XOC_UNO_REGISTRY_DIR/types.rdb',
            })
        
        # general 'mode' switches.
        # we need configuration tar files
        self.values['CREATE_CONFIGURATION_ARCHIVE.plainBase.D'] = 'True'
        # we generate local IDL class interfaces, by default
        self.values['CREATE_IDL_INTERFACE_CLASSES.plainBase.D'] = 'True'
        
        # the project type specific values
        # baseC is - surprise - the 'common stock' for all c-type stuff
        self.values.update(base_c_values())
        self.values.update(c_type_projects_values())
        self.values.update(idl_values())
        self.values.update(java_values())
        
    def getMap(self): return self.values
    
    def dump(self):
        '''
        return a list of strings with all key/val pairs from self.values
        '''
        thedump = []
        for x in self.values:
            thedump.append('%s - %s' % (x, self.values[x]))
        return thedump
    
                
        
if __name__ == '__main__':
    myValues = BuildVariables()
    print '#key.scope.strength - value'
    print '\n'.join(sorted(myValues.dump()))
            
