/* -*-C++-*- */
/**
 * Simple test program, similar to iread(1).
 ******************************************************************************
 * (C) Copyright 2014 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   GioRead.cpp
 * @author Jens Kilian
 * @date   Created:  Wed Feb  5 08:56:48 2014
 * @date   Modified: Fri Jan 15 11:37:44 2016 (Jens Kilian)
 ******************************************************************************
 */

#include <algorithm>
#include <iostream>
#include <unistd.h>

using namespace ::std;

#include "xoc/hw/cor/gio/gio.h"

namespace
{
  /** Maximum size of chunks to read. */
  const long BUFFER_SIZE = 1024 * 1024;

  /**
   * Print usage message.
   *
   * @param  pProgName Name of executable.
   */
  void
  usage(const char *pProgName)
  {
    cerr << "Usage: " << pProgName << " [-c count] [-t <timeout>] <interface>\n\n"
         << "       <count>      Number of characters to read.\n"
         << "       <timeout>    I/O timeout in milliseconds.\n"
         << "       <interface>  Name of GIO interface, e.g. 'vxi11/192.168.0.100/gpib0,9'.\n"
         << endl;
  }
}

/**
 * Main program.
 *
 * @param  argc  Number of command-line arguments.
 * @param  argv  Command-line argument strings.
 *
 * @return int Exit status.
 */
int
main(int argc, char **argv)
{
  // Check and decode command-line arguments.

  const char *const pProgName = argv[0];
  int opt;
  long count = -1;
  long timeout = -1;

  while ((opt = getopt(argc, argv, "c:t:")) != -1) {
    switch (opt) {

    case 'c':
      count = strtol(optarg, NULL, 10);
      break;

    case 't':
      timeout = strtol(optarg, NULL, 10);
      break;

    default:
      usage(pProgName);
      return 1;
    }
  }

  if (argc <= optind) {
    usage(pProgName);
    return 1;
  }

  const char *const pInterface = argv[optind];

  // Errors will be considered fatal.
  
  gio_set_error_handler(GIO_ERROR_EXIT);

  // Send input from the GIO interface to cout.

  IDID idid = gio_open(pInterface);
  if (timeout > 0) {
    gio_set_timeout(idid, timeout);
  }

  char buffer[BUFFER_SIZE];
  while (count != 0) {
    size_t len = (count > 0)
      ? min(count, BUFFER_SIZE)
      : BUFFER_SIZE;
    gio_read(idid, buffer, len, NULL, &len);
    cout.write(buffer, len);

    if (count > 0) {
      count -= len;
    }
  }

  gio_close(idid);

  return 0;
}
