/* -*-C++-*- */
/**
 * Monitor and trace activity on an RS-232 port.
 ******************************************************************************
 * (C) Copyright 2014 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   Rs232Monitor.cpp
 * @author Jens Kilian
 * @date   Created:  Thu Mar 27 11:23:06 2014
 * @date   Modified: Mon Mar 31 09:48:04 2014 (Jens Kilian)
 ******************************************************************************
 */

/*
 * System includes.
 * ----------------------------------------------------------------------------
 */

#include <algorithm>
#include <curses.h>
#include <poll.h>
#include <signal.h>
#include <string>
#include <sys/time.h>
#include <unistd.h>
#include <vector>

using namespace ::std;

/*
 * Module includes.
 * ----------------------------------------------------------------------------
 */

#include "xoc/hw/cor/gio/gio.h"

namespace
{
  /** Refresh interval [us]. */
  const long REFRESH_uSECS = 1000 * 1000;

  /** The GIO interface. */
  IDID idid;

  /** If true, received data will be echoed back. */
  bool echoData = false;

  /**
   * Print usage message.
   *
   * @param pProgName Name of executable.
   */
  void
  usage(const char *pProgName)
  {
    fprintf(stderr,
            "Usage: %s [-e] <interface>\n\n"
            "       -e           Echo received data.\n"
            "       <interface>  Name of GIO RS-232 interface, e.g.,\n"
            "                    'rs232/dev/usb/ttyUSB0'\n\n",
            pProgName);
  }

  /** Clean up. */
  void
  cleanup(int)
  {
    endwin();

    if (idid) {
      gio_close(idid);
      idid = 0;
    }

    exit(0);
  }

  /**
   * Handle GIO errors.
   *
   * @param id GIO session.
   * @param err  Error code.
   */
  void
  errorHandler(IDID id, GIO_ERROR err)
  {
    endwin();

    fprintf(stderr, "%s\n", gio_get_error_str(id, err));

    if (idid) {
      gio_close(idid);
      idid = 0;
    }

    exit(1);
  }

  /**
   * Convert byte width to a symbolic character.
   *
   * @param width Width of transferred bytes.
   */
  char
  widthToChar(uint32_t width)
  {
    if (width < 5 || width > 8) {
      return '?';
    }
    return (char)(width + '0');
  }

  /**
   * Convert parity setting to a symbolic character.
   *
   * @param parity Parity option.
   */
  char
  parityToChar(uint32_t parity)
  {
    switch (parity) {

    case GIO_RS232_PARITY_NONE:
      return 'N';

    case GIO_RS232_PARITY_EVEN:
      return 'E';

    case GIO_RS232_PARITY_ODD:
      return 'O';

    case GIO_RS232_PARITY_MARK:
      return 'M';

    case GIO_RS232_PARITY_SPACE:
      return 'S';
    }

    return '?';
  }

  /**
   * Convert number of stop bits to a symbolic character.
   *
   * @param stopBits Number of stop bits.
   */
  char
  stopBitsToChar(uint32_t stopBits)
  {
    if (stopBits < 1 || stopBits > 2) {
      return '?';
    }
    return (char)(stopBits + '0');
  }
}

/**
 * Main program.
 *
 * @param  argc  Number of command-line arguments.
 * @param  argv  Command-line argument strings.
 *
 * @return int Exit status.
 */
int
main(int argc, char **argv)
{
  // Check and decode command-line arguments.
  
  const char *const pProgName = argv[0];
  int opt;

  while ((opt = getopt(argc, argv, "e")) != -1) {
    switch (opt) {

    case 'e':
      echoData = true;
      break;

    default:
      usage(pProgName);
      return 1;
    }
  }

  if (argc <= optind) {
    usage(pProgName);
    return 1;
  }

  const char *const pInterface = argv[optind];

  // Open the interface and initialize the screen.
  gio_set_error_handler(GIO_ERROR_EXIT);
  idid = gio_open(pInterface);

  initscr();
  signal(SIGINT, cleanup);
  gio_set_error_handler(errorHandler);

  cbreak();
  noecho();
  timeout(0);

  WINDOW *errors = newwin(4,       COLS, 0, 0);
  WINDOW *status = newwin(1,       COLS, 4, 0);
  WINDOW *msglog = newwin(LINES-5, COLS, 5, 0);

  mvwaddstr(errors, 0, 0, "Overrun errors detected: 0");
  mvwaddstr(errors, 1, 0, "Parity errors detected:  0");
  mvwaddstr(errors, 2, 0, "Framing errors detected: 0");
  mvwaddstr(errors, 3, 0, "Breaks detected:         0");

  mvwaddstr(errors, 0, COLS-16, "(r) toggle RTS");
  mvwaddstr(errors, 1, COLS-16, "(d) toggle DTR");
  mvwaddstr(errors, 2, COLS-16, "(e) toggle echo");
  mvwaddstr(errors, 3, COLS-16, "(q) quit");

  wattron(status, A_REVERSE);
  mvwaddstr(status, 0, 0, string(COLS, ' ').c_str());

  idlok(msglog, true);
  scrollok(msglog, true);
  wmove(msglog, 0, 0);

  // Main loop; never exits.
  struct timeval lastUpdate;
  gettimeofday(&lastUpdate, 0);

  int overruns = 0;
  int parityErrors = 0;
  int framingErrors = 0;
  int breaks = 0;
  bool_t rts = false;
  bool_t dtr = false;

  while (true) {
    // Handle input.
    switch (getch()) {

    case 'r':
      gio_rs232_modem_control(idid, GIO_RS232_MODEM_CONTROL_RTS, !rts);
      break;

    case 'd':
      gio_rs232_modem_control(idid, GIO_RS232_MODEM_CONTROL_DTR, !dtr);
      break;

    case 'e':
      echoData = !echoData;
      break;

    case 'q':
      cleanup(0);
      break;

    case ERR:
      break;

    default:
      beep();
      break;
    }

    // Check for errors.  Note that the numbers may be inaccurate, since GIO
    // (like SICL) only delivers an indication that errors have occurred,
    // not a precise count.
    uint32_t flags;
    gio_rs232_status(idid, GIO_RS232_STATUS, &flags);

    if (flags & GIO_RS232_STATUS_OVERFLOW) {
      mvwprintw(errors, 0, 25, "%d", ++overruns);
    }
    if (flags & GIO_RS232_STATUS_PARERR) {
      mvwprintw(errors, 1, 25, "%d", ++parityErrors);
    }
    if (flags & GIO_RS232_STATUS_FRAMING) {
      mvwprintw(errors, 2, 25, "%d", ++framingErrors);
    }
    if (flags & GIO_RS232_STATUS_BREAK) {
      mvwprintw(errors, 3, 25, "%d", ++breaks);
    }

    // Check modem configuration and status.
    uint32_t baud, width, parity, stopBits, modemStatus;
    gio_rs232_status(idid, GIO_RS232_BAUD, &baud);
    gio_rs232_status(idid, GIO_RS232_WIDTH, &width);
    gio_rs232_status(idid, GIO_RS232_PARITY, &parity);
    gio_rs232_status(idid, GIO_RS232_STOP_BITS, &stopBits);
    gio_rs232_status(idid, GIO_RS232_MODEM_STATUS, &modemStatus);

    gio_rs232_modem_control_status(idid, GIO_RS232_MODEM_CONTROL_RTS, &rts);
    gio_rs232_modem_control_status(idid, GIO_RS232_MODEM_CONTROL_DTR, &dtr);

    mvwprintw(status,
              0, 0,
              "%10d Baud  %c%c%c  %s %s %s %s  %s %s  %*s",
              baud,
              widthToChar(width),
              parityToChar(parity),
              stopBitsToChar(stopBits),
              (modemStatus & GIO_RS232_MODEM_STATUS_DCD) ? "DCD" : "___",
              (modemStatus & GIO_RS232_MODEM_STATUS_DSR) ? "DSR" : "___",
              (modemStatus & GIO_RS232_MODEM_STATUS_CTS) ? "CTS" : "___",
              (modemStatus & GIO_RS232_MODEM_STATUS_RI)  ? "RI"  : "__",
              rts ? "RTS" : "___",
              dtr ? "DTR" : "___",
              max(4, COLS-48),
              echoData ? "ECHO" : "____");

    // Receive, log and (optionally) echo data.
    for (int lines = 0; (flags & GIO_RS232_STATUS_DAV) && lines < LINES;) {
      uint32_t nBytes;
      gio_rs232_status(idid, GIO_RS232_READ_DAV, &nBytes);

      vector<char> buffer(nBytes);
      int reasons;
      size_t nRead;
      gio_read(idid, &buffer[0], nBytes, &reasons, &nRead);
      
      waddnstr(msglog, &buffer[0], nRead);

      if (echoData) {
        gio_write(idid, &buffer[0], nRead, false, NULL);
      }

      gio_rs232_status(idid, GIO_RS232_STATUS, &flags);
      if (reasons & GIO_REASON_CHR) {
        ++lines;
      }
    }

    // Refresh screen.
    wnoutrefresh(errors);
    wnoutrefresh(status);
    wnoutrefresh(msglog);
    doupdate();

    // Avoid burning CPU time.
    struct timeval now;
    gettimeofday(&now, 0);

    long delay = (now.tv_sec * 1000 * 1000 + now.tv_usec)
      -   (lastUpdate.tv_sec * 1000 * 1000 + lastUpdate.tv_usec);

    if (delay < REFRESH_uSECS) {
      // Wait for timeout or until new input is available.
      struct pollfd fd = { 0, POLLIN, 0 };
      (void)poll(&fd, 1, (REFRESH_uSECS - delay + 500) / 1000);
    }

    gettimeofday(&lastUpdate, 0);
  }

  return 0; // keep compiler happy
}
