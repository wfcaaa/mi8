# Builds rs232_monitor C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
    'PROJECT_TYPE' : ['c_program'],
    'NAME' : ['rs232_monitor'],
    'DEST' : ['../..'],
    'CXXFLAGS_LOCAL' : ['--std=c++11'],
    'LDFLAGS_LOCAL' : ['-lhw_cor_gio', '-lcurses']
}
# **** CODE GENERATOR CHECKSUM a64e5c7393ff1897e33f819fb1b68d65
