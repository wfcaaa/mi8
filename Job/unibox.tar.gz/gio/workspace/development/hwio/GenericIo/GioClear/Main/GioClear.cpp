/* -*-C++-*- */
/**
 * Simple test program, similar to iclear(1).
 ******************************************************************************
 * (C) Copyright 2013 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   GioClear.cpp
 * @author Jens Kilian
 * @date   Created:  Mon Dec  2 14:33:13 2013
 * @date   Modified: Fri Jan 15 11:37:01 2016 (Jens Kilian)
 ******************************************************************************
 */

#include <iostream>
using namespace ::std;

#include "xoc/hw/cor/gio/gio.h"

namespace
{
  /**
   * Print usage message.
   *
   * @param  pProgName Name of executable.
   */
  void
  usage(const char *pProgName)
  {
    cerr << "Usage: " << pProgName << " <interface>\n\n"
         << "       <interface>  Name of GIO interface, e.g. 'vxi11/192.168.0.100/gpib0,9'.\n"
         << endl;
  }
}

/**
 * Main program.
 *
 * @param  argc  Number of command-line arguments.
 * @param  argv  Command-line argument strings.
 *
 * @return int Exit status.
 */
int
main(int argc, char **argv)
{
  // Check and decode command-line arguments.
  
  if (argc != 2) {
    usage(argv[0]);
    return 1;
  }

  const char *pInterface = argv[1];

  // Errors will be considered fatal.
  
  gio_set_error_handler(GIO_ERROR_EXIT);

  // Open the interface, clear and close.

  IDID idid = gio_open(pInterface);
  gio_clear(idid);
  gio_close(idid);

  return 0;
}
