# Builds gio_clear C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
    'PROJECT_TYPE' : ['c_program'],
    'NAME' : ['gio_clear'],
    'DEST' : ['../..'],
    'CXXFLAGS_LOCAL' : ['--std=c++11'],
    'LDFLAGS_LOCAL' : ['-lhw_cor_gio']
}
# **** CODE GENERATOR CHECKSUM 8bbf8fefd934f0fa8426e87695f1ef71
