/* -*-C++-*- */
/**
 * An access method for instruments connected via RS-232.
 ******************************************************************************
 * (C) Copyright 2014 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   Rs232Session.cpp
 * @author Jens Kilian
 * @date   Created:  Thu Jan 16 14:24:25 2014
 * @date   Modified: Fri Jan 15 11:15:28 2016 (Jens Kilian)
 * 
 * This file implements an access method for controlling devices via an RS-232
 * serial interface.
 ******************************************************************************
 */

#include "Rs232Session.hpp"

#include <algorithm>
#include <cassert>
#include <map>
#include <new>
#include <string>

#include <errno.h>
#ifdef OS_LINUX
#  include <linux/serial.h>
#endif
#include <poll.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

#include "xoc/hw/cor/gio/gio.h"

#include "generic_io_t.hpp"
#include "gio_.hpp"
#include "Rs232Device.hpp"

using namespace ::std;
using namespace ::hw_cor_hwio_GenericIo;

namespace
{
  /*
   * Macros.
   * --------------------------------------------------------------------------
   */

  /** Perform a system library call, handling errors.
   *
   * @param call The system call to perform.  Must return -1 on failure.
   * @param err Variable of type GIO_ERROR; updated on failure.
   *
   * @return true on success, false on error.
   */
#define SYSCALL(call, err)                      \
  (((call) < 0)                                 \
   ? ((err) = mapErrno(), false)                \
   : true)

  /*
   * Constants.
   * --------------------------------------------------------------------------
   */

  /** Suffix for symbolic name of a device session (SICL compatibility). */
  const char kDeviceNameSuffix[] = ",488";

  /** Prefix of device file names. */
  const char kDevPrefix[] = "/";

  /*
   * Local functions.
   * --------------------------------------------------------------------------
   */

  /**
   * Convert an errno value to a GIO error code.
   *
   * The mapping is ad-hoc and possibly could be improved.
   *
   * @return GIO_ERROR
   */
  GIO_ERROR
  mapErrno(void)
  {
    switch (errno) {

    case EACCES:
    case EPERM:
      return GIO_ERR_PERMISSION_DENIED;

    case ENOENT:
    case ENODEV:
    case ENOTDIR:
    case ENXIO:
      return GIO_ERR_DEVICE_NOT_ACCESSIBLE;

    case ENFILE:
    case ENOMEM:
      return GIO_ERR_OUT_OF_RESOURCES;

    case EINTR:
      return GIO_ERR_INTERRUPT;

    default:
      return GIO_ERR_IO_ERROR;
    }
  }

  /**
   * Convert GIO selector for modem control line to ioctl() argument.
   *
   * @return GIO_ERROR
   */
  GIO_ERROR
  mapModemControlLine(
    /** Modem control line selector. */
    GIO_RS232_MODEM_CONTROL line,
    /** OUT: Argument for ioctl(). */
    int &arg)
  {
    switch (line) {

    case GIO_RS232_MODEM_CONTROL_DTR:
      arg = TIOCM_DTR;
      return GIO_ERR_NO_ERROR;

    case GIO_RS232_MODEM_CONTROL_RTS:
      arg = TIOCM_RTS;
      return GIO_ERR_NO_ERROR;

    default:
      arg = 0;
      return GIO_ERR_PARAMETER_ERROR;
    }
  }

  /**
   * Check if 'eoi' is a valid value for the read/write EOI settings.
   *
   * @return GIO_ERROR
   */
  GIO_ERROR
  checkEOI(
    /** The value to be checked. */
    uint32_t eoi,
    /** If true, the EOI value is for writing; if false, for reading. */
    bool forWriting)
  {
    switch (eoi) {

    case GIO_RS232_EOI_NONE:
    case GIO_RS232_EOI_BIT8:
      break;

    default:
      if (((eoi & ~0xff) != GIO_RS232_EOI_CHR) || forWriting) {
        return GIO_ERR_PARAMETER_ERROR;
      }
      break;
    }

    return GIO_ERR_NO_ERROR;
  }

  /*
   * Types.
   * --------------------------------------------------------------------------
   */

  /** The RS-232 session class. */
  class Rs232Session : public generic_io_t
  {
  public:
    /** Construct an RS-232 session. */
    Rs232Session(
      /** Factory creating this session. */
      const SessionFactory &factory,
      /** Symbolic name of interface or device. */
      const ::std::string &name,
      /** Device descriptor. */
      Rs232Device *pDevice,
      /** Indicates whether to create an interface session. */
      bool isInterface,
      /** OUT: Error code. */
      GIO_ERROR &err)
    : generic_io_t(factory, name),
      mDevice(*pDevice),
      mIsInterface(isInterface),
      mReadEOI(GIO_RS232_EOI_CHR | '\n'),
      mWriteEOI(GIO_RS232_EOI_NONE),
      mTimeout(0)
    {
#ifdef OS_LINUX
      mHasInterruptCounters = false;
      memset(&mInterruptCounters, 0, sizeof(mInterruptCounters));

      if (lock(err)) {
        // Save state of interrupt counters.
        mHasInterruptCounters =
          (ioctl(mDevice, TIOCGICOUNT, &mInterruptCounters) >= 0);

        unlock(err);
      }
#endif
    }

  private:
    // Not implemented.
    Rs232Session(const Rs232Session &);
    Rs232Session &operator =(const Rs232Session &);

    /**
     * Try to lock the connection.
     *
     * @return true iff connection was locked.
     */
    bool
    lock(
      /** OUT: Error code (updated if a failure occurs). */
      GIO_ERROR &err)
    {
      if (mDevice.lock()) {
        return true;
      }

      gio_merge_errors_(err, mapErrno());
      return false;
    }

    /**
     * Unlock the connection.
     */
    void
    unlock(
      /** OUT: Error code (updated if a failure occurs). */
      GIO_ERROR &err)
    {
      if (!mDevice.unlock()) {
        gio_merge_errors_(err, mapErrno());
      }
    }

    /** Close and delete the session. */
    GIO_ERROR
    close(GIO_ERROR err)
    {
      // Close the connection.
      mDevice.close();

      // NB: Errors must be reported before destroying the session.
      gio_set_errno_(this, err);

      // Delete the session.
      delete this;

      return err;
    }

    /** Wait until device is ready for I/O or a timeout occurs. */
    GIO_ERROR
    wait(
      /** Events to poll for. */
      short events)
    {
      struct pollfd fd = { mDevice, events, 0 };
      int timeout = mTimeout
        ? mTimeout
        : -1;                   // infinite timeout

      do {
        int result = poll(&fd, 1, timeout);

        switch (result) {

        case 0:
          return GIO_ERR_IO_TIMEOUT;

        case 1:
          if (fd.revents & (POLLERR|POLLHUP)) {
            return GIO_ERR_IO_ERROR;
          }
          if (fd.revents & POLLNVAL) {
            return GIO_ERR_INVALID_ID;
          }
          return GIO_ERR_NO_ERROR;

        default:
          break;
        }
      } while (errno == EINTR);

      return mapErrno();
    }

    /** Write data. */
    GIO_ERROR
    write(
      /** Buffer containing data to be written. */
      const void *pBuffer,
      /** Amount of data to be written. */
      size_t len,
      /** Send last byte with END indicator. */
      bool_t end,
      /** OUT: Actual number of bytes written. */
      size_t *pActual)
    {
      if (!pBuffer) {
        return GIO_ERR_PARAMETER_ERROR;
      }

      GIO_ERROR err = GIO_ERR_NO_ERROR;
      if (!lock(err)) {
        return err;
      }

      string buffer;
      if (mWriteEOI == GIO_RS232_EOI_BIT8) {
        // Copy to temporary buffer and set MSB of last byte.
        try {
          buffer = string((const char *)pBuffer, len);
          buffer[len-1] |= '\x80';

          pBuffer = buffer.c_str();

        } catch (bad_alloc &) {
          unlock(err);
          return GIO_ERR_OUT_OF_RESOURCES;
        }
      }

      size_t totalWritten = 0;
      do {
        if ((err = wait(POLLOUT)) == GIO_ERR_NO_ERROR) {
          ssize_t didWrite = ::write(mDevice,
                                     (const char *)pBuffer + totalWritten,
                                     len - totalWritten);
          if (didWrite < 0) {
            if (errno != EINTR) {
              err = mapErrno();
            }
          } else {
            totalWritten += didWrite;
          }
        }
      } while (err == GIO_ERR_NO_ERROR && len > totalWritten);

      if (pActual) {
        *pActual = totalWritten;
      }

      unlock(err);
      return err;
    }

    /** Helper for sending simple commands. */
    GIO_ERROR
    write(
      /** Buffer containing command to be written. */
      const void *pBuffer)
    {
      return write(pBuffer, strlen((const char *)pBuffer), FALSE, NULL);
    }

    /** Check for termination character. */
    bool
    isTermChr(unsigned char ch)
    {
      if (mReadEOI & GIO_RS232_EOI_CHR) {
        return (ch == (mReadEOI & 0xff));
      }
      return false;
    }

    /** Read data. */
    GIO_ERROR
    read(
      /** Buffer into which data should be read. */
      void *pBuffer,
      /** Size of buffer. */
      size_t len,
      /** OUT: Reasons for termination. */
      int *pReasons,
      /** OUT: Actual number of bytes read. */
      size_t *pActual)
    {
      if (!pBuffer) {
        return GIO_ERR_PARAMETER_ERROR;
      }

      GIO_ERROR err = GIO_ERR_NO_ERROR;
      if (!lock(err)) {
        return err;
      }

      unsigned char *const cBuffer = (unsigned char *)pBuffer;
      size_t totalRead = 0;
      int reasons = 0;
      do {
        if ((err = wait(POLLIN)) == GIO_ERR_NO_ERROR) {
          const size_t toRead =
            (mReadEOI == GIO_RS232_EOI_NONE)
            ? len - totalRead
            : 1; // If we have to check for EOI, we can only read single bytes.

          ssize_t didRead = ::read(mDevice,
                                   cBuffer + totalRead,
                                   toRead);
          if (didRead < 0) {
            if (errno != EINTR) {
              err = mapErrno();
            }
          } else {
            if ((totalRead += didRead) == len) {
              reasons = GIO_REASON_REQCNT;
            }
            if ((mReadEOI != GIO_RS232_EOI_NONE) && (totalRead > 0)) {
              const unsigned char lastChar = cBuffer[totalRead-1];

              if (mReadEOI == GIO_RS232_EOI_BIT8) {
                if (lastChar & '\x80') {
                  cBuffer[totalRead-1] &= '\x7f';
                  reasons |= GIO_REASON_END;
                }
              } else if (isTermChr(lastChar)) {
                reasons |= GIO_REASON_CHR;
              }
            }
          }
        }
      } while (err == GIO_ERR_NO_ERROR && reasons == 0);

      if (pReasons) {
        *pReasons = reasons;
      }
      if (pActual) {
        *pActual = totalRead;
      }

      unlock(err);
      return err;
    }

    /** Read status byte. */
    GIO_ERROR
    read_status_byte(
      /** OUT: Status byte. */
      uint8_t *pStb)
    {
      if (!pStb) {
        return GIO_ERR_PARAMETER_ERROR;
      }

      GIO_ERROR err = write("*STB?");
      if (err == GIO_ERR_NO_ERROR) {
        char buffer[256];
        size_t nRead;
        err = read(buffer, sizeof(buffer)-1, NULL, &nRead);

        if (err == GIO_ERR_NO_ERROR) {
          buffer[nRead] = '\0';

          // Parse the <NR1 NUMERIC RESPONSE DATA> result.
          char *endptr;
          long n = strtol(buffer, &endptr, 10);

          if ((endptr == buffer)                            // empty response
              || ((*endptr != '\0') && !isTermChr(*endptr)) // trailing junk
              || (n < 0)                                    // value out of range
              || (n > 255))
          {
            err = GIO_ERR_BAD_FORMAT;

          } else if (pStb) {
            *pStb = (uint8_t)n;
          }
        }
      }
      return err;
    }

    /** Trigger device(s). */
    GIO_ERROR
    trigger(void)
    {
      if (mIsInterface) {
        GIO_ERROR err = GIO_ERR_NO_ERROR;
        if (!lock(err)) {
          return err;
        }

        // SICL compatibility: Pulse DTR low for 10 ms.
        const int arg = TIOCM_DTR;

        if (SYSCALL(ioctl(mDevice, TIOCMBIC, &arg), err)) {
          usleep(10 * 1000);
          SYSCALL(ioctl(mDevice, TIOCMBIS, &arg), err);
        }

        unlock(err);
        return err;
      }

      // Device session.
      return write("*TRG");
    }

    /** Send BREAK signal on an RS-232 interface. */
    GIO_ERROR
    rs232_break(void)
    {
      GIO_ERROR err = GIO_ERR_NO_ERROR;
      if (!lock(err)) {
        return err;
      }

      SYSCALL(tcsendbreak(mDevice, 0), err);

      unlock(err);
      return err;
    }

    /** Reset an RS-232 interface. */
    GIO_ERROR
    rs232_reset(void)
    {
      GIO_ERROR err = GIO_ERR_NO_ERROR;
      if (!lock(err)) {
        return err;
      }

      // Discard all pending data.
      SYSCALL(tcflush(mDevice, TCIOFLUSH), err);

      // Reset flow control.
      SYSCALL(tcflow(mDevice, TCION), err);
      SYSCALL(tcflow(mDevice, TCOON), err);

#ifdef OS_LINUX
      if (mHasInterruptCounters) {
        // Reset interrupt counters.
        SYSCALL(ioctl(mDevice, TIOCGICOUNT, &mInterruptCounters), err);
      }
#endif

      unlock(err);
      return err;
    }

    /** Control communication parameters of an RS-232 interface. */
    GIO_ERROR
    rs232_control(
      /** Feature to be modified. */
      GIO_RS232_REQUEST request,
      /** New setting of feature. */
      uint32_t setting)
    {
      if (!mIsInterface) {
        // Not supported for device sessions.
        return GIO_ERR_OPERATION_NOT_SUPPORTED;
      }

      if (request == GIO_RS232_RESET) {
        return rs232_reset();
      }

      GIO_ERROR err = GIO_ERR_NO_ERROR;
      if (!lock(err)) {
        return err;
      }

      if (request == GIO_RS232_READ_EOI) {
        err = checkEOI(setting, false);
        if (err == GIO_ERR_NO_ERROR) {
          mReadEOI = setting;
        }

      } else if (request == GIO_RS232_WRITE_EOI) {
        err = checkEOI(setting, true);
        if (err == GIO_ERR_NO_ERROR) {
          mWriteEOI = setting;
        }

      } else {
        struct termios tio;
        if (SYSCALL(tcgetattr(mDevice, &tio), err)) {
          switch (request) {

          case GIO_RS232_BAUD:
          {
            speed_t speed = B0;

            switch (setting) {

            case 0:      speed = B0;      break;
            case 50:     speed = B50;     break;
            case 75:     speed = B75;     break;
            case 110:    speed = B110;    break;
            case 134:    speed = B134;    break;
            case 150:    speed = B150;    break;
            case 200:    speed = B200;    break;
            case 300:    speed = B300;    break;
            case 600:    speed = B600;    break;
            case 1200:   speed = B1200;   break;
            case 1800:   speed = B1800;   break;
            case 2400:   speed = B2400;   break;
            case 4800:   speed = B4800;   break;
            case 9600:   speed = B9600;   break;
            case 19200:  speed = B19200;  break;
            case 38400:  speed = B38400;  break;
            case 57600:  speed = B57600;  break;
            case 115200: speed = B115200; break;
            case 230400: speed = B230400; break;

            default:
              err = GIO_ERR_PARAMETER_ERROR;
              break;
            }

            if (err == GIO_ERR_NO_ERROR) {
              SYSCALL(cfsetispeed(&tio, speed), err);
              SYSCALL(cfsetospeed(&tio, speed), err);
            }
            break;
          }

          case GIO_RS232_PARITY:
            tio.c_cflag &= ~(PARENB | PARODD | CMSPAR);

            switch (setting) {

            case GIO_RS232_PARITY_NONE:
              tio.c_iflag &= ~INPCK;
              break;
            case GIO_RS232_PARITY_EVEN:
              tio.c_iflag |= INPCK;
              tio.c_cflag |= PARENB;
              break;
            case GIO_RS232_PARITY_ODD:
              tio.c_iflag |= INPCK;
              tio.c_cflag |= PARENB | PARODD;
              break;
            case GIO_RS232_PARITY_MARK:
              tio.c_iflag |= INPCK;
              tio.c_cflag |= PARENB | PARODD | CMSPAR;
              break;
            case GIO_RS232_PARITY_SPACE:
              tio.c_iflag |= INPCK;
              tio.c_cflag |= PARENB          | CMSPAR;
              break;

            default:
              err = GIO_ERR_PARAMETER_ERROR;
              break;
            }
            break;

          case GIO_RS232_STOP_BITS:
            switch (setting) {

            case 1:
              tio.c_cflag &= ~CSTOPB;
              break;
            case 2:
              tio.c_cflag |=  CSTOPB;
              break;

            default:
              err = GIO_ERR_PARAMETER_ERROR;
              break;
            }
            break;

          case GIO_RS232_WIDTH:
            tio.c_cflag &= ~CSIZE;

            switch (setting) {

            case 5:
              tio.c_cflag |= CS5;
              break;
            case 6:
              tio.c_cflag |= CS6;
              break;
            case 7:
              tio.c_cflag |= CS7;
              break;
            case 8:
              tio.c_cflag |= CS8;
              break;

            default:
              err = GIO_ERR_PARAMETER_ERROR;
              break;
            }
            break;

          case GIO_RS232_FLOW_CONTROL:
            switch (setting) {

            case GIO_RS232_FLOW_CONTROL_NONE:
              tio.c_iflag &= ~(IXON | IXOFF);
              tio.c_cflag &= ~CRTSCTS;
              break;
            case GIO_RS232_FLOW_CONTROL_XON_XOFF:
              tio.c_iflag |=  IXON | IXOFF;
              tio.c_cflag &= ~CRTSCTS;
              break;
            case GIO_RS232_FLOW_CONTROL_RTS_CTS:
              tio.c_iflag &= ~(IXON | IXOFF);
              tio.c_cflag |=  CRTSCTS;
              break;

            default:
              err = GIO_ERR_PARAMETER_ERROR;
              break;
            }
            break;

          case GIO_RS232_XON_CHAR:
            if (setting <= 0xff) {
              tio.c_cc[VSTART] = setting;
            } else {
              err = GIO_ERR_PARAMETER_ERROR;
            }
            break;

          case GIO_RS232_XOFF_CHAR:
            if (setting <= 0xff) {
              tio.c_cc[VSTOP] = setting;
            } else {
              err = GIO_ERR_PARAMETER_ERROR;
            }
            break;

          default:
            err = GIO_ERR_PARAMETER_ERROR;
            break;
          }

          if (err == GIO_ERR_NO_ERROR) {
            SYSCALL(tcsetattr(mDevice, TCSADRAIN, &tio), err);
          }
        }
      }

      unlock(err);
      return err;
    }

    /** Inquire status of an RS-232 interface. */
    GIO_ERROR
    rs232_status(
      /** Type of status report. */
      GIO_RS232_REQUEST request,
      /** OUT: Current state. */
      uint32_t *pResult)
    {
      if (!pResult) {
        return GIO_ERR_PARAMETER_ERROR;
      }

      if (!mIsInterface) {
        // Not supported for device sessions.
        return GIO_ERR_OPERATION_NOT_SUPPORTED;
      }

      GIO_ERROR err = GIO_ERR_NO_ERROR;

      if (request == GIO_RS232_READ_EOI) {
        *pResult = mReadEOI;

      } else if (request == GIO_RS232_WRITE_EOI) {
        *pResult = mWriteEOI;

      } else if (request == GIO_RS232_MODEM_STATUS) {
        int arg;
        if (SYSCALL(ioctl(mDevice, TIOCMGET, &arg), err)) {
          *pResult =
            ( ((arg & TIOCM_CD)  ? GIO_RS232_MODEM_STATUS_DCD : 0))
            | ((arg & TIOCM_LE)  ? GIO_RS232_MODEM_STATUS_DSR : 0)
            | ((arg & TIOCM_CTS) ? GIO_RS232_MODEM_STATUS_CTS : 0)
            | ((arg & TIOCM_RI)  ? GIO_RS232_MODEM_STATUS_RI  : 0);
        }
      } else if (request == GIO_RS232_STATUS) {
        if (lock(err)) {
          *pResult = 0;

          int arg;
          if (SYSCALL(ioctl(mDevice, TIOCINQ, &arg), err)) {
            if (arg > 0) {
              *pResult |= GIO_RS232_STATUS_DAV;  // Input data available.
            }
          }
          if (SYSCALL(ioctl(mDevice, TIOCOUTQ, &arg), err)) {
            if (arg == 0) {
              *pResult |= GIO_RS232_STATUS_TEMT; // Output queue empty.
            }
          }
#ifdef OS_LINUX
          if (mHasInterruptCounters) {
            struct serial_icounter_struct sis;
            if (SYSCALL(ioctl(mDevice, TIOCGICOUNT, &sis), err)) {
              if (mInterruptCounters.overrun != sis.overrun) {
                *pResult |= GIO_RS232_STATUS_OVERFLOW;
              }
              if (mInterruptCounters.parity != sis.parity) {
                *pResult |= GIO_RS232_STATUS_PARERR;
              }
              if (mInterruptCounters.frame != sis.frame) {
                *pResult |= GIO_RS232_STATUS_FRAMING;
              }
              if (mInterruptCounters.brk != sis.brk) {
                *pResult |= GIO_RS232_STATUS_BREAK;
              }
            mInterruptCounters = sis;
            }
          }
#endif
          unlock(err);
        }
      } else if (request == GIO_RS232_READ_DAV) {
        int arg;
        if (SYSCALL(ioctl(mDevice, FIONREAD, &arg), err)) {
          *pResult = arg;
        }
      } else {
        struct termios tio;
        if (SYSCALL(tcgetattr(mDevice, &tio), err)) {
          switch (request) {

          case GIO_RS232_BAUD:
            // Assume input & output run at same speed.
            switch (cfgetispeed(&tio)) {

            case B0:      *pResult = 0;      break;
            case B50:     *pResult = 50;     break;
            case B75:     *pResult = 75;     break;
            case B110:    *pResult = 110;    break;
            case B134:    *pResult = 134;    break;
            case B150:    *pResult = 150;    break;
            case B200:    *pResult = 200;    break;
            case B300:    *pResult = 300;    break;
            case B600:    *pResult = 600;    break;
            case B1200:   *pResult = 1200;   break;
            case B1800:   *pResult = 1800;   break;
            case B2400:   *pResult = 2400;   break;
            case B4800:   *pResult = 4800;   break;
            case B9600:   *pResult = 9600;   break;
            case B19200:  *pResult = 19200;  break;
            case B38400:  *pResult = 38400;  break;
            case B57600:  *pResult = 57600;  break;
            case B115200: *pResult = 115200; break;
            case B230400: *pResult = 230400; break;

            default:
              err = GIO_ERR_IO_ERROR;
              break;
            }
            break;

          case GIO_RS232_PARITY:
            switch (tio.c_cflag & (PARENB | PARODD | CMSPAR)) {

            case PARENB:
              *pResult = GIO_RS232_PARITY_EVEN;
              break;
            case PARENB | PARODD:
              *pResult = GIO_RS232_PARITY_ODD;
              break;
            case PARENB | PARODD | CMSPAR:
              *pResult = GIO_RS232_PARITY_MARK;
              break;
            case PARENB          | CMSPAR:
              *pResult = GIO_RS232_PARITY_SPACE;
              break;

            default:
              *pResult = GIO_RS232_PARITY_NONE;
              break;
            }
            break;

          case GIO_RS232_STOP_BITS:
            *pResult = (tio.c_cflag & CSTOPB) ? 2 : 1;
            break;

          case GIO_RS232_WIDTH:
            switch (tio.c_cflag & CSIZE) {

            case CS5:
              *pResult = 5;
              break;
            case CS6:
              *pResult = 6;
              break;
            case CS7:
              *pResult = 7;
              break;
            case CS8:
              *pResult = 8;
              break;

            default:
              err = GIO_ERR_IO_ERROR;
              break;
            }
            break;

          case GIO_RS232_FLOW_CONTROL:
            // Assume sane settings.
            if (tio.c_iflag & (IXON | IXOFF)) {
              *pResult = GIO_RS232_FLOW_CONTROL_XON_XOFF;

            } else if (tio.c_cflag & CRTSCTS) {
              *pResult = GIO_RS232_FLOW_CONTROL_RTS_CTS;

            } else {
              *pResult = GIO_RS232_FLOW_CONTROL_NONE;
            }
            break;

          case GIO_RS232_XON_CHAR:
            *pResult = tio.c_cc[VSTART];
            break;

          case GIO_RS232_XOFF_CHAR:
            *pResult = tio.c_cc[VSTOP];
            break;

          default:
            err = GIO_ERR_PARAMETER_ERROR;
            break;
          }
        }
      }

      return err;
    }

    /** Control modem control lines of an RS-232 interface. */
    GIO_ERROR
    rs232_modem_control(
      /** Modem control line to be switched. */
      GIO_RS232_MODEM_CONTROL line,
      /** New status of line. */
      bool_t enable)
    {
      if (mIsInterface) {
        int arg;
        GIO_ERROR err = mapModemControlLine(line, arg);

        if (err == GIO_ERR_NO_ERROR) {
          if (!lock(err)) {
            return err;
          }

          const int cmd = enable ? TIOCMBIS : TIOCMBIC;
          SYSCALL(ioctl(mDevice, cmd, &arg), err);

          unlock(err);
        }

        return err;
      }

      // Not supported for device sessions.
      return GIO_ERR_OPERATION_NOT_SUPPORTED;
    }

    /** Inquire modem control line status of an RS-232 interface. */
    GIO_ERROR
    rs232_modem_control_status(
      /** Modem control line to be checked. */
      GIO_RS232_MODEM_CONTROL line,
      /** OUT: Current state. */
      bool_t *pStatus)
    {
      if (!pStatus) {
        return GIO_ERR_PARAMETER_ERROR;
      }

      if (mIsInterface) {
        int mask;
        GIO_ERROR err = mapModemControlLine(line, mask);

        if (err == GIO_ERR_NO_ERROR) {
          int arg;
          if (SYSCALL(ioctl(mDevice, TIOCMGET, &arg), err)) {
            *pStatus = (arg & mask) != 0;
          }
        }
        return err;
      }

      // Not supported for device sessions.
      return GIO_ERR_OPERATION_NOT_SUPPORTED;
    }

    /** Switch device to local operation. */
    GIO_ERROR
    local(void)
    {
      // SICL compatibility: set DTR active.
      return rs232_modem_control(GIO_RS232_MODEM_CONTROL_DTR, true);
    }

    /** Switch device to remote operation. */
    GIO_ERROR
    remote(void)
    {
      // SICL compatibility: set DTR inactive.
      return rs232_modem_control(GIO_RS232_MODEM_CONTROL_DTR, false);
    }

    /** Clear an interface or device. */
    GIO_ERROR
    clear(void)
    {
      // Send BREAK and clear the interface.
      GIO_ERROR err = rs232_break();
      gio_merge_errors_(err, rs232_reset());
      
      return err;
    }

    /** Set termination character. */
    GIO_ERROR
    set_termchr(
      /** New termination character. */
      int termChar)
    {
      GIO_ERROR err = GIO_ERR_NO_ERROR;
      if (!lock(err)) {
        return err;
      }

      // I don't know what SICL does here, but this seems logical...
      if (termChar >= 0x00 && termChar <= 0xff) {
        mReadEOI = GIO_RS232_EOI_CHR | termChar;

      } else if (termChar == -1) {
        mReadEOI = GIO_RS232_EOI_NONE;

      } else {
        err = GIO_ERR_PARAMETER_ERROR;
      }

      unlock(err);
      return err;
    }

    /** Inquire current termination character. */
    GIO_ERROR
    get_termchr(
      /** OUT: Termination character. */
      int *pTermChar)
    {
      if (!pTermChar) {
        return GIO_ERR_PARAMETER_ERROR;
      }

      GIO_ERROR err = GIO_ERR_NO_ERROR;
      if (!lock(err)) {
        return err;
      }

      // I don't know what SICL does here, but this seems logical...
      if (mReadEOI & GIO_RS232_EOI_CHR) {
        *pTermChar = mReadEOI & 0xff;

      } else {
        *pTermChar = -1;
      }

      unlock(err);
      return err;
    }

    /** Set timeout. */
    GIO_ERROR
    set_timeout(
      /** New timeout. */
      uint32_t milliSeconds)
    {
      GIO_ERROR err = GIO_ERR_NO_ERROR;
      if (!lock(err)) {
        return err;
      }

      mTimeout = milliSeconds;

      unlock(err);
      return err;
    }

    /** Inquire current timeout. */
    GIO_ERROR
    get_timeout(
      /** OUT: Current timeout. */
      uint32_t *pMilliSeconds)
    {
      if (!pMilliSeconds) {
        return GIO_ERR_PARAMETER_ERROR;
      }

      *pMilliSeconds = mTimeout;

      return GIO_ERR_NO_ERROR;
    }

    /** Inquire human-readable description of a given GIO(!) error code. */
    const char *
    get_error_str(
      /** Error code. */
      GIO_ERROR error)
    {
      switch (error) {

      case GIO_ERR_NO_ERROR:
        return "No error";

      case GIO_ERR_INVALID_SYMBOLIC_NAME:
        return "Invalid symbolic name";

      case GIO_ERR_DEVICE_NOT_ACCESSIBLE:
        return "Device not accessible";

      case GIO_ERR_INVALID_ID:
        return "Invalid ID";

      case GIO_ERR_PARAMETER_ERROR:
        return "Parameter error";

      case GIO_ERR_PERMISSION_DENIED:
        return "Permission denied";

      case GIO_ERR_OPERATION_NOT_SUPPORTED:
        return "Operation not supported";

      case GIO_ERR_OUT_OF_RESOURCES:
        return "Out of resources";

      case GIO_ERR_BAD_FORMAT:
        return "Bad format";

      case GIO_ERR_IO_TIMEOUT:
        return "I/O timeout";

      case GIO_ERR_IO_ERROR:
        return "I/O error";

      case GIO_ERR_NOT_IMPLEMENTED:
        return "Not implemented";

      case GIO_ERR_INVALID_CONFIGURATION:
        return "Invalid configuration";

      case GIO_ERR_INTERRUPT:
        return "Interrupt";

      default:
        // Unknown error code.
        return 0;
      }
    }

    /** Dummy function for testing purposes. */
    GIO_ERROR
    do_nothing(void)
    {
      return GIO_ERR_NO_ERROR;
    }


    /** Device descriptor. */
    Rs232Device &mDevice;

    /** Indicates whether this is an interface session. */
    const bool mIsInterface;

#ifdef OS_LINUX
    /** Indicates interrupt counters are available. */
    bool mHasInterruptCounters;
    /** Saved state of interrupt counters. */
    struct serial_icounter_struct mInterruptCounters;
#endif

    /** Current setting of EOI option for reading. */
    uint32_t mReadEOI;
    /** Current setting of EOI option for writing. */
    uint32_t mWriteEOI;

    /** Current timeout. */
    uint32_t mTimeout;
  };

  /** Open a new RS-232 session. */
  generic_io_t *
  openSession(
    /** Factory creating this session. */
    const SessionFactory &factory,
    /** Symbolic name of interface or device, without prefix. */
    const ::std::string &name,
    /** Associated device session (@c gio_get_interface() only). */
    generic_io_t *pDeviceSession = 0)
  {
    // The symbolic name is just the name of a TTY device, including
    // the '/dev/' directory prefix.
    // To be (more) compatible with SICL, we use a special suffix
    // to distinguish device sessions from interface sessions.
    //
    // Examples:
    //   rs232/dev/ttyS0                   interface session on ttyS0
    //   rs232/dev/usb/ttyUSB0,488         device session on ttyUSB0
    const string::size_type commaPos = name.find(',');
    if (commaPos != string::npos) {
      if (name.substr(commaPos) != kDeviceNameSuffix) {
        // Invalid suffix.
        gio_set_errno_(pDeviceSession, GIO_ERR_INVALID_SYMBOLIC_NAME);
        return 0;
      }
    }

    // Try to open the device.
    const string devName = kDevPrefix + name.substr(0, commaPos);
    Rs232Device *pDevice = Rs232Device::open(devName);
    if (!pDevice) {
      gio_set_errno_(pDeviceSession, mapErrno());
      return 0;
    }

    // OK, create the session descriptor.
    GIO_ERROR err = GIO_ERR_NO_ERROR;
    generic_io_t *pIO = new (nothrow) Rs232Session(factory,
                                                   name,
                                                   pDevice,
                                                   (commaPos == string::npos),
                                                   err);
    if (!pIO) {
      pDevice->close();
      gio_set_errno_(pDeviceSession, GIO_ERR_OUT_OF_RESOURCES);

    } else if (err != GIO_ERR_NO_ERROR) {
      pIO->close(err);
      pIO = 0;
    }
    return pIO;
  }
}

/*
 * RS-232 session factory.
 * ----------------------------------------------------------------------------
 */

namespace hw_cor_hwio_GenericIo
{
  Rs232SessionFactory::Rs232SessionFactory(const ::std::string &prefix)
  : SessionFactory(prefix)
  {
    // empty
  }

  generic_io_t *
  Rs232SessionFactory::create(
    const ::std::string &name,
    generic_io_t *pDeviceSession) const
  {
    if (!pDeviceSession) {
      // Session explicitly opened by client (@c gio_open()).
      return openSession(*this, name);
    }

    // Session implicitly opened (@c gio_get_interface()).
    //
    // Convert the device session name into an interface session name
    // (see above).
    const string interfaceName = name.substr(0, name.rfind(','));

    // Try to open the interface session.
    return openSession(*this, interfaceName, pDeviceSession);
  }

  GIO_ERROR
  Rs232SessionFactory::suspendSessionEvents(void)
  {
    return GIO_ERR_NO_ERROR;
  }

  GIO_ERROR
  Rs232SessionFactory::resumeSessionEvents(void)
  {
    return GIO_ERR_NO_ERROR;
  }
}
