/* -*-C++-*- */
/**
 * An access method for VXI-11 Network Instrument Servers.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   Vxi11Session.hpp
 * @author Jens Kilian
 * @date   Created:  Thu Dec 20 09:15:12 2012
 * @date   Modified: Fri Feb  8 15:32:00 2013 (Jens Kilian)
 *
 * This file implements an access method for controlling devices connected
 * to a VXI-11 Network Instrument Server, such as a LAN-to-GPIB interface.
 ******************************************************************************
 */

#ifndef HD5E23654_2EA4_4E40_9B8D_A38AC0A35223_
#define HD5E23654_2EA4_4E40_9B8D_A38AC0A35223_

#include "SessionFactory.hpp"

namespace hw_cor_hwio_GenericIo
{
  /** Factory for VXI-11 sessions. */
  class Vxi11SessionFactory : public SessionFactory
  {
  public:
    /** Construct the VXI-11 session factory. */
    Vxi11SessionFactory(
      /** Symbolic name prefix for sessions created by this factory. */
      const ::std::string &prefix);

  private:
    // Not implemented.
    Vxi11SessionFactory(const Vxi11SessionFactory &);
    Vxi11SessionFactory &operator =(const Vxi11SessionFactory &);

    /** Create a session with the given local symbolic name. */
    virtual generic_io_t *
    create(
      /** Symbolic name of interface or device, without prefix. */
      const ::std::string &name,
      /** Associated device session (@c gio_get_interface() only). */
      generic_io_t *pDevice) const;

    /**
     * Suspend asynchronous events in all sessions created by this factory.
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    virtual GIO_ERROR
    suspendSessionEvents(void);

    /**
     * Resume asynchronous events in all sessions created by this factory.
     *
     * @attention
     * The factory is responsible for not losing events which occur
     * between suspension and resumption.  It must deliver pending events
     * after resumption, in the correct order.
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    virtual GIO_ERROR
    resumeSessionEvents(void);
  };
}

#endif /* HD5E23654_2EA4_4E40_9B8D_A38AC0A35223_ */
