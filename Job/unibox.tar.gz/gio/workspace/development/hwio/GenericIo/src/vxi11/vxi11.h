/* -*-C++-*- */
/**
 * Definitions from the VXI-11 standard documents.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   vxi11.h
 * @author Jens Kilian
 * @date   Created:  Mon Dec  3 10:17:15 2001
 * @date   Modified: Wed Dec 19 13:34:30 2012 (Jens Kilian)
 *
 * This file contains various definitions for constants which are specified
 * in the VXI-11 standard, but which are not part of the RPC protocol
 * descriptions.
 * ----------------------------------------------------------------------------
 */

#ifndef HC90DCF42_D14F_4B04_BC19_CA423F5ECFA3_
#define HC90DCF42_D14F_4B04_BC19_CA423F5ECFA3_

/*
 * Type definitions.
 * ----------------------------------------------------------------------------
 */

/**
 * Flags, as specified in VXI-11 B.5.3.
 *
 * These flags are used to modify the behavior of some VXI-11 RPC requests.
 */
enum {
  /**
   * Wait for lock to succeed.
   *
   * If this flag is set, requests which support it will wait for a locking
   * condition to end.  If the flag is not set, these requests will return
   * an error instead.
   */
  VXI11_FLAG_WAITLOCK   = 0x00000001,
  /**
   * Terminate writes with @c END marker.
   *
   * This flag indicates that @c device_write() should set the @c END
   * marker on the last byte sent.
   */
  VXI11_FLAG_END        = 0x00000008,
  /**
   * Termination character set.
   * 
   * This flags indicates that @c device_read() should obey the current
   * termination character (which is also part of these requests).
   */
  VXI11_FLAG_TERMCHRSET = 0x00000080
};

/**
 * Reasons for returning from @c device_read(), as specified in VXI-11 B.6.4.
 *
 * These values are returned by @c device_read() to indicate different
 * termination conditions.  They are cumulative; all three could potentially
 * be returned at once.
 */
enum {
  /**
   * Requested number of bytes read.
   *
   * If set, @c device_read() has read as many characters as were specified
   * in the original request.
   */
  VXI11_REASON_REQCNT   = 0x00000001,
  /**
   * Termination character received.
   *
   * If set, @c device_read() has encountered the current termination
   * character.
   */
  VXI11_REASON_CHR      = 0x00000002,
  /**
   * @c END marker encountered.
   *
   * If set, @c device_read() has encountered a character with the @c END
   * marker set on it.
   */
  VXI11_REASON_END      = 0x00000004
};

/**
 * GPIB commands for @c device_docmd(), as specified in VXI-11.2 Rule B.5.1.
 *
 * These values control the action of the @c device_docmd() request when
 * it is sent to a VXI-11.2 compliant Network Instrument Server (i.e.,
 * a LAN-to-GPIB gateway).
 */
enum {
  /**
   * Send GPIB command.
   *
   * Direct @c device_docmd() to send a GPIB command.  This entails
   * asserting the ATN line on the interface and writing a sequence
   * of bytes.
   */
  VXI11_GPIB_CMD_SEND_COMMAND = 0x020000,
  /**
   * Inquire bus status.
   *
   * Direct @c device_docmd() to return status information.
   * Various options for this command exist to inquire different types
   * of information.
   */
  VXI11_GPIB_CMD_BUS_STATUS   = 0x020001,
  /**
   * Control ATN line.
   *
   * Direct @c device_docmd() to assert resp. deassert the ATN line.
   */
  VXI11_GPIB_CMD_ATN_CONTROL  = 0x020002,
  /**
   * Control REN line.
   *
   * Direct @c device_docmd() to assert resp. deassert the REN line.
   */
  VXI11_GPIB_CMD_REN_CONTROL  = 0x020003,
  /**
   * Pass control to other device.
   *
   * Direct @c device_docmd() to pass control to another device on the bus.
   */
  VXI11_GPIB_CMD_PASS_CONTROL = 0x020004,
  /**
   * Set bus address.
   *
   * Direct @c device_docmd() to modify the gateway's GPIB address.
   */
  VXI11_GPIB_CMD_BUS_ADDRESS  = 0x02000a,
  /**
   * Control IFC line.
   *
   * Direct @c device_docmd() to assert resp. deassert the IFC line.
   */
  VXI11_GPIB_CMD_IFC_CONTROL  = 0x020010
};

/**
 * Parameters for VXI-11.2 GPIB Bus Status command (VXI-11.2 Rule B.5.6).
 *
 * These values control which information is returned by a status inquiry
 * via @c device_docmd() (when using the VXI11_GPIB_CMD_BUS_STATUS option).
 */
enum {
  /**
   * Checks if the GPIB interface is in remote state.
   */
  VXI11_GPIB_STATUS_REMOTE               = 1,
  /**
   * Checks if the SRQ line is asserted, indicating a service request
   * is pending.
   */
  VXI11_GPIB_STATUS_SRQ                  = 2,
  /**
   * Checks if the NDAC line is asserted.
   */
  VXI11_GPIB_STATUS_NDAC                 = 3,
  /**
   * Checks if the interface is the system controller.
   */
  VXI11_GPIB_STATUS_SYSTEM_CONTROLLER    = 4,
  /**
   * Checks if the interface is the active controller.
   */
  VXI11_GPIB_STATUS_CONTROLLER_IN_CHARGE = 5,
  /**
   * Checks if the interface is addressed to talk.
   */
  VXI11_GPIB_STATUS_TALKER               = 6,
  /**
   * Checks if the interface is addressed to listen.
   */
  VXI11_GPIB_STATUS_LISTENER             = 7,
  /**
   * Returns the GPIB address of the interface.
   */
  VXI11_GPIB_STATUS_BUS_ADDRESS          = 8
};

#endif /* HC90DCF42_D14F_4B04_BC19_CA423F5ECFA3_ */
