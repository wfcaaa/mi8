/* -*-C++-*- */
/**
 * A wrapper class for VXI-11 links that are shared between sessions.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   Vxi11Link.cpp
 * @author Jens Kilian
 * @date   Created:  Fri Dec 21 10:19:25 2012
 ******************************************************************************
 */

#include "Vxi11Link.hpp"

#include <memory>
using namespace ::std;

#include "Vxi11Server.hpp"

namespace hw_cor_hwio_GenericIo
{
  Vxi11Link::Vxi11Link(const shared_ptr<Vxi11Server> &pServer,
                       const Create_LinkResp &creationResult)
  : mpServer(pServer),
    mLinkID(creationResult.lid),
    mMaxRecvSize(creationResult.maxRecvSize)
  {
    // empty
  }

  Vxi11Link::~Vxi11Link(void)
  {
    mpServer->closeLink(mLinkID);
  }
}
