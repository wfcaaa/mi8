/* -*-C++-*- */
/**
 * An access method for instruments which support raw SCPI over TCP.
 * ----------------------------------------------------------------------------
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 * ============================================================================
 *
 * @file   ScpiSession.cpp
 * @author Jens Kilian
 * @date   Created:  Tue Dec 18 11:06:05 2012
 * ----------------------------------------------------------------------------
 */

#include "ScpiSession.hpp"

#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>
using namespace ::std;

#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>

#include "xoc/hw/cor/gio/gio.h"

#include "generic_io_t.hpp"
#include "gio_.hpp"
using namespace ::hw_cor_hwio_GenericIo;

namespace
{
  /*
   * Constants.
   * --------------------------------------------------------------------------
   */

  /** Semi-standard protocol name for raw-SCPI-over-TCP. */
  const char SCPI_RAW_PROTOCOL[] = "scpi-raw";

  /** IANA assigned port for scpi-raw protocol. */
  const char SCPI_RAW_PORT[] = "5025";

  const char DEFAULT_PORT[] = "1394";
  /*
   * Types.
   * --------------------------------------------------------------------------
   */

  /** The SCPI session class. */
  class ScpiSession : public generic_io_t
  {
  public:
    /** Construct a SCPI session. */
    ScpiSession(
      /** Factory creating this session. */
      const SessionFactory &factory,
      /** Symbolic name of interface or device. */
      const ::std::string &name,
      /** Socket used for SCPI communication. */
      int socket)
    : generic_io_t(factory, name),
      mSocket(socket),
      mTimeout(0)
    {
      // empty
    }

  private:
    // Not implemented.
    ScpiSession(const ScpiSession &);
    ScpiSession &operator =(const ScpiSession &);


    /** Wait until device is ready for I/O or a timeout occurs. */
    GIO_ERROR
    wait(short events)
    {
      struct pollfd fd = { mSocket, events, 0 };
      int timeout = mTimeout
        ? mTimeout
        : -1;                       // infinite timeout

      switch (poll(&fd, 1, timeout)) {

      case 0:
        return GIO_ERR_IO_TIMEOUT;

      case 1:
        if (fd.revents & (POLLERR|POLLHUP)) {
          return GIO_ERR_IO_ERROR;
        }
        if (fd.revents & POLLNVAL) {
          return GIO_ERR_INVALID_ID;
        }
        return GIO_ERR_NO_ERROR;

      default:
        break;
      }

      return GIO_ERR_IO_ERROR;
    }

    /** Close and delete the session. */
    GIO_ERROR
    close(GIO_ERROR err)
    {
      // Close the SCPI session.
      gio_merge_errors_(
        err,
        (::close(mSocket) < 0) ? GIO_ERR_IO_ERROR : GIO_ERR_NO_ERROR);

      // NB: Errors must be reported before destroying the wrapper.
      gio_set_errno_(this, err);

      // Delete the session.
      delete this;

      return err;
    }

    /** Clear an interface or device. */
    GIO_ERROR
    clear(void)
    {
      // There is no common equivalent to a GPIB 'DCL' for a raw connection.
      // Agilent instruments provide a control port which offers this
      // operation, but the Keithley instruments we currently use do not.
      return GIO_ERR_NO_ERROR;
    }

    /** Write data. */
    GIO_ERROR
    write(
      /** Buffer containing data to be written. */
      const void *pBuffer,
      /** Amount of data to be written. */
      size_t len,
      /** Send last byte with END indicator. */
      bool_t end,
      /** OUT: Actual number of bytes written. */
      size_t *pActual)
    {
      size_t totalWritten = 0;
      GIO_ERROR err = GIO_ERR_NO_ERROR;
      do {
        if ((err = wait(POLLOUT)) == GIO_ERR_NO_ERROR) {
          ssize_t didWrite = ::write(mSocket,
                                     (char *)pBuffer + totalWritten,
                                     len - totalWritten);
          if (didWrite < 0) {
            err = GIO_ERR_IO_ERROR;
          } else {
            totalWritten += didWrite;
          }
        }
      } while (err == GIO_ERR_NO_ERROR && len > totalWritten);

      if (pActual) {
        *pActual = totalWritten;
      }

      return err;
    }

    /** Helper for sending simple commands. */
    GIO_ERROR
    write(
      /** Buffer containing command to be written. */
      const void *pBuffer)
    {
      return write(pBuffer, strlen((const char *)pBuffer), FALSE, NULL);
    }

    /** Read data. */
    GIO_ERROR
    read(
      /** Buffer into which data should be read. */
      void *pBuffer,
      /** Size of buffer. */
      size_t len,
      /** OUT: Reasons for termination. */
      int *pReasons,
      /** OUT: Actual number of bytes read. */
      size_t *pActual)
    {
      char *cBuffer = (char *)pBuffer;
      size_t totalRead = 0;
      int reasons = 0;
      GIO_ERROR err = GIO_ERR_NO_ERROR;
      do {
        if ((err = wait(POLLIN)) == GIO_ERR_NO_ERROR) {
          ssize_t didRead = ::read(mSocket,
                                   cBuffer + totalRead,
                                   len - totalRead);
          if (didRead < 0) {
            err = GIO_ERR_IO_ERROR;
          } else if (didRead == 0) {
            reasons = GIO_REASON_END;
          } else {
            if ((totalRead += didRead) == len) {
              reasons = GIO_REASON_REQCNT;
            }
            if (totalRead > 0 && cBuffer[totalRead-1] == '\n') {
              reasons |= GIO_REASON_CHR;
            }
          }
        }
      } while (err == GIO_ERR_NO_ERROR && reasons == 0);

      if (pReasons) {
        *pReasons = reasons;
      }
      if (pActual) {
        *pActual = totalRead;
      }

      return err;
    }

    /** Read status byte. */
    GIO_ERROR
    read_status_byte(
      /** OUT: Status byte. */
      uint8_t *pStb)
    {
      GIO_ERROR err = write("*STB?\n");
      if (err == GIO_ERR_NO_ERROR) {
        char buffer[256];
        size_t nRead;
        err = read(buffer, sizeof(buffer)-1, NULL, &nRead);

        if (err == GIO_ERR_NO_ERROR) {
          buffer[nRead] = '\0';

          /* Parse the <NR1 NUMERIC RESPONSE DATA> result. */
          char *endptr;
          long n = strtol(buffer, &endptr, 10);

          if ((endptr == buffer)                          // empty response
              || ((*endptr != '\0') && (*endptr != '\n')) // trailing junk
              || (n < 0)                                  // value out of range
              || (n > 255))
          {
            err = GIO_ERR_BAD_FORMAT;

          } else if (pStb) {
            *pStb = (uint8_t)n;
          }
        }
      }
      return err;
    }

    /** Trigger device(s). */
    GIO_ERROR
    trigger(void)
    {
      return write("*TRG\n");
    }

    /** Switch device to local operation. */
    GIO_ERROR
    local(void)
    {
      // NB: This may be specific to Keithley instruments.
      return write("SYSTEM:LOCAL\n");
    }

    /** Switch device to remote operation. */
    GIO_ERROR
    remote(void)
    {
      // NB: This may be specific to Keithley instruments.
      return write("SYSTEM:REMOTE\n");
    }

    /** Send an IFC (interface clear) on a GPIB interface. */
    GIO_ERROR
    gpib_send_IFC(void)
    {
      // For SICL compatibility, we allow this function to be called
      // for raw-SCPI sessions, doing a DEVICE_CLEAR instead.
      // Some existing client code (in PV/TraceCal) relies on this.
      return clear();
    }

    /** Place all devices on a GPIB interface into local lockout mode. */
    GIO_ERROR
    gpib_local_lockout(void)
    {
      // NB: This may be specific to Keithley instruments.
      return write("SYSTEM:RWLOCK\n");
    }

    /** Set timeout. */
    GIO_ERROR
    set_timeout(
      /** New timeout. */
      uint32_t milliSeconds)
    {
      mTimeout = milliSeconds;

      return GIO_ERR_NO_ERROR;
    }

    /** Inquire current timeout. */
    GIO_ERROR
    get_timeout(
      /** OUT: Current timeout. */
      uint32_t *pMilliSeconds)
    {
      *pMilliSeconds = mTimeout;

      return GIO_ERR_NO_ERROR;
    }

    /** Inquire human-readable description of a given GIO(!) error code. */
    const char *
    get_error_str(
      /** Error code. */
      GIO_ERROR error)
    {
      switch (error) {

      case GIO_ERR_BAD_FORMAT:
        return "Badly formatted answer from device.";

      case GIO_ERR_DEVICE_NOT_ACCESSIBLE:
        return "Device not accessible.";

      case GIO_ERR_INVALID_ID:
        return "Invalid device ID.";

      case GIO_ERR_INVALID_SYMBOLIC_NAME:
        return "Invalid symbolic name.";

      case GIO_ERR_IO_ERROR:
        return "I/O error.";

      case GIO_ERR_IO_TIMEOUT:
        return "I/O timeout.";

      case GIO_ERR_NO_ERROR:
        return "No error.";

      case GIO_ERR_OUT_OF_RESOURCES:
        return "Out of resources.";

      default:
        break;
      }

      return 0;
    }

    /** Dummy function for testing purposes. */
    GIO_ERROR
    do_nothing(void)
    {
      return GIO_ERR_NO_ERROR;
    }


    /** Connection to instrument. */
    int mSocket;

    /** Current timeout. */
    uint32_t mTimeout;
  };

  /*
   * Local functions.
   * --------------------------------------------------------------------------
   */

  /** Try to connect the given socket to the given host and service. */
  bool
  openConnection(int socket, const string &hostname, const string &service)
  {
    struct addrinfo *pInfo = NULL;

    if (getaddrinfo(hostname.c_str(), service.c_str(), NULL, &pInfo) != 0) {
      // Could not resolve address.
      return false;
    }

    // Try every record in sequence.
    for (struct addrinfo *p = pInfo; p != NULL; p = p->ai_next) {
      if (connect(socket, p->ai_addr, p->ai_addrlen) == 0) {
        // Success!
        freeaddrinfo(pInfo);
        return true;
      }
    }

    // Couldn't connect to any of the addresses.
    freeaddrinfo(pInfo);
    return false;
  }
}

/*
 * SCPI session factory.
 * ----------------------------------------------------------------------------
 */

namespace hw_cor_hwio_GenericIo
{
  ScpiSessionFactory::ScpiSessionFactory(const ::std::string &prefix)
  : SessionFactory(prefix)
  {
    // empty
  }

  generic_io_t *
  ScpiSessionFactory::create(
    const ::std::string &name,
    generic_io_t *pDevice) const
  {
    // NB: There are no interface sessions for raw-SCPI instruments.
    //     We will open device sessions instead; this is compatible to SICL.
    const string::size_type slashPos = name.find('/');

    const string sname = name.substr(0, slashPos);

    // The symbolic name has the following structure:
    //
    // scpi-name ::= host [ ':' port ]
    const string::size_type colonPos = sname.find(':');
    if ((colonPos == 0) || (colonPos == sname.length()-1)) {
      // Error: empty hostname or port.
      gio_set_errno_(pDevice, GIO_ERR_INVALID_SYMBOLIC_NAME);
      return 0;
    }
    const string hostname = sname.substr(0, colonPos);

    // Create the socket.
    int scpiSocket = socket(PF_INET, SOCK_STREAM, 0);
    if (scpiSocket < 0) {
      gio_set_errno_(pDevice, GIO_ERR_OUT_OF_RESOURCES);
      return 0;
    }

    if (colonPos != string::npos) {
      // A port was given in the symbolic name - try to use it.
      const string port = sname.substr(colonPos+1);
      //if (!openConnection(scpiSocket, hostname, sname.substr(colonPos+1))) {
      if (!openConnection(scpiSocket, hostname, port)) {
        close(scpiSocket);
        gio_set_errno_(pDevice, GIO_ERR_DEVICE_NOT_ACCESSIBLE);
        return 0;
      }
    } else {
      // No port was given
      // First try  default port  ( used by keithley LAN direct connect)
      if (!openConnection(scpiSocket, hostname, DEFAULT_PORT))
      {
        // second try the standard service name and port number.
        if (!openConnection(scpiSocket, hostname, SCPI_RAW_PROTOCOL)
            && !openConnection(scpiSocket, hostname, SCPI_RAW_PORT))
        {
          close(scpiSocket);
          gio_set_errno_(pDevice, GIO_ERR_DEVICE_NOT_ACCESSIBLE);
          return 0;
        }
      }
    }

    // Try to set TCP_NODELAY option on the socket.
    int val = 1;
    if (setsockopt(scpiSocket, IPPROTO_TCP, TCP_NODELAY, &val, sizeof(val)) < 0) {
      cerr << "Failed to set TCP_NODELAY option for '" << hostname << "'." << endl;
    }

    // OK, we will use this connection for all further operations.
    generic_io_t *pIO = new (nothrow) ScpiSession(*this, name, scpiSocket);

    if (!pIO) {
      (void)close(scpiSocket);
      gio_set_errno_(pDevice, GIO_ERR_OUT_OF_RESOURCES);
      return 0;
    }

    // Friedemann reported that the Keithley 2701 requires this delay
    // (otherwise the first read from the device may hang).
    usleep(1000);

    return pIO;
  }

  GIO_ERROR
  ScpiSessionFactory::suspendSessionEvents(void)
  {
    return GIO_ERR_NO_ERROR;
  }

  GIO_ERROR
  ScpiSessionFactory::resumeSessionEvents(void)
  {
    return GIO_ERR_NO_ERROR;
  }
}
