/* -*-C++-*- */
/**
 * Management of RPC and VXI-11 connections to Network Instrument Servers.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 *
 * @file   Vxi11Server.cpp
 * @author Jens Kilian
 * @date   Created:  Wed Dec 19 15:53:29 2012
 ******************************************************************************
 */

#include "Vxi11Server.hpp"

#include <algorithm>
#include <cassert>
#include <cerrno>
#include <csignal>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <memory>
#include <vector>
using namespace ::std;

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <pthread.h>
#include <rpc/rpc.h>
#include <rpc/pmap_clnt.h>
#include <sys/ioctl.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include "gio_.hpp"
#include "vxi11.h"
#include "vxi11core.h"
#include "vxi11intr.h"
#include "vxi11_errors.hpp"
#include "Vxi11Link.hpp"
using namespace ::hw_cor_hwio_GenericIo;

/** RPC interrupt service routine.
 *
 * The RPC code generator doesn't seem to produce this prototype in any header
 * file (probably because the code using it is normally also auto generated).
 */
extern void device_intr_1(struct svc_req *rqstp, register SVCXPRT *transp);

namespace
{
  /*
   * Constants.
   * --------------------------------------------------------------------------
   */

  /**
   * Default RPC timeout value.
   *
   * We would like an "infinite" timeout, which is not possible; ten hours
   * should be sufficient.
   */
  const struct timeval kInfiniteTimeout = { 36000, 0 };

  /** Table of known LAN-to-GPIB gateways and their special quirks. */
  struct ServerQuirk
  {
    /** Gateway model. */
    const char *const mModel;
    /** Quirks. */
    const uint32_t mQuirks;

  } kQuirkTable[] = {
    // Keysight E5810A.
    { "E5810A", Vxi11Server::QUIRK_LONG_READ_CAUSES_DROPPED_BYTES },
    { "E5810",  Vxi11Server::QUIRK_LONG_READ_CAUSES_DROPPED_BYTES },
    { "",       Vxi11Server::QUIRK_LONG_READ_CAUSES_DROPPED_BYTES },

    // Keysight E5810B.  Assume it is similar to the E5810A.
    { "E5810B", Vxi11Server::QUIRK_LONG_READ_CAUSES_DROPPED_BYTES },

    // TAMS L488.
    { "L488", 0 },

    { NULL, 0 }
  };

  /*
   * Global variables.
   * --------------------------------------------------------------------------
   */

  /** Map from server name to Vxi11Server instance. */
  typedef map< string, weak_ptr<Vxi11Server> > ConnectionMap;
  /** Map of currently open server connections. */
  ConnectionMap gOpenConnections;

  /** Flag: SRQ callback RPC service has been initialized. */
  bool gSRQServiceInitialized = false;

  /** RPC transport structure for SRQ callback service. */
  SVCXPRT *gSRQServiceTransport = 0;

  /** Active file descriptors for SRQ callback service. */
  vector<struct pollfd> gSRQServiceFDs;

  /** Saved SIGPIPE action for SRQ callback service. */
  struct sigaction gOldSIGPIPEAction;

  /** Saved SIGIO action for SRQ callback service. */
  struct sigaction gOldSIGIOAction;

  /** Thread ID of the SIGIO handler thread. */
  pthread_t gSIGIOThread;

  /** Current blocking state of SIGIO. */
  int gSIGIOState = SIG_UNBLOCK;

  /*
   * Handling RPC callbacks
   * --------------------------------------------------------------------------
   *
   * These routines and the associated data are responsible for handling
   * callbacks from the Network Instrument Server to the client.
   *
   * In the VXI-11 protocol, SRQs cause an RPC request from the instrument
   * server to the client.  The library must provide an RPC server to process
   * these callbacks.  A normal RPC server handles requests using the function
   * @c svc_run(), which contains an endless loop, or by providing equivalent
   * code which performs additional tasks inside the main service loop.
   * This isn't suitable for a library which tries to hide the RPC machinery.
   *
   * Instead, we use the same approach as in the SICL LAN client, namely to
   * process RPC requests in an asynchronous signal handler.  This may not be
   * safe (because the set of functions which can be safely used in a signal
   * handler is quite small; it doesn't even include @c select(), and certainly
   * none of the functions from the RPC library).  An alternative might be
   * to use a dedicated RPC server thread.
   */

  /**
   * Block resp. unblock the SIGIO signal.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  setSIGIOState(
    /** New state of signal (SIG_BLOCK/SIG_UNBLOCK). */
    int state,
    /** Indicates function is called during initialization. */
    bool force)
  {
    gSIGIOState = state;

    if (force
        || (gSRQServiceInitialized
            && pthread_equal(pthread_self(), gSIGIOThread)))
    {
      sigset_t mask;

      sigemptyset(&mask);
      sigaddset(&mask, SIGIO);

      if (pthread_sigmask(state, &mask, 0) != 0) {
        return GIO_ERR_OS_ERROR;
      }
    }

    return GIO_ERR_NO_ERROR;
  }

  /**
   * (Re-)establish @c SIGIO handlers for RPC file descriptors.
   *
   * Set up asynchronous I/O via @c SIGIO for all the file descriptors
   * on which we are processing RPC requests.
   *
   * This routine must be called every time the set of RPC file descriptors
   * (@c svc_pollfd) may have changed - including every call to
   * @c svc_getreq_poll()!
   *
   * @return VOID
   */
  void
  resetAsyncIo(void)
  {
    const int pid  = getpid();
    const int flag = 1;

    if (gSRQServiceFDs.size() < svc_max_pollfd) {
      // New FDs have been added.
      struct pollfd empty = { -1, 0, 0 };
      gSRQServiceFDs.resize(svc_max_pollfd, empty);
    }

    for (int i = 0; i < svc_max_pollfd; ++i) {
      int svc_fd = svc_pollfd[i].fd;
      int our_fd = gSRQServiceFDs[i].fd;

      if ((svc_fd >= 0) && (our_fd < 0)) {
        // RPC service uses this FD, but we don't yet know it.
        if (fcntl(svc_fd, F_SETOWN, pid) == -1) {
          char buf[256];
          cerr << "resetAsyncIo: fcntl() error: "
               << strerror_r(errno, buf, sizeof(buf)) << endl;
        }
        if (ioctl(svc_fd, FIOASYNC, &flag) == -1) {
          char buf[256];
          cerr << "resetAsyncIo: ioctl() error: "
               << strerror_r(errno, buf, sizeof(buf)) << endl;
        }

        gSRQServiceFDs[i] = svc_pollfd[i];

      } else if ((svc_fd < 0) && (our_fd >= 0)) {
        // RPC service no longer uses this FD.
        gSRQServiceFDs[i].fd = -1;

      } else {
        // We assume that a given FD never moves to another slot in the array.
        assert(svc_fd == our_fd);
      }
    }
  }

  /**
   * (Re-)initialize RPC file descriptor monitoring.
   *
   * Completely (re)initialize the set of file descriptors
   * on which we are waiting for asynchronous I/O.
   *
   * @return void
   */
  void
  initAsyncIo(void)
  {
    gSRQServiceFDs.clear();
    resetAsyncIo();
  }

  /**
   * Signal handler for @c SIGIO.
   *
   * This is basically the usual implementation of @c svc_run(),
   * except for the endless loop.  We only loop as long as
   * input is pending on one of our file descriptors.
   *
   * @return void
   */
  void
  asyncIoHandler(
    /** Signal ID - will be @c SIGIO. */
    int sig)
  {
    // Verify that this handler is being called from the correct thread.
    assert(pthread_equal(pthread_self(), gSIGIOThread));

    bool done = false;
    while (!done) {
      // Must copy the fd_set because select() can modify it.
      int ret = poll(&gSRQServiceFDs[0], gSRQServiceFDs.size(), 0);

      switch (ret) {

      case -1:
        if (errno != EINTR) {
          char buf[256];
          cerr << "asyncIoHandler: poll() error: "
               << strerror_r(errno, buf, sizeof(buf)) << endl;

          if (errno == EBADF) {
            // Try to recover from a possible out-of-sync set of FDs.
            initAsyncIo();
          }
          done = true;
        }
        break;

      case 0:
        done = true;
        break;

      default:
        svc_getreq_poll(&gSRQServiceFDs[0], ret);
        resetAsyncIo();
        break;
      }
    }

    // If a signal handler was already defined for SIGIO, call it now.
    if (gOldSIGIOAction.sa_handler != SIG_DFL
        && gOldSIGIOAction.sa_handler != SIG_IGN
        && gOldSIGIOAction.sa_handler != asyncIoHandler)
    {
      (gOldSIGIOAction.sa_handler)(sig);
    }
  }

  /**
   * Shut down the SRQ service and restore signal handlers.
   *
   * This routine is called at @c exit() time to stop serving SRQs.
   *
   * @return void
   */
  void
  stopSRQService(void)
  {
    svc_exit();
    svc_unregister(DEVICE_INTR, DEVICE_INTR_VERSION);
    svc_destroy(gSRQServiceTransport);
    gSRQServiceTransport = 0;

    sigaction(SIGPIPE, &gOldSIGPIPEAction, 0);
    sigaction(SIGIO,   &gOldSIGIOAction,   0);
  }

  /**
   * Start up the SRQ service.
   *
   * - Create and register the RPC service.
   * - Establish handlers for @c SIGPIPE (ignored) and @c SIGIO.
   * - Initialize the service, and arrange for shutdown at @c exit() time.
   *
   * @return boolean
   * @retval true  Operation succeeded.
   * @retval false An error has occurred.
   */
  bool
  startSRQService(void)
  {
    // Create and register the RPC service.
    pmap_unset(DEVICE_INTR, DEVICE_INTR_VERSION);
    gSRQServiceTransport = svctcp_create(RPC_ANYSOCK, 0, 0);
    if (gSRQServiceTransport != 0
        && svc_register(gSRQServiceTransport,
                        DEVICE_INTR, DEVICE_INTR_VERSION,
                        device_intr_1,
                        IPPROTO_TCP))
    {
      // Establish handlers for SIGPIPE (ignored) and SIGIO.
      //
      // We don't support multiple threads; SIGIO must be handled by the same
      // thread that called this function.
      struct sigaction action;
      action.sa_handler = SIG_IGN;
      sigemptyset(&action.sa_mask);
      action.sa_flags = 0;
      sigaction(SIGPIPE, &action, &gOldSIGPIPEAction);

      gSIGIOThread = pthread_self();

      action.sa_handler = asyncIoHandler;
      action.sa_flags = SA_RESTART;
      sigaction(SIGIO, &action, &gOldSIGIOAction);

      setSIGIOState(gSIGIOState, true);

      // Initialize the service, and arrange for shutdown. */
      initAsyncIo();
      atexit(stopSRQService);

      // OK.
      return true;
    }

    // Something went wrong.
    cerr << "Cannot create RPC service for receiving SRQs." << endl;
    return false;
  }

  /**
   * Create a VXI-11 Interrupt Channel.
   *
   * Instruct a Network Instrument Server to create an interrupt channel
   * for reporting SRQs.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation succeeded.
   * @retval other            An error has occurred.
   */
  GIO_ERROR
  createInterruptChannel(
    /** Identifies the Network Instrument Server. */
    CLIENT *pClient)
  {
    // Initialize the RPC service the first time through.
    if (!gSRQServiceInitialized) {
      gSRQServiceInitialized = startSRQService();
    }

    // Retrieve socket connection to server.
    int client_fd;
    if (!clnt_control(pClient, CLGET_FD, (char *)&client_fd)) {
      // Couldn't get client FD.
      return GIO_ERR_SYSTEM_ERROR;
    }

    // Determine the correct callback address.
    struct sockaddr_storage addr;
    struct sockaddr *pAddr = (struct sockaddr *)&addr;
    socklen_t addrLength = sizeof(addr);
    if ((getsockname(client_fd, pAddr, &addrLength) != 0)
        || (pAddr->sa_family != AF_INET))
    {
      // Cannot find the calback address for some reason.
      return GIO_ERR_SYSTEM_ERROR;
    }

    // Create the channel.
    Device_RemoteFunc params;
    params.hostAddr   = htonl(((struct sockaddr_in *)&addr)->sin_addr.s_addr);
    params.hostPort   = gSRQServiceTransport->xp_port;
    params.progNum    = DEVICE_INTR;
    params.progVers   = DEVICE_INTR_VERSION;
    params.progFamily = DEVICE_TCP;

    Device_Error result;
    enum clnt_stat status = create_intr_chan_1(&params, &result, pClient);
    return mapVXI11Error(status, result.error);
  }

  /**
   * Destroy a VXI-11 Interrupt Channel.
   *
   * Instruct a Network Instrument Server to destroy an existing interrupt
   * channel.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation succeeded.
   * @retval other            An error has occurred.
   */
  GIO_ERROR
  destroyInterruptChannel(
    /** Identifies the Network Instrument Server. */
    CLIENT *pClient)
  {
    Device_Error result;
    enum clnt_stat status = destroy_intr_chan_1(0, &result, pClient);
    return mapVXI11Error(status, result.error);
  }
}

namespace hw_cor_hwio_GenericIo
{
  Vxi11Server::Vxi11Server(const string &hostname,
                           CLIENT *pClient,
                           uint32_t quirks)
  : mHostname(hostname),
    mpClient(pClient),
    mQuirks(quirks),
    mInterruptChannelCreated(false)
  {
    // empty
  }

  Vxi11Server::~Vxi11Server(void)
  {
    // Sanity check - there should be no more open links on the server.
    assert(find_if(mOpenLinks.begin(), mOpenLinks.end(), isLinkOpen)
               == mOpenLinks.end());

    // Unregister this instance.
    gOpenConnections.erase(mHostname);

    // Disconnect from the Network Instrument Server.
    if (mInterruptChannelCreated) {
      // We can't report errors here.
      (void)destroyInterruptChannel(mpClient);
    }
    clnt_destroy(mpClient);
  }

  void
  Vxi11Server::setTimeout(uint32_t milliSeconds)
  {
    struct timeval timeout;
    if (milliSeconds > 0) {
      // Timeout is specified in milliseconds.
      timeout.tv_sec  =  milliSeconds * 2 / 1000;
      timeout.tv_usec = (milliSeconds * 2 % 1000) * 1000;

    } else {
      // Client has not set a timeout.
      timeout = kInfiniteTimeout;
    }

    if (!clnt_control(mpClient, CLSET_TIMEOUT, (char *)&timeout)) {
      cerr << "Warning: Failed to set RPC timeout for '" << mHostname << "'." << endl;
    }
  }

  shared_ptr<Vxi11Server>
  Vxi11Server::connect(const string &model,
                       const string &hostname,
                       generic_io_t *pIO)
  {
    // Check if the server has known quirks.
    int quirkIndex;
    for (quirkIndex = 0; kQuirkTable[quirkIndex].mModel != NULL; ++quirkIndex) {
      if (!strcasecmp(model.c_str(), kQuirkTable[quirkIndex].mModel)) {
        break;
      }
    }
    if (kQuirkTable[quirkIndex].mModel == NULL) {
      cerr << "Unknown VXI-11 server model '" << model << "'." << endl;
    }
    const uint32_t quirks = kQuirkTable[quirkIndex].mQuirks;

    // Try to find an existing server on the given host.
    ConnectionMap::const_iterator found = gOpenConnections.find(hostname);
    if (found != gOpenConnections.end()) {
      // Reuse this instance.
      shared_ptr<Vxi11Server> pServer = found->second.lock();
      assert(pServer.get());

      if (pServer->mQuirks != quirks) {
        cerr << "Inconsistent VXI-11 server models for '" << hostname << "'." << endl;
      }
      return pServer;
    }

    // Not found; must open a new connection.
    CLIENT *pClient =
      clnt_create(hostname.c_str(), DEVICE_CORE, DEVICE_CORE_VERSION, "tcp");
    if (!pClient) {
      gio_set_errno_(pIO, mapVXI11Error(rpc_createerr.cf_stat, GIO_ERR_NO_ERROR));
      return shared_ptr<Vxi11Server>();
    }

    int client_fd;
    if (clnt_control(pClient, CLGET_FD, (char *)&client_fd)) {
      // Try to set TCP_NODELAY option on the socket.
      const int val = 1;
      if (setsockopt(client_fd, SOL_TCP, TCP_NODELAY, &val, sizeof(val)) < 0) {
        cerr << "Failed to set TCP_NODELAY option for '" << hostname << "'." << endl;
      }
    } else {
      // Couldn't get client FD.
      clnt_destroy(pClient);
      gio_set_errno_(pIO, GIO_ERR_SYSTEM_ERROR);
      return shared_ptr<Vxi11Server>();
    }

    // Create the server instance.
    shared_ptr<Vxi11Server> pServer;
    try {
        /** @todo pServer = make_shared<Vxi11Server>(hostname, pClient, quirks); */
      pServer.reset(new Vxi11Server(hostname, pClient, quirks));

      // Register the new instance.
      gOpenConnections.insert(make_pair(hostname, pServer));

    } catch(bad_alloc &) {
      // Clean up.
      clnt_destroy(pClient);
      gio_set_errno_(pIO, GIO_ERR_OUT_OF_RESOURCES);
    }
  
    return pServer;
  }

  shared_ptr<Vxi11Link>
  Vxi11Server::openLink(const string &name, generic_io_t *pIO)
  {
    shared_ptr<Vxi11Link> pLink;

    // Check if a session with this name has already been opened.
    LinkMap::const_iterator found = mOpenLinks.find(name);
    if (found != mOpenLinks.end()) {
      // Try to reuse this instance.
      pLink = found->second.lock();
    }

    if (!pLink) {
      // No (currently) open session exists - open a new one.
      setTimeout(0);

      Create_LinkParms params;
      params.clientId     = (long)this; // useful for debugging
      params.lockDevice   = 0;
      params.lock_timeout = 0;
      params.device       = (char *)(name.c_str()); // const cast away

      Create_LinkResp result;
      enum clnt_stat status = create_link_1(&params, &result, mpClient);
      GIO_ERROR err = mapVXI11Error(status, result.error);
      if (err != GIO_ERR_NO_ERROR) {
        gio_set_errno_(pIO, err);
        return shared_ptr<Vxi11Link>();
      }

      try
      {
        /** @todo pLink = make_shared<Vxi11Link>(shared_from_this(), result); */
        pLink.reset(new Vxi11Link(shared_from_this(), result));

        // Register the new instance.
        mOpenLinks[name] = pLink;

      } catch(bad_alloc &) {
        // Clean up.
        closeLink(result.lid);
        gio_set_errno_(pIO, GIO_ERR_OUT_OF_RESOURCES);
      }
    }

    return pLink;
  }

  bool
  Vxi11Server::isLinkOpen(const LinkMap::value_type &entry)
  {
    return !entry.second.expired();
  }

  void
  Vxi11Server::closeLink(Device_Link linkID)
  {
    Device_Error result;
    enum clnt_stat status = destroy_link_1(&linkID, &result, mpClient);

    // Because links are shared between sessions of the same name,
    // we cannot report the session responsible for the error.
    gio_set_errno_(0, mapVXI11Error(status, result.error));
  }

  GIO_ERROR
  Vxi11Server::enableInterrupts(void)
  {
    GIO_ERROR err = GIO_ERR_NO_ERROR;

    if (!mInterruptChannelCreated) {
      // Create an interrupt channel.
      err = createInterruptChannel(mpClient);
      if (err == GIO_ERR_NO_ERROR) {
        mInterruptChannelCreated = true;
      }
    }

    return err;
  }

  GIO_ERROR
  Vxi11Server::suspendEvents(void)
  {
    // Asynchronous events are handled via SIGIO, so we just need to block
    // the signal.  This prevents new events from being accepted via the RPC
    // callback service.
    return setSIGIOState(SIG_BLOCK, false);
  }

  GIO_ERROR
  Vxi11Server::resumeEvents(void)
  {
    // Unblock the SIGIO handler, restoring normal service.
    return setSIGIOState(SIG_UNBLOCK, false);
  }
}
