/* -*-C++-*- */
/**
 * An access method for instruments connected via RS-232.
 ******************************************************************************
 * (C) Copyright 2014 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 *
 * @file   Rs232Session.hpp
 * @author Jens Kilian
 * @date   Created:  Thu Jan 16 14:22:15 2014
 * @date   Modified: Thu Jan 16 14:24:06 2014 (Jens Kilian)
 ******************************************************************************
 */

#ifndef H56627A93_8258_4E7B_B74D_8779BB527F98_
#define H56627A93_8258_4E7B_B74D_8779BB527F98_

#include "SessionFactory.hpp"

namespace hw_cor_hwio_GenericIo
{
  /** Factory for RS-232 sessions. */
  class Rs232SessionFactory : public SessionFactory
  {
  public:
    /** Construct the RS-232 session factory. */
    Rs232SessionFactory(
      /** Symbolic name prefix for sessions created by this factory. */
      const ::std::string &prefix);

  private:
    // Not implemented.
    Rs232SessionFactory(const Rs232SessionFactory &);
    Rs232SessionFactory &operator =(const Rs232SessionFactory &);

    /** Create a session with the given local symbolic name. */
    virtual generic_io_t *
    create(
      /** Symbolic name of interface or device, without prefix. */
      const ::std::string &name,
      /** Associated device session (@c gio_get_interface() only). */
      generic_io_t *pDevice) const;

    /**
     * Suspend asynchronous events in all sessions created by this factory.
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    virtual GIO_ERROR
    suspendSessionEvents(void);

    /**
     * Resume asynchronous events in all sessions created by this factory.
     *
     * @attention
     * The factory is responsible for not losing events which occur
     * between suspension and resumption.  It must deliver pending events
     * after resumption, in the correct order.
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    virtual GIO_ERROR
    resumeSessionEvents(void);
  };
}

#endif /* H56627A93_8258_4E7B_B74D_8779BB527F98_ */
