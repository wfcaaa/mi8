/* -*-C++-*- */
/**
 * Error handling for the VXI-11 access method.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 *
 * @file   vxi11_errors.cpp
 * @author Jens Kilian
 * @date   Created:  Mon Dec  3 10:41:33 2001
 * @date   Modified: Fri Dec 21 12:51:56 2012 (Jens Kilian)
 *
 * This file implements the internal interfaces for error handling
 * within the VXI-11 access method.
 * ----------------------------------------------------------------------------
 */

#include "vxi11_errors.hpp"

namespace
{
  /**
   * Convert an RPC client status to a GIO error code.
   *
   * @attention
   * This function relies on the fact that RPC error codes are represented 1:1
   * within the GIO error codes.
   *
   * @return GIO_ERROR
   */
  GIO_ERROR
  mapError(
    /** RPC client status. */
    enum clnt_stat error)
  {
    if (error == RPC_SUCCESS) {
      return GIO_ERR_NO_ERROR;
    }
    return (GIO_ERROR)(error
                       - RPC_CANTENCODEARGS
                       + GIO_ERR_CANNOT_ENCODE_ARGUMENTS);
  }

  /**
   * Convert a GIO error code to an RPC client status.
   *
   * @attention
   * This function relies on the fact that RPC error codes are represented 1:1
   * within the GIO error codes.
   *
   * @return clnt_stat
   */
  enum clnt_stat
  mapError(
    /** GIO error code. */
    GIO_ERROR error)
  {
    if (error == GIO_ERR_NO_ERROR) {
      return RPC_SUCCESS;
    }
    return (enum clnt_stat)(error
                            - GIO_ERR_CANNOT_ENCODE_ARGUMENTS
                            + RPC_CANTENCODEARGS);
  }
}

namespace hw_cor_hwio_GenericIo
{
  GIO_ERROR
  mapVXI11Error(enum clnt_stat status, Device_ErrorCode error)
  {
    if (status != RPC_SUCCESS) {
      /*
       * An RPC error.
       */
      return mapError(status);
    }

    return (GIO_ERROR)error;
  }

  const char *
  getVXI11ErrorString(GIO_ERROR error)
  {
    const char *errorStrings[] = {
      "No error",
      "Syntax error",
      "Invalid symbolic name",
      "Device not accessible",
      "Invalid link identifier",
      "Parameter error",
      "Channel not established",
      0,
      "Operation not supported",
      "Out of resources",
      0,
      "Device locked by another link",
      "No lock held by this link",
      0,
      0,
      "I/O timeout",
      0,
      "I/O error",
      "OS error",
      0,
      0,
      "Invalid address",
      0,
      "Abort",
      0,
      0,
      0,
      0,
      0,
      "Channel already established"
    };

    if (error < GIO_ERR_CANNOT_ENCODE_ARGUMENTS) {
      if ((size_t)error < sizeof(errorStrings) / sizeof(const char *)) {
        // VXI-11 protocol error.
        return errorStrings[error];
      }

    } else if (error < GIO_ERR_NO_ACCESS_METHOD) {
      // RPC client error.
      return clnt_sperrno(mapError(error));
    }

    // Unknown error code.
    return 0;
  }
}
