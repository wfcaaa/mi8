/* -*-C++-*- */
/**
 * Error handling for the VXI-11 access method.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   vxi11_errors.hpp
 * @author Jens Kilian
 * @date   Created:  Mon Dec  3 10:28:23 2001
 * @date   Modified: Wed Dec 19 13:49:10 2012 (Jens Kilian)
 *
 * This file provides internal interfaces for error handling within
 * the VXI-11 access method.
 * ----------------------------------------------------------------------------
 */
#ifndef H09B37D18_7438_4BDD_8526_36CB4C9106FA_
#define H09B37D18_7438_4BDD_8526_36CB4C9106FA_

/*
 * System includes.
 * ----------------------------------------------------------------------------
 */

#include <rpc/rpc.h>

/*
 * Module includes.
 * ----------------------------------------------------------------------------
 */

#include "xoc/hw/cor/gio/gio.h"
#include "vxi11core.h"

namespace hw_cor_hwio_GenericIo
{
  /**
   * Encode an error from RPC or VXI-11 into GIO format.
   *
   * @return GIO_ERROR Encoded error code.
   */
  GIO_ERROR
  mapVXI11Error(
    /** RPC error code. */
    enum clnt_stat status,
    /** VXI-11 error code. */
    Device_ErrorCode error);

  /**
   * Inquire human-readable description of a given GIO(!) error code.
   *
   * @return const char * Description of error.
   */
  const char *
  getVXI11ErrorString(
    /** Error code. */
    GIO_ERROR error);
}

#endif /* H09B37D18_7438_4BDD_8526_36CB4C9106FA_ */
