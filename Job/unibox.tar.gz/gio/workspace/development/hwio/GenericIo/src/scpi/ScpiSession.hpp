/* -*-C++-*- */
/**
 * An access method for instruments which support raw SCPI over TCP.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 *
 * @file   ScpiSession.hpp
 * @author Jens Kilian
 * @date   Created:  Tue Dec 18 11:04:20 2012
 * @date   Modified: Fri Feb  8 15:31:12 2013 (Jens Kilian)
 *
 * This file implements an access method for controlling devices that support
 * raw SCPI transport over TCP (see, e.g., Agilent Technologies Application
 * Note 1465-29).
 ******************************************************************************
 */

#ifndef HE1D2E5AB_5000_4136_8871_41E81469FEC6_
#define HE1D2E5AB_5000_4136_8871_41E81469FEC6_

#include "SessionFactory.hpp"

namespace hw_cor_hwio_GenericIo
{
  /** Factory for SCPI sessions. */
  class ScpiSessionFactory : public SessionFactory
  {
  public:
    /** Construct the SCPI session factory. */
    ScpiSessionFactory(
      /** Symbolic name prefix for sessions created by this factory. */
      const ::std::string &prefix);

  private:
    // Not implemented.
    ScpiSessionFactory(const ScpiSessionFactory &);
    ScpiSessionFactory &operator =(const ScpiSessionFactory &);

    /** Create a session with the given local symbolic name. */
    virtual generic_io_t *
    create(
      /** Symbolic name of interface or device, without prefix. */
      const ::std::string &name,
      /** Associated device session (@c gio_get_interface() only). */
      generic_io_t *pDevice) const;

    /**
     * Suspend asynchronous events in all sessions created by this factory.
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    virtual GIO_ERROR
    suspendSessionEvents(void);

    /**
     * Resume asynchronous events in all sessions created by this factory.
     *
     * @attention
     * The factory is responsible for not losing events which occur
     * between suspension and resumption.  It must deliver pending events
     * after resumption, in the correct order.
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    virtual GIO_ERROR
    resumeSessionEvents(void);
  };
}

#endif /* HE1D2E5AB_5000_4136_8871_41E81469FEC6_ */
