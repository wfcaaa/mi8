/* -*-C++-*- */
/**
 * Helper class for managing access to RS-232 devices.
 ******************************************************************************
 * (C) Copyright 2014 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   Rs232Device.hpp
 * @author Jens Kilian
 * @date   Created:  Wed Feb  5 12:30:13 2014
 * @date   Modified: Fri Jan 15 10:59:37 2016 (Jens Kilian)
 *
 ******************************************************************************
 */

#ifndef HD9E8F231_3EE9_49AB_A40C_487834A74306_
#define HD9E8F231_3EE9_49AB_A40C_487834A74306_

#include <pthread.h>
#include <string>
#include <termios.h>

namespace hw_cor_hwio_GenericIo
{
  /** Wrapper for an RS-232 device.
   *
   * Instances of this class are used to gain access to RS-232 devices
   * and to protect them from concurrent access.
   */
  class Rs232Device
  {
  public:
    /** Get an Rs232Device object for the device with the given name.
     *
     * If the device has been opened already, this function just increments
     * its reference count.
     *
     * @return NULL (with errno set) if an error occurs.
     */
    static Rs232Device *
    open(
      /** Name of a device file. */
      const ::std::string &deviceName);

    /** Close the device (once the last reference disappears).
     *
     * @return 0 on success, -1 (with errno set) if an error occurs.
     */
    void
    close(void);

    /** Return the device's file handle. */
    operator int(void) const
    {
      return mHandle;
    }

    /** Lock the device.
     *
     * @return true on success, false (with errno set) if an error occurs.
     */
    bool
    lock(void);

    /** Unlock the device.
     *
     * @return true on success, false (with errno set) if an error occurs.
     */
    bool
    unlock(void);
    
  private:
    // Not to be implemented.
    Rs232Device(const Rs232Device &);
    Rs232Device &operator =(const Rs232Device &);

    /** Create a new instance of the class. */
    Rs232Device(
      /** Name of device file. */
      const ::std::string &name,
      /** Handle of device file. */
      int handle,
      /** Handle of lock file protecting the device. */
      int lock);

    /** Destroy the instance. */
    ~Rs232Device(void);

    /** Name of the device file. */
    const ::std::string mName;

    /** Reference count. */
    long mReferenceCount;

    /** Handle of the device file. */
    int mHandle;

    /** Handle of a lock file protecting the device. */
    int mLock;

    /** Mutex protecting the device. */
    pthread_mutex_t mMutex;
  };
}

#endif /* HD9E8F231_3EE9_49AB_A40C_487834A74306_ */
