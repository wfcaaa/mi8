/* -*-C++-*- */
/**
 * An access method for VXI-11 Network Instrument Servers.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   Vxi11Session.cpp
 * @author Jens Kilian
 * @date   Created:  Thu Dec 20 09:16:49 2012
 ******************************************************************************
 */

#include "Vxi11Session.hpp"

#include <map>
#include <memory>
#include <cassert>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <fstream>
using namespace ::std;

#include <rpc/rpc.h>

#include "xoc/hw/cor/gio/gio.h"

#include "generic_io_t.hpp"
#include "gio_.hpp"
using namespace ::hw_cor_hwio_GenericIo;

#include "vxi11.h"
#include "vxi11core.h"
#include "vxi11intr.h"
#include "vxi11_errors.hpp"
#include "Vxi11Server.hpp"

ofstream mlogFile;
namespace
{
  /*
   * Constants.
   * --------------------------------------------------------------------------
   */

  /** Prefix of VXI-11.3 instrument names. */
  const char INSTRUMENT_PREFIX[] = { 'i', 'n', 's', 't' };

  /**
   * The GPIB "local lockout" command.
   *
   * This sequence of bytes represents the GPIB command @c LLO;
   * it is used in the function @c vxi11_gpib_local_lockout().
   */
  const char LLO[] = { 0x11 };

  /*
   * Local functions.
   * --------------------------------------------------------------------------
   */

  /**
   * Check if a symbolic name refers to a VXI-11.3 instrument.
   *
   * According to VXI-11.3, instruments which directly support VXI-11 operation
   * use symbolic names of the form 'inst<N>', with N an integer.
   *
   * @return bool Indicates if the name is of the required form.
   */
  bool
  isInstrumentName(
    /** Name to be checked. */
    const string &name)
  {
    // Check length - the name must be strictly longer than INSTRUMENT_PREFIX.
    const size_t prefixLength = sizeof(INSTRUMENT_PREFIX);
    const size_t nameLength = name.length();

    if (nameLength <= prefixLength) {
      return false;
    }

    // Check prefix.
    if (strncmp(name.c_str(), INSTRUMENT_PREFIX, prefixLength) != 0) {
      return false;
    }

    // Check that prefix is followed only by digits.
    for (size_t i = prefixLength; i < nameLength; ++i) {
      if (!isdigit(name[i])) {
        return false;
      }
    }

    // Yes, this is the name of an instrument.
    return true;
  }

  /**
   * Check if a symbolic name refers to a VXI-11.2 device session.
   *
   * Device session names end in a comma-separated GPIB address.
   *
   * @return bool Indicates if the name refers to a device session.
   */
  bool
  isDeviceName(
    /** Name to be checked. */
    const string &name)
  {
    if (isInstrumentName(name)) {
      // Can't be a VXI-11.2 session.
      return false;
    }

    const string::size_type commaPos = name.rfind(',');
    if (commaPos == string::npos) {
      // Not a device session.
      return false;
    }

    // We could check if the address part contains only digits, but that
    // would be redundant (the server will reject invalid addresses anyway).
    // Note that VXI-11 doesn't support the ',cmdr' form for commander
    // sessions.
    return true;
  }

  /**
   * Get the name of an interface session for the given device session name.
   *
   * @return string Name of the interface session.
   */
  string
  getInterfaceName(
    /** Name of device session. */
    const string &name)
  {
    const string::size_type commaPos = name.rfind(',');
    assert(commaPos != string::npos);

    return name.substr(0, commaPos);
  }

  /*
   * Type definitions.
   * --------------------------------------------------------------------------
   */

  /** The VXI-11 session class. */
  class Vxi11Session : public generic_io_t
  {
  public:
    /**
     * SRQ 'handle' data for identifying the source of a callback.
     *
     * This data structure is created when an SRQ handler for a session
     * is first set up.  It is sent to the Network Instrument Server, which
     * doesn't interpret it; when an SRQ occurs, the server sends it back
     * as part of a callback (using a VXI-11 Interrupt Channel to the client).
     *
     * The actual data sent to the server (and returned by it) is a raw
     * byte stream; the @c vxi11_SRQ_union_t type is used for conversion.
     */
    struct SRQHandle {
      /** SRQ source. */
      Vxi11Session *mpSource;
      /** Used for double-checking link integrity. */
      Device_Link mLinkID;
    };

    /**
     * Union used to convert between a vxi11_SRQ_handle_t and raw data.
     *
     * @attention
     * This works because the Network Instrument Server only uses the data
     * to send it back to the client which originated it; thus there are
     * no problems involving different byte orders or structure formats.
     */
    union SRQUnion {
      /** Structured data. */
      SRQHandle mHandle;
      /** Raw byte stream. */
      char mRaw[sizeof(SRQHandle)];
    };

    /** Construct a VXI-11 session. */
    Vxi11Session(
      /** Factory creating this session. */
      const SessionFactory &factory,
      /** Symbolic name of interface or device. */
      const ::std::string &name,
      /** VXI-11 link identifying the session. */
      const shared_ptr<Vxi11Link> &pLink,
      /** VXI-11 link of associated interface session, if any. */
      const shared_ptr<Vxi11Link> &pInterface)
    : generic_io_t(factory, name),
      mpLink(pLink),
      mpInterface(pInterface),
      mTermChar(-1),            // no termination character defined
      mTimeout(0),              // timeouts disabled
      mLockWait(FALSE),         // no waiting for locks
      mSRQEnabled(FALSE)        // SRQ handling disabled
    {
      // empty
    }

    /** Handle an SRQ callback. */
    void
    handleSRQ(
      /** SRQ handle data passed by VXI-11 server. */
      const SRQUnion &u)
    {
      // Verify validity of received data (not very thoroughly, though).
      if (mpLink->linkID() == u.mHandle.mLinkID) {
        if (mSRQEnabled && mpSRQCallback) {
          // OK, notify generic layer.
          mpSRQCallback(this);
        }
      }
    }

  private:
    // Not implemented.
    Vxi11Session(const Vxi11Session &);
    Vxi11Session &operator =(const Vxi11Session &);


    /** Close and delete the session. */
    GIO_ERROR
    close(GIO_ERROR err)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      // Delete the session.
      delete this;

      return GIO_ERR_NO_ERROR;
    }

    /** Clear an interface or device. */
    GIO_ERROR
    clear(void)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_GenericParms params;
      params.lid          = mpLink->linkID();
      params.flags        = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.lock_timeout = mTimeout;
      params.io_timeout   = mTimeout;

      Device_Error result;
      enum clnt_stat status = device_clear_1(&params, &result, *pServer);
      return mapVXI11Error(status, result.error);
    }

    /** Write data. */
    GIO_ERROR
    write(
      /** Buffer containing data to be written. */
      const void *pBuffer,
      /** Amount of data to be written. */
      size_t len,
      /** Send last byte with END indicator. */
      bool_t end,
      /** OUT: Actual number of bytes written. */
      size_t *pActual)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      size_t totalWritten = 0;
      GIO_ERROR err = GIO_ERR_NO_ERROR;
      do {
        const size_t toWrite = len - totalWritten;
        const size_t maxSize = mpLink->maxRecvSize();
        const size_t chunkSize = (toWrite < maxSize) ? toWrite : maxSize;

        Device_WriteParms params;
        params.lid           = mpLink->linkID();
        params.io_timeout    = mTimeout;
        params.lock_timeout  = mTimeout;
        params.flags         =
          ( (end && toWrite == chunkSize) ? VXI11_FLAG_END : 0)
          | (mLockWait ? VXI11_FLAG_WAITLOCK : 0);
        params.data.data_len = (unsigned int)chunkSize;
        params.data.data_val = (char *)pBuffer + totalWritten;

        Device_WriteResp result;
        enum clnt_stat status = device_write_1(&params, &result, *pServer);
        if ((err = mapVXI11Error(status, result.error)) == GIO_ERR_NO_ERROR) {
          totalWritten += result.size;
        }
      } while (err == GIO_ERR_NO_ERROR && len > totalWritten);

      if (pActual) {
        *pActual = totalWritten;
      }
  
      return err;
    }

    /** Read data. */
    GIO_ERROR
    read(
      /** Buffer into which data should be read. */
      void *pBuffer,
      /** Size of buffer. */
      size_t len,
      /** OUT: Reasons for termination. */
      int *pReasons,
      /** OUT: Actual number of bytes read. */
      size_t *pActual)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_ReadParms params;
      params.lid          = mpLink->linkID();
      params.requestSize  = (long)len;
      params.io_timeout   = mTimeout;
      params.lock_timeout = mTimeout;
      params.flags        = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      if (mTermChar < 0) {
        params.termChar   = 0;
      } else {
        params.flags     |= VXI11_FLAG_TERMCHRSET;
        params.termChar   = (char)mTermChar;
      }
  
      // The VXI-11 server may choose to break up a read request into smaller
      // chunks.  This causes problems with some instruments, e.g., a loss of
      // one byte per 16384-byte chunk when reading from a Wavecrest TIA
      // (DTS-1000 or DTS-2077) using a Keysight E5810A Lan-to-GPIB gateway.
      //
      // To work around this problem, we use the following strategy:
      // - Start off by issuing a normal read request.
      // - If the original request was not satisfied, read additional chunks
      //   using an interface session instead of a device session.  This avoids
      //   readressing the GPIB device for each chunk.
      size_t totalRead = 0;
      int reasons = 0;
      GIO_ERROR err = GIO_ERR_NO_ERROR;
      if(!mlogFile.is_open())
        mlogFile.open("/tmp/myLog.txt");
      do {
        Device_ReadResp result = { 0, 0, { 0, 0 } };
        enum clnt_stat status = device_read_1(&params, &result, *pServer);
        if(mlogFile.is_open())
          mlogFile<<"the error code of device_read_1 is:"<<result.error<<endl;
        if ((err = mapVXI11Error(status, result.error)) == GIO_ERR_NO_ERROR) {
          memcpy((char *)pBuffer + totalRead,
                 result.data.data_val,
                 result.data.data_len);

          params.requestSize -= result.data.data_len;
          totalRead += result.data.data_len;
        }
        reasons = (int)(result.reason);
        xdr_free((xdrproc_t)xdr_Device_ReadResp, (char *)&result);

        if (mpInterface) {
          // Use associated interface session for any further requests.
          params.lid = mpInterface->linkID();
        }
      } while (err == GIO_ERR_NO_ERROR && reasons == 0);
      mlogFile.close();
      if (pReasons) {
        *pReasons = reasons;
      }
      if (pActual) {
        *pActual = totalRead;
      }

      return err;
    }

    /** Read status byte. */
    GIO_ERROR
    read_status_byte(
      /** OUT: Status byte. */
      uint8_t *pStb)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_GenericParms params;
      params.lid          = mpLink->linkID();
      params.flags        = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.lock_timeout = mTimeout;
      params.io_timeout   = mTimeout;

      Device_ReadStbResp result;
      enum clnt_stat status = device_readstb_1(&params, &result, *pServer);
      GIO_ERROR err = mapVXI11Error(status, result.error);

      if (err == GIO_ERR_NO_ERROR && pStb) {
        *pStb = result.stb;
      }

      return err;
    }

    /** Trigger device(s). */
    GIO_ERROR
    trigger(void)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_GenericParms params;
      params.lid          = mpLink->linkID();
      params.flags        = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.lock_timeout = mTimeout;
      params.io_timeout   = mTimeout;

      Device_Error result;
      enum clnt_stat status = device_trigger_1(&params, &result, *pServer);
      return mapVXI11Error(status, result.error);
    }

    /** Switch device to local operation. */
    GIO_ERROR
    local(void)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_GenericParms params;
      params.lid          = mpLink->linkID();
      params.flags        = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.lock_timeout = mTimeout;
      params.io_timeout   = mTimeout;

      Device_Error result;
      enum clnt_stat status = device_local_1(&params, &result, *pServer);
      return mapVXI11Error(status, result.error);
    }

    /** Switch device to remote operation. */
    GIO_ERROR
    remote(void)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_GenericParms params;
      params.lid          = mpLink->linkID();
      params.flags        = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.lock_timeout = mTimeout;
      params.io_timeout   = mTimeout;

      Device_Error result;
      enum clnt_stat status = device_remote_1(&params, &result, *pServer);
      return mapVXI11Error(status, result.error);
    }

    /** Lock an interface or device. */
    GIO_ERROR
    lock(void)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_LockParms params;
      params.lid          = mpLink->linkID();
      params.flags        = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.lock_timeout = mTimeout;

      Device_Error result;
      enum clnt_stat status = device_lock_1(&params, &result, *pServer);
      return mapVXI11Error(status, result.error);
    }

    /** Unlock an interface or device. */
    GIO_ERROR
    unlock(void)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_Link param;
      param = mpLink->linkID();

      Device_Error result;
      enum clnt_stat status = device_unlock_1(&param, &result, *pServer);
      return mapVXI11Error(status, result.error);
    }

    /** Send an IFC (interface clear) on a GPIB interface. */
    GIO_ERROR
    gpib_send_IFC(void)
    {
      // For SICL compatibility, we allow this function to be called
      // for VXI-11.3 device sessions, doing a DEVICE_CLEAR instead.
      // Some existing client code (in PV/TraceCal) relies on this.
      if (isInstrumentName(name())) {
        return clear();
      }
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_DocmdParms params;
      params.lid                 = mpLink->linkID();
      params.flags               = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.io_timeout          = mTimeout;
      params.lock_timeout        = mTimeout;
      params.cmd                 = VXI11_GPIB_CMD_IFC_CONTROL;
      params.network_order       = 1;
      params.datasize            = 0;
      params.data_in.data_in_len = 0;
      params.data_in.data_in_val = 0;

      Device_DocmdResp result = { 0, { 0, 0 } };
      enum clnt_stat status = device_docmd_1(&params, &result, *pServer);
      return mapVXI11Error(status, result.error);
    }

    /** Send a GPIB command. */
    GIO_ERROR
    gpib_send_cmd(
      /** Command to be sent. */
      const void *pCommand,
      /** Length of command. */
      size_t len)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      Device_DocmdParms params;
      params.lid                 = mpLink->linkID();
      params.flags               = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.io_timeout          = mTimeout;
      params.lock_timeout        = mTimeout;
      params.cmd                 = VXI11_GPIB_CMD_SEND_COMMAND;
      params.network_order       = 1;
      params.datasize            = 1;
      params.data_in.data_in_len = len;
      params.data_in.data_in_val = (char *)pCommand;

      Device_DocmdResp result = { 0, { 0, 0 } };
      enum clnt_stat status = device_docmd_1(&params, &result, *pServer);
      GIO_ERROR err = mapVXI11Error(status, result.error);
      xdr_free((xdrproc_t)xdr_Device_DocmdResp, (char *)&result);
  
      return err;
    }

    /** Inquire GPIB bus status. */
    GIO_ERROR
    gpib_bus_status(
      /** Request type. */
      GIO_GPIB_STATUS_REQUEST request,
      /** OUT: Status. */
      uint8_t *pResult)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      uint16_t tmp = htons(request); /* network order */
      Device_DocmdParms params;
      params.lid                 = mpLink->linkID();
      params.flags               = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.io_timeout          = mTimeout;
      params.lock_timeout        = mTimeout;
      params.cmd                 = VXI11_GPIB_CMD_BUS_STATUS;
      params.network_order       = 1;
      params.datasize            = 2;
      params.data_in.data_in_len = 2;
      params.data_in.data_in_val = (char *)&tmp;

      Device_DocmdResp result = { 0, { 0, 0 } };
      enum clnt_stat status = device_docmd_1(&params, &result, *pServer);
      GIO_ERROR err = mapVXI11Error(status, result.error);

      if (err == GIO_ERR_NO_ERROR && pResult) {
        // NB: VXI-11.2 mandates that the data size is 2.  We specified network
        //     byte order, so the result must be in the second byte.
        *pResult = result.data_out.data_out_val[1];
      }
      xdr_free((xdrproc_t)xdr_Device_DocmdResp, (char *)&result);

      return err;
    }

    /** Control the ATN (attention) line on a GPIB interface. */
    GIO_ERROR
    gpib_ATN_control(
      /** New status of ATN line. */
      bool_t enable)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      uint16_t tmp = htons(enable);  /* network order */
      Device_DocmdParms params;
      params.lid                 = mpLink->linkID();
      params.flags               = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.io_timeout          = mTimeout;
      params.lock_timeout        = mTimeout;
      params.cmd                 = VXI11_GPIB_CMD_ATN_CONTROL;
      params.network_order       = 1;
      params.datasize            = 2;
      params.data_in.data_in_len = 2;
      params.data_in.data_in_val = (char *)&tmp;

      Device_DocmdResp result = { 0, { 0, 0 } };
      enum clnt_stat status = device_docmd_1(&params, &result, *pServer);
      GIO_ERROR err = mapVXI11Error(status, result.error);
      xdr_free((xdrproc_t)xdr_Device_DocmdResp, (char *)&result);

      return err;
    }

    /** Control the REN (remote enable) line on a GPIB interface. */
    GIO_ERROR
    gpib_REN_control(
      /** New status of REN line. */
      bool_t enable)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      uint16_t tmp = htons(enable);  /* network order */
      Device_DocmdParms params;
      params.lid                 = mpLink->linkID();
      params.flags               = mLockWait ? VXI11_FLAG_WAITLOCK : 0;
      params.io_timeout          = mTimeout;
      params.lock_timeout        = mTimeout;
      params.cmd                 = VXI11_GPIB_CMD_REN_CONTROL;
      params.network_order       = 1;
      params.datasize            = 2;
      params.data_in.data_in_len = 2;
      params.data_in.data_in_val = (char *)&tmp;

      Device_DocmdResp result = { 0, { 0, 0 } };
      enum clnt_stat status = device_docmd_1(&params, &result, *pServer);
      GIO_ERROR err = mapVXI11Error(status, result.error);
      xdr_free((xdrproc_t)xdr_Device_DocmdResp, (char *)&result);

      return err;
    }

    /** Place all devices on a GPIB interface into local lockout mode. */
    GIO_ERROR
    gpib_local_lockout(void)
    {
      // This seems to be the way in which SICL implements igpibllo().
      return gpib_send_cmd(LLO, sizeof(LLO));
    }

    /** Enable resp.\ disable SRQ callbacks. */
    GIO_ERROR
    enable_SRQ_callback(
      /** New status. */
      bool_t enable)
    {
      auto pServer = mpLink->server();
      pServer->setTimeout(mTimeout);

      // Ensure that an interrupt channel is set up.
      GIO_ERROR err = pServer->enableInterrupts();
      if (err != GIO_ERR_NO_ERROR) {
        return err;
      }

      // Actually enable SRQs.
      SRQUnion u;
      u.mHandle.mpSource = this;
      u.mHandle.mLinkID  = mpLink->linkID();
  
      Device_EnableSrqParms params;
      params.lid               = mpLink->linkID();
      params.enable            = enable;
      params.handle.handle_len = sizeof(u.mRaw);
      params.handle.handle_val = u.mRaw;
  
      Device_Error result;
      enum clnt_stat status = device_enable_srq_1(&params, &result, *pServer);
      if ((err = mapVXI11Error(status, result.error)) == GIO_ERR_NO_ERROR) {
        mSRQEnabled = enable;
      }

      return err;
    }

    /** Set termination character. */
    GIO_ERROR
    set_termchr(
      /** New termination character. */
      int termChar)
    {
      if (termChar >= 0 && termChar <= 255) {
        mTermChar = termChar;
      } else {
        mTermChar = -1;
      }
      return GIO_ERR_NO_ERROR;
    }

    /** Inquire current termination character. */
    GIO_ERROR
    get_termchr(
      /** OUT: Termination character. */
      int *pTermChar)
    {
      if (pTermChar) {
        *pTermChar = mTermChar;
      }
      return GIO_ERR_NO_ERROR;
    }

    /** Set timeout. */
    GIO_ERROR
    set_timeout(
      /** New timeout. */
      uint32_t milliSeconds)
    {
      mTimeout = milliSeconds;
      return GIO_ERR_NO_ERROR;
    }

    /** Inquire current timeout. */
    GIO_ERROR
    get_timeout(
      /** OUT: Current timeout. */
      uint32_t *pMilliSeconds)
    {
      if (pMilliSeconds) {
        *pMilliSeconds = mTimeout;
      }
      return GIO_ERR_NO_ERROR;
    }

    /** Set lock waiting flag. */
    GIO_ERROR
    set_lock_wait(
      /** Lock waiting flag. */
      bool_t flag)
    {
      mLockWait = flag;
      return GIO_ERR_NO_ERROR;
    }

    /** Inquire current lock waiting flag. */
    GIO_ERROR
    get_lock_wait(
      /** OUT: Lock waiting flag. */
      bool_t *pFlag)
    {
      if (pFlag) {
        *pFlag = mLockWait;
      }
      return GIO_ERR_NO_ERROR;
    }

    /** Inquire human-readable description of a given GIO(!) error code. */
    const char *
    get_error_str(
      /** Error code. */
      GIO_ERROR error)
    {
      return getVXI11ErrorString(error);
    }

    /** Dummy function for testing purposes. */
    GIO_ERROR
    do_nothing(void)
    {
      return mapVXI11Error(RPC_SUCCESS, 0);
    }


    /** VXI-11 link for this session. */
    shared_ptr<Vxi11Link> mpLink;
    /** VXI-11 link for the associated interface session (if any). */
    shared_ptr<Vxi11Link> mpInterface;

    /** Current termination character. */
    int mTermChar;
    /** Current timeout. */
    uint32_t mTimeout;
    /** Current lock waiting flag. */
    bool_t mLockWait;
    /** Flag indicating whether SRQ callbacks are enabled. */
    bool_t mSRQEnabled;
  };

  /** Open a new session. */
  Vxi11Session *
  openSession(
    /** Factory creating this session. */
    const SessionFactory &factory,
    /** Symbolic name of interface or device, without prefix. */
    const ::std::string &name,
    /** Associated device session (@c gio_get_interface() only). */
    generic_io_t *pDevice = 0)
  {
    // The symbolic name has the following structure:
    //
    // vxi11-name    ::= [ model '/' ] host / internal-name
    // model         ::= 'e5810a' | 'l488' | ...
    // host          ::= ...
    // internal-name ::= 'gpib0' [ ',' address ]
  
    // Extract up to 2 '/'-terminated prefixes.
    string prefix[2];
    string::size_type pos = 0;

    int numberOfPrefixes = 0;
    while (numberOfPrefixes < 2) {
      string::size_type slashPos = name.find('/', pos);
      if (slashPos == string::npos) {
        // No (more) prefix.
        break;

      } else if (slashPos == pos) {
        // Error: empty prefix.
        gio_set_errno_(pDevice, GIO_ERR_INVALID_SYMBOLIC_NAME);
        return 0;
      }

      prefix[numberOfPrefixes] = name.substr(pos, slashPos-pos);
      pos = slashPos + 1;

      ++numberOfPrefixes;
    }

    // Determine model, hostname and local name.
    string model, hostname;

    switch (numberOfPrefixes) {

    case 0:
      // Missing hostname.
      gio_set_errno_(pDevice, GIO_ERR_INVALID_SYMBOLIC_NAME);
      return 0;

    case 1:
      // No model, only hostname.
      hostname = prefix[0];
      break;

    case 2:
      // Both model and hostname.
      model = prefix[0];
      hostname = prefix[1];
      break;

    default:
      // This can't happen.
      cerr << "Internal error while decoding VXI-11 symbolic name." << endl;
      abort();
    }

    string localName = name.substr(pos);

    // Open a connection to the server.
    shared_ptr<Vxi11Server> pServer = Vxi11Server::connect(model, hostname, pDevice);
    if (!pServer) {
      return 0;
    }

    // Create a VXI-11 link to the interface resp. device.
    shared_ptr<Vxi11Link> pLink = pServer->openLink(localName, pDevice);
    if (!pLink) {
      return 0;
    }

    // If the server has the "long read" quirk, and if we are trying to open
    // a VXI-11.2 device session, find or create an associated
    // interface session (which is needed to work around the problem).
    shared_ptr<Vxi11Link> pInterface;
    if (pServer->hasQuirk(Vxi11Server::QUIRK_LONG_READ_CAUSES_DROPPED_BYTES)
        && isDeviceName(name))
    {
      pInterface = pServer->openLink(getInterfaceName(localName), pDevice);
      if (!pInterface) {
        return 0;
      }
    }

    // Create the session instance.
    Vxi11Session *pIO =
      new (nothrow) Vxi11Session(factory, name, pLink, pInterface);
    if (!pIO) {
      gio_set_errno_(pDevice, GIO_ERR_OUT_OF_RESOURCES);
    }

    return pIO;
  }
}

/*
 * RPC service routines.
 * ----------------------------------------------------------------------------
 */

/**
 * RPC procedure handling callbacks from the Network Instrument Server.
 *
 * This routine is called by the RPC service handling the VXI-11 Interrupt
 * Channel.  Its only function is to identify the source of an SRQ and to
 * notify the generic layer that an SRQ occurred.
 *   
 * @return bool_t
 * @retval TRUE  Send a reply packet.
 * @retval FALSE Do not send a reply packet.
 */
bool_t
device_intr_srq_1_svc(
  /** Pointer to (VXI-11 defined) parameter structure. */
  Device_SrqParms *pParams,
  /** Dummy result (not used, request returns 'void'). */
  void *pDummy,
  /** Structure describing the RPC request. */
  struct svc_req *pRequest)
{
  // Decode the handle passed by the Network Instrument Server.
  Vxi11Session::SRQUnion u;
  if (pParams->handle.handle_len == sizeof(u.mRaw)) {
    memcpy(u.mRaw, pParams->handle.handle_val, sizeof(u.mRaw));

    // Call the session's handler.
    u.mHandle.mpSource->handleSRQ(u);
  }

  // The VXI-11 standard defines device_intr_srq to be a 'one-way' call,
  // i.e., we must not send a reply.  There are VXI-11 servers (e.g.,
  // the TAMS L488 LAN-to-GPIB gateway) which cannot handle unexpected
  // reply packets.
  //
  // NB: There seems to be no documentation for the return value
  //     of an RPC server callback function (especially not for the
  //     threadsafe variant that we use).  We used to treat it as
  //     a success/error code, which apparently is wrong.
  return FALSE;
}

/** Dummy function.
 *
 * This routine is called by the RPC service to free memory after
 * a callback via the VXI-11 Interrupt Channel.  Since the only request
 * defined by the interrupt protocol has no result, this function
 * doesn't actually have to do anything.
 *   
 * @return int
 * @retval TRUE  Operation succeeded.
 * @retval FALSE An error occurred.
 */
int
device_intr_1_freeresult(
  /** RPC service descriptor. */
  SVCXPRT *SVC,
  /** RPC procedure descriptor. */
  xdrproc_t proc,
  /** Dummy result. */
  caddr_t dummy)
{
  return TRUE;
}

/*
 * VXI-11 session factory.
 * ----------------------------------------------------------------------------
 */

namespace hw_cor_hwio_GenericIo
{
  Vxi11SessionFactory::Vxi11SessionFactory(const ::std::string &prefix)
  : SessionFactory(prefix)
  {
    // Check consistency of definitions in GIO layer.
    //
    // We require some of the enum types in the GIO layer to be compatible
    // with VXI-11, to reduce the conversion overhead.
    assert(GIO_REASON_REQCNT == (int)VXI11_REASON_REQCNT
               && GIO_REASON_CHR == (int)VXI11_REASON_CHR
               && GIO_REASON_END == (int)VXI11_REASON_END);

    assert(GIO_GPIB_STATUS_REMOTE == (int)VXI11_GPIB_STATUS_REMOTE
               && GIO_GPIB_STATUS_SRQ == (int)VXI11_GPIB_STATUS_SRQ
               && GIO_GPIB_STATUS_NDAC == (int)VXI11_GPIB_STATUS_NDAC
               && GIO_GPIB_STATUS_SYSTEM_CONTROLLER == (int)VXI11_GPIB_STATUS_SYSTEM_CONTROLLER
               && GIO_GPIB_STATUS_CONTROLLER_IN_CHARGE == (int)VXI11_GPIB_STATUS_CONTROLLER_IN_CHARGE
               && GIO_GPIB_STATUS_TALKER == (int)VXI11_GPIB_STATUS_TALKER
               && GIO_GPIB_STATUS_LISTENER == (int)VXI11_GPIB_STATUS_LISTENER
               && GIO_GPIB_STATUS_BUS_ADDRESS == (int)VXI11_GPIB_STATUS_BUS_ADDRESS);
  }

  generic_io_t *
  Vxi11SessionFactory::create(
    const ::std::string &name,
    generic_io_t *pDevice) const
  {
    if (!pDevice) {
      // Session explicitly opened by client (@c gio_open()).
      return openSession(*this, name);
    }

    // Session implicitly opened (@c gio_get_interface()).
    const string interfaceName = getInterfaceName(name);

    // Try to open a new interface session.
    return openSession(*this, interfaceName, pDevice);
  }

  GIO_ERROR
  Vxi11SessionFactory::suspendSessionEvents(void)
  {
    return Vxi11Server::suspendEvents();
  }

  GIO_ERROR
  Vxi11SessionFactory::resumeSessionEvents(void)
  {
    return Vxi11Server::resumeEvents();
  }
}
