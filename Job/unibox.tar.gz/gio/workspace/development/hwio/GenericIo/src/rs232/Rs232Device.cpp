/* -*-C++-*- */
/**
 * Helper class for managing access to RS-232 devices.
 ******************************************************************************
 * (C) Copyright 2014 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   Rs232Device.cpp
 * @author Jens Kilian
 * @date   Created:  Wed Feb  5 12:49:21 2014
 * @date   Modified: Fri Jan 15 11:14:34 2016 (Jens Kilian)
 * 
 * We use a two-level strategy for protecting against concurrent access
 * to RS-232 devices, to ensure that it works across process boundaries:
 *
 * - Within the same process, a thread must first acquire a mutex associated
 *   with the device it wants to lock.
 *
 * - When the mutex has been acquired, the thread must lockf(3) a file
 *   associated with the device to protect against access from other processes.
 *
 * Alternative mechanisms that were considered are
 *
 * - POSIX semaphores; these cause problems when processes crash or are
 *   terminated by signals.  (A POSIX semaphore is not released when
 *   the process holding it is terminated.)
 *
 * - Plain file locking without the additional mutex.  This may work on Linux,
 *   but is not portable (on other systems, file locks are managed per process,
 *   not per thread).
 *
 * - UUCP lock files (lockdev(3)).  Although this is the standard convention
 *   for locking terminal devices, it would be very slow to take and release
 *   a lock for every GIO function (as we want to do).
 *
 *   NB: Not using the 'lockdev' convention means that GIO clients must not
 *       use devices that are also accessed by tools like getty, uucp etc.
 *       This should not be a problem in practice.
 *
 * - Locking the device file itself instead of a separate file.  This works
 *   as long as nobody else EVER opens and closes the device, even a library
 *   function that only wants to look at its status (file locks are dropped
 *   when ANY file descriptor referring to the device is closed).
 *
 *
 * Background on why file locking is so broken in POSIX systems:
 *
 *   https://www.samba.org/samba/news/articles/low_point/tale_two_stds_os2.html
 *
 ******************************************************************************
 */

#include "Rs232Device.hpp"

#include <algorithm>
#include <cassert>
#include <cerrno>
#include <cstdio>
#include <map>
#include <new>

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <termios.h>
#include <unistd.h>

using namespace ::std;

/*
 * Global variables.
 * ----------------------------------------------------------------------------
 */

namespace
{
  using namespace hw_cor_hwio_GenericIo;

  /** RAII guard for pthread mutexes. */
  struct Guard
  {
    Guard(pthread_mutex_t &mutex)
    : mMutex(mutex),
      mLocked(pthread_mutex_lock(&mMutex) == 0)
    {
      // empty
    }

    ~Guard(void)
    {
      if (mLocked) {
        pthread_mutex_unlock(&mMutex);
      }
    }

    bool
    locked(void) const
    {
      return mLocked;
    }

  private:
    pthread_mutex_t &mMutex;
    const bool mLocked;
  };

  /** Prefix of lock file names. */
  const char kLockPrefix[] = "/tmp/Advantest_V93K";

  /** Map holding all open devices. */
  map<string, Rs232Device *> gOpenDevices;

  /** Mutex protecting the map of open devices. */
  pthread_mutex_t gOpenDeviceLock = PTHREAD_MUTEX_INITIALIZER;
}

/*
 * Implementation.
 * ----------------------------------------------------------------------------
 */

namespace hw_cor_hwio_GenericIo
{
  Rs232Device *
  Rs232Device::open(const string &deviceName)
  {
    Guard guard(gOpenDeviceLock);
    assert(guard.locked());

    // Check if the device is already open.
    const map<string, Rs232Device *>::const_iterator found = gOpenDevices.find(deviceName);
    if (found != gOpenDevices.end()) {
      ++(found->second->mReferenceCount);
      return found->second;
    }

    // Try to open the device.
    int handle = ::open(deviceName.c_str(), O_RDWR | O_NOCTTY);
    if (handle < 0) {
      return 0;
    }
    if (fcntl(handle, F_SETFD, FD_CLOEXEC) < 0) {
      ::close(handle);
      return 0;
    }

    // Put the device into raw (non-canonical) mode.
    struct termios tio;
    if (tcgetattr(handle, &tio) < 0) { 
      ::close(handle);
      return 0;
    }

    tio.c_iflag &=
      ~(IGNBRK | BRKINT                          // break -> '\0'
        | IGNPAR | PARMRK                        // parity error -> '\0'
        | ISTRIP | INLCR | IGNCR | ICRNL | IUCLC // pass data unchanged
        | IXANY);                                // only XON restarts flow

    tio.c_oflag &=
      ~OPOST;                                    // pass data unchanged

    tio.c_cflag |=
      CLOCAL | CREAD;                            // enable receiver

    tio.c_lflag &=
      ~(ECHO | ECHONL                            // no echo
        | ISIG                                   // no signals
        | ICANON | IEXTEN);                      // no line editing

    /** @todo set MIN=1, TIME=0? */

    if (tcsetattr(handle, TCSADRAIN, &tio) < 0) {
      ::close(handle);
      return 0;
    }

    // Try to open the lock file protecting the device.
    // NB: Any '/' characters in the device name must be replaced.
    string lockName = kLockPrefix + deviceName;
    replace(lockName.begin() + sizeof(kLockPrefix) - 1, lockName.end(), '/', '_');

    const mode_t oldUmask = umask(0);
    int lock =
      ::open(lockName.c_str(), O_RDWR | O_CREAT, 0666); // Here is wisdom.
    umask(oldUmask);

    if (lock < 0) {
      ::close(handle);
      return 0;
    }
    if (fcntl(lock, F_SETFD, FD_CLOEXEC) < 0) {
      ::close(lock);
      ::close(handle);
      return 0;
    }

    // OK, create a descriptor and record it.
    /** @todo In C++11, we could emplace() it and use a single try block... */
    try {
      Rs232Device *pDevice = new Rs232Device(deviceName, handle, lock);

      try {
        gOpenDevices[deviceName] = pDevice;
        return pDevice;

      } catch (bad_alloc &) {
        pDevice->close();
        errno = ENOMEM;
      }
    } catch (bad_alloc &) {
      ::close(handle);
      ::close(lock);
      errno = ENOMEM;
    }

    return 0;
  }

  void
  Rs232Device::close(void)
  {
    Guard guard(gOpenDeviceLock);
    assert(guard.locked());

    if (--mReferenceCount == 0) {
      const map<string, Rs232Device *>::iterator found = gOpenDevices.find(mName);
      assert(found != gOpenDevices.end());

      gOpenDevices.erase(found);
      delete this;
    }
  }

  bool
  Rs232Device::lock(void)
  {
    // First try to acquire the per-process mutex.
    if (pthread_mutex_lock(&mMutex) == 0) {
      // Then try to lock the lock file.
      do {
        if (lockf(mLock, F_LOCK, 0) == 0) {
          return true;
        }
      } while (errno == EINTR);

      pthread_mutex_unlock(&mMutex);
    }
    return false;
  }

  bool
  Rs232Device::unlock(void)
  {
    // Unlock the lock file, then release the mutex.
    bool unlocked = (lockf(mLock, F_ULOCK, 0) == 0);
    return (pthread_mutex_unlock(&mMutex) == 0) && unlocked;
  }

  Rs232Device::Rs232Device(const string &name, int handle, int lock)
  : mName(name),
    mReferenceCount(1),
    mHandle(handle),
    mLock(lock)
  {
    // empty
  }

  Rs232Device::~Rs232Device(void)
  {
    assert(mReferenceCount == 0);

    (void)::close(mHandle);
    mHandle = -1;
    (void)::close(mLock);
    mLock = -1;
  }
}
