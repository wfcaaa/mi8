/* -*-C++-*- */
/**
 * A wrapper class for VXI-11 links that are shared between sessions.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   Vxi11Link.hpp
 * @author Jens Kilian
 * @date   Created:  Fri Dec 21 10:04:46 2012
 ******************************************************************************
 */

#ifndef HA087652E_FB8C_4F5B_A02E_4C50C8941CF5_
#define HA087652E_FB8C_4F5B_A02E_4C50C8941CF5_

#include <memory>

#include "vxi11core.h"

namespace hw_cor_hwio_GenericIo
{
  class Vxi11Server;

  /** A wrapper for VXI-11 sessions. */
  class Vxi11Link
  {
  public:
    /** Construct a wrapper for a newly opened session. */
    Vxi11Link(
      /** VXI-11 server holding the session. */
      const ::std::shared_ptr<Vxi11Server> &pServer,
      /** Result of CREATE_LINK operation. */
      const Create_LinkResp &creationResult);

    /** Destroy the wrapper, closing the associated session. */
    ~Vxi11Link(void);

    /** Inquire the VXI-11 server. */
    const ::std::shared_ptr<Vxi11Server> &
    server(void) const
    {
      return mpServer;
    }

    /** Inquire the link ID. */
    Device_Link
    linkID(void) const
    {
      return mLinkID;
    }

    /** Inquire the link's maximum receive size. */
    unsigned long
    maxRecvSize(void) const
    {
      return mMaxRecvSize;
    }

  private:
    // Not implemented.
    Vxi11Link(const Vxi11Link &);
    Vxi11Link &operator =(const Vxi11Link &);

    /** VXI-11 server holding the session. */
    ::std::shared_ptr<Vxi11Server> mpServer;
    /** Link ID of session. */
    const Device_Link mLinkID;
    /** Maximum receive size. */
    const unsigned long mMaxRecvSize;
  };
}

#endif /* HA087652E_FB8C_4F5B_A02E_4C50C8941CF5_ */
