/* -*-C++-*- */
/**
 * Simple test program, similar to iwrite(1).
 ******************************************************************************
 * (C) Copyright 2014 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   GioWrite.cpp
 * @author Jens Kilian
 * @date   Created:  Wed Feb  5 08:53:01 2014
 * @date   Modified: Fri Jan 15 11:37:20 2016 (Jens Kilian)
 ******************************************************************************
 */

#include <iostream>
#include <string>
#include <unistd.h>

using namespace ::std;

#include "xoc/hw/cor/gio/gio.h"

namespace
{
  /**
   * Print usage message.
   *
   * @param  pProgName Name of executable.
   */
  void
  usage(const char *pProgName)
  {
    cerr << "Usage: " << pProgName << " [-t <timeout>] <interface>\n\n"
         << "       <timeout>    I/O timeout in milliseconds.\n"
         << "       <interface>  Name of GIO interface, e.g. 'vxi11/192.168.0.100/gpib0,9'.\n"
         << endl;
  }
}

/**
 * Main program.
 *
 * @param  argc  Number of command-line arguments.
 * @param  argv  Command-line argument strings.
 *
 * @return int Exit status.
 */
int
main(int argc, char **argv)
{
  // Check and decode command-line arguments.

  const char *const pProgName = argv[0];
  int opt;
  long timeout = -1;

  while ((opt = getopt(argc, argv, "t:")) != -1) {
    switch (opt) {

    case 't':
      timeout = strtol(optarg, NULL, 10);
      break;

    default:
      usage(pProgName);
      return 1;
    }
  }

  if (argc <= optind) {
    usage(pProgName);
    return 1;
  }

  const char *const pInterface = argv[optind];

  // Errors will be considered fatal.
  
  gio_set_error_handler(GIO_ERROR_EXIT);

  // Send input from cin to the GIO interface, line by line.

  IDID idid = gio_open(pInterface);
  if (timeout > 0) {
    gio_set_timeout(idid, timeout);
  }

  string line;
  while (getline(cin, line)) {
    line.append(1, '\n');
    gio_write(idid, line.c_str(), line.size(), TRUE, NULL);
  }

  gio_close(idid);

  return 0;
}
