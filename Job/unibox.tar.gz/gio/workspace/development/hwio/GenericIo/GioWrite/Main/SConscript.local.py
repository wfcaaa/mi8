# Builds gio_write C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
    'PROJECT_TYPE' : ['c_program'],
    'NAME' : ['gio_write'],
    'DEST' : ['../..'],
    'CXXFLAGS_LOCAL' : ['--std=c++11'],
    'LDFLAGS_LOCAL' : ['-lhw_cor_gio']
}
