/* -*-C++-*- */
/**
 * Rudimentary VXI-11 server for testing SRQ behavior.
 ******************************************************************************
 * (C) Copyright 2008-2013 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   vxi11server.cpp
 * @author Jens Kilian
 * @date   Created:  Fri Jul 11 11:34:56 2008
 * @date   Modified: Tue Jul  7 12:25:38 2015 (Jens Kilian)
 * 
 * This file implements a server for the VXI-11 RPC protocol.  Only very few
 * of the RPC procedures actually do anything, and even they don't do much.
 *
 * The server is used in a regression test to verify that the problem
 * described in CR39892 is fixed.
 ******************************************************************************
 */

#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <rpc/pmap_clnt.h>
#include <rpc/rpc.h>
#include <vector>
using namespace ::std;

#include "xoc/hw/cor/gio/gio.h"

#include "vxi11core.h"
#include "vxi11intr.h"
#include "Link.hpp"
using namespace ::hw_cor_hwio_GenericIo_TestServer;

#ifdef DEBUG
#  define TRACE(x) cout << x
#else
#  define TRACE(x) do {} while (0)
#endif

/** RPC service routines.
 *
 * The RPC code generator doesn't seem to produce these prototypes
 * in any header file (probably because the code using them is normally
 * also auto generated).
 */
extern void device_core_1(struct svc_req *rqstp, register SVCXPRT *transp);
extern void device_async_1(struct svc_req *rqstp, register SVCXPRT *transp);

namespace {
  // Some constants used for generating answers.
  const u_long MAX_RECEIVE_SIZE = 32 * 1024;
  const string ANSWER_STRING = "Taradiddle.\r\n";
  const unsigned char STATUS_BYTE = 0x46;

  // The server's transport data structure.
  SVCXPRT *gTransport = 0;

  // The SRQ stuff should be per connection... we support only one.
  CLIENT *gSRQClient = 0;

  // Link table.
  vector<Link *> gLinkTable;

  Device_ErrorCode
  createInterruptChannel(Device_RemoteFunc *pArg)
  {
    if (gSRQClient) {
      // Already done.
      return GIO_ERR_NO_ERROR;
    }

    // Set up socket address from information given by client.
    struct sockaddr_storage addr;
    memset(&addr, 0, sizeof(addr));
    ((struct sockaddr *)&addr)->sa_family = AF_INET;

    struct sockaddr_in *pAddr = (struct sockaddr_in *)&addr;
    pAddr->sin_addr.s_addr = ntohl(pArg->hostAddr);
    pAddr->sin_port        = ntohs(pArg->hostPort);

    // Create RPC client structure.
    if (pArg->progFamily == DEVICE_TCP) {
      int socket = RPC_ANYSOCK;
      gSRQClient = clnttcp_create(pAddr,
                                  pArg->progNum, pArg->progVers,
                                  &socket,
                                  0, 0);

    } else if (pArg->progFamily == DEVICE_UDP) {
      static struct timeval TIMEOUT = { 1, 0 };
      int socket = RPC_ANYSOCK;
      gSRQClient = clntudp_create(pAddr,
                                  pArg->progNum, pArg->progVers,
                                  TIMEOUT,
                                  &socket);
    }

    // OK, done.
    return gSRQClient ? GIO_ERR_NO_ERROR : GIO_ERR_OS_ERROR;
  }
  
  Device_ErrorCode
  destroyInterruptChannel(void)
  {
    if (!gSRQClient) {
      return GIO_ERR_CHANNEL_NOT_ESTABLISHED;
    }

    clnt_destroy(gSRQClient);
    gSRQClient = 0;
    return GIO_ERR_NO_ERROR;
  }

  void
  sendSRQ(const Link &link)
  {
    if (gSRQClient && link.srqHandle()) {
      Device_SrqParms params;

      params.handle.handle_val = (char *)(link.srqHandle()->c_str());
      params.handle.handle_len = link.srqHandle()->size();

      // We want a one-way call.
      static struct timeval TIMEOUT = { 0, 0 };
      clnt_call(gSRQClient, device_intr_srq,
		(xdrproc_t)xdr_Device_SrqParms, (caddr_t)&params,
		(xdrproc_t)xdr_void, (caddr_t)0,
		TIMEOUT);
    }
  }
}

// ----------------------------------------------------------------------------

bool_t
create_link_1_svc(Create_LinkParms *pArg, Create_LinkResp *pRes,
                  svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("create_link(" << pArg->device << ")" << endl);

  // Find a free link ID and create a link.
  vector<Link *>::iterator i =
    find(gLinkTable.begin(), gLinkTable.end(), (Link *)0);
  if (i == gLinkTable.end()) {
    gLinkTable.push_back(0);
    i = gLinkTable.end() - 1;
  }
  *i = new Link(pArg->device);

  pRes->lid = (Device_Link)(i - gLinkTable.begin());
  pRes->abortPort = gTransport->xp_port;
  pRes->maxRecvSize = MAX_RECEIVE_SIZE;

  return TRUE;
}

bool_t
destroy_link_1_svc(Device_Link *pArg, Device_Error *pRes,
                   svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("destroy_link(" << gLinkTable[*pArg]->name() << ")" << endl);

  delete gLinkTable[*pArg];
  gLinkTable[*pArg] = 0;

  return TRUE;
}

bool_t
create_intr_chan_1_svc(Device_RemoteFunc *pArg, Device_Error *pRes,
                       svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("create_intr_chan" << endl);

  pRes->error = createInterruptChannel(pArg);

  return TRUE;
}

bool_t
destroy_intr_chan_1_svc(void *pArg, Device_Error *pRes,
                        svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("destroy_intr_chan" << endl);

  pRes->error = destroyInterruptChannel();

  return TRUE;
}

bool_t
device_write_1_svc(Device_WriteParms *pArg, Device_WriteResp *pRes,
                   svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_write(" << gLinkTable[pArg->lid]->name() << "): "
        << string(pArg->data.data_val, pArg->data.data_len) << endl);

  pRes->size = pArg->data.data_len;

  return TRUE;
}

bool_t
device_read_1_svc(Device_ReadParms *pArg, Device_ReadResp *pRes,
                  svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_read(" << gLinkTable[pArg->lid]->name() << ", "
        << pArg->requestSize << ") -> " << ANSWER_STRING << endl);

  pRes->data.data_len = ANSWER_STRING.size();
  pRes->data.data_val = strdup(ANSWER_STRING.c_str());

  pRes->reason = GIO_REASON_END;

  return TRUE;
}

bool_t
device_readstb_1_svc(Device_GenericParms *pArg, Device_ReadStbResp *pRes,
                     svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_readstb(" << gLinkTable[pArg->lid]->name() << ")" << endl);

  pRes->stb = STATUS_BYTE;

  return TRUE;
}

bool_t
device_trigger_1_svc(Device_GenericParms *pArg, Device_Error *pRes,
                     svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_trigger(" << gLinkTable[pArg->lid]->name() << ")" << endl);

  return TRUE;
}

bool_t
device_clear_1_svc(Device_GenericParms *pArg, Device_Error *pRes,
                   svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_clear(" << gLinkTable[pArg->lid]->name() << ")" << endl);

  return TRUE;
}

bool_t
device_remote_1_svc(Device_GenericParms *pArg, Device_Error *pRes,
                    svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_remote(" << gLinkTable[pArg->lid]->name() << ")" << endl);

  return TRUE;
}

bool_t
device_local_1_svc(Device_GenericParms *pArg, Device_Error *pRes,
                   svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_local(" << gLinkTable[pArg->lid]->name() << ")" << endl);

  return TRUE;
}

bool_t
device_lock_1_svc(Device_LockParms *pArg, Device_Error *pRes,
                  svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_lock(" << gLinkTable[pArg->lid]->name() << ")" << endl);

  return TRUE;
}

bool_t
device_unlock_1_svc(Device_Link *pArg, Device_Error *pRes,
                    svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_unlock(" << gLinkTable[*pArg]->name() << ")" << endl);

  return TRUE;
}

bool_t
device_enable_srq_1_svc(Device_EnableSrqParms *pArg, Device_Error *pRes,
                        svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_enable_srq(" << gLinkTable[pArg->lid]->name() << ")" << endl);

  if (pArg->enable) {
    gLinkTable[pArg->lid]->setSrqHandle(pArg->handle.handle_val,
                                        pArg->handle.handle_len);

    // Send an SRQ immediately.
    sendSRQ(*gLinkTable[pArg->lid]);

  } else {
    gLinkTable[pArg->lid]->setSrqHandle(0, 0);
  }

  return TRUE;
}

bool_t
device_docmd_1_svc(Device_DocmdParms *pArg, Device_DocmdResp *pRes,
                   svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_docmd(" << gLinkTable[pArg->lid]->name() << ", "
        << hex << pArg->cmd << ")" << endl);

  switch (pArg->cmd) {

  case 0x020002: // ATN control
  case 0x020010: // IFC control
    // Just pretend to do it.
    break;

  default:
    pRes->error = GIO_ERR_OPERATION_NOT_SUPPORTED;
    break;
  }

  return TRUE;
}

int
device_core_1_freeresult (SVCXPRT *, xdrproc_t xdr_result, caddr_t result)
{
  xdr_free(xdr_result, result);
  return 1;
}

// ----------------------------------------------------------------------------

bool_t
device_abort_1_svc(Device_Link *pArg, Device_Error *pRes,
                   svc_req *)
{
  memset(pRes, 0, sizeof(*pRes));

  TRACE("device_abort(" << gLinkTable[*pArg]->name() << ")" << endl);

  return TRUE;
}

int
device_async_1_freeresult (SVCXPRT *, xdrproc_t xdr_result, caddr_t result)
{
  xdr_free(xdr_result, result);
  return 1;
}

// ----------------------------------------------------------------------------

int
main(int argc, char **argv)
{
  if (argc != 2) {
    cerr << "Usage: " << argv[0] << " message";
    return 1;
  }

  pmap_unset(DEVICE_ASYNC, DEVICE_ASYNC_VERSION);
  pmap_unset(DEVICE_CORE,  DEVICE_CORE_VERSION);

  gTransport = svctcp_create(RPC_ANYSOCK, 0, 0);
  if (!gTransport) {
    cerr << "Failed to create RPC service." << endl;
    return 1;
  }

  if (!svc_register(gTransport,
                    DEVICE_CORE, DEVICE_CORE_VERSION, device_core_1,
                    IPPROTO_TCP))
  {
    cerr << "Failed to register core dispatcher." << endl;
    return 1;
  }
  if (!svc_register(gTransport,
                    DEVICE_ASYNC, DEVICE_ASYNC_VERSION, device_async_1,
                    IPPROTO_TCP))
  {
    cerr << "Failed to register async dispatcher." << endl;
    return 1;
  }

  // Notify the client that the server is running.
  cout << argv[1] << flush;

  svc_run();

  // Should never come here, but clean up anyway.
  for (vector<Link *>::iterator i = gLinkTable.begin(), e = gLinkTable.end(); i != e; ++i) {
    delete *i;
    *i = 0;
  }

  if (gSRQClient) {
    clnt_destroy(gSRQClient);
    gSRQClient = 0;
  }

  svc_destroy(gTransport);
  gTransport = 0;

  cerr << "Returned from svc_run()." << endl;
  return 1;
}
