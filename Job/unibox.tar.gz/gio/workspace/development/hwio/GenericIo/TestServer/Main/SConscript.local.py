{
    'PROJECT_TYPE' : ['c_program'] ,
    'NAME' : ['TestServer'],
    'CXXFLAGS_LOCAL' : ['--std=c++11',
                        '-Wno-unused-variable'], # XDR routines trigger this
    'DEST' : ['..'],
    'RUN_DEST' : ['']
}
