/* -*-C++-*- */
/**
 * Representation of a VXI-11 link.
 ******************************************************************************
 * (C) Copyright 2008-2013 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   Link.hpp
 * @author Jens Kilian
 * @date   Created:  Fri Jul 11 11:33:42 2008
 * @date   Modified: Fri Jan 25 08:37:00 2013 (Jens Kilian)
 ******************************************************************************
 */

#ifndef H6A3139CB_6FF5_489E_BA7D_7D902BFDDE14_
#define H6A3139CB_6FF5_489E_BA7D_7D902BFDDE14_

#include <string>

namespace hw_cor_hwio_GenericIo_TestServer
{
  class Link
  {
  public:
    Link(const char *const device)
    : mName(device),
      mpSrqHandle(0)
    {
      // empty
    }

    const std::string &
    name(void) const
    {
      return mName;
    }

    const std::string *
    srqHandle(void) const
    {
      return mpSrqHandle;
    }

    void
    setSrqHandle(const char *const pData, unsigned int length)
    {
      delete mpSrqHandle;
      mpSrqHandle = pData ? new std::string(pData, length) : 0;
    }

  private:
    const std::string mName;
    const std::string *mpSrqHandle;
  };
}

#endif /* H6A3139CB_6FF5_489E_BA7D_7D902BFDDE14_ */
