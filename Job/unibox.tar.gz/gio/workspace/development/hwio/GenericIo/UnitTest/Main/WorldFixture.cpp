/**
 ****************************************************************************
 *
 * Unit Tests: The World fixture
 *
 * Copyright by Advantest Europe GmbH, 2012
 *
 * @author
 *
 * @date
 *
 ****************************************************************************
 */

#include "WorldFixture.hpp"

#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
using namespace ::std;

namespace
{
  // PID of VXI-11 server process.
  pid_t gServerPid = 0;

  // Message sent by the server when it's ready.
  const char PASSWOID[] = "Swordfish\n";
}

WorldFixture::WorldFixture(void)
: mOk(true)
{
  if (gServerPid != 0) {
    // This can't happen.
    fprintf(stderr, "Server already running.\n");
    mOk = false;
    return;
  }

  // Create a pipe for letting the server notify us that it's ready.
  int pipefd[2];
  if (pipe(pipefd) < 0) {
    perror("pipe");
    mOk = false;
    return;
  }

  // Fork off a child process.
  pid_t child = fork();
  if (child == 0) {
    // In child process - start the server.
    string executable = getenv("WORKSPACE");
    executable += "/development/hwio/GenericIo/TestServer/TestServer";

    // Redirect stdout/stderr into the pipe.
    if (dup2(pipefd[1], 1) != 1 || dup2(pipefd[1], 2) != 2) {
      perror("dup2");
      exit(1);
    }
    close(pipefd[0]);
    close(pipefd[1]);

    execl(executable.c_str(), executable.c_str(), PASSWOID, (const char *)NULL);

    // If we come here, the server could not be started.
    perror(executable.c_str());
    exit(1);
  }

  if (child < 0) {
    // Failed to fork.
    perror("fork");
    mOk = false;
    return;
  }

  // OK, server is starting.  Wait until it signals that it is ready.
  gServerPid = child;

  char message[1024];
  ssize_t nBytes = read(pipefd[0], message, sizeof(message)-1);
  if (nBytes >= 0) {
    message[nBytes] = '\0';
    if (strcmp(message, PASSWOID) != 0) {
      // Something went wrong.
      fprintf(stderr, "Server error: %s\n", message);
      mOk = false;
    }
  } else {
    // Read failed.
    perror("read");
    mOk = false;
  }

  close(pipefd[0]);
  close(pipefd[1]);
}

WorldFixture::~WorldFixture(void)
{
  if (gServerPid != 0) {
    // Shut down the server process.
    if (kill(gServerPid, SIGTERM) < 0) {
      perror("kill");
    }

    // Wait for the server to terminate.
    if (waitpid(gServerPid, NULL, 0) < 0) {
      perror("waitpid");
    }

    gServerPid = 0;
  }
}
