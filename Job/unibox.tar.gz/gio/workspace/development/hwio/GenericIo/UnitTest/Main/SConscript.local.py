# Builds the Unit Test Program 
#
# Developer maintained file, initial version is created by component generator
#
{
    'PROJECT_TYPE' : ['c_program'],
    'NAME' : ['UnitTestRunner'],
    'DEST' : ['..'],
    'RUN_DEST' : [''],
    'CXXFLAGS_LOCAL' : ['--std=c++11'],
    'LDFLAGS_LOCAL' : ['-lhw_cor_gio']
}
