#pragma once

/**
 ****************************************************************************
 *
 * Unit Tests: The World fixture
 *
 * Copyright by Advantest Europe GmbH, 2012
 *
 * @author
 *
 * @date
 *
 ****************************************************************************
 */

class WorldFixture
{
public:
  WorldFixture(void);
  ~WorldFixture(void);

  operator bool(void) const
  {
    return mOk;
  }

private:
  bool mOk;
};


