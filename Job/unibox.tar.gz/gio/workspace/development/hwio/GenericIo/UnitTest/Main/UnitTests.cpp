/**
 ****************************************************************************
 *
 * Unit test for VXI-11 SRQ handling.
 *
 * Copyright by Advantest Europe GmbH, 2012
 *
 ****************************************************************************
 */

#include "WorldFixture.hpp"

#include <algorithm>
#include <csignal>
#include <iostream>
#include <sched.h>
using namespace ::std;

#include "xoc/hw/cor/gio/gio.h"

namespace
{
  // Symbolic name for connecting to a VXI-11 server running on localhost.
  const char SERVER_NAME[] = "vxi11/localhost/gpib0,22";

  // Sequence numbers used to verify that SRQ is handled at the right time.
  enum {
    SEQUENCE_INITIAL,
    SEQUENCE_SRQ_SUSPENDED,
    SEQUENCE_CONNECTION_OPENED,
    SEQUENCE_SRQ_ENABLED,
    SEQUENCE_SRQ_RESUMED,
    SEQUENCE_CONNECTION_CLOSED,
    SEQUENCE_ERROR
  };

  sig_atomic_t gSequenceNumber = SEQUENCE_INITIAL;

  // Result of test.
  enum { UNKNOWN, PASSED, FAILED };

  sig_atomic_t gResult = UNKNOWN;

  // --------------------------------------------------------------------------

  // Set the sequence number.
  void
  setSequenceNumber(sig_atomic_t s)
  {
    // We use sched_yield in the hope that it will make the behavior a bit
    // more predictable.
    sched_yield();
    gSequenceNumber = s;
    sched_yield();
  }

  // SRQ handler.
  void
  srqHandler(IDID id)
  {
    // This is not really necessary here, but a real SRQ handler would do it.
    uint8_t stb;
    (void)gio_read_status_byte(id, &stb);

    // We expect the SRQ to be handled during or after the call
    // to gio_resume_events().
    //
    // NB: We must use a global variable here.  Using TS_ASSERT/TS_FAIL etc.
    //     doesn't work - the bug is not detected.
    switch (gSequenceNumber) {

    case SEQUENCE_SRQ_ENABLED:
    case SEQUENCE_SRQ_RESUMED:
      gResult = max<sig_atomic_t>(gResult, PASSED);
      break;

    default:
      gResult = FAILED;
      break;
    }
  }

  // Error handler, should never be called.
  void
  errorHandler(IDID id, GIO_ERROR error)
  {
    const char *const msg = gio_get_error_str(id, error);
    cout << (msg ? msg : "GIO operation failed.") << endl;
    gResult = FAILED;
  }
}

int
main(void)
{
  // Test that CR-39892 is fixed.
  WorldFixture fixture;

  if (fixture) {
    // Establish GIO error handler.
    gio_set_error_handler(errorHandler);

    // Suspend events.
    gio_suspend_events();
    setSequenceNumber(SEQUENCE_SRQ_SUSPENDED);

    // Open connection to the VXI-11 server.
    IDID id = gio_open(SERVER_NAME);
    setSequenceNumber(SEQUENCE_CONNECTION_OPENED);

    // Establish SRQ handler.
    //
    // This will enable SRQ reporting by the VXI-11 server, but SRQs
    // are still suspended.  The bug we are testing for will cause
    // the SRQ handler to be called at this point.
    gio_set_SRQ_handler(id, srqHandler);
    setSequenceNumber(SEQUENCE_SRQ_ENABLED);

    // Resume event handling.
    //
    // This is the point at which the SRQ handler may be first called.
    gio_resume_events();
    setSequenceNumber(SEQUENCE_SRQ_RESUMED);

    // Close the connection to the VXI-11 server.
    gio_close(id);
    setSequenceNumber(SEQUENCE_CONNECTION_CLOSED);
  }

  if (gResult == PASSED) {
    cout << "+TEST GenericIo.UnitTest : PASSED" << endl;
  } else {
    cout << "+TEST GenericIo.UnitTest : FAILED" << endl;
  }

  return 0;
}

