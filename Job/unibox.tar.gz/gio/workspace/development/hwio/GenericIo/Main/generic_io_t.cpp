/* -*-C++-*- */
/**
 * Base class representing an external interface or device.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   generic_io_t.cpp
 * @author Jens Kilian
 * @date   Created:  Thu Dec 13 12:45:43 2012
 * @date   Modified: Wed Feb 10 10:06:07 2016 (Jens Kilian)
 ******************************************************************************
 */

#include "generic_io_t.hpp"

#include <string>
using namespace ::std;

#include "xoc/hw/cor/gio/gio.h"
#include "gio_.hpp"
using namespace hw_cor_hwio_GenericIo;

/*
 * Default implementations of access method operations.
 * ----------------------------------------------------------------------------
 */

GIO_ERROR
generic_io_t::clear(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::write(
  const void *pBuffer,
  size_t len,
  bool_t end,
  size_t *pActual)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::read(
  void *pBuffer,
  size_t len,
  int *pReasons,
  size_t *pActual)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::read_status_byte(
  uint8_t *pStb)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::set_status_byte(
  uint8_t stb)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::trigger(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::local(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::remote(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::lock(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::unlock(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::gpib_send_IFC(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::gpib_send_cmd(
  const void *pCommand,
  size_t len)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::gpib_bus_status(
  GIO_GPIB_STATUS_REQUEST request,
  uint8_t *pResult)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::gpib_ATN_control(
  bool_t enable)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::gpib_REN_control(
  bool_t enable)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::gpib_local_lockout(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::rs232_break(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::rs232_control(
  GIO_RS232_REQUEST request,
  uint32_t setting)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::rs232_status(
  GIO_RS232_REQUEST request,
  uint32_t *pResult)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::rs232_modem_control(
  GIO_RS232_MODEM_CONTROL line,
  bool_t enable)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::rs232_modem_control_status(
  GIO_RS232_MODEM_CONTROL line,
  bool_t *pStatus)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::enable_SRQ_callback(
  bool_t enable)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::set_termchr(
  int termChar)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::get_termchr(
  int *pTermChar)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::set_timeout(
  uint32_t milliSeconds)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::get_timeout(
  uint32_t *pMilliSeconds)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::set_lock_wait(
  bool_t flag)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

GIO_ERROR
generic_io_t::get_lock_wait(
  bool_t *pFlag)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

const char *
generic_io_t::get_error_str(
  GIO_ERROR error)
{
  return 0;
}

GIO_ERROR
generic_io_t::do_nothing(void)
{
  return GIO_ERR_NOT_IMPLEMENTED;
}

/*
 * Implementation of other functions.
 * ----------------------------------------------------------------------------
 */

generic_io_t::generic_io_t(const SessionFactory &factory,
                           const string &name)
: mpSRQCallback(handleSRQ),
  mFactory(factory),
  mName(name),
  mpSRQHandler(0)
{
  // empty
}

GIO_ERROR
generic_io_t::setSRQHandler(gio_SRQ_handler_t newHandler)
{
  // To avoid race conditions, temporarily disable asynchronous events
  // while things are in flux.
  GIO_ERROR err = gio_suspend_events();

  if (!mpSRQHandler && newHandler) {
    mpSRQHandler = newHandler;
    gio_merge_errors_(err, enable_SRQ_callback(TRUE));

  } else if (mpSRQHandler && !newHandler) {
    gio_merge_errors_(err, enable_SRQ_callback(FALSE));
    mpSRQHandler = newHandler;

  } else {
    mpSRQHandler = newHandler;
  }

  gio_merge_errors_(err, gio_resume_events());
  return err;
}

void
generic_io_t::handleSRQ(generic_io_t *pIO)
{
  if (pIO->mpSRQHandler) {
    (pIO->mpSRQHandler)(pIO);

    gio_event_handled_();
  }
}
