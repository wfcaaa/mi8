/* -*-C++-*- */
/**
 * Utility functions for use with the GIO library (not SICL compatible).
 ******************************************************************************
 * (C) Copyright 2013 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   gio_util.cpp
 * @author Jens Kilian
 * @date   Created:  Fri Jun 28 07:57:20 2013
 * @date   Modified: Fri Jun 28 09:51:26 2013 (Jens Kilian)
 * 
 * This file implements utilities for instrument I/O which are not SICL
 * compatible.  Caveat user.
 ******************************************************************************
 */

#include "xoc/hw/cor/gio/gio.h"

#include <cstdarg>
#include <cstdio>
#include <cstring>

#include "gio_.hpp"
using namespace ::hw_cor_hwio_GenericIo;

namespace
{
  /**
   * End-of-line character; @c gio_printf() will send an @c END indicator
   * for each @c EOL character in the output string.
   */
  const char EOL = '\n';
}

GIO_ERROR
gio_printf(IDID idid,
           char *pBuffer, size_t bufferSize,
           const char *pFormat, ...)
{
  GIO_ERROR err = GIO_ERR_NO_ERROR;

  // Retrieve argument list and format the output string.
  va_list args;
  va_start(args, pFormat);
  int ret = vsnprintf(pBuffer, bufferSize, pFormat, args);
  va_end(args);

  if (ret < 0) {
    // Some error occurred in vsnprintf().
    err = GIO_ERR_PARAMETER_ERROR;
  }

  // Send the data to the device or interface.
  char *pEOL;
  while (err == GIO_ERR_NO_ERROR && (pEOL = strchr(pBuffer, EOL)) != 0) {
    err = gio_write(idid, pBuffer, pEOL - pBuffer + 1, TRUE, 0);
    pBuffer = pEOL + 1;
  }
  if (err == GIO_ERR_NO_ERROR && *pBuffer) {
    err = gio_write(idid, pBuffer, strlen(pBuffer), FALSE, 0);
  }

  return gio_set_errno_(idid, err);
}

GIO_ERROR
gio_scanf(IDID idid,
          char *pBuffer, size_t bufferSize,
          const char *pFormat, ...)
{
  // Read data from the device or interface.
  size_t actual;
  GIO_ERROR err = gio_read(idid, pBuffer, bufferSize - 1, 0, &actual);
  if (err == GIO_ERR_NO_ERROR) {
    pBuffer[actual] = '\0';

    // Retrieve argument list and interpret the buffer contents.
    va_list args;
    va_start(args, pFormat);
    int ret = vsscanf(pBuffer, pFormat, args);
    va_end(args);

    if (ret < 0) {
      // Some error occurred in vsscanf().
      err = GIO_ERR_PARAMETER_ERROR;
    }
  }

  return gio_set_errno_(idid, err);
}
