/* -*-C++-*- */
/**
 * Public API to GIO library.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 *
 * @file   gio.cpp
 * @author Jens Kilian
 * @date   Created:  Wed Dec 12 16:13:08 2012
 *
 * This file implements the generic (client visible) layer of the GIO module.
 * Most of the functions in the generic layer are very small and very similar
 * because they only have to do two things:
 * - check the @c IDID parameter for validity
 * - perform an indirect call into a lower layer
 ******************************************************************************
 */

#include "xoc/hw/cor/gio/gio.h"

#include <algorithm>
#include <csignal>
#include <cstdio>
#include <map>
#include <set>
#include <string>
#include <sys/time.h>
using namespace ::std;

#include "generic_io_t.hpp"
#include "gio_.hpp"
#include "SessionFactory.hpp"
#include "rs232/Rs232Session.hpp"
#include "scpi/ScpiSession.hpp"
#include "vxi11/Vxi11Session.hpp"
using namespace ::hw_cor_hwio_GenericIo;

namespace
{
  /*
   * Supported access methods.
   * --------------------------------------------------------------------------
   */
  Rs232SessionFactory gRs232SessionFactory("rs232");
  ScpiSessionFactory gScpiSessionFactory("scpi");
  Vxi11SessionFactory gVxi11SessionFactory("vxi11");

  /*
   * Global variables.
   * --------------------------------------------------------------------------
   */

  /**
   * Table of explicitly opened sessions.
   *
   * This table keeps track of sessions opened by a client application.
   *
   * @ingroup openclose
   */
  set<IDID> *gpOpenConnectionTable = 0;

  /**
   * Table of implicitly opened interface sessions.
   *
   * This table keeps track of sessions opened via @c gio_get_interface().
   *
   * @ingroup openclose
   */
  set<IDID> *gpInterfaceTable = 0;

  /**
   * Table mapping device @c IDIDs to interface @c IDIDs.
   *
   * This table is used to keep track of the associations between device
   * sessions and interface sessions that were opened via @c gio_get_interface().
   *
   * @ingroup openclose
   */
  map<IDID, IDID> *gpDeviceInterfaceTable = 0;

  /**
   * Nesting level of @c gio_suspend_events() / @c gio_resume_events().
   *
   * Each call to @c gio_suspend_events() increases the nesting level,
   * each call to @c gio_resume_events() decreases it.  Events are actually
   * suspended or resumed when a transition from or to zero occurs.
   *
   * @ingroup events
   */
  uint32_t gSuspensionLevel = 0;

  /**
   * Global flag used to signal exit from loop in @c gio_wait_event().
   *
   * This flag indicates that an asynchronous event has been handled.
   * It is used by @c gio_wait_event() to check for termination.
   *
   * @ingroup events
   */
  volatile sig_atomic_t gEventHandled = 0;

  /**
   * Last error code returned by any GIO routine.
   *
   * This is the value returned by @c gio_get_errno().
   *
   * @ingroup errors
   */
  GIO_ERROR gErrorCode = GIO_ERR_NO_ERROR;

  /**
   * Current error handler.
   *
   * This variable is zero if no error handler has been defined, otherwise
   * it points to the error handler function.
   *
   * @ingroup errors
   */
  gio_error_handler_t gErrorHandler = 0;

  /*
   * Local functions.
   * --------------------------------------------------------------------------
   */

  /**
   * Clean up the device/interface tables.
   *
   * @attention
   * We must be careful here: When closing a connection, @c spOpenConnectionTable
   * and/or @c spInterfaceTable would normally be modified.  To prevent that,
   * we clear the table pointers before starting to make modifications.
   *
   * @return void
   * @ingroup openclose
   */
  void
  cleanupTables(void)
  {
    // Save pointers to tables which must be protected from modification.
    set<IDID> *pOpenConnectionTable = gpOpenConnectionTable;
    set<IDID> *pInterfaceTable      = gpInterfaceTable;

    // Prevent modifications of these tables.
    gpOpenConnectionTable = gpInterfaceTable = 0;

    // Actually clean up.
    delete gpDeviceInterfaceTable;
    gpDeviceInterfaceTable = 0;

    if (pOpenConnectionTable) {
      for_each(pOpenConnectionTable->begin(), pOpenConnectionTable->end(),
               gio_close);
      delete pOpenConnectionTable;
    }
    if (pInterfaceTable) {
      for_each(pInterfaceTable->begin(), pInterfaceTable->end(),
               gio_close);
      delete pInterfaceTable;
    }
  }

  /**
   * Remove an IDID from any table in which it may be present.
   *
   * The following situations can occur when a client program calls
   * @c gio_close():
   *
   * - The @c IDID being closed was opened via @c gio_open().
   *   It will be present in @c gpOpenConnectionTable; if an interface
   *   has been opened for it via @c gio_get_interface(), a mapping
   *   will also exist in @c spDeviceInterfaceTable.
   *   This case is easy to handle (just remove from both tables, if present).
   *
   * - The @c IDID was opened via @c gio_get_interface().
   *   It will be present in @c gpInterfaceTable, and any number
   *   of mappings in @c gpDeviceInterfaceTable may reference it.
   *   To handle this case, we must find all device-to-interface mappings
   *   referencing the given @c IDID, and remove them from
   *   @c gpDeviceInterfaceTable.
   *
   * @return void
   * @ingroup openclose
   */
  void
  updateTables(
    /** The interface or device which must be closed. */
    IDID pIO)
  {
    if (gpOpenConnectionTable
        && gpOpenConnectionTable->erase(pIO) > 0)
    {
      // The easy case - we just have to clean up a single mapping, at most.
      if (gpDeviceInterfaceTable) {
        gpDeviceInterfaceTable->erase(pIO);
      }
    } else if (gpInterfaceTable
               && gpInterfaceTable->erase(pIO) > 0)
    {
      // The hard case - we may have to remove multiple mappings.
      if (gpDeviceInterfaceTable) {
        map<IDID, IDID>::iterator i = gpDeviceInterfaceTable->begin();
        while (i != gpDeviceInterfaceTable->end()) {
          // Advance i before (potentially) erasing its contents.
          map<IDID, IDID>::iterator tmp = i++;

          if (tmp->second == pIO) {
            gpDeviceInterfaceTable->erase(tmp);
          }
        }
      }
    }
  }

  /**
   * Check an @c IDID for validity.
   *
   * This function merely checks if the @c IDID can be used by the generic layer.
   * When it is passed to an access method, further checks may be needed.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR The IDID is valid for the generic layer.
   * @retval other            The IDID is invalid.
   * @ingroup errors
   */
  GIO_ERROR
  checkIDID(
    /** The value to be checked. */
    generic_io_t *pIO)
  {
    // Check if this IDID has been registered as open.
    if (gpOpenConnectionTable
        && gpOpenConnectionTable->find(pIO) != gpOpenConnectionTable->end())
    {
      return GIO_ERR_NO_ERROR;
    }
    if (gpInterfaceTable
        && gpInterfaceTable->find(pIO) != gpInterfaceTable->end())
    {
      return GIO_ERR_NO_ERROR;
    }

    // Not found - must be invalid.
    return GIO_ERR_INVALID_ID;
  }
}

/*
 * Internal API.
 * ----------------------------------------------------------------------------
 */

namespace hw_cor_hwio_GenericIo
{
  void
  gio_event_handled_(void)
  {
    gEventHandled = 1;
  }

  GIO_ERROR
  gio_set_errno_(generic_io_t *pIO, GIO_ERROR errorCode)
  {
    gio_cause_error(pIO, errorCode, TRUE);
    return errorCode;
  }

  void
  gio_merge_errors_(GIO_ERROR &err1, GIO_ERROR err2)
  {
    if (err1 == GIO_ERR_NO_ERROR) {
      err1 = err2;
    }
  }
}

/*
 * Public API.
 * ----------------------------------------------------------------------------
 */

IDID
gio_open(const char *pName)
{
  // Try to open a session.
  generic_io_t *pIO = SessionFactory::create(pName);

  if (pIO) {
    try {
      // Enter the new descriptor into the table of open connections.
      if (!gpOpenConnectionTable) {
        gpOpenConnectionTable = new set<IDID>;

        // Ensure tables will be destroyed when program exits.
        if (!gpInterfaceTable) {
          atexit(cleanupTables);
        }
      }
      gpOpenConnectionTable->insert(pIO);

    } catch (bad_alloc &) {
      gio_set_errno_(pIO, GIO_ERR_OUT_OF_RESOURCES);
      gio_close(pIO);
      pIO = 0;
    } 
  }
  return pIO;
}

IDID
gio_get_interface(IDID pDevice)
{
  // Look up the device in spDeviceInterfaceTable; if found, return.
  if (gpDeviceInterfaceTable) {
    map<IDID, IDID>::const_iterator found = gpDeviceInterfaceTable->find(pDevice);
    if (found != gpDeviceInterfaceTable->end()) {
      return found->second;
    }
  }

  // Try to open a new interface session.
  generic_io_t *pIO = pDevice->factory().create(pDevice->name(), pDevice);

  if (pIO) {
    try {
      // Register the new descriptor.
      if (!gpInterfaceTable) {
        gpInterfaceTable = new set<IDID>;
        gpDeviceInterfaceTable = new map<IDID, IDID>;

        // Ensure tables will be destroyed when program exits.
        if (!gpOpenConnectionTable) {
          atexit(cleanupTables);
        }
      }
      gpInterfaceTable->insert(pIO);
      gpDeviceInterfaceTable->insert(make_pair(pDevice, pIO));

    } catch (bad_alloc &) {
      gio_set_errno_(pIO, GIO_ERR_OUT_OF_RESOURCES);
      gio_close(pIO);
      pIO = 0;
    } 
  }
  return pIO;
}

GIO_ERROR
gio_close(IDID pIO)
{
  const GIO_ERROR err = checkIDID(pIO);
  if (err != GIO_ERR_NO_ERROR) {
    return gio_set_errno_(pIO, err);
  }

  // Remove the IDID from any hash tables where it is present.
  updateTables(pIO);

  // OK, destroy the session.
  return pIO->close();
}

const char *
gio_get_name(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    return pIO->name().c_str();
  }
  return 0;
}

GIO_ERROR
gio_clear(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->clear();
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_write(IDID pIO, const void *pBuffer, size_t len, bool_t end, size_t *pActual)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->write(pBuffer, len, end, pActual);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_read(IDID pIO, void *pBuffer, size_t len, int *pReasons, size_t *pActual)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->read(pBuffer, len, pReasons, pActual);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_read_status_byte(IDID pIO, uint8_t *pStb)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->read_status_byte(pStb);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_set_status_byte(IDID pIO, uint8_t stb)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->set_status_byte(stb);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_trigger(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->trigger();
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_local(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->local();
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_remote(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->remote();
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_lock(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->lock();
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_unlock(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->unlock();
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_gpib_send_IFC(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->gpib_send_IFC();
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_gpib_send_cmd(IDID pIO, const void *pCommand, size_t len)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->gpib_send_cmd(pCommand, len);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_gpib_bus_status(IDID pIO, GIO_GPIB_STATUS_REQUEST request, uint8_t *pResult)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->gpib_bus_status(request, pResult);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_gpib_ATN_control(IDID pIO, bool_t enable)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->gpib_ATN_control(enable);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_gpib_REN_control(IDID pIO, bool_t enable)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->gpib_REN_control(enable);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_gpib_local_lockout(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->gpib_local_lockout();
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_rs232_break(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->rs232_break();
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_rs232_control(IDID pIO, GIO_RS232_REQUEST request,
                  uint32_t setting)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->rs232_control(request, setting);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_rs232_status(IDID pIO, GIO_RS232_REQUEST request,
                 uint32_t *pResult)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->rs232_status(request, pResult);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_rs232_modem_control(IDID pIO, GIO_RS232_MODEM_CONTROL line,
                        bool_t enable)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->rs232_modem_control(line, enable);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_rs232_modem_control_status(IDID pIO, GIO_RS232_MODEM_CONTROL line,
                               bool_t *pStatus)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->rs232_modem_control_status(line, pStatus);
  }

  return gio_set_errno_(pIO, err);
}
GIO_ERROR
gio_set_SRQ_handler(IDID pIO, gio_SRQ_handler_t handler)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->setSRQHandler(handler);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_suspend_events(void)
{
  GIO_ERROR err = GIO_ERR_NO_ERROR;

  if (++gSuspensionLevel == 1) {
    // Level was 0 before - must suspend.
    err = SessionFactory::suspendEvents();
  }

  return gio_set_errno_(0, err);
}

GIO_ERROR
gio_resume_events(void)
{
  GIO_ERROR err = GIO_ERR_NO_ERROR;

  if (gSuspensionLevel == 0) {
    err = GIO_ERR_PARAMETER_ERROR;

  } else if (--gSuspensionLevel == 0) {
    // Level 0 reached - must resume.
    err = SessionFactory::resumeEvents();
  }

  return gio_set_errno_(0, err);
}

GIO_ERROR
gio_wait_event(uint32_t milliSeconds)
{
  GIO_ERROR err = GIO_ERR_NO_ERROR;

  /* Reset the event flag. */
  gEventHandled = 0;

  if (gSuspensionLevel > 0) {
    // Temporarily resume event processing.
    gio_merge_errors_(err, SessionFactory::resumeEvents());
  }

  // Compute the end time of the timeout interval.
  struct timeval now;
  gettimeofday(&now, 0);

  struct timeval timeout;
  timeout.tv_usec = (milliSeconds % 1000) * 1000;
  timeout.tv_sec  = (milliSeconds / 1000);
  timeradd(&now, &timeout, &timeout);

  // Loop until an event was handled or the timeout expires.
  while (!gEventHandled) {
    // Sleep for 100ms.
    struct timeval tick;
    tick.tv_sec  = 0;
    tick.tv_usec = 100000;
    select(0, 0, 0, 0, &tick); // NB: 'tick' is undefined after return!

    if (milliSeconds > 0) {
      // Check if timeout has expired. */
      gettimeofday(&now, 0);
      if (timercmp(&now, &timeout, >)) {
        break;
      }
    }
  }

  if (gSuspensionLevel > 0) {
    // Restore event suspensions.
    gio_merge_errors_(err, SessionFactory::suspendEvents());
  }

  // CR-137615: We must check gEventHandled again since an event could have
  //            occurred right after the timeout expired, before re-suspending.
  if (!gEventHandled) {
    gio_merge_errors_(err, GIO_ERR_IO_TIMEOUT);
  }

  return gio_set_errno_(0, err);
}

GIO_ERROR
gio_set_termchr(IDID pIO, int termChar)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->set_termchr(termChar);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_get_termchr(IDID pIO, int *pTermChar)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->get_termchr(pTermChar);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_set_timeout(IDID pIO, uint32_t milliSeconds)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->set_timeout(milliSeconds);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_get_timeout(IDID pIO, uint32_t *pMilliSeconds)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->get_timeout(pMilliSeconds);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_set_lock_wait(IDID pIO, bool_t flag)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->set_lock_wait(flag);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_get_lock_wait(IDID pIO, bool_t *pFlag)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->get_lock_wait(pFlag);
  }

  return gio_set_errno_(pIO, err);
}

GIO_ERROR
gio_get_errno(void)
{
  return gErrorCode;
}

void
gio_cause_error(IDID id, GIO_ERROR errorCode, bool_t flag)
{
  gErrorCode = errorCode;

  if (flag && (errorCode != GIO_ERR_NO_ERROR)) {
    // Call appropriate error handler, if one is defined.
    if (gErrorHandler) {
      gErrorHandler(id, errorCode);
    }
  }
}

const char *
gio_get_error_str(IDID pIO, GIO_ERROR errorCode)
{
  // Delegate to the access method if possible.
  const char *pResult = 0;

  if (checkIDID(pIO) == GIO_ERR_NO_ERROR) {
    pResult = pIO->get_error_str(errorCode);
  }

  if (!pResult) {
    // Fallback for common errors.
    switch (errorCode) {

    case GIO_ERR_NO_ERROR:
      pResult = "No error.";
      break;

    case GIO_ERR_INVALID_SYMBOLIC_NAME:
      pResult = "Invalid symbolic name.";
      break;

    case GIO_ERR_DEVICE_NOT_ACCESSIBLE:
      pResult = "Device not accessible.";
      break;

    case GIO_ERR_INVALID_ID:
      pResult = "Invalid interface or device ID.";
      break;

    case GIO_ERR_PARAMETER_ERROR:
      pResult = "Parameter error.";
      break;

    case GIO_ERR_PERMISSION_DENIED:
      pResult = "Permission denied";
      break;

    case GIO_ERR_OUT_OF_RESOURCES:
      pResult = "Out of resources.";
      break;

    case GIO_ERR_BAD_FORMAT:
      pResult = "Bad format";
      break;

    case GIO_ERR_IO_TIMEOUT:
      pResult = "I/O timeout";
      break;

    case GIO_ERR_IO_ERROR:
      pResult = "I/O error";
      break;

    case GIO_ERR_NOT_IMPLEMENTED:
      pResult = "Operation not implemented.";
      break;

    case GIO_ERR_NO_ACCESS_METHOD:
      pResult = "Symbolic name contains no access method.";
      break;

    case GIO_ERR_ACCESS_METHOD_NOT_FOUND:
      pResult = "Access method not found.";
      break;

    default:
      break;
    }
  }

  return pResult;
}

gio_error_handler_t
gio_set_error_handler(gio_error_handler_t handler)
{
  gio_error_handler_t oldHandler = gErrorHandler;
  gErrorHandler = handler;
  return oldHandler;
}

void
GIO_ERROR_NO_EXIT(IDID pIO, GIO_ERROR error)
{
  const char *const pName = gio_get_name(pIO);
  const char *const pMsg  = gio_get_error_str(pIO, error);

  // Print diagnostic message.
  fprintf(stderr, "GIO ERROR %d (%s): %s\n",
          error,
          pName ? pName : "-",
          pMsg  ? pMsg  : "-");
}

void
GIO_ERROR_EXIT(IDID pIO, GIO_ERROR error)
{
  // Print diagnostic message and exit.
  GIO_ERROR_NO_EXIT(pIO, error);
  exit(42);
}

GIO_ERROR
gio_do_nothing(IDID pIO)
{
  GIO_ERROR err = checkIDID(pIO);

  if (err == GIO_ERR_NO_ERROR) {
    err = pIO->do_nothing();
  }

  return gio_set_errno_(pIO, err);
}
