/* -*-C++-*- */
/**
 * Base class representing an external interface or device.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   generic_io_t.hpp
 * @author Jens Kilian
 * @date   Created:  Wed Dec 12 11:12:35 2012
 * @date   Modified: Wed Feb 10 10:04:14 2016 (Jens Kilian)
 *
 * The interface defined in this file is used for communication between
 * the generic (client visible) layer of the GIO module and the individual
 * "access methods" which encapsulate the actual hardware interfaces.
 ******************************************************************************
 */

#ifndef H7C8710BC_5597_43E0_B29C_4B29936E26EC_
#define H7C8710BC_5597_43E0_B29C_4B29936E26EC_

#include "xoc/hw/cor/gio/gio.h"

#include <string>

namespace hw_cor_hwio_GenericIo
{
  class SessionFactory;
}

/**
 * Base class describing an interface or device session.
 *
 * Every interface or device session opened by a client application
 * is represented internally by an instance of a class derived from
 * @c generic_io_t which contains local data for that session.
 */
struct generic_io_t {
  /** Get the factory which created this session. */
  const ::hw_cor_hwio_GenericIo::SessionFactory &
  factory(void) const
  {
    return mFactory;
  }

  /** Get the name of the session. */
  const ::std::string &
  name(void) const
  {
    return mName;
  }

  /** @name Operations applicable to diverse interface or device types
   * These functions (or a large subset) will be supported by most access
   * methods.  
   */
  /*@{*/

  /**
   * Close and delete the session.
   *
   * This function is called by @c gio_close().
   * The reason for providing this method instead of a public destructor
   * is to allow errors to be reported back to the caller.
   *
   * Derived classes must always override this function.  If an error occurs,
   * it must be reported using @c gio_set_errno_() before the session is
   * destroyed.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  close(
    /** Error code (used when a session is implicitly closed). */
    GIO_ERROR err = GIO_ERR_NO_ERROR) = 0;

  /**
   * Clear an interface or device.
   *
   * This function is called by @c gio_clear().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  clear(void);

  /**
   * Write data.
   *
   * This function is called by @c gio_write().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  write(
    /** Buffer containing data to be written. */
    const void *pBuffer,
    /** Amount of data to be written. */
    size_t len,
    /** Send last byte with END indicator. */
    bool_t end,
    /** OUT: Actual number of bytes written. */
    size_t *pActual);

  /**
   * Read data.
   *
   * This function is called by @c gio_read().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  read(
    /** Buffer into which data should be read. */
    void *pBuffer,
    /** Size of buffer. */
    size_t len,
    /** OUT: Reasons for termination. */
    int *pReasons,
    /** OUT: Actual number of bytes read. */
    size_t *pActual);

  /**
   * Read status byte.
   *
   * This function is called by @c gio_read_status_byte().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  read_status_byte(
    /** OUT: Status byte. */
    uint8_t *pStb);

  /**
   * Set status byte.
   *
   * This function is called by @c gio_set_status_byte().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  set_status_byte(
    /** Status byte. */
    uint8_t stb);

  /**
   * Trigger device(s).
   *
   * This function is called by @c gio_trigger().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  trigger(void);

  /**
   * Switch device to local operation.
   *
   * This function is called by @c gio_local().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  local(void);

  /**
   * Switch device to remote operation.
   *
   * This function is called by @c gio_remote().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  remote(void);

  /**
   * Lock an interface or device.
   *
   * This function is called by @c gio_lock().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  lock(void);

  /**
   * Unlock an interface or device.
   *
   * This function is called by @c gio_unlock().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  unlock(void);

  /*@}*/

  /** @name Operations specific to GPIB devices
   * The functions in this section will only be overridden by access methods
   * which support GPIB hardware.
   */
  /*@{*/

  /**
   * Send an IFC (interface clear) on a GPIB interface.
   *
   * This function is called by @c gio_gpib_send_IFC().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  gpib_send_IFC(void);

  /**
   * Send a GPIB command.
   *
   * This function is called by @c gio_gpib_send_cmd().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  gpib_send_cmd(
    /** Command to be sent. */
    const void *pCommand,
    /** Length of command. */
    size_t len);

  /**
   * Inquire GPIB bus status.
   *
   * This function is called by @c gio_gpib_bus_status().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  gpib_bus_status(
    /** Request type. */
    GIO_GPIB_STATUS_REQUEST request,
    /** OUT: Status. */
    uint8_t *pResult);

  /**
   * Control the ATN (attention) line on a GPIB interface.
   *
   * This function is called by @c gio_gpib_ATN_control().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  gpib_ATN_control(
    /** New status of ATN line. */
    bool_t enable);

  /**
   * Control the REN (remote enable) line on a GPIB interface.
   *
   * This function is called by @c gio_gpib_REN_control().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  gpib_REN_control(
    /** New status of REN line. */
    bool_t enable);

  /**
   * Place all devices on a GPIB interface into local lockout mode.
   *
   * This function is called by @c gio_gpib_local_lockout().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  gpib_local_lockout(void);

  /*@}*/

  /** @name Operations specific to RS-232 devices
   * The functions in this section will only be overridden by access methods
   * which support RS-232 hardware.
   */
  /*@{*/

  /**
   * Send BREAK signal on an RS-232 interface.
   *
   * This function is called by @c gio_rs232_break().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  rs232_break(void);

  /**
   * Control communication parameters of an RS-232 interface.
   *
   * This function is called by @c gio_rs232_control().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  rs232_control(
    /** Feature to be modified. */
    GIO_RS232_REQUEST request,
    /** New setting of feature. */
    uint32_t setting);

  /**
   * Inquire status of an RS-232 interface.
   *
   * This function is called by @c gio_rs232_status().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  rs232_status(
    /** Type of status report. */
    GIO_RS232_REQUEST request,
    /** OUT: Current state. */
    uint32_t *pResult);

  /**
   * Control modem control lines of an RS-232 interface.
   *
   * This function is called by @c gio_rs232_modem_control().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  rs232_modem_control(
    /** Modem control line to be modified. */
    GIO_RS232_MODEM_CONTROL line,
    /** New status of line. */
    bool_t enable);

  /**
   * Inquire modem control line status of an RS-232 interface.
   *
   * This function is called by @c gio_rs232_modem_control_status().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  rs232_modem_control_status(
    /** Modem control line to check. */
    GIO_RS232_MODEM_CONTROL line,
    /** OUT: Status of line. */
    bool_t *pStatus);

  /*@}*/

  /** @name Asynchronous events
   * These functions support processing of asynchronous events (service
   * requests and interrupts).\ They interact with functions in the generic
   * layer.
   */
  /*@{*/

  /**
   * Set the SRQ handler.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  GIO_ERROR
  setSRQHandler(
    /** New SRQ handler. */
    gio_SRQ_handler_t newHandler);

  /**
   * Enable resp.\ disable SRQ callbacks.
   *
   * This function is called by @c gio_set_SRQ_handler() if the
   * current status of service requests (enabled or disabled) is changing.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  enable_SRQ_callback(
    /** New status. */
    bool_t enable);

  /*@}*/

  /** @name Parameters affecting communication with devices
   * Most access methods will implement the functions in this section,
   * which are called by their counterparts in the generic layer.
   */
  /*@{*/

  /**
   * Set termination character.
   *
   * This function is called by @c gio_set_termchr().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  set_termchr(
    /** New termination character. */
    int termChar);

  /**
   * Inquire current termination character.
   *
   * This function is called by @c gio_get_termchr().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  get_termchr(
    /** OUT: Termination character. */
    int *pTermChar);

  /**
   * Set timeout.
   *
   * This function is called by @c gio_set_timeout().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  set_timeout(
    /** New timeout. */
    uint32_t milliSeconds);

  /**
   * Inquire current timeout.
   *
   * This function is called by @c gio_get_timeout().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  get_timeout(
    /** OUT: Current timeout. */
    uint32_t *pMilliSeconds);

  /**
   * Set lock waiting flag.
   *
   * This function is called by @c gio_set_lock_wait().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  set_lock_wait(
    /** Lock waiting flag. */
    bool_t flag);

  /**
   * Inquire current lock waiting flag.
   *
   * This function is called by @c gio_get_lock_wait().
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   * @retval other            An error occurred.
   */
  virtual GIO_ERROR
  get_lock_wait(
    /** OUT: Lock waiting flag. */
    bool_t *pFlag);

  /*@}*/

  /** @name Error handling
   * These functions must be implemented by any access method that can return
   * an error code other than @c GIO_ERR_NO_ERROR (i.e., practically everyone).
   */
  /*@{*/

  /**
   * Inquire human-readable description of a given GIO(!) error code.
   *
   * This function is called by @c gio_get_error_str().
   *
   * @attention
   * The access method must translate the GIO @c error back to its local
   * error code set.  If it encounters an error it doesn't know, it must
   * return @c NULL to notify the generic layer of the problem.
   *
   * @return const char *
   * @retval NULL  The access method cannot interpret the given error code.
   * @retval other String describing the error (may be in static memory).
   */
  virtual const char *
  get_error_str(
    /** Error code. */
    GIO_ERROR error);

  /*@}*/

  /** @name Miscellany */
  /*@{*/

  /**
   *
   * Dummy function for testing purposes.
   *
   * This function is called by @c gio_do_nothing().
   *
   * OK, so we lied and @c gio_do_nothing() really @e does do something.
   * But it's still pretty useless, as an access method isn't allowed to
   * do anything else in here.
   *
   * @return GIO_ERROR
   * @retval GIO_ERR_NO_ERROR Operation successfully completed.
   */
  virtual GIO_ERROR
  do_nothing(void);

  /*@}*/

protected:
  /** Construct a new session. */
  generic_io_t(
    /** Factory creating this session. */
    const ::hw_cor_hwio_GenericIo::SessionFactory &factory,
    /** Symbolic name of interface or device. */
    const ::std::string &name);

  /** Destroy the session. */
  virtual ~generic_io_t(void)
  {
    // empty
  }

  /**
   * SRQ callback function.
   *
   * This function pointer will be called by the access method when it
   * intercepts a service request.  It is part of the internal mechanism
   * for handling asynchronous events.  This slot normally points to
   * a function in the generic layer which calls the @c mpSRQHandler
   * if it is defined.  An access method may modify this slot for
   * debugging or other purposes.
   */
  gio_SRQ_handler_t mpSRQCallback;

private:
  // Not implemented.
  generic_io_t(const generic_io_t &);
  generic_io_t &operator =(const generic_io_t &);

  /** Default SRQ callback. */
  static void
  handleSRQ(generic_io_t *pIo);

  /**
   * Factory which created the session.
   *
   * This is used by gio_get_interface() to create an associated
   * interface session.
   */
  const ::hw_cor_hwio_GenericIo::SessionFactory &mFactory;
  /**
   * Symbolic name of the session.
   *
   * This is the string which was used by the client application to
   * open the session.
   */
  const ::std::string mName;
  /**
   * Client application's SRQ handler.
   *
   * This slot contains a pointer to the client application's SRQ handler
   * for this session; if the client has not defined an SRQ handler, the
   * value of @c mpSRQHandler is zero.
   */
  gio_SRQ_handler_t mpSRQHandler;
};

#endif /* H7C8710BC_5597_43E0_B29C_4B29936E26EC_ */
