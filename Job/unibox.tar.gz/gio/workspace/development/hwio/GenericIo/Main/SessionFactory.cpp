/* -*-C++-*- */
/**
 * Base class for factories of interface and device sessions.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   SessionFactory.cpp
 * @author Jens Kilian
 * @date   Created:  Thu Dec 13 08:41:54 2012
 * @date   Modified: Fri Jan 15 10:49:11 2016 (Jens Kilian)
 ******************************************************************************
 */

#include "SessionFactory.hpp"

#include <algorithm>
#include <cassert>
#include <map>
using namespace ::std;

#include "gio_.hpp"
using namespace hw_cor_hwio_GenericIo;

namespace
{
  /*
   * Local functions.
   * --------------------------------------------------------------------------
   */

  /** Type of registry for session factories. */
  typedef map<string, SessionFactory *> SessionFactoryRegistry;

  /** Retrieve registry for session factories.
   *
   * This is not a global variable because the order of initializations
   * is not predictable between translation units.  When a session factory
   * is statically initialized, it must be able to register itself even
   * if the initializers for this file have not yet run.
   */
  SessionFactoryRegistry &
  sessionFactoryRegistry(void)
  {
    static SessionFactoryRegistry registry;
    return registry;
  }
}

namespace hw_cor_hwio_GenericIo
{
  SessionFactory::SessionFactory(const string &prefix)
  : mPrefix(prefix)
  {
    // Ensure the prefix is not already registered.
    SessionFactory *&factory = sessionFactoryRegistry()[mPrefix];
    assert(!factory);

    // Register this object as the factory for the given prefix.
    factory = this;
  }

  SessionFactory::~SessionFactory(void)
  {
    // Ensure this object is the one registered for its prefix.
    SessionFactory *&factory = sessionFactoryRegistry()[mPrefix];
    assert(factory == this);

    // Unregister this object.
    factory = 0;
  }

  generic_io_t *
  SessionFactory::create(const string &name)
  {
    try {
      // Identify the correct access method.
      //
      // The access method is given by a prefix of the symbolic name,
      // separated with a '/'.
      string prefix;

      string::size_type slashPos = name.find('/');
      if ((slashPos > 0) && (slashPos != string::npos)) {
        // Use given prefix.
        prefix = name.substr(0, slashPos);
        ++slashPos;
      } else {
        // Missing or empty prefix - error.
        gio_set_errno_(0, GIO_ERR_NO_ACCESS_METHOD);
        return 0;
      }

      // Find the corresponding factory.
      SessionFactory *const factory = sessionFactoryRegistry()[prefix];
      if (!factory) {
        // Error - invalid prefix.
        gio_set_errno_(0, GIO_ERR_ACCESS_METHOD_NOT_FOUND);
        return 0;
      }

      // Use the factory to create the session.
      return factory->create(name.substr(slashPos), 0);

    } catch (bad_alloc &) {
      gio_set_errno_(0, GIO_ERR_OUT_OF_RESOURCES);
      return 0;
    }
  }

  GIO_ERROR
  SessionFactory::suspendEvents(void)
  {
    GIO_ERROR err = GIO_ERR_NO_ERROR;

    // Notify each registered factory.
    for (SessionFactoryRegistry::iterator i = sessionFactoryRegistry().begin(),
           /* dito */                     e = sessionFactoryRegistry().end();
         i != e;
         ++i)
    {
      gio_merge_errors_(err, i->second->suspendSessionEvents());
    }

    return err;
  }

  GIO_ERROR
  SessionFactory::resumeEvents(void)
  {
    GIO_ERROR err = GIO_ERR_NO_ERROR;

    // Notify each registered factory.
    for (SessionFactoryRegistry::iterator i = sessionFactoryRegistry().begin(),
           /* dito */                     e = sessionFactoryRegistry().end();
         i != e;
         ++i)
    {
      gio_merge_errors_(err, i->second->resumeSessionEvents());
    }

    return err;
  }
}
