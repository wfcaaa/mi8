/* -*-C++-*- */
/**
 * Base class for factories of interface and device sessions.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   SessionFactory.hpp
 * @author Jens Kilian
 * @date   Created:  Thu Dec 13 08:29:52 2012
 * @date   Modified: Fri Feb  8 15:28:35 2013 (Jens Kilian)
 ******************************************************************************
 */

#ifndef H5FC92F3E_710C_4588_86DF_300BF106B8EC_
#define H5FC92F3E_710C_4588_86DF_300BF106B8EC_

#include <string>

#include "xoc/hw/cor/gio/gio.h"

namespace hw_cor_hwio_GenericIo
{
  /** Base class for session factories. */
  class SessionFactory
  {
  public:
    /** Destroy a SessionFactory. */
    virtual ~SessionFactory(void);

    /** Create a session given a full symbolic name. */
    static generic_io_t *
    create(
      /** Symbolic name of interface or device. */
      const ::std::string &name);

    /** Create a session with the given local symbolic name. */
    virtual generic_io_t *
    create(
      /** Symbolic name of interface or device, without prefix. */
      const ::std::string &name,
      /** Associated device session (@c gio_get_interface() only). */
      generic_io_t *pDevice) const = 0;

    /**
     * Globally suspend asynchronous events in all active sessions.
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    static GIO_ERROR
    suspendEvents(void);

    /**
     * Globally resume asynchronous events in all active sessions.
     *
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    static GIO_ERROR
    resumeEvents(void);

  protected:
    /** Construct a SessionFactory. */
    SessionFactory(
      /** Symbolic name prefix for sessions created by this factory. */
      const ::std::string &prefix);

    /**
     * Suspend asynchronous events in all sessions created by this factory.
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    virtual GIO_ERROR
    suspendSessionEvents(void) = 0;

    /**
     * Resume asynchronous events in all sessions created by this factory.
     *
     * @attention
     * The factory is responsible for not losing events which occur
     * between suspension and resumption.  It must deliver pending events
     * after resumption, in the correct order.
     *
     * @return GIO_ERROR
     * @retval GIO_ERR_NO_ERROR Operation successfully completed.
     * @retval other            An error occurred.
     */
    virtual GIO_ERROR
    resumeSessionEvents(void) = 0;

  private:
    // Not implemented.
    SessionFactory(const SessionFactory &);
    SessionFactory &operator =(const SessionFactory &);

    /** Symbolic name prefix. */
    const ::std::string mPrefix;
  };
}

#endif /* H5FC92F3E_710C_4588_86DF_300BF106B8EC_ */
