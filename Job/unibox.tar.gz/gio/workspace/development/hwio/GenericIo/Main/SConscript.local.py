# Builds hw_cor_gio C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
    'PROJECT_TYPE' : ['utility_library'],
    'NAME' : ['hw_cor_gio'],
    'CXXFLAGS_LOCAL' : ['--std=c++11',
                        '-D__STDC_LIMIT_MACROS',    # see <stdint.h>
                        '-DFD_SETSIZE=512',         # must match kernel 'maxfiles'
                        '-Wno-unused-variable'],    # XDR routines trigger this
    'LDFLAGS_LOCAL' : ['-lnsl', '-lpthread']
}
# **** CODE GENERATOR CHECKSUM ae12273e1ed64c8aab4aa20135f38d94
