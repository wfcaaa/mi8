/* -*-C++-*- */
/**
 * Internal routines.
 ******************************************************************************
 * (C) Copyright 2012 Advantest Europe GmbH
 * All Rights Reserved.
 ******************************************************************************
 * 
 * @file   gio_.hpp
 * @author Jens Kilian
 * @date   Created:  Thu Dec 13 08:47:45 2012
 * @date   Modified: Fri Dec 14 09:37:19 2012 (Jens Kilian)
 ******************************************************************************
 */

#ifndef HC8C6C8AE_687B_4B85_9771_38C46D407FFE_
#define HC8C6C8AE_687B_4B85_9771_38C46D407FFE_

#include "xoc/hw/cor/gio/gio.h"

namespace hw_cor_hwio_GenericIo
{
  /** Note that an asynchronous event (SRQ or interrupt) has been handled. */
  void
  gio_event_handled_(void);

  /** Signal an error.
   *
   * @return GIO_ERROR Same value as passed in.
   */
  GIO_ERROR
  gio_set_errno_(
    /** Session which caused the error (may be 0). */
    generic_io_t *pIo,
    /** Error code. */
    GIO_ERROR errorCode);

  /** Propagate errors.
   *
   * If 'err1' is GIO_ERR_NO_ERROR, set it to 'err2'.  Otherwise preserve
   * the older error code.
   */
  void
  gio_merge_errors_(GIO_ERROR &err1, GIO_ERROR err2);
}

#endif /* HC8C6C8AE_687B_4B85_9771_38C46D407FFE_ */
