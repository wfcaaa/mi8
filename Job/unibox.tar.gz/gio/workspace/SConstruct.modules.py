{'c_program': ['development/hwio/GenericIo/TestServer/Main/SConscript',
               'development/hwio/GenericIo/Rs232Monitor/Main/SConscript',
               'development/hwio/GenericIo/GioWrite/Main/SConscript',
               'development/hwio/GenericIo/GioRead/Main/SConscript',
               'development/hwio/GenericIo/GioClear/Main/SConscript',
               'development/hwio/GenericIo/UnitTest/Main/SConscript'],
 'utility_library': ['development/hwio/GenericIo/Main/SConscript']}
