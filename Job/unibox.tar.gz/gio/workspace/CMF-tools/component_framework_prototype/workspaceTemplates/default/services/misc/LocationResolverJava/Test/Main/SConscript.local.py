# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'REQUIRED_LIBS' : ['#lib/LocationResolver.jar'] ,
'PROJECT_TYPE' : ['java_component_exe'] ,
'NAME' : ['LocationResolverTester'] ,
#'DEST' : ['services/misc/LocationResolverJava/Test'] ,
#'CLASSPATH_LOCAL' : ['$WORKSPACE/services/misc/LocationResolverJava/LocationResolver.jar']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = java_component_exe
#NAME           = LocationResolverTester
#
#DEST=services/misc/LocationResolverJava/Test
#
#CLASSPATH_LOCAL = $(WORKSPACE)/services/misc/LocationResolverJava/LocationResolver.jar
#
#REQUIRED_MODULES = services/misc/LocationResolver/Main \
#                   services/misc/LocationResolverJava/Main
