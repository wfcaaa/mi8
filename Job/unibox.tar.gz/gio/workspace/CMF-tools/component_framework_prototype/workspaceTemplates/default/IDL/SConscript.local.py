# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'PROJECT_TYPE' : ['rdb_package'] ,
'NAME' : ['zenith'],
'IDL_BASE_DIRECTORIES' : ['xoc'],
'IDL_INCLUDE_DIRECTORIES' : ['$WORKSPACE/IDL', '$SDK_IDL_DIR']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE  = rdb_package
#NAME          = zenith
#
#URD_SOURCE_SUBDIR = .
#URD_DEST_SUBDIR = .
#RDB_DEST = $(MODULE)
#REGMERGE_FLAGS_LOCAL = /UCR
#
