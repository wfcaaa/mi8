# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
#'REQUIRED_MODULES' : ['services/session/DebuggerHooker/Main','services/session/UnoServiceHelper/Main','services/misc/SystemLoggerHelper/Main'] ,
'REQUIRED_LIBS' : ['#lib/libSystemLoggerHelper.so',
		   '#lib/libDebuggerHooker.so',
		   '#lib/libservices_session_UnoServiceHelper.so',
		   '#lib/libthreads.so'],

'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['SessionServiceManager'] ,
'DEST' : ['#lib'],
'LDFLAGS_LOCAL' : ['-lDebuggerHooker','-lservices_session_UnoServiceHelper','-lSystemLoggerHelper','-lthreads']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = utility_library
#NAME           = SessionServiceManager
##   flags to pass to the linker
#LDFLAGS_LOCAL      += -lDebuggerHooker \
#   -lservices_session_UnoServiceHelper \
#   -lSystemLoggerHelper
#
#REQUIRED_MODULES = services/session/DebuggerHooker/Main \
#  services/session/UnoServiceHelper/Main \
#  services/misc/SystemLoggerHelper/Main
