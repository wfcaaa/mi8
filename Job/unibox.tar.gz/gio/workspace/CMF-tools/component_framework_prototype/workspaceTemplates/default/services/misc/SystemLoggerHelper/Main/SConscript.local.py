# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'PROJECT_TYPE' : ['shared_library'] ,
'NAME' : ['SystemLoggerHelper'] ,
'DEST' : ['#lib'],
'REQUIRED_LIBS' : ['#lib/libLocationResolver.so'] ,
'LDFLAGS_LOCAL' : ['$LDFLAGS_SYSTEM_LOGGER','-lLocationResolver']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = shared_library
#NAME           = SystemLoggerHelper
#
#LDFLAGS_LOCAL += $(LDFLAGS_SYSTEM_LOGGER) $(LDFLAGS_STLPORT_LIB) $(LDFLAGS_SAL_LIB) -lLocationResolver
#
#REQUIRED_MODULES += services/misc/LocationResolver/Main
