# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'PROJECT_TYPE' : ['java_component_utility'] ,
'NAME' : ['LocationResolver'],
'DEST' : ['#lib']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = java_component_utility
#NAME           = LocationResolver
#
#REQUIRED_MODULES = 
