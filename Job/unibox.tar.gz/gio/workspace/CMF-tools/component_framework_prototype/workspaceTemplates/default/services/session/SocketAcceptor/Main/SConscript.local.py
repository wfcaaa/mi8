#GENERATED
# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'REQUIRED_MODULES' : ['services/zutils/Main'] ,
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['services_session_SocketAcceptor'] ,
'LDFLAGS_LOCAL' : ['-lservices_zutils'],
'DEST' : ['#componentPackages']
}
# +++ map above generated from this Makefile.local:
## Builds services_session_SocketAcceptor C++ Implementation
## 
## Developer maintained file, initial version is created by component generator
##
#PROJECT_TYPE   = cpp_component
#NAME           = services_session_SocketAcceptor
#
## Use the following make variables to localize the build:
##   flags to pass to the compiler
##CXXFLAGS_LOCAL     +=
##   list of locations to find headers to include when compiling 
##INCLUDE_PATH_LOCAL +=
##   flags to pass to the linker
#LDFLAGS_LOCAL      +=-lservices_zutils
#
#REQUIRED_MODULES += services/zutils/Main
#
## **** CODE GENERATOR CHECKSUM 54c42185f68bb76a442f3ce383dc5f96
