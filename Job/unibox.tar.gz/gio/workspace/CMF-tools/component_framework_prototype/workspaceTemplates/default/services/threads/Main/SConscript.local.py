# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['threads'] ,
'LDFLAGS_LOCAL' : ['$LDFLAGS_ACE',
                   '$LDFLAGS_UNO',
                   '$LDFLAGS_SYSTEM_LOGGER'],
'DEST' : ['#lib']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = utility_library
#NAME           = threads
#
#LDFLAGS_LOCAL  = $(LDFLAGS_ACE)
#
#
