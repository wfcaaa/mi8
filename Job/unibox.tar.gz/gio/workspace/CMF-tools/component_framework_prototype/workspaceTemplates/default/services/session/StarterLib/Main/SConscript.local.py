# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'REQUIRED_LIBS' : ['#lib/libExceptionSupport.so',
                   '#lib/libSystemLoggerHelper.so',
		   '#lib/libservices_session_UnoServiceHelper.so',
		   '#lib/libSessionServiceManager.so',
		   '#lib/libLocationResolver.so',
		   '#lib/libDebuggerHooker.so',
		   '#lib/libservices_zsignal.so',
		   '#lib/libservices_zutils.so',
		   '#lib/libthreads.so'] ,
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['services_session_StarterLib'] ,
'DEST' : ['#lib'],
'LDFLAGS_LOCAL' : ['-lExceptionSupport','-lSessionServiceManager','-lLocationResolver','-lSystemLoggerHelper','-lservices_zsignal','-lDebuggerHooker','-lservices_session_UnoServiceHelper','-lservices_zutils','-lthreads']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = utility_library
#NAME           = services_session_StarterLib
#
#LDFLAGS_LOCAL  = \
#    -lExceptionSupport \
#    -lSessionServiceManager \
#    -lLocationResolver \
#    -lSystemLoggerHelper \
#    -lservices_zsignal \
#    -lDebuggerHooker \
#    -lservices_session_UnoServiceHelper \
#    -lservices_zutils \
#    -lthreads
#
#REQUIRED_MODULES += services/exception/ExceptionSupport/Main \
#                    services/misc/SystemLoggerHelper/Main \
#                    services/session/UnoServiceHelper/Main \
#                    services/session/SessionServiceManager/Main \
#                    services/misc/LocationResolver/Main \
#                    services/session/DebuggerHooker/Main \
#                    services/signal_handling/Main/ \
#                    services/zutils/Main \
#                    services/threads/Main
#
