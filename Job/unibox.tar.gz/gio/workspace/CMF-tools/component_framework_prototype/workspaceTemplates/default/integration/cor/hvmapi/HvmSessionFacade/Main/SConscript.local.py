# Builds integration_cor_hvmapi_HvmSessionFacade C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['integration_cor_hvmapi_HvmSessionFacade'],
'DEST' : ['#componentPackages']
}
# **** CODE GENERATOR CHECKSUM f630fbc79b0a0ccfc2fb6a0ed56fe34f
