# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'REQUIRED_LIBS' : ['#lib/SystemLoggerHelper.jar'] ,
'PROJECT_TYPE' : ['java_component_package'] ,
'NAME' : ['services_session_ZSCompF'] ,
'CLASSPATH_LOCAL' : ['/usr/share/java/log4j.jar']
}
# +++ map above generated from this Makefile.local:
## Builds services_session_ZSCompF Java Implementation
## 
## Developer maintained file, initial version is created by component generator
##
#PROJECT_TYPE   = java_component_package
#NAME           = services_session_ZSCompF
#
#REQUIRED_MODULES = services/misc/SystemLoggerHelperJava/Main
## Add following to REQUIRED_MODULES if component uses SessionServiceManger
## services/session/SessionServiceManagerJava/Main
#
## Jars in CLASSPATH_LOCAL may also need to go in component .mf file
#CLASSPATH_LOCAL = /usr/share/java/log4j.jar:${WORKSPACE}/services/misc/SystemLoggerHelperJava/SystemLoggerHelper.jar
## Add following to CLASSPATH_LOCAL if component uses SessionServiceManger
## ${WORKSPACE}/services/session/SessionServiceManagerJava/SessionServiceManager.jar
## **** CODE GENERATOR CHECKSUM d1e2befae80c96f7521f2cf290f964d0
