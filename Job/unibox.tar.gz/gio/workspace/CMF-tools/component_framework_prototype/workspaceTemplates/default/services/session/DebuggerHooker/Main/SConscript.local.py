#GENERATED
# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
#'PROJECT_TYPE' : ['utility_library'] ,
'PROJECT_TYPE' : ['shared_library'] ,
'NAME' : ['DebuggerHooker'],
'LDFLAGS_LOCAL' : ['$LDFLAGS_UNO',
                   '$LDFLAGS_SYSTEM_LOGGER'],
'DEST' : ['#lib']
}
# +++ map above generated from this Makefile.local:
## Builds DebuggerHooker C++ Implementation
## 
## Developer maintained file, initial version is created by component generator
##
#PROJECT_TYPE   = utility_library
#NAME           = DebuggerHooker
#
## Use the following make variables to localize the build:
##   flags to pass to the compiler
##CXXFLAGS_LOCAL     +=
##   list of locations to find headers to include when compiling 
##INCLUDE_PATH_LOCAL +=
##   flags to pass to the linker
##LDFLAGS_LOCAL      +=
# **** CODE GENERATOR CHECKSUM 1b4167cb67d6a56356dc2c5d188f16a1