# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
#'REQUIRED_MODULES' : ['services/exception/ExceptionSupport/Main','services/session/SessionServiceManager/Main','services/misc/LocationResolver/Main','services/misc/SystemLoggerHelper/Main','services/session/DebuggerHooker/Main','services/session/UnoServiceHelper/Main','services/zutils/Main'] ,
'REQUIRED_LIBS' : ['#lib/libExceptionSupport.so',
                   '#lib/libSessionServiceManager.so',
		   '#lib/libLocationResolver.so',
		   '#lib/libSystemLoggerHelper.so',
		   '#lib/libDebuggerHooker.so',
		   '#lib/libservices_session_UnoServiceHelper.so',
		   '#lib/libservices_zutils.so'] ,
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['SessionAccess'] ,
'DEST' : ['#lib'],
'LDFLAGS_LOCAL' : ['-lExceptionSupport','-lSessionServiceManager','-lLocationResolver','-lSystemLoggerHelper','-lDebuggerHooker','-lservices_session_UnoServiceHelper','-L$UNO_SDK_LIB_DIR','-lsalcpprt','-lservices_zutils']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = utility_library
#NAME           = SessionAccess
#
#LDFLAGS_LOCAL +=  \
#                 -lExceptionSupport \
#                 -lSessionServiceManager \
#                 -lLocationResolver \
#                 -lSystemLoggerHelper \
#                 -lDebuggerHooker \
#                 -lservices_session_UnoServiceHelper \
#                 -lsalcpprt \
#                 -lservices_zutils
#
#REQUIRED_MODULES =  services/exception/ExceptionSupport/Main \
#                    services/session/SessionServiceManager/Main \
#                    services/misc/LocationResolver/Main \
#                    services/misc/SystemLoggerHelper/Main \
#                    services/session/DebuggerHooker/Main \
#                    services/session/UnoServiceHelper/Main \
#                    services/zutils/Main
