# Builds services_session_SessionManager C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'REQUIRED_MODULES' : ['services/session/UnoServiceHelper/Main','services/misc/LocationResolver/Main','services/zutils/Main'] ,
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['services_session_SessionManager'] ,
'DEST' : ['#componentPackages'],
'LDFLAGS_LOCAL' : ['-lservices_session_UnoServiceHelper','-lLocationResolver','-lservices_zutils'] ,
}
# **** CODE GENERATOR CHECKSUM 0a84fe43158e784e4af45b97d6aa9d9a
