#GENERATED
# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'REQUIRED_LIBS' : ['#lib/libDebuggerHooker.so'] ,
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['services_session_UnoServiceHelper'] ,
'LDFLAGS_LOCAL' : ['-lDebuggerHooker',
                   '-lLocationResolver',
                   '$LDFLAGS_SYSTEM_LOGGER',
                   '$LDFLAGS_UNO'],
'DEST' : ['#lib']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = utility_library
#NAME           = services_session_UnoServiceHelper
#
#LDFLAGS_LOCAL += -lDebuggerHooker
#
#REQUIRED_MODULES = services/session/DebuggerHooker/Main
