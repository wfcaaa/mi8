# Builds services_zutils C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'REQUIRED_LIBS' : ['#lib/libSessionServiceManager.so'] ,
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['services_zutils'],
'DEST' : ['#lib'],
'LDFLAGS_LOCAL' : ['-lSessionServiceManager']
}
# **** CODE GENERATOR CHECKSUM 14aad46dc44f6fb3ab6872b8e88d4bfc
