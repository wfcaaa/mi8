#GENERATED
# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'REQUIRED_LIBS' : ['#lib/libservices_xocLog4c.so'] ,
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['DummyXocLog4cClient'] ,
'LDFLAGS_LOCAL' : ['-lservices_xocLog4c']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = shared_library
#NAME           = DummyXocLog4cClient
#
#REQUIRED_MODULES = services/misc/xocLog4c/Main
#
#LDFLAGS_LOCAL = -lservices_xocLog4c
#
