# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
#'REQUIRED_MODULES' : ['services/zutils/Main','services/session/SessionAccessLib/Main'] ,
'REQUIRED_LIBS' : ['#lib/libservices_zutils.so',
                   '#lib/libSessionAccess.so',
		   '#lib/libservices_zcoco.so'] ,
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['hvm_cpp'] ,
'DEST' : ['#lib'],
'LDFLAGS_LOCAL' : ['$LDFLAGS_SYSTEM_LOGGER',
                   '-lservices_zutils',
                   '-lSessionAccess',
		   '-lservices_zcoco',
		   '$LDFLAGS_UNO']
}
# +++ map above generated from this Makefile.local:
## Builds hvm_cpp C++ Implementation
## 
## Developer maintained file, initial version is created by component generator
##
#PROJECT_TYPE   = utility_library
#NAME           = hvm_cpp
#
#LDFLAGS_LOCAL  = \
#	-lservices_zutils \
#	-lSessionAccess
#
#REQUIRED_MODULES += \
#	services/zutils/Main \
#	services/session/SessionAccessLib/Main
#
#
## Use the following make variables to localize the build:
##   flags to pass to the compiler
##CXXFLAGS_LOCAL     +=
##   list of locations to find headers to include when compiling 
##INCLUDE_PATH_LOCAL +=
##   flags to pass to the linker
##LDFLAGS_LOCAL      +=
## **** CODE GENERATOR CHECKSUM 62ef3144f8e5f9be5beba7008754439f
