# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'REQUIRED_LIBS' : ['#lib/LocationResolver.jar'] ,
'PROJECT_TYPE' : ['java_component_utility'] ,
'NAME' : ['SystemLoggerHelper'] ,
'DEST' : ['#lib'],
'CLASSPATH_LOCAL' : ['/usr/share/java/log4j.jar']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = java_component_utility
#NAME           = SystemLoggerHelper
#
#CLASSPATH_LOCAL += $(WORKSPACE)/lib/LocationResolver.jar:/usr/share/java/log4j.jar
#
#REQUIRED_MODULES = services/misc/LocationResolverJava/Main
