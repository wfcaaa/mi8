# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['services_zsignal'] ,
'LDFLAGS_LOCAL' : ['-ldl',
                   '$LDFLAGS_UNO',
                   '$LDFLAGS_SYSTEM_LOGGER'] ,
# do not treat warnings as errors for this project! local flags come last.
'CXXFLAGS_LOCAL' : ['-Wno-error'],
'DEST' : ['#lib']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = utility_library
#NAME           = services_zsignal
#
#CFLAGS_WARNINGS_AS_WARNINGS = TRUE
#
#LDFLAGS_LOCAL  = -ldl
#
## Fix for compilation warnings related with intentional use of sigvec.
#ifeq ($(XOC_OS_VERSION), RHEL5)
#  override CXXFLAGS_LOCAL += -Wno-deprecated-declarations
#endif
#
