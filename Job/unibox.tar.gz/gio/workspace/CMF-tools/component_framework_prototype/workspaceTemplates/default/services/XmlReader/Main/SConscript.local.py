# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'USE_PERFMON_LOCAL_SWITCH' : ['TRUE'] ,
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['services_XmlReader'] ,
'LDFLAGS_LOCAL' : ['$LDFLAGS_XERCES'] ,
'CXXFLAGS_LOCAL' : ['$CXXFLAGS_XERCES','-Wno-sign-compare'],
'DEST' : ['#componentPackages']
}
# +++ map above generated from this Makefile.local:
## Builds services_XmlReader C++ Implementation
## 
## Developer maintained file, initial version is created by component generator
##
#PROJECT_TYPE   = cpp_component
#NAME           = services_XmlReader
#
## Use the following make variables to localize the build:
##   flags to pass to the compiler
#CXXFLAGS_LOCAL     = -Wno-sign-compare  # because of xerces warning
##   list of locations to find headers to include when compiling 
#INCLUDE_PATH_LOCAL += \
#  $(INCLUDE_PATH_XERCES)
##   flags to pass to the linker
#LDFLAGS_LOCAL = $(LDFLAGS_XERCES)
#
#USE_PERFMON_LOCAL_SWITCH=TRUE
## **** CODE GENERATOR CHECKSUM 6029542c0d3cfe656a190abb12e87e53
