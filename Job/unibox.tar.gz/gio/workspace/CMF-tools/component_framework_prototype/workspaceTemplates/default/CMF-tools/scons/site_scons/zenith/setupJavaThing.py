'''
this is the setup routine for a Java-style thing
these are shared libraries, utility libraries, cpp component libraries and
cpp executables
Created on July 14, 2010
@author: horstp
'''
from SCons.Script import *

def javaThingInit(callerGlobals, localVars):
    #print localVars
    name = localVars['NAME'][0]
    projectType = localVars['PROJECT_TYPE'][0]
    
    envmap = callerGlobals['zenithEnvironments']
    buildMode = callerGlobals['zenithBuildMode']
    
    # a little bit of progress message; we abbreviate the project type
    # to keep the listing tidy and column-adjusted
    projectTypeAbbreviation = {'java_component_exe'     :'JX',
                               'java_component_package' :'JC',
                               'java_component_utility' :'JU'}
    
    print 'setup %s %s, %s (%s)' % (projectTypeAbbreviation[projectType],
                                    Dir('.').path,
                                    name,
                                    buildMode)
    
    # lets clone a local environment out of the map
    lenv = envmap[projectType][buildMode].Clone()
    
    # we have now an environment instance for this compilation project.
    
    # now process the specials defined in the local configuration file (if any)
    if 'CLASSPATH_LOCAL' in localVars:
        lenv.Append(JAVACLASSPATH = localVars['CLASSPATH_LOCAL'])
        
    # required libs are jar files too, of course
    requiredJars = []
    # for the project type java_component_package we provide some default
    # stuff.
    #if projectType == 'java_component_package':
        # all components do logging...
        #requiredJars = #['#services/misc/SystemLoggerHelperJava/SystemLoggerHelper.jar']
    
    # the user may require more, of course
    if 'REQUIRED_LIBS' in localVars:
        requiredJars.extend(localVars['REQUIRED_LIBS'])
        
    # required jars should be in the classpath
    if requiredJars:
        lenv.Append(JAVACLASSPATH = [File(jar).path for jar in requiredJars])
        
    
    # check for explicite destination, default is the parent directory
    if 'DEST' in localVars:
        # we have an explicit installation destination
        installPlace = localVars['DEST'][0]
        # '.' is locically the same as no destination
        if installPlace == '.':
            installPlace = ''
    else:
        installPlace = '..'
    
    # the source files are always under ./src, the class files go to 
    # ./classes
    # the class files are the 'sources' of the jar
    srcDir = Dir('src')
    classDir = Dir('classes')
    jarSources = []
    
    # if there is a file <name>.xml then we need to generate some types
    # using javamaker
    xmldesc = name + '.xml'
    genincFlag = None
    if os.path.exists(xmldesc):
        # build the cppumaker command line
        # we have t build a genclasses directory; potentially there is a
        # special type registry to be used
        if 'ZENITH_REGISTRY' in localVars:
            lenv.Replace(ZENITH_REGISTRY = localVars['ZENITH_REGISTRY'])
        # the type options list
        from zenith.unoTypesFromXml import typesFromXmlFile
        typeopts = ' '.join(['-T' + t for t in typesFromXmlFile(str(xmldesc))])
        # we create a directory, these are difficult targets. so we use
        # the old trick to define a tag file as target and create the
        # real stuff as side effect.
        genincFlagFile = File('genclasses-flag-file')
        # the cppumaker needs the absolute path to the output
        # directory - probably a bug!
        # hence the ---.abspath stuff
        lenv.Replace(GENINC_DIR = classDir.abspath)
        lenv.Replace(UNO_TYPELIST = typeopts)
        
        # now build the flag file
        genincFlag = lenv.GenClass(genincFlagFile,xmldesc)
        
        # flag files must not be cached! retrieving (only!) the flag file
        # from the cache does not help - the real stuff is built as
        # 'side effect' of the generation of the flag file.
        lenv.NoCache(genincFlag)
        
        # the flag file depends on the used zenith registry
        Depends(genincFlag, lenv.subst('$ZENITH_REGISTRY'))
        # remove the directory with the flag file
        Clean(genincFlag, classDir)
    
    
    
    # compile the java stuff;
    lenv.Prepend(JAVACLASSPATH = classDir.path)
    jarSources.extend(lenv.Java(target = classDir, source = srcDir))
    
    # the jar sources (classes) depend on the generated java stuff
    # and on the required libs
    # required libs are jar files too, of course
    Depends(jarSources, genincFlag)
    if requiredJars:
        Depends(jarSources, requiredJars)
    
    # if there is a manifest file named <name>.mf remember
    # its name for later
    
    theManifestFileName=None
    manifest = name + '.mf'
    if os.path.exists(manifest):
        theManifestFileName = File(manifest).path
    
    # now all the prerequisites to build the jar are done.
    # unfortunately we can not use the scons-supplied jar
    # builder because it is too smart!
    # it automatically keeps track which classes were build by
    # the Java builder and bundles them up ONLY.
    # we have this weird javamaker thing that generates class files
    # (NOT java files!) in the classes directory that must also
    # be bundled up if present.
    # so lets do it ourselves...
    #
    # we first build a jar command line and then pass it to the 
    # generic 'Command' builder
    if theManifestFileName:
        # build a jar command line including the manifest
        jarcmd = 'jar cfm $TARGET %s ' % (theManifestFileName)
    else:
        jarcmd = 'jar cf $TARGET '
    
    # now add all stuff from the 'classes' directory
    jarcmd += '-C %s . ' % classDir.path
    
    
    # go for it!
    buildTarget = lenv.Command(name + '.jar', jarSources, jarcmd)
    
        
    # the classes directory goes away with the build target
    Clean(buildTarget, classDir)
    
    theTarget = buildTarget
    
    if installPlace:
        installTarget = lenv.Install(installPlace, buildTarget)
        theTarget = installTarget
    
    # get the alias nodes map. when specifying a dependency we need to
    # give a node object so scons does not confuse it with a real file
    zam = callerGlobals['zenithAliasMap']
    
    # now assign the target to its alias group and register the
    # group dependencies. we have a coarse hierarchy:
    # - sharedLibraries
    # -- utilityLibraries
    # --- components / java stuff
    # --- programs
    # ---- test beds
    # attention! the target to BUILD depends on targets to INSTALL!
    # so its always 'theTarget' that gets aliased but the 'buildTarget'
    # that gets dependencies glued on.
    Alias(zam['javaTargets'], theTarget)
    Depends(buildTarget, zam['utilityLibraryTargets'])
    Depends(buildTarget, zam['sharedLibraryTargets'])
    
    
    # add the target to the big global phony target
    Alias(zam['all'], theTarget)
    
    # if explicit dependencies given then add them now
    if requiredJars:
        Depends(buildTarget, requiredJars)

