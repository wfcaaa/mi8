# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'PROJECT_TYPE' : ['cpp_component_exe'] ,
'NAME' : ['starter'] ,
'DEST' : ['#bin'],
'LDFLAGS_LOCAL' : ['-lservices_session_StarterLib',
                   '-lExceptionSupport',
                   '-lSessionServiceManager',
                   '-lLocationResolver',
                   '-lSystemLoggerHelper',
                   '-lservices_zsignal',
                   '-lDebuggerHooker',
                   '-lservices_session_UnoServiceHelper',
                   '-lservices_zutils',
                   '-ltcmalloc_minimal',
                   '-lservices_xocLog4c']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = cpp_component_exe
#NAME           = starter
#
#LDFLAGS_LOCAL  = \
#    -lExceptionSupport \
#    -lSessionServiceManager \
#    -lLocationResolver \
#    -lSystemLoggerHelper \
#    -lservices_zsignal \
#    -lDebuggerHooker \
#    -lservices_session_UnoServiceHelper \
#    -lservices_zutils
#
#REQUIRED_MODULES += services/exception/ExceptionSupport/Main \
#                    services/session/SessionServiceManager/Main \
#                    services/misc/LocationResolver/Main \
#                    services/misc/SystemLoggerHelper/Main \
#                    services/signal_handling/Main/ \
#                    services/session/DebuggerHooker/Main \
#                    services/session/UnoServiceHelper/Main \
#                    services/zutils/Main
#
