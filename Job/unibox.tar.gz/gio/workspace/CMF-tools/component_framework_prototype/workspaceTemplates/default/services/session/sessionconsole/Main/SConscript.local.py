#GENERATED
# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'REQUIRED_MODULES' : ['services/misc/SystemLoggerHelper/Main','services/misc/LocationResolver/Main','services/exception/ExceptionSupport/Main','services/session/UnoServiceHelper/Main'] ,
'PROJECT_TYPE' : ['cpp_component_exe'] ,
'NAME' : ['sessionconsole'] ,
'LDFLAGS_LOCAL' : ['-lSystemLoggerHelper','-lLocationResolver','-lExceptionSupport','-lservices_session_UnoServiceHelper'],
'DEST' : ['#bin']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = cpp_component_exe
#NAME           = sessionconsole
#
#LDFLAGS_LOCAL  = -lSystemLoggerHelper \
#                 -lLocationResolver \
#                 -lExceptionSupport \
#                 -lservices_session_UnoServiceHelper
#
#REQUIRED_MODULES += services/misc/SystemLoggerHelper/Main \
#                    services/misc/LocationResolver/Main \
#                    services/exception/ExceptionSupport/Main \
#                    services/session/UnoServiceHelper/Main
