# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
#'PROJECT_TYPE' : ['shared_library'] ,
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['services_zcoco'] ,
'DEST' : ['#lib'],
'REQUIRED_LIBS' : ['#lib/libthreads.so',
                   '#lib/libLocationResolver.so',
		   '#lib/libDebuggerHooker.so',
		   '#lib/libSessionServiceManager.so',
		   '#lib/libservices_zutils.so'] ,
'LDFLAGS_LOCAL' : ['-lthreads',
                   '-lLocationResolver',
		   '-lDebuggerHooker',
                   '-lSessionServiceManager',
		   '-lservices_zutils',
		   '$LDFLAGS_ACE',
		   '$LDFLAGS_XERCES',
		   '$LDFLAGS_UNO']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = shared_library
#NAME           = services_zcoco
#
#REQUIRED_MODULES = \
#    services/threads/Main \
#    services/misc/LocationResolver/Main \
#    services/session/DebuggerHooker/Main \
#    services/session/SessionServiceManager/Main \
#    services/zutils/Main
#
#
#LDFLAGS_LOCAL += \
#    -lthreads \
#    -lLocationResolver \
#    -lDebuggerHooker \
#    -lSessionServiceManager \
#    -lservices_zutils \
#    $(LDFLAGS_ACE)
#
