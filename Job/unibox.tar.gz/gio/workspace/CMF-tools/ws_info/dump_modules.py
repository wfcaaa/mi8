#!/usr/bin/env python
'''
Created on Jun 15, 2011
dump the build project list in a form close to the
script 'list_components_canonical.sh' here.
the output is a three column comma separated list:
<project_type>,<name>,<path>
we generate this by simply parsing and dumping the file
$WORKSPACE/SConstruct.modules.py
but there are some differences;
the pathaes are always relative to the workspacs and they are the
logical path names.
the <name> field will always be '?' because the project names are not
stored in the cache file.
it appears that nobody is using the name anyway.
@author: horstp
'''
import sys, os

def dumpFile(fname,fileBase):
    '''
    fname is the python map file to dump
    fileBase is the prefix for the path name (usually the workspace)
    '''
    try:
        subModuleProc = open(fname).read()
    except:
        sys.stderr.write('\n\nError: exception caught while opening %s (in %s)\n' %
                          (fname,os.getcwd()))
        et, ev, etrace = sys.exc_info()
        sys.stderr.write( ev, '\n')
        sys.exit(1)
        
    try:
        submodules = eval(subModuleProc)
    except:
        sys.stderr.write( '\n\nError: exception caught while evaluating %s (in %s)' % 
                          (fname,os.getcwd()))
        raise
    
    # now dump out the stuff
    for project in submodules:
        for module in submodules[project]:
            path = fileBase + '/' + '/'.join(module.split('/')[:-1])
            print '%s,?,%s' % (project, path)
    
    
if __name__ == '__main__':
    '''
    check that WORKSPACE is in env and dump the modules file
    '''
    try:
        workspace = os.environ['WORKSPACE']
    except:
        sys.stderr.write( '\n\nError: unable to read WORKSPACE environment variable\n')
        sys.exit(1)
    modulesFile = workspace + '/' + 'SConstruct.modules.py'
    dumpFile(modulesFile,workspace)