#!/bin/bash
set -u
#set -x
unalias -a

# this script just pipes up some of the more elementary tools
ws_tools=$WORKSPACE/CMF-tools/ws_info
project_lister=$ws_tools/list_projects_canonical.sh
test_filter=$ws_tools/filter_test_dir.sh

$project_lister ${1:-.} | $test_filter
