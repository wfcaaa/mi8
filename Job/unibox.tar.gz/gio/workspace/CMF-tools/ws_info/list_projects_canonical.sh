#!/bin/bash
set -u
#set -x
unalias -a

function usage_and_exit
{
cat <<@EOF >&2

${1:-}

usage $(basename $0) [workspace]

Produce a listing of all build projects in the workspace.
It is recommended to run this command from the workspace directory.
The optional argument actually must be the workspace directory (if
not missing) - it is only there to keep call-compatibility with the
previous, make-based implementation of this script.
This version uses the $WORKSPACE/SConstruct.modules.py file that is created
as side effect by the scons-based zenith_build tool.
Notice that this implies that zenith_build (in any calling form) must have
been executed at least once before this command can be used.

You must be in a zenith WORKSPACE environment to make this thing work
@EOF
exit 1
}

# some sanity checks
# we must be in a zenith workspace environment
[[ -z ${WORKSPACE:-} ]] && usage_and_exit "not in a workspace"
[[ ! -d ${1:-.} ]] && usage_and_exit "target directory is not a directory"

# from now on we continue in the target directory
cd ${1:-.}
# and now we must be right in the workspace
[[ $(readlink -f .) != $(readlink -f $WORKSPACE) ]] && usage_and_exit "${PWD} is not the WORKSPACE"

# a python program does the actual listing
$WORKSPACE/CMF-tools/ws_info/dump_modules.py


