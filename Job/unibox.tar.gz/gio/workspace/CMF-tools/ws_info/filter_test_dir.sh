#!/bin/bash
# this is a filter supposed to apply to the output of
# list_projects_canonical.sh
# it filters out project types test,
# cuts out the directory path,
# removes the last path component (usually the 'TestBed' directory)


grep -e "^test," | \
cut -d, -f 3 | \
sed 's!/[^/]*$!!'
    