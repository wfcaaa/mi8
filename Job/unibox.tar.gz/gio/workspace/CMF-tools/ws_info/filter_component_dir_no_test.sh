#!/bin/bash
# this is a filter supposed to apply to the output of
# list_projects_canonical.sh
# it filters out project types cpp_component and java_component_package,
# cuts out the directory path,
# filters away path containing '/Test<number>/',
# removes the last path component (usually the 'Main' directory)
# and, since people do not adhere to standards, check
# if a 'TestBed' directory is in the resuting directory; if so
# it is not a component


grep -e "^cpp_component," -e "^java_component_package," | \
cut -d, -f 3 | \
grep -v -e "/Test[0-9]*/" | \
sed 's!/[^/]*$!!' | \
while read l
do
	[[ ! -d $l/TestBed ]] && echo "$l"
done
    