#!/bin/bash
set -u
#set -x
unalias -a

# this script just pipes up some of the more elementary tools
ws_tools=$WORKSPACE/CMF-tools/ws_info
project_lister=$ws_tools/list_projects_canonical.sh
component_filter=$ws_tools/filter_component_dir_no_test.sh

$project_lister ${1:-.} | $component_filter
