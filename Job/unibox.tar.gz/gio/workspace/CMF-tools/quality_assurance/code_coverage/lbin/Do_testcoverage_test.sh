#!/bin/bash


shopt -s extglob
. /bstd_tools/contrib/lib/TIME_FUNCTIONS

baseline=`cleartool catcs | grep -m 1 -A 1 mkbranch  | tail -1 | cut -d" " -f4`
currentDate=`date +%Y%m%d`
codeCoveragePath="$WORKSPACE/CMF-tools/quality_assurance/code_coverage/measured_results/"
generatedCodeCoverageLog=$codeCoveragePath"AutomatedTestCoverage_"$baseline"_"$currentDate".log"
resultDir="CodeCoverageResult_"$baseline"_"$currentDate
FeatBuild="/bstd_tools/scm/bm/FeatBuild"
coverageExtractorScript="$WORKSPACE/CMF-tools/quality_assurance/code_coverage/lbin/tools/coverageExtractor.pl"
compareCoverageScript="$WORKSPACE/CMF-tools/quality_assurance/code_coverage/lbin/tools/compareCodeCoverage.pl"
listAllComponents="$WORKSPACE/CMF-tools/ws_info/list_components_logical.sh"
listTestComponents="$WORKSPACE/CMF-tools/quality_assurance/code_coverage/measured_results/listTestComponents.txt"
zCompTest="z_comp_test.ksh"
excludeComponents="-e /services/session/SessionMode -e /services/configsystem/ConfigSystem -e /services/dependencydb/DependencyDb -e /examples/"
SUCCESS=0
ERROR=1
FATAL=2
KILLED=3

#
# Print usage of the script.
#
PrintUsage()
{
  echo "Usage: $(basename $0) [OPTION]"
  echo "Please use following options to execute the utility."
  echo ""
  echo "OPTION 1 -p <all|WORKSPACE dir>  :- Calculates the code coverage for all components under "
  echo "                                    WORKSPACE or all components under given WORKSPACE directory. "
  echo "                                    The WORKSPACE directory path should be absolute."
  echo ""
  echo "OPTION 2 -f <tester>             :- Calculates the code coverage for all components in the "
  echo "                                    WORKSPACE with FeatBuild (offline + online). Online "
  echo "                                    FeatBuild will be executed in nightly time frame on "
  echo "                                    specified tester machine/hardware."
  echo ""
  echo "OPTION 3 -h                      :- Print utility help."
  echo "e.g."
  echo "     $(basename $0) "'-p $WORKSPACE/ate/ext/TestData/Wavetable/'
  echo "     $(basename $0) "'-p $WORKSPACE/hw/'
  echo "     $(basename $0) "'-p all'
  echo "     $(basename $0) "'-f PEPI'
  echo "     $(basename $0) "'-f ps400'

  return $SUCCESS
}

#
# Create directory for storing results.
#
CreateLogDir()
{
  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : CreateLogDir() called" >> $generatedCodeCoverageLog

  codeCoveragePath=$codeCoveragePath"$resultDir/"

# Remove existing directory.
  rm -rf $codeCoveragePath

  local componentLog=$codeCoveragePath"gcov_reports"

  mkdir -p "$componentLog"

  return $SUCCESS
}

#
# Compile directory with gcov.
#
CompileWithGcov()
{
  local componentDir=$2

  cd "$componentDir"
  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : GCOV STARTED" >> $generatedCodeCoverageLog

# To ensure that the old coverage is removed, following cleanup is executed.
  fzb -c

# Compile the directory with gcov.
  fzb --gcov

  local cmdStatus=`echo $?`
  if [ $cmdStatus -ne 0 ]
  then
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Error : GCOV Compilation Failed for component "$componentDir >> $generatedCodeCoverageLog
  else
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : GCOV Compilation Succeeded for component "$componentDir >> $generatedCodeCoverageLog
  fi

  return $SUCCESS
}

#
# Accept exit status of FeatBuild and log appropriate message.
#
ReportFeatBuildStatus()
{
  local exitStatus=$2

# Log message according to exit status.
  if [ $exitStatus -eq $SUCCESS ]
  then
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" :FeatBuild SUCCEEDED" >> $generatedCodeCoverageLog
  elif [ $exitStatus -eq $ERROR ]
  then
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" :FeatBuild FAILED" >> $generatedCodeCoverageLog
  elif [ $exitStatus -eq $FATAL ]
  then
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" :FeatBuild FATAL" >> $generatedCodeCoverageLog
  elif [ $exitStatus -eq $KILLED ]
  then
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" :FeatBuild KILLED" >> $generatedCodeCoverageLog
  else
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" :FeatBuild exited with unknown status" >> $generatedCodeCoverageLog
  fi

  return $SUCCESS
}

#
# Execute offline and online FeatBuild.
# Following steps are performed in this function.
# 1. Execute FeatBuild with incremental compilation.
# 2. Compile all components under $WORKSPACE with 'gcov=yes' option.
# 3. Execute offline FeatBuild.
# 4. Execute online FeatBuild on specified tester.
#
ExecuteFeatBuild()
{
  local testerName=$2

#
# 1. Execute FeatBuild with incremental compilation.
#
  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Compilation FeatBuild STARTED" >> $generatedCodeCoverageLog
  $FeatBuild -n ack -y cpl -n blt -n tst

# Get FeatBuild exit status
  local cmdStatus=`echo $?`
  ReportFeatBuildStatus [ $cmdStatus ]

#
# 2. Compile all components under $WORKSPACE with 'gcov=yes' option.
#
# Compile component directories with gcov.
  local componentList=( `$listAllComponents $WORKSPACE 2> /dev/null | grep --invert-match $excludeComponents` )

  for name in ${componentList[@]}
  do
    CompileWithGcov [ $name ]
  done

#
# 3. Execute offline FeatBuild.
#
  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Offline FeatBuild STARTED" >> $generatedCodeCoverageLog
  $FeatBuild -n ack -n cpl -n blt -y tst offline -c LARGE

# Get FeatBuild exit status
  cmdStatus=`echo $?`
  ReportFeatBuildStatus [ $cmdStatus ]

#
# 4. Execute online FeatBuild on specified tester.
#
  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Online FeatBuild STARTED" >> $generatedCodeCoverageLog
  $FeatBuild -n ack -n cpl -n blt -y tst online -c LARGE -t $testerName

# Get FeatBuild exit status
  cmdStatus=`echo $?`
  ReportFeatBuildStatus [ $cmdStatus ]

  return $SUCCESS
}

#
# Execute test component/s of specified component.
#
ExecuteTest()
{
  local componentDir=$2

  cd "$componentDir"

# Get list of test components in current component dir.
  local testComponentsList=( `cat $listTestComponents | grep $componentDir` )

# Return if there is no test component.
  if [[ ${#testComponentsList[@]} -le 0 ]]
  then
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Error - No Test component exist for the component "$componentDir >> $generatedCodeCoverageLog
    return $ERROR
  fi

# Execute tester component.
  for testerComponent in ${testComponentsList[@]}
  do
    $testerComponent/$zCompTest >> $generatedCodeCoverageLog
    local cmdStatus=`echo $?`
    if [ $cmdStatus -ne 0 ]
    then
      echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Error : Test execution failed for component "$componentDir  >> $generatedCodeCoverageLog
    else
      echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Test Execution Succeeded for component "$componentDir >> $generatedCodeCoverageLog
    fi
  done

  return $SUCCESS
}

#
# Generate and measure code coverage of specified component.
#
GenerateCoverage()
{
  local componentDir=$2
  local componentLog=$3
  local codeCoverageFile=$4
  local gcov_analysis='gcov_analysis'

  cd $componentDir
  rm -rf $gcov_analysis
  mkdir $gcov_analysis

  componentDir=`echo $componentDir|sed 's/.*workspace\(.*\)/.\1/i'`

# Append "/" at path end
  echo $componentDir|grep -P "/$"
  local cmdStatus=`echo $?`
  if [ $cmdStatus -ne 0 ]
  then
    componentDir="$componentDir"/
  fi

# Prepare a new directory path to store html log file.
  local htmlDir="$componentLog"gcov_reports`echo $componentDir|sed 's/^\.//'`

# Remove directory if already present
  rm -rf "$htmlDir"

  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : lcov for $componentDir started" >> $generatedCodeCoverageLog
  lcov --base-directory $WORKSPACE --directory . --capture -output-file "$gcov_analysis"/application.info
  genhtml -o "$htmlDir" "$gcov_analysis"/application.info
  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : lcov for $componentDir ended" >> $generatedCodeCoverageLog

# Extract code coverage from index file.
  local indexFile="$htmlDir"index.html
  local codeCoverage=""

  if [ -e $indexFile ]
  then
    codeCoverage=`$coverageExtractorScript $indexFile`
  else
    codeCoverage=0
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Error : Could not get code coverage for $componentDir" >> $generatedCodeCoverageLog
  fi

  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : $componentDir: Code Coverage = $codeCoverage" >> $generatedCodeCoverageLog

# Put the code coverage into a file.
  local infoCodeCoverage="$componentDir $codeCoverage"
  echo $infoCodeCoverage >> $codeCoverageFile

  rm -rf $gcov_analysis

  return $SUCCESS
}

#
# Execute test component/s of given component/s and measure code coverage.
#
CodeCoverage()
{
# Remove existing log.
  rm -f $generatedCodeCoverageLog

  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : START - Component tests" >> $generatedCodeCoverageLog

# Create directory for storing logs.
  CreateLogDir [ ]

  local componentList

  if [[ "$2" != @(ALL|All|all) ]]
  then
    # Remove trailing "/" from directory name
    dirName=`dirname $2`
    baseName=`basename $2`
    dirPath="$dirName"/"$baseName"

    componentList=( `$listAllComponents $WORKSPACE 2> /dev/null | grep $dirPath | grep --invert-match $excludeComponents` )
  else
# Get list of all components under $WORKSPACE.
    componentList=( `$listAllComponents $WORKSPACE 2> /dev/null | grep --invert-match $excludeComponents` )
  fi

# Check if component list contain components.
  if [[ ${#componentList[@]} -ge 1 ]]
  then

# File to store measured code coverage.
    local generatedCodeCoverage=$codeCoveragePath"/GCOV_CodeCoverage_"$baseline"_"$currentDate".log"
    rm -f $generatedCodeCoverage

   # Get the list of test components.
   find -L $WORKSPACE -type f -name $zCompTest -exec dirname '{}' \; 2> /dev/null | grep -v "/ucomp/" > $listTestComponents

# Compile component, execute test/s, generate code coverage.
    for componentName in ${componentList[@]}
    do
      echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : START - Component Name:- $componentName" >> $generatedCodeCoverageLog
      CompileWithGcov [ $componentName ]
      ExecuteTest [ $componentName ]
      GenerateCoverage [ $componentName $codeCoveragePath $generatedCodeCoverage ]
      echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : END - Component Name:- $componentName" >> $generatedCodeCoverageLog
    done

    # Remove file containing list of test components.
    rm -f $listTestComponents

# Check if file containing measured code coverages exist.
    if [[ -e $generatedCodeCoverage ]]
    then
# Compare code coverage with expected code coverage after test execution and
# create log.
      echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Code coverage comparison with given reference test coverage started" >> $generatedCodeCoverageLog
      cd $WORKSPACE
      $compareCoverageScript testcoverage $generatedCodeCoverage
      echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Code coverage comparison with given reference test coverage ended" >> $generatedCodeCoverageLog

# Remove unnecessary files.
      rm -f $generatedCodeCoverage
    else
      echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : File does not exist : $generatedCodeCoverage" >> $generatedCodeCoverageLog
      echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Unable to run : $compareCoverageScript" >> $generatedCodeCoverageLog
    fi

    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : END - Component tests" >> $generatedCodeCoverageLog

# Component list does not contain any components.
  else
    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : No component found" >> $generatedCodeCoverageLog
  fi

  return $SUCCESS
}

#
# Execute offline and online FeatBuild and measure code coverage of all
# components.
#
FeatCodeCoverageAll()
{
# Remove existing log.
  rm -f $generatedCodeCoverageLog

  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : START - FeatBuild tests" >> $generatedCodeCoverageLog

# Note: At present there is no way to validate the tester name specified by
#       user.
  local testerName=$2

  CreateLogDir [ ]
  ExecuteFeatBuild [ "$testerName" ]

# File to store measured code coverage.
  local generatedCodeCoverage=$codeCoveragePath"/GCOV_CodeCoverage_"$baseline"_"$currentDate".log"
  rm -f $generatedCodeCoverage

# Generate code coverage for every component.
  local componentList=( `$listAllComponents $WORKSPACE 2> /dev/null | grep --invert-match $excludeComponents` )
  for componentName in ${componentList[@]}
  do
    GenerateCoverage [ $componentName $codeCoveragePath $generatedCodeCoverage ]
  done

# Compare code coverage with expected code coverage after FeatBuild execution
# and create log.
  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Code coverage comparison with given reference FeatBuild coverage started" >> $generatedCodeCoverageLog
  cd $WORKSPACE
  $compareCoverageScript featcoverage $generatedCodeCoverage
  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : Code coverage comparison with given reference FeatBuild coverage ended" >> $generatedCodeCoverageLog

# Remove unnecessary files.
  rm -f $generatedCodeCoverage

  echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : END - FeatBuild tests" >> $generatedCodeCoverageLog

  return $SUCCESS
}

#
# Start of main script.
#

if [ $# -eq 0 ]
then
  PrintUsage [ ]
  exit $ERROR
fi

while getopts p:f:h OPTION 2>/dev/null
do
    case "$OPTION" in
      p)
        CodeCoverage [ "$OPTARG" ]
        exit $SUCCESS
      ;;
      f)
        FeatCodeCoverageAll [ "$OPTARG" ]
        exit $SUCCESS
      ;;
      h)
        PrintUsage [ ]
        exit $SUCCESS
      ;;
      *)
        PrintUsage [ ]
        exit $ERROR
      ;;
    esac
done
