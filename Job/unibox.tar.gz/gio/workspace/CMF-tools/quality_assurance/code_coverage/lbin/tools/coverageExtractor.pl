#!/usr/bin/perl

#this script extracts the code coverage from index.html for a component

use strict;

{
  #index.html is provided as input
  my $inputFile = shift(@ARGV);
  open(INFILE, $inputFile) or die $!;

  my $addCov = 0;
  my $count = 0;
  my $found = 0;
  #read index.html to extract code coverage
  while(<INFILE>){
    if ( (!$found) && ((/Main\/index\.html"/) || (/Main\/cpp\/index\.html"/)) ){
      my $nextLine;
      my $lineCounter;
      for($lineCounter = 0; $lineCounter < 4; $lineCounter += 1){
          $nextLine = <INFILE>;
      }
      if ($nextLine =~ />\s*(\d*\.\d*)/){
          $addCov = $addCov + $1;
          $count++;
      }
      $found = 1;
    }

    if ((/src\//) && (/\/index\.html"/)){
      my $nextLine;
      my $lineCounter;
      for($lineCounter = 0; $lineCounter < 4; $lineCounter += 1){
          $nextLine = <INFILE>;
      }
      if ($nextLine =~ />\s*(\d*\.\d*)/){
          $addCov = $addCov +  $1;
          $count++;
      }
    }
  }
  close(INFILE);

  if(0 != $count){
    my $avgCov = $addCov/$count;
    print sprintf("%.2f", $avgCov);
  }
}
