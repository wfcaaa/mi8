This README.txt file describes the functionality provided by the quality assurance
tools in brief. For further details of each individual tool refer to the
README.txt present in the corresponding tool directory.

1. Do_checkguidelines_test

   To use the utility, pass appropriate arguments to it depending on the desired
   test. Brief description about the tools provided by the utility are as
   follows:

  1.1 checkinclude
      This test checks the directory passed to it for valid component package
      root directory or path containing $WORKSPACE/IDL directory.
      All cpp, hpp or idl files in that directory are scanned and
      #include files are checked for validity.

  1.2 checkaccessrule
      This test checks the directory passed to it for valid component package
      root directory or path containing $WORKSPACE/IDL directory.
      Finds cpp, hpp or idl files in that directory, parses the group
      specification file. The cpp, hpp or idl files are then scanned and are
      checked for access rules mentioned in the group specification file.
      Exceptions can be mentioned in a file which will not be reported
      as errors.

   For usage of the script, execute
   $WORKSPACE/CMF-tools/quality_assurance/dependency_check/lbin/
   Do_checkguidelines_test -h

2. Do_MemoryLeakCheck_test.sh

   The Do_MemoryLeakCheck_test.ksh script is used to perform memory leak
   checks for all Zenith components and report the results to the user.
   The checking is performed using the valgrind tool which is integrated
   in the Zenith component test framework.

   For usage of the script, execute
   $WORKSPACE/CMF-tools/quality_assurance/memory_leak_check/lbin/
   Do_MemoryLeakCheck_test.sh -h

3. Do_testcoverage_test.sh
   This utility executes tests of specified Zenith component or all Zenith
   components and measures the code coverage. It also provides option for
   measuring code coverage of all Zenith Components after execution of offline
   and online FeatBuild. The generated code coverage is compared with expected
   code coverage specified in $WORKSPACE/CMF-tools/quality_assurance/
   code_coverage/expected_results/ReferenceCodeCoverage.txt. This file contains
   for each component package the expected (%) code coverages after execution
   of its component tests and after execution of online and offline FeatBuild
   (including execution of all component tests). A html report is generated
   after comparison of generated code coverage and expected code coverage to
   find areas where an enhancement of the test coverage is potentially needed.

   PSL runs this utility periodically to measure the code coverage after
   execution of tests of all Zenith components and also after execution of
   offline and online FeatBuild on PEPI with LARGE test coverage.

   For usage of the script, execute
   $WORKSPACE/CMF-tools/quality_assurance/code_coverage/lbin/
   Do_testcoverage_test.sh -h
