
Check Guidelines: README (V0.3)

Index

1. General overview
2. How to use the utility
3. Implementation overview


1. General overview

   To use the utility, pass appropriate arguments to it depending on the desired
   test. Brief description about the tools provided by the utility are as
   follows:

  1.1 checkinclude
      This test checks the directory passed to it for valid component package
      root directory or path containing $WORKSPACE/IDL directory.
      All cpp, hpp or idl files in that directory are scanned and
      #include files are checked for validity.

  1.2 checkaccessrule
      This test checks the directory passed to it for valid component package
      root directory or path containing $WORKSPACE/IDL directory.
      Finds cpp, hpp or idl files in that directory, parses the group
      specification file. The cpp, hpp or idl files are then scanned and are
      checked for access rules mentioned in the group specification file.
      Exceptions can be mentioned in a file which will not be reported
      as errors.


2. How to use the utility

   For usage of the script, execute
   $WORKSPACE/CMF-tools/quality_assurance/dependency_check/lbin/
   Do_checkguidelines_test -h


3. Implementation overview

   The implementation for Do_checkguidelines_test utility (checkinclude and
   checkaccessrule) is divided into five files.
   Following are the implementation details of each file.

  3.1 Do_checkguidelines_test
      This script can be used for checking include files, checking access
      rules or for both.
      This script checks the directory passed to it for valid component package
      root directory or path containing $WORKSPACE/IDL directory.
      Depending on the arguments provided to the script, desired tests are
      executed. The location of the script is as follows.
      Location:
      $WORKSPACE/CMF-tools/quality_assurance/dependency_check/lbin/
      Do_checkguidelines_test

  3.2 checkinclude.pl
      Do_checkguidelines_test uses this script when -i or --includes argument is
      supplied to it. This script accepts the path of the directory that should
      be checked for included header files. If the directory path comprises of
      $WORKSPACE/IDL, all idl files under that directory are scanned for
      included header files and are checked whether those are valid includes.
      If the directory path is not descendent of $WORKSPACE/IDL then all .cpp,
      .hpp or .idl files under that directory are scanned for included header
      files and are checked whether those are valid includes.
      The location of the script is as follows.
      Location:
      $WORKSPACE/CMF-tools/quality_assurance/dependency_check/lbin/
      tools/checkinclude.pl

  3.3 includevalidator.pm
      This perl module is used by checkinclude.pl. This module provides
      sub-routines to check project type, find cpp, hpp, idl files, and check
      the validity of included file.
      Location:
      $WORKSPACE/CMF-tools/quality_assurance/dependency_check/lbin/
      tools/includevalidator.pm

  3.4 checkaccessrule.pl
      Do_checkguidelines_test uses this script when -r or --rules argument is
      supplied to it. This script accepts three arguments. First argument should
      be path of the directory that should be checked for access guide lines.
      Second argument should be absolute path the group specification file.
      Third argument whether to log messages in log file.
      If the directory path comprises of $WORKSPACE/IDL, all idl files under
      that directory are searched to find current and used namespaces, and by
      parsing the group specification file for interface groups, access guide
      lines are checked.
      If the directory is not descendent of $WORKSPACE/IDL then group
      specification file is parsed for component groups. If rules for the
      namespace of the directory are defined in group specification file then
      all cpp, hpp files in that directory are scanned to find current and used
      namespaces and access guide lines are checked.
      Location:
      $WORKSPACE/CMF-tools/quality_assurance/dependency_check/lbin/
      tools/checkaccessrule.pl

  3.5 accessvalidator.pm
      This perl module is used by checkaccessrule.pl. This module provides
      sub-routines to check project type, find cpp, hpp, idl files, scan those
      files for current and used namespaces, check access guide lines, validate
      group specification file using schema definition and parse it.
      Location:
      $WORKSPACE/CMF-tools/quality_assurance/dependency_check/lbin/
      tools/accessvalidator.pm
