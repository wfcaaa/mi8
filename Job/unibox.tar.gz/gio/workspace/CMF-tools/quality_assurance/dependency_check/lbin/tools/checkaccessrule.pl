#!/usr/bin/perl -w

use strict;
use lib "$ENV{WORKSPACE}/CMF-tools/quality_assurance/dependency_check/lbin/".
        "tools";
use accessvalidator;

# Assign schema definition file name to a variable. This file is used validate
# group specification file.
my $schemaFile = $ENV{WORKSPACE}.q(/CMF-tools/quality_assurance/).
  q(dependency_check/expected_results/group_specification.xsd);
my $groupSpecificationFile;

# Assign name of exception file to a variable.
my $exceptionFile = $ENV{WORKSPACE}.q(/CMF-tools/quality_assurance/).
  q(dependency_check/expected_results/Check_IDL_Guidelines_Exceptions);

# Assign path of get_time.sh file to a variable.
my $getCurTime = $ENV{WORKSPACE}.q(/CMF-tools/quality_assurance/).
  q(dependency_check/lbin/tools/get_time.sh);

# Exit value can be 0:Passed, 1:Failed, 2:Crashed, 3:Not executed
my $exitPassed = 0;
my $exitFailed = 1;
my $exitNotExecuted = 3;
my $exitValue = $exitPassed;

# Main script
{
  my $dirErrMsg = "checkaccessrule.pl expects two arguments. First argument ".
                  "should be Main directory of\na component or \$WORKSPACE/IDL".
                  " directory. Second argument should be name of specification".
                  " file.\n";
  my $cwd;
  my $currentTime;

  # Check if two arguments are passed.
  if (scalar @ARGV == 2) {
    $cwd = $ARGV[0];
    $groupSpecificationFile = $ARGV[1];
    chomp($cwd);

    # Remove starting, trailing spaces if any.
    $cwd =~ s/^\s+//;
    $cwd =~ s/\s+$//;

    # Check that argument exists and is directory.
    if (not -e $cwd) {
      $currentTime = qx/$getCurTime/;
      chomp($currentTime);
      print("$currentTime ERROR $cwd does not exist.\n$dirErrMsg");
      exit $exitNotExecuted;
    }
    if (not -d $cwd) {
      $currentTime = qx/$getCurTime/;
      chomp($currentTime);
      print("$currentTime ERROR $cwd not directory.\n$dirErrMsg");
      exit $exitNotExecuted;
    }
  }
  else {
    $currentTime = qx/$getCurTime/;
    chomp($currentTime);
    print("$currentTime ERROR $dirErrMsg");
    exit $exitNotExecuted;
  }

  # Initialize variable with IDL path.
  my $idlDir = $ENV{WORKSPACE}.'/IDL';
  my $validAccessRetVal;

  # Check if directory path contains $WORKSPACE/IDL in it.
  if ($cwd =~ m/$idlDir/) {

    # Create object of accessvalidator for argument directory.
    my $accessValidator = accessvalidator->new($cwd);

    # Parse exceptions file.
    parseExceptionsFile($accessValidator);

    # Check whether the object's directory path is to be excluded.
    if ($accessValidator->isPathExcluded()) {
      exit $exitNotExecuted;
    }

    # Test whether group specification file is well formed and parse it.
    parseSpecificationFile($accessValidator);

    # Get list of idl files in $cwd.
    my @idlFiles = $accessValidator->getIdlList();

    # For each idl file, check its used namespaces are according to group
    # specification file.
    if (@idlFiles) {
      $currentTime = qx/$getCurTime/;
      chomp($currentTime);
      print("Directory: $cwd....$currentTime\n");
      foreach my $idlFile (@idlFiles) {
        chomp($idlFile);

        $validAccessRetVal = $accessValidator->validateAccess($idlFile);

        if ($validAccessRetVal == 3) {

          # Set exit value to 3 i.e. not executed
          $exitValue = $exitNotExecuted;
        }
        else {
          print("+TEST Checking access rules - file: $idlFile ");

          # If validate access does not return 1 this means validation failed.
          if ($validAccessRetVal == 1) {
            print(": PASSED\n");
          }
          else {
            print(": FAILED\n");
            $accessValidator->printErrorMessages();

            # Check if any previous return value is not greater than Failed
            # i.e. 1
            if ($exitValue < $exitFailed) {

              # Set exit value to 1 i.e. Failed
              $exitValue = $exitFailed;
            }
          }
        }
        if ($accessValidator->checkUnneededExceptions($idlFile)) {
          print("+TEST Unneeded rule in Check_IDL_Guidelines_Exceptions".
                "(CHECKACCESS) - file: $idlFile : FAILED\n");
          $accessValidator->printErrorMessages();
        }
      }
    }

    # No file found.
    else {
      exit $exitNotExecuted;
    }
  }
  else {

    # Create object of accessvalidator for argument directory.
    my $accessValidator = accessvalidator->new($cwd);

    # Parse exceptions file.
    parseExceptionsFile($accessValidator);

    # Check whether the object's directory path is to be excluded.
    if ($accessValidator->isPathExcluded()) {
      exit $exitNotExecuted;
    }

    # Test whether group specification file is well formed and parse it.
    parseSpecificationFile($accessValidator);

    # Get namespace of current directory.
    my $currentNamespace = $accessValidator->getCurrentNamespace();
    if (not defined $currentNamespace) {
      my $errMsg = "Unable to find namespace for $cwd\n";
      $currentTime = qx/$getCurTime/;
      chomp($currentTime);
      print("$currentTime ERROR $errMsg");
      exit $exitNotExecuted;
    }

    # Check if the namespace is defined in group specification file.
    my $grpDefined = $accessValidator->isGroupDefined($currentNamespace);
    if ($grpDefined == 1) {

      my $chkDisabled = $accessValidator->isCheckingDisabled(
          $currentNamespace);

      if ($chkDisabled == 0) {

        # Get list of source, header files in argument directory.
        my @filesCppHpp = $accessValidator->getCppHppList();

        # For each file, check its used namespaces are according to group
        # specification file.
        if (@filesCppHpp) {
          $currentTime = qx/$getCurTime/;
          chomp($currentTime);
          print("Directory: $cwd....$currentTime\n");
          foreach my $file (@filesCppHpp) {
            chomp($file);
            print("+TEST Checking access rules - file: $file ");

            $validAccessRetVal = $accessValidator->validateAccess($file);

            if ($validAccessRetVal == 1) {
              print(": PASSED\n");
            }
            else {
              print(": FAILED\n");
              $accessValidator->printErrorMessages();
              $exitValue = $exitFailed;
            }
            if ($accessValidator->checkUnneededExceptions($file)) {
              print("+TEST Unneeded rule in Check_IDL_Guidelines_Exceptions".
                  "(CHECKACCESS) - file: $file : FAILED\n");
              $accessValidator->printErrorMessages();
            }
          }
        }

        # No file found.
        else {
          exit $exitNotExecuted;
        }
      }
      else {
        exit $exitNotExecuted;
      }
    }
    else {
      $currentTime = qx/$getCurTime/;
      chomp($currentTime);
      print("$currentTime WARNING Group specification file do not contain ".
            "group for $currentNamespace\n");
      exit $exitNotExecuted;
    }
  }
  exit $exitValue;
}

# This sub-routine checks whether the group specification file is well formed by
# parsing it.
# @param validatorRef - Reference of validator object.
sub parseSpecificationFile
{
  my $validatorRef = shift;
  my $wellFormedSpecification;

  print("+TEST Parsing group specifications - file: $groupSpecificationFile ");

  # Parse group specification file for groups.
  $wellFormedSpecification =
    $validatorRef->parseRuleSpecifications($groupSpecificationFile,
        $schemaFile);
  if ($wellFormedSpecification != 1) {
    print(": FAILED\n");
    $validatorRef->printErrorMessages();
    exit $exitNotExecuted;
  }
  else {
    print(": PASSED\n");
  }
}

# This sub-routine parses the file containing list of exceptions.
# @param validatorRef - Reference of validator object.
sub parseExceptionsFile
{
  my $validatorRef = shift;
  my $exceptionFileWellFormed;

  print("\n+TEST Parsing exceptions - file: $exceptionFile ");

  # Parse exceptions list.
  $exceptionFileWellFormed =
    $validatorRef->parseExceptionsFile($exceptionFile);

  if ($exceptionFileWellFormed != 1) {
    print(": FAILED\n");
    $validatorRef->printErrorMessages();
    exit $exitNotExecuted;
  }
  else {
    print(": PASSED\n");
  }
}
