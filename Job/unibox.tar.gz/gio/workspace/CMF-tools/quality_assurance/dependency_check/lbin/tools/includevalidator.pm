package includevalidator;

use strict;
use Carp;
use File::Basename;

# To see documentation of includevalidator, type following command
# pod2text < includevalidator.pm

=head1 NAME

 includevalidator - perl module that provides methods to find and check
                    included files in header, source, idl files in WORKSPACE.

=head1 DESRIPTION

 This module provides functions for

 1. Searching source, header, idl files in a directory.

 2. Finding #include files in a file.

 3. Checking existence of included files in source, header files at
     * geninc directory
     * $WORKSPACE/include directory
     * $OO_SDK_HOME/include directory
     * Directory path which is passed while creating the object. This will be
       the directory path passed with --path option to utility or current
       directory from where the utility is invoked.
     * zenithAllowedIncludes
       Path of zenithAllowedIncludes can be changed in new() sub-routine.
       To change the file path, write the absolute path in place of PATH in
       q(PATH) without quotes.

 4. Checking existence of included files in idl file at
     * $WORKSPACE/IDL directory
     * $OO_SDK_HOME/idl directory

=head1 CONFIG FORMAT

 The zenithAllowedIncludes file contains names of header files allowed to be
 included in component source and header files.

 Format of this file should be as mentioned below
 *<white space>header_file_name
 A line should start with "*" followed by white space, followed by header file
 name. One header file should be mentioned on a single line.

=head1 FUNCTIONS

=over

=item new(directoryName)

 This constructor sub-routine creates object variables and stores object's
 directory name. If the directory is not descendent of $WORKSPACE/IDL then
 parses zenith allowed includes file and stores it in object variable.
 @param dirname - name of the component directory.

=cut
sub new
{
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  my $currentTime;

  # Name of the file that contains zenith allowed includes.
   my $zenithAllowedIncludesFileName = $ENV{WORKSPACE}.q(/CMF-tools/).
     q(quality_assurance/dependency_check/expected_results/).
     q(zenithAllowedIncludes);

  if (@_ != 1) {
    $currentTime = getTime();
    print("$currentTime $class->new expects one parameter. Parameter should be".
          " directory name.\n");
    croak();
  }
  my $dirname = shift;
  chomp($dirname);

  $self->{dir} = $dirname;
  $self->{zenithAllowedIncludes} = {};
  $self->{hrefExceptionMap} = {};
  my $idlDir = $ENV{WORKSPACE}.q(/IDL);

  # This variable is used to store error messages.
  $self->{arefErrMessages}       = [];

  $self->{mySubDirList}          = [];
  $self->{myMainCompSubDirList}  = [];
  $self->{myTestCompSubDirList}  = [];
  $self->{myMainCompCppHppFiles} = [];
  $self->{myTestCompCppHppFiles} = [];

  # If directory name do not contain WORKSPACE/IDL, then only scan
  # zenithAllowedIncludes file. Idl files include only idl files.
  if ($dirname !~ m/$idlDir/) {

    # Check that zenithAllowedincludes file exists and is readable.
    if ((not -e $zenithAllowedIncludesFileName) ||
        (not -r $zenithAllowedIncludesFileName)) {
      $currentTime = getTime();
      print("$currentTime ERROR Can not read $zenithAllowedIncludesFileName\n");
      croak();
    }

    my $allowedFile;
    open(my $fileHandle, $zenithAllowedIncludesFileName) or
      croak("$zenithAllowedIncludesFileName: $!");

    # Read while there are more lines in the file.
    while (<$fileHandle>) {

      # Search a pattern that starts with * followed by 1 or more spaces
      if ($_ =~ m/^\*\s+(.*)/) {
        $allowedFile = $1;
        chomp($allowedFile);
        $allowedFile =~ s/^\s+//;
        $allowedFile =~ s/\s+$//;

        # Check that this file already included
        if (exists $self->{zenithAllowedIncludes}->{$allowedFile}) {
          $currentTime = getTime();
          print("$currentTime WARNING $allowedFile already included in ".
                "$zenithAllowedIncludesFileName");
        }
        else {
          $self->{zenithAllowedIncludes}->{$allowedFile} = 1;
        }
      }
    }
    close($fileHandle);
  }
  bless($self, $class);
  return $self;
}

=item parseExceptionsFile()

 This sub-routine parses the exception file passed to it.
 @param exceptionFile - name of the file containing list of exceptions.
 @return 0 - error while parsing the file.
 @return 1 - no error in parsing the file.

=cut
sub parseExceptionsFile
{
  my $self = shift;
  my $exceptionFileParsed = 0;
  my $line;
  my $fileName;
  my $exceptionStr;
  my $currentTime;
  my $scanFile;
  my $sectionStart;
  my $sectionEnd;

  undef @{$self->{arefErrMessages}};

  # Check that one parameter is passed or not.
  if (@_ != 1) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR ".
        "parseExceptionsFile() expects name of file containing exception ".
        "list\n");
    return $exceptionFileParsed;
  }

  my $exceptionFile = shift;
  chomp($exceptionFile);
  $exceptionFile =~ s/^\s+//;
  $exceptionFile =~ s/\s+$//;

  # Check that file exists and is readable.
  if ((not -e $exceptionFile) || (not -r $exceptionFile)) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR Can not read ".
        "$exceptionFile\n");
    return $exceptionFileParsed;
  }

  $scanFile = 0;
  $sectionStart = q(CHECKINCLUDE EXCEPTIONS BEGIN);
  $sectionEnd = q(CHECKINCLUDE EXCEPTIONS END);
  open(my $fileHandle, $exceptionFile) or croak("$exceptionFile: $!");
  LOOP_WHILE:
  while($line = <$fileHandle>) {

    if ($line =~ m/^$sectionStart$/) {
      $scanFile = 1;
      next LOOP_WHILE;
    }
    elsif ($line =~ m/^$sectionEnd$/) {
      $scanFile = 0;
      last LOOP_WHILE;
    }

    if ($scanFile == 1) {
      # Line should not start with # or line should not be empty.
      if (($line !~ m/^\s*#/) && ($line !~ m/^\s*$/)) {

        # File name specified on single line.
        if ($line =~ m/^\*\s+(.*):$/) {
          $fileName = $1;
          chomp($fileName);
          $fileName =~ s/\s+$//;

          # Read exception string for the above file. Exception string may span
          # over multiple lines.
          LOOP_WHILE_EXP_STR:
          while(defined($line = <$fileHandle>)) {

            # Check if line is not comment or empty.
            if (($line !~ m/^\s*#/) && ($line !~ m/^\s*$/)) {

              # Validation - line should not start with "*".
              if ($line =~ m/^\*/) {
                $currentTime = getTime();
                push(@{$self->{arefErrMessages}}, "$currentTime WARNING ".
                    "Exception file: $exceptionFile contains invalid syntax on".
                    " line - $line\n");
                close($fileHandle);
                return $exceptionFileParsed;
              }
              if ($line =~ m/^"(.*)"$/) {
                $exceptionStr = $1;
                last LOOP_WHILE_EXP_STR;
              }
              elsif ($line =~ m/^"(.+)/) {
                $exceptionStr = $1;
            }
            elsif ($line =~ m/(.+)"$/) {
              $exceptionStr .= $1;
            last LOOP_WHILE_EXP_STR;
            }
              else {
                $exceptionStr .= $line;
              }
            }
          }

          # Add exception string to hash.
          $self->{hrefExceptionMap}->{$fileName}->{"$exceptionStr"} = 0;
        }
        else {
          $currentTime = getTime();
          push(@{$self->{arefErrMessages}}, "$currentTime WARNING Exception ".
              "file: $exceptionFile contains invalid syntax on line - $line\n");
          close($fileHandle);
          return $exceptionFileParsed;
        }
      }
    }
  }
  close($fileHandle);
  $exceptionFileParsed = 1;
  return $exceptionFileParsed;
}

=item getIdlList()

 This sub-routine returns the list of .idl files present in object's directory
 and returns the array of file names.
 @return idlFiles - array containing name of the .idl files found in search.

=cut
sub getIdlList
{
  my $self = shift;
  my $searchPath = $self->{dir};
  my $searchFiles = q("*.idl");

  # Prepare a command to find idl files.
  my $searchCommand = "find $searchPath -follow -iname $searchFiles 2>/dev/null";

  # Search $WORKSPACE/IDL/ for .idl files
  my @idlFiles = `$searchCommand`;
  return @idlFiles;
}

=item getCppHppList()

 This sub-routine finds .c, .cpp, .h, .hpp files in the object's directory upto
 maximum depth 1 and returns the array of file names.
 @return filesCppHpp - array containing name of the files found in the directory.

=cut
sub getCppHppList
{
  my $self = shift;
  my $searchPath = $self->{dir};
  my $ignorePaths = "/geninc/|/Configuration/|/TestBed/|/TestBedTemplate/|".
                    "/\.setting/";
  my $findCommand = '';

  undef @{$self->{mySubDirList}};
  undef @{$self->{myMainCompSubDirList}};
  undef @{$self->{myTestCompSubDirList}};
  undef @{$self->{myMainCompCppHppFiles}};
  undef @{$self->{myTestCompCppHppFiles}};

  # Sub directories list including Main, src and Test component directories.
  $findCommand = "find $searchPath -type d | grep -v -E \"$ignorePaths\"";
  @{$self->{mySubDirList}} = `$findCommand`;

   my $foundTestCompDir = 0;
   my $testCompDirPath = '';

  # Seperate Main component source directories and Test component directories.
  foreach my $dirName ( @{$self->{mySubDirList}} ) {
    chomp ($dirName);
    if (-d "$dirName/TestBed") {
      # Name of test component
      $testCompDirPath = $dirName;
      push(@{$self->{myTestCompSubDirList}}, $dirName);
      $foundTestCompDir = 1;
    }
    else {
      if ($foundTestCompDir == 1) {
        if ($dirName =~ /^$testCompDirPath/) {
          # Store test component source directories
          push(@{$self->{myTestCompSubDirList}}, $dirName);
          next;
        }
      }

      # Store main component source directories
      push(@{$self->{myMainCompSubDirList}}, $dirName);
    }
  }

  # Files to be searched.
  my @searchFiles = qw("*.c" "*.h" "*.cpp" "*.hpp");
  my @filesCppHpp;

  foreach my $dirName ( @{$self->{myMainCompSubDirList}} ) {
    # Prepare a find command to find source files in main component
    # source directories.
    $findCommand = "find $dirName -maxdepth 1 -iname $searchFiles[0] -or ".
                    "-iname $searchFiles[1] -or -iname $searchFiles[2] -or ".
                    "-iname $searchFiles[3] 2>/dev/null | ".
                    "grep -v -E \"$ignorePaths\"";
    @filesCppHpp = `$findCommand`;
    push(@{$self->{myMainCompCppHppFiles}}, @filesCppHpp);
  }

  foreach my $dirName ( @{$self->{myTestCompSubDirList}} ) {
    # Prepare a find command to find source files in test component
    # source directories.
    $findCommand = "find $dirName -maxdepth 1 -iname $searchFiles[0] -or ".
                    "-iname $searchFiles[1] -or -iname $searchFiles[2] -or ".
                    "-iname $searchFiles[3] 2>/dev/null | ".
                    "grep -v -E \"$ignorePaths\"";
    @filesCppHpp = `$findCommand`;
    push(@{$self->{myTestCompCppHppFiles}}, @filesCppHpp);
  }
}

=item checkIdlIncludes()

 This sub-routine takes idl file name in object's directory as parameter, scans
 that file for included files and checks existence of included files.
 @param fileName - name of the file to be scanned.

=cut
sub checkIdlIncludes
{
  my $self = shift;
  my $validIncludes = 0;
  my $currentTime;
  my $errMessage;
  undef @{$self->{arefErrMessages}};

  if (@_ != 1) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR checkIdlIncludes() ".
        "expects one idl file name as parameter\n");
    return $validIncludes;
  }

  my $fileName = shift;
  chomp($fileName);

  # Remove starting and trailing spaces if any.
  $fileName =~s/^\s+//;
  $fileName =~s/\s+$//;

  # Check if file exist and is readable.
  if ((not -e $fileName) || (not -r $fileName)) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR Can not read ".
        "$fileName. Skipping file.\n");
    return $validIncludes;
  }

  # Get included file list. Return if no file found.
  my @includeList = _findIncludedFiles($fileName);

  # Set valid include to 1. If included file not found, set it to 0 in
  # following loop.
  $validIncludes = 1;

  # Check existence of included files.
  LOOP_FOR_EACH_IDL:
  foreach my $includeFile (@includeList) {
    if ( -e $ENV{WORKSPACE}.'/IDL/'.$includeFile ) {
    }
    elsif ( ($fileName =~ /published_IDL/) and (-e $ENV{WORKSPACE}.'/IDL/Test/published_IDL/'.$includeFile ) ) {
    }
    elsif ( -e $ENV{OO_SDK_HOME}.'/idl/'.$includeFile ) {
    }
    else {
      $errMessage = "$includeFile file not found";

      # Check in array of exceptions that error message is mentioned there.
      foreach my $exceptionStr
        (keys %{ $self->{hrefExceptionMap}->{$fileName}}) {
        if ($errMessage eq $exceptionStr) {
          $self->{hrefExceptionMap}->{$fileName}->{"$exceptionStr"} = 1;
          next LOOP_FOR_EACH_IDL;
        }
      }
      $validIncludes = 0;
      $currentTime = getTime();
      push(@{$self->{arefErrMessages}}, "$currentTime ERROR $errMessage\n");
    }
  }# End for each file
  return $validIncludes;
}


=item checkIncludes()

 This sub-routine takes file name in object's directory as parameter, scans that
 file for included files and checks existence of included files.
 @param fileName - name of the file to be scanned.

=cut
sub checkIncludes
{
  my $self = shift;
  my $validIncludes = 0;
  my $currentTime;
  my $errMessage;
  undef @{$self->{arefErrMessages}};

  if (@_ != 2) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR checkIncludes() ".
        "expects file name as parameter\n");
    return $validIncludes;
  }

  my $fileName = shift;
  chomp($fileName);

  my $verifyComp = shift;
  my @dirList;
  undef @dirList;
  if ($verifyComp == 0) {
    @dirList = @{$self->{myMainCompSubDirList}};
  }
  else {
    @dirList = @{$self->{mySubDirList}};
  }

  # Remove starting and trailing spaces if any.
  $fileName =~s/^\s+//;
  $fileName =~s/\s+$//;

  # Check if file exist and is readable.
  if ((not -e $fileName) || (not -r $fileName)) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR Can not read ".
        "$fileName. Skipping file.\n");
    return $validIncludes;
  }

  # Get included file list. Return if no file found.
  my @includeList = _findIncludedFiles($fileName);

  # Set valid include to 1. If included file not found, set it to 0 in
  # following loop.
  $validIncludes = 1;

  # Check existence of included files.
  LOOP_FOR_EACH_FILE:
  foreach my $includeFile (@includeList) {
    my $result = 0;
    my $includeFileName = (split m(\.\.\/\w+), $includeFile)[-1];
    foreach my $dirName (@dirList) {
      if (-e $dirName.'/'.$includeFile) {
        $result = 1;
        last;
      }
    }
    if ( $result == 1 ) {
    }
    elsif ( -e $ENV{WORKSPACE}.'/include/'.$includeFile ) {
    }
    elsif ( -e $ENV{OO_SDK_HOME}.'/include/'.$includeFile ) {
    }
    elsif ( exists $self->{zenithAllowedIncludes}->{$includeFile} ) {
    }
    else {
      $errMessage = "$includeFile file not found";

      # Check in array of exceptions that error message is mentioned there.
      foreach my $exceptionStr
        (keys %{ $self->{hrefExceptionMap}->{$fileName}}) {
        if ($errMessage eq $exceptionStr) {
          $self->{hrefExceptionMap}->{$fileName}->{"$exceptionStr"} = 1;
          next LOOP_FOR_EACH_FILE;
        }
      }
      $validIncludes = 0;
      $currentTime = getTime();
      push(@{$self->{arefErrMessages}}, "$currentTime ERROR $errMessage\n");
    }
  }# End for each file
  return $validIncludes;
}

=item printErrorMessages()

 This sub-routine prints the error messages.

=cut
sub printErrorMessages
{
  my $self = shift;
  if (@{$self->{arefErrMessages}}) {
    foreach my $errMsg (@{$self->{arefErrMessages}}) {
      print($errMsg);
    }
  }
}

=item checkUnneededExceptions()

 This sub-routine checks if there are any unnecessary exceptions mentioned for
 the file name passed to it.
 @param fileName - name of the file for which unnecessary exceptions are
 searched.
 @return 1 - if the file contains unneeded exceptions.
 @return 0 - otherwise.

=cut
sub checkUnneededExceptions
{
  my $self = shift;
  my $fileName = shift;
  my $unneededExpPresent = 0;

  if (exists $self->{hrefExceptionMap}->{$fileName}) {
    undef @{$self->{arefErrMessages}};

    # Check in hash of exceptions that all exceptions are encountered or not.
    foreach my $exceptionStr (keys %{$self->{hrefExceptionMap}->{$fileName} }) {
      if ($self->{hrefExceptionMap}->{$fileName}->{"$exceptionStr"} == 0) {
        push(@{$self->{arefErrMessages}}, "$exceptionStr\n");
        $unneededExpPresent = 1;
      }
    }
  }
  return $unneededExpPresent;
}

=item isPathExcluded()

 This sub-routine checks if the directory path of the object contains any path
 mentioned in the list of excluded paths.
 @return 1 - if the object's directory path contains excluded path.
 @return 0 - otherwise.

=cut
sub isPathExcluded
{
  my $self = shift;

  my $excludePath = 0;
  my $hkeyPath = q(Exclude path);

  if (exists $self->{hrefExceptionMap}->{$hkeyPath}) {

    # Check whether object's directory is present in list of excluded paths.
    LOOP_FOREACH_EXCLUDE_PATH:
    foreach my $path (keys %{$self->{hrefExceptionMap}->{$hkeyPath}}) {
      if ($self->{dir} =~ $path) {
        $excludePath = 1;
        last LOOP_FOREACH_EXCLUDE_PATH;
      }
    }
  }
  return $excludePath;
}

# This sub-routine scans a file to find included files. This is internal
# sub-routine. It should not be called from outside of this module.
# @param fileName - name of the file to be scanned.
# @return includedFiles - array of included file names.
sub _findIncludedFiles
{
  # Copy the file name
  my $fileName = shift;
  my %hIncludeFiles;
  my $line;

  # Open file for reading
  open(my $fileHandle, $fileName) or croak("$fileName: $!\n");

  while (<$fileHandle>) {
    $line = $_;

    # Check if line contains start of multiline comment. i.e. should not start
    # with /*
    if ($line =~ m/^\s*\/\*/) {

      # Read all lines unless there is end of multiline comment. i.e. */
      while ((defined($line = <$fileHandle>) && $line !~ m/\*\//)) {

        # Do nothing.
      }
    }
    # Line should not be single line comment. i.e. should not start with //
    elsif ($line !~ m{^\s*\/\/}) {

      # Check that the line contains required pattern.
      if ( $line =~ m/^\s*#include\s+[<|"]\s*(.*?)\s*[>|"].*$/ ) {

        # Add the included file name to the hash.
        $hIncludeFiles{$1} = 1;
      }
    }
  }
  close ($fileHandle);

  # Return array of included file names
  my @includedFiles = keys(%hIncludeFiles);
  return @includedFiles;
}

# This sub-routine returns current local time.
# This is internal sub-routine. It should not be called from outside of this
# module.
# @return nowTime - current local time.
sub getTime
{
  # Assign path of get_time.sh file to a variable.
  my $getCurTime = $ENV{WORKSPACE}.q(/CMF-tools/quality_assurance/).
    q(dependency_check/lbin/tools/get_time.sh);
  my $nowTime = qx/$getCurTime/;
  chomp($nowTime);
  return $nowTime;
}

1;

=back

=head1 AUTHOR

 PSL

=cut
