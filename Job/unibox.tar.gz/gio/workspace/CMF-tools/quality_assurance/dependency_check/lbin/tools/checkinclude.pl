#!/usr/bin/perl -w

use strict;
use lib "$ENV{WORKSPACE}/CMF-tools/quality_assurance/dependency_check/lbin/".
        "tools";
use includevalidator;

# Assign name of exception file to a variable.
my $exceptionFile = $ENV{WORKSPACE}.q(/CMF-tools/quality_assurance/).
  q(dependency_check/expected_results/Check_Include_Guidelines_Exceptions);

# Exit value can be 0:Passed, 1:Failed, 2:Crashed, 3:Not executed
my $exitPassed = 0;
my $exitFailed = 1;
my $exitNotExecuted = 3;
my $exitValue = $exitPassed;

# Main script
{
  my $cwd;
  my $currentTime;
  my $dirErrMsg = "checkinclude.pl expects one argument. The argument should".
                  " be component package root directory or path containing ".
                  "\$WORKSPACE/IDL directory.\n";

  # Assign path of get_time.sh file to a variable.
  my $getCurTime = $ENV{WORKSPACE}.q(/CMF-tools/quality_assurance/).
    q(dependency_check/lbin/tools/get_time.sh);

  # Check if an argument is passed.
  if (scalar @ARGV == 1) {
    $cwd = $ARGV[0];
    chomp($cwd);

    # Remove starting, trailing spaces if any.
    $cwd =~ s/^\s+//;
    $cwd =~ s/\s+$//;

    # Check that argument exists and is directory.
    if (not -e $cwd) {
      $currentTime = qx/$getCurTime/;
      chomp($currentTime);
      print("$currentTime ERROR $cwd does not exist.\n$dirErrMsg");
      exit $exitNotExecuted;
    }
    if (not -d $cwd) {
      $currentTime =  qx/$getCurTime/;
      chomp($currentTime);
      print("$currentTime ERROR $cwd not directory.\n$dirErrMsg");
      exit $exitNotExecuted;
    }
  }
  else {
    $currentTime = qx/$getCurTime/;
    chomp($currentTime);
    print("$currentTime ERROR $dirErrMsg");
    exit $exitNotExecuted;
  }

  # Initialize variable with IDL path.
  my $idlDir = $ENV{WORKSPACE}.'/IDL';

  # Create includevalidator object.
  my $includeValidator = includevalidator->new($cwd);
  my $validInclude;

  # Parse exceptions file.
  parseExceptionsFile($includeValidator);

  # Check whether the object's directory path is to be excluded.
  if ($includeValidator->isPathExcluded()) {
    exit $exitNotExecuted;
  }

  # Check if directory path contains $WORKSPACE/IDL in it.
  if ($cwd =~ m/$idlDir/) {

    # Get list of idl files in the directory.
    my @fileList = $includeValidator->getIdlList();
    if (@fileList) {

      # For each idl file, find included files and check existence of included
      # files.
      $currentTime = qx/$getCurTime/;
      chomp($currentTime);
      print("Directory: $cwd....$currentTime\n");

      foreach my $file (@fileList) {
        chomp($file);
        print("+TEST Checking includes - file: $file ");

        $validInclude = $includeValidator->checkIdlIncludes($file);

        if ($validInclude == 1) {
          print(": PASSED\n");
        }
        else {
          print(": FAILED\n");
          $includeValidator->printErrorMessages();

          # Set exit value to 1 i.e. Failed
          $exitValue = $exitFailed;
        }
        if ($includeValidator->checkUnneededExceptions($file)) {
          print("+TEST Unneeded rule in Check_Include_Guidelines_Exceptions".
                "(CHECKINCLUDE) - file: $file : FAILED\n");
          $includeValidator->printErrorMessages();
        }
      }
    }

    # No file found.
    else {
      exit $exitNotExecuted;
    }
  }
  else {
    my @fileList;
    my $srcFilesCount = 0;
    my $validCompPath = 0;

    # Get list of cpp / hpp files in the directory.
    $includeValidator->getCppHppList();

    $currentTime = qx/$getCurTime/;
    chomp($currentTime);
    print("Directory: $cwd....$currentTime\n");

    # Seperate Main component and Test component source files.
    for (my $loop=0; $loop<2; $loop++) {
      if ($loop == 0) {
        @fileList= @{$includeValidator->{myMainCompCppHppFiles}};
        $srcFilesCount = scalar @fileList;
      }
      else {
        @fileList= @{$includeValidator->{myTestCompCppHppFiles}};
        $srcFilesCount = scalar @fileList;
      }
      foreach my $file (@fileList) {
        chomp($file);
        print("+TEST Checking includes - file: $file ");
        $validInclude = $includeValidator->checkIncludes($file, $loop);
        if ($validInclude == 1) {
          print(": PASSED\n");
        }
        else {
          print(": FAILED\n");
          $includeValidator->printErrorMessages();

          # Set exit value to 1 i.e. Failed
          $exitValue = $exitFailed;
        }
        if ($includeValidator->checkUnneededExceptions($file)) {
          print("+TEST Unneeded rule in Check_Include_Guidelines_Exceptions".
              "(CHECKINCLUDE) - file: $file : FAILED\n");
          $includeValidator->printErrorMessages();
        }
      }
    }
  }
  exit $exitValue;
}

# This sub-routine parses the file containing list of exceptions.
# @param validatorRef - Reference of validator object.
# @param logMessages - whether to log messages.
sub parseExceptionsFile
{
  my $includeValidatorRef = shift;
  my $exceptionFileWellFormed;

  print("\n+TEST Parsing exceptions - file: $exceptionFile ");

  # Parse exceptions list.
  $exceptionFileWellFormed =
    $includeValidatorRef->parseExceptionsFile($exceptionFile);

  if ($exceptionFileWellFormed != 1) {
    print(": FAILED\n");
    $includeValidatorRef->printErrorMessages();
    exit $exitNotExecuted;
  }
  else {
    print(": PASSED\n");
  }
}
