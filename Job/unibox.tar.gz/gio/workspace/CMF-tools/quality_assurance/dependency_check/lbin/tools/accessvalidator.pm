package accessvalidator;

use strict;
use Carp;
use XML::LibXML;

# To see documentation of accessvalidator, type following command
# pod2text < accessvalidator.pm

=head1 NAME

  accessvalidator - perl module that provides methods for component and idl
                    files to check access rules are followed or not by parsing
                    group specification file.

=head1 DESCRIPTION

  This module provides functions for

 1. Parsing group specification file. According to object's directory either
    interface groups or component groups are scanned.

 2. Searching idl, source, header files in object's directory.

 3. Validating a file by finding it's current and used namespaces and checking
    whether access rules are followed or not.

=head1 CONFIG FORMAT

 The group specification file contains rules for interfaces and components in
 workspace.

 Interface group is defined by IF_Group tag. It contains an attribute Name
 and elements as ContainsNamespace, ContainsIFGroup, UsesIFGroup .

 Component group is defined by CO_Group tag. It contains an attribute Name
 and elements as ContainsNamespace, ContainsCOGroup, UsesCOGroup.

 Structure of this file is as follows
 1. A group is defined with Name attribute.
 2. A group may have ContainsNamespace tag.
 3. A group may have ContainsCOGroup / ContainsIFGroup tag.
 4. A group may have UsesCOGroup / UsesIFGroup tag.
 5. A new namespace (interface or component) should be added under appropriate
    group name for that layer.

 Note: A namespace should belong to only one group.

=head1 FUNCTIONS

=over

=item new(directoryName)

 This constructor sub-routine creates data structures used to store data from
 group specification file and stores them in object variables, stores object's
 directory name.
 @param dirname - name of component or IDL directory.

=cut
sub new
{
  my $proto = shift;
  my $class = ref($proto) || $proto;
  my $self = {};
  my $currentTime;

  # Check that one parameter is passed or not.
  if (@_ != 1) {
    $currentTime = getTime();
    print("$currentTime INFO $class->new expects one parameter.\n");
    croak();
  }

  # Get the directory name and store it in instance variable
  my $dirname = shift;
  chomp($dirname);
  if ($dirname !~ m/\/$/) {
    $dirname .= '/';
  }

  # Create instance variables.
  $self->{dir} = $dirname;
  $self->{hrefInterfaceRule} = {};
  $self->{hrefComponentRule} = {};
  $self->{hrefInterfaceGrpMap} = {};
  $self->{hrefComponentGrpMap} = {};
  $self->{hrefExceptionMap} = {};

  # This variable is used to store error messages.
  $self->{arefErrMessages} = [];

  # These variables contains reference to a hash that contain first word of a
  # namespace as key and value is array reference that contain all namespaces
  # that start with the key.
  $self->{hrefInterfaceNamespaceKey} = {};
  $self->{hrefComponentNamespaceKey} = {};

  # This variable is used to decide whether to apply interface rules or
  # component rules in validateAccess(). This variable is set in
  # parseRuleSpecifications() sub-routine.
  $self->{parsedGroups} = q(none);

  bless($self, $class);
  return $self;
}

=item parseRuleSpecifications(groupSpecificationFileName, schema_file)

 This sub-routine parses group specification file. Depending on the dir name,
 interface groups or component groups are scanned and are stored in object
 variables. Group specification file should be in xml format.
 @param groupSpecificationFileName - name of the file that contains interface,
 component groups.
 @param schema_file - name of schema definition file used to validate group
 specification file.
 @return 1 - if specification file is well formed.
 @return 0 - if specification file is not well formed.

=cut
sub parseRuleSpecifications
{
  my $self = shift;
  my $currentTime;
  undef @{$self->{arefErrMessages}};

  # Initialize return value with 1 assuming that group specification file is
  # well formed. In case of error in group specification file, assign 0 to
  # return value and immediately return.
  my $specificationFileWellFormed = 1;

  # Check that two parameters are passed or not.
  if (@_ != 2) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR ".
        "parseRuleSpecifications() expects name of rule specification file ".
        "(file should be in xml format) and schema definition file (.xsd).\n");
    $specificationFileWellFormed = 0;
    return $specificationFileWellFormed;
  }

  my $xmlFile = shift;
  chomp($xmlFile);
  $xmlFile =~ s/^\s+//;
  $xmlFile =~ s/\s+$//;

  # Check that file exists and is readable.
  if ((not -e $xmlFile) || (not -r $xmlFile)) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR Can not read ".
        "$xmlFile\n");
    $specificationFileWellFormed = 0;
    return $specificationFileWellFormed;
  }

  my $schema_file = shift;
  chomp($schema_file);
  $schema_file =~ s/^\s+//;
  $schema_file =~ s/\s+$//;

  # Check that file exists and is readable.
  if ((not -e $schema_file) || (not -r $schema_file)) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR Can not read ".
        "$schema_file\n");
    $specificationFileWellFormed = 0;
    return $specificationFileWellFormed;
  }

  # Create object of parser and object of document.
  my $xmlParser = XML::LibXML->new();
  my $xmlDocument;

  # Rule specification file is parsed in eval() block so that if the file
  # contains any syntax error, then it should not crash application.
  eval{$xmlDocument = $xmlParser->parse_file($xmlFile);};

  # Check whether any error occurred while parsing the file.
  if ($@) {

    # Remove module line number from error message.
    $@ =~ s/at \/.*?$//s;
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR $@");
    $specificationFileWellFormed = 0;
    return $specificationFileWellFormed;
  }

  # Create object of schema definition file.
  my $schema = XML::LibXML::Schema->new(location => $schema_file);

  # Validate the file according to schema definition.
  eval { $schema->validate($xmlDocument); };

  # Check for error in validation.
  if ($@) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR While validating ".
        "$xmlFile using $schema_file: $@");
    $specificationFileWellFormed = 0;
    return $specificationFileWellFormed;
  }

  # Store IDL/ directory path in a variable.
  my $idlDir = $ENV{WORKSPACE}.'/IDL';

  # If object's dir name contains $WORKSPACE/IDL dir then parse rule
  # specification file, scan for interface groups and fill data structures.
  if ($self->{dir} =~ m/$idlDir/) {

    # Set this instance variable to later identify interface groups are scanned.
    $self->{parsedGroups} = q(interface);

    # Assign element, tag names used in configuration file.
    my $tagIF_Group = q(IF_Group);
    my $tagContainsIFGroup = q(ContainsIFGroup);
    my $tagContainsNamespace = q(ContainsNamespace);
    my $tagUsesIFGroup = q(UsesIFGroup);
    my $attrName = q(Name);
    my $attrDisableChk = q(disableChecking);

    # LibXML exports integer constants for DOM node types.
    # XML_TEXT_NODE => 3
    my $textNode = 3;

    # This hash is used to map a group to it's parent group.
    my %hContainedGroupParentGroupMap;

    # Iterate over all interface groups in specification file having element
    # IFGroup.
    foreach my $ifGroup ($xmlDocument->getElementsByTagName($tagIF_Group)) {

      # Assign name of the interface group to a variable.
      my $valueOfNameAttribute = $ifGroup->getAttribute($attrName);

      # Remove starting and trailing spaces if any.
      $valueOfNameAttribute =~ s/^\s+//;
      $valueOfNameAttribute =~ s/\s+$//;

      # Add name of interface group as key in the hash and assign a empty array
      # reference as it's value.
      $self->{hrefInterfaceRule}->{$valueOfNameAttribute} = [];

      # Check if attribute disableChecking is specified and its value.
      my $valueOfAttrDisableChk = q(false);
      if ($ifGroup->hasAttribute($attrDisableChk)) {
        $valueOfAttrDisableChk = $ifGroup->getAttribute($attrDisableChk);

        # Remove starting and trailing spaces if any.
        $valueOfAttrDisableChk =~ s/^\s+//;
        $valueOfAttrDisableChk =~ s/\s+$//;
      }

      # Declare arrays to store namespaces and groups.
      my @containsIFGroup;
      my @containsNamespace;
      my @usesIFGroup;

      # Iterate over each element of a interface group having value
      # ContainsIFGroup
      foreach my $elementOfContainsIFGroup
        ($ifGroup->getElementsByTagName($tagContainsIFGroup)) {

          # Iterate over each child node of the element.
          foreach my $valueOfContainsIFGroup
            ($elementOfContainsIFGroup->getChildNodes()) {

              # Check if it is TEXT_NODE.
              if ($valueOfContainsIFGroup->nodeType() == $textNode) {

                # Get node value of the TEXT_NODE.
                my $nodeValue = $valueOfContainsIFGroup->nodeValue();

                # Remove starting and trailing spaces if any from group name.
                $nodeValue =~ s/^\s+//;
                $nodeValue =~ s/\s+$//;

                # Store group name in an array.
                push(@containsIFGroup,$nodeValue);

                # Check that this group already belongs to other group. A group
                # may belong to only one group or none.
                if (not (exists $hContainedGroupParentGroupMap{$nodeValue})) {
                  $hContainedGroupParentGroupMap{$nodeValue} =
                    $valueOfNameAttribute;
                }
                else {
                  $currentTime = getTime();
                  push(@{$self->{arefErrMessages}}, "$currentTime ERROR ".
                      "$nodeValue interface group belongs to more than one ".
                      "group: $hContainedGroupParentGroupMap{$nodeValue}, ".
                      "$valueOfNameAttribute\n");
                  $specificationFileWellFormed = 0;
                  return $specificationFileWellFormed;
                }
              }
            }
        }

      # Iterate over each element of a interface group having value
      # ContainsNamespace.
      foreach my $elementOfContainsNamespace
        ($ifGroup->getElementsByTagName($tagContainsNamespace)) {

        # Iterate over each child node of the element.
        foreach my $valueOfContainsNamespace
          ($elementOfContainsNamespace->getChildNodes()) {

          # Check if it is TEXT_NODE.
          if ($valueOfContainsNamespace->nodeType() == $textNode) {

            # Get node value of TEXT_NODE.
            my $nodeValue = $valueOfContainsNamespace->nodeValue();

            # Remove starting and trailing spaces if any from namespace.
            $nodeValue =~ s/^\s+//;
            $nodeValue =~ s/\s+$//;

            # Store namespace in an array.
            push(@containsNamespace,$nodeValue);

            # Check that this namespace already belongs to other group. A
            # namespace may belong to only one group.
            if (not exists $self->{hrefInterfaceGrpMap}->{$nodeValue}) {
              $self->{hrefInterfaceGrpMap}->{$nodeValue} =
                $valueOfNameAttribute;

              # Extract the first word of the namespace, using it as a key store
              # the namespace in the array pointed by array reference in the
              # value.
              if ($nodeValue =~ m/^(\w+)/) {
                push(@{ $self->{hrefInterfaceNamespaceKey}->{$1} }, $nodeValue);
              }
              else {
                $currentTime = getTime();
                push(@{$self->{arefErrMessages}}, "$currentTime ERROR ".
                    "$nodeValue interface namespace do not start with word\n");
                $specificationFileWellFormed = 0;
                return $specificationFileWellFormed;
              }
            }
            else {
              $currentTime = getTime();
              push(@{$self->{arefErrMessages}}, "$currentTime ERROR: ".
                  "$nodeValue namespace belongs to more than one group: ".
                  "$self->{hrefInterfaceGrpMap}->{$nodeValue}".
                  ", $valueOfNameAttribute\n");
              $specificationFileWellFormed = 0;
              return $specificationFileWellFormed;
            }
          }
        }
      }

      # Iterate over each element of a interface group having value
      # UsesIFGroup.
      foreach my $elementOfUsesIfGroup
        ($ifGroup->getElementsByTagName($tagUsesIFGroup)) {

          # Iterate over each child node of element.
          foreach my $valueOfUsesIFGroup
            ($elementOfUsesIfGroup->getChildNodes()) {

            # Check if it is TEXT_NODE.
            if ($valueOfUsesIFGroup->nodeType() == $textNode) {

              # Get node value of TEXT_NODE.
              my $nodeValue = $valueOfUsesIFGroup->nodeValue();

              # Remove starting and trailing spaces if any from group name.
              $nodeValue =~ s/^\s+//;
              $nodeValue =~ s/\s+$//;

              # Store used group name in an array.
              push(@usesIFGroup,$nodeValue);
            }
          }
        }

      # Add array reference to hash. Hash value is an array reference that
      # in turn contains array references to contained groups, contained
      # namespaces, used namespaces and attribute value of disableChecking.
      push(@{ $self->{hrefInterfaceRule}->{$valueOfNameAttribute} },
        \@containsIFGroup);
      push(@{ $self->{hrefInterfaceRule}->{$valueOfNameAttribute} },
        \@containsNamespace);
      push(@{ $self->{hrefInterfaceRule}->{$valueOfNameAttribute} },
        \@usesIFGroup);
      push(@{ $self->{hrefInterfaceRule}->{$valueOfNameAttribute} },
        $valueOfAttrDisableChk);
    }

    # Initialize variable with 0 i.e. no dummy namespace.
    my $dummyNamespace = 0;

    # Check each namespace that it is dummy or not, with every other namespace.
    # If dummy namespaces are found, log the error.
    foreach my $currentInterfaceNamespace (keys( %{$self->{hrefInterfaceGrpMap}} )) {
      foreach my $interfaceNamespace (keys( %{$self->{hrefInterfaceGrpMap}} )) {
        if ($currentInterfaceNamespace ne $interfaceNamespace) {
          if ($interfaceNamespace =~ m/^$currentInterfaceNamespace(\W+)/) {
            $currentTime = getTime();
            push(@{$self->{arefErrMessages}}, "$currentTime ERROR Group ".
                "specification file contains interface namespace ".
                "$currentInterfaceNamespace more than once: ".
                "$interfaceNamespace\n");

            # Assign 1 to variable as there is dummy namespace.
            $dummyNamespace = 1;
          }
        }
      }
    }

    # Return if dummy namespaces are found.
    if ($dummyNamespace == 1) {
      $specificationFileWellFormed = 0;
      return $specificationFileWellFormed;
    }

    # Assign parent group. Top most groups that are not contained in any group
    # will not have parent group and such group names will not appear as key of
    # the below mentioned hash.
    foreach my $keyContainedGroup (keys %hContainedGroupParentGroupMap) {

      # Check that the group is defined.
      if (exists $self->{hrefInterfaceRule}->{$keyContainedGroup}) {

        # Add the parent group at end.
        push(@{ $self->{hrefInterfaceRule}->{$keyContainedGroup} },
            $hContainedGroupParentGroupMap{$keyContainedGroup});
      }
      else {
        $currentTime = getTime();
        push(@{$self->{arefErrMessages}}, "$currentTime ERROR ".
            "$keyContainedGroup not defined.It is only included in ".
            "$hContainedGroupParentGroupMap{$keyContainedGroup}\n");
        $specificationFileWellFormed = 0;
        return $specificationFileWellFormed;
      }
    }
  }

  # If object's dir name do not contain $WORKSPACE/IDL dir then parse group
  # specification file, scan for component groups and fill data structures.
  else {

    # Set this instance variable to later identify component groups are scanned.
    $self->{parsedGroups} = q(component);

    # Assign element, tag names used in configuration file.
    my $tagCO_Group = q(CO_Group);
    my $tagContainsCOGroup = q(ContainsCOGroup);
    my $tagContainsNamespace = q(ContainsNamespace);
    my $tagUsesCOGroup = q(UsesCOGroup);
    my $attrName = q(Name);
    my $attrDisableChk = q(disableChecking);

    # LibXML exports integer constants for DOM node types.
    # XML_TEXT_NODE => 3
    my $textNode = 3;

    # This hash is used to map a group to it's parent group.
    my %hContainedGroupParentGroupMap;

    # Iterate over all component groups having element CO_Group.
    foreach my $coGroup ($xmlDocument->getElementsByTagName($tagCO_Group)) {

      # Assign name of the component group to a variable.
      my $valueOfNameAttribute = $coGroup->getAttribute($attrName);

      # Remove starting and trailing spaces
      $valueOfNameAttribute =~ s/^\s+//;
      $valueOfNameAttribute =~ s/\s+$//;

      # Add name of interface group as key into the hash.
      $self->{hrefComponentRule}->{$valueOfNameAttribute} = [];

      # Check if attribute disableChecking is specified and its value.
      my $valueOfAttrDisableChk = q(false);
      if ($coGroup->hasAttribute($attrDisableChk)) {
        $valueOfAttrDisableChk = $coGroup->getAttribute($attrDisableChk);

        # Remove starting and trailing spaces if any.
        $valueOfAttrDisableChk =~ s/^\s+//;
        $valueOfAttrDisableChk =~ s/\s+$//;
      }

      # Declare arrays to store namespaces and groups.
      my @containsCOGroup;
      my @containsNamespace;
      my @usesCOGroup;

      # Iterate over each element of a component group having value
      # ContainsCOGroup
      foreach my $elementOfContainsCOGroup
        ($coGroup->getElementsByTagName($tagContainsCOGroup)) {

        # Iterate over each child node of the element
        foreach my $valueOfContainsCOGroup
          ($elementOfContainsCOGroup->getChildNodes()) {

          # Check if it is TEXT_NODE
          if ($valueOfContainsCOGroup->nodeType() == $textNode) {

            # Get node value of the TEXT_NODE.
            my $nodeValue = $valueOfContainsCOGroup->nodeValue();

            # Remove starting and trailing spaces.
            $nodeValue =~ s/^\s+//;
            $nodeValue =~ s/\s+$//;

            # Store group name in an array.
            push(@containsCOGroup,$nodeValue);

            # Check that this group already belongs to other group.
            # A group may belong to only one group.
            if(not exists $hContainedGroupParentGroupMap{$nodeValue}) {
              $hContainedGroupParentGroupMap{$nodeValue} =
                $valueOfNameAttribute;
            }
            else {
              $currentTime = getTime();
              push(@{$self->{arefErrMessages}}, "$currentTime ERROR $nodeValue".
                  " component group belongs to more than one group: ".
                  "$hContainedGroupParentGroupMap{$nodeValue}, ".
                  "$valueOfNameAttribute\n");
              $specificationFileWellFormed = 0;
              return $specificationFileWellFormed;
            }
          }
        }
      }

      # Iterate over each element of a component group having value
      # ContainsNamespace.
      foreach my $elementOfContainsNamespace
        ($coGroup->getElementsByTagName($tagContainsNamespace)) {

        # Iterate over each child node of the element.
        foreach my $valueOfContainsNamespace
          ($elementOfContainsNamespace->getChildNodes()) {

          # Check if it is TEXT_NODE.
          if ($valueOfContainsNamespace->nodeType() == $textNode) {

            # Get node value of TEXT_NODE.
            my $nodeValue = $valueOfContainsNamespace->nodeValue();

            # Remove starting and trailing spaces
            $nodeValue =~ s/^\s+//;
            $nodeValue =~ s/\s+$//;

            # Store namespace in an array.
            push(@containsNamespace,$nodeValue);

            # Check that this namespace already belongs to a group. A namespace
            # may belong to only one group.
            if (not exists $self->{hrefComponentGrpMap}->{$nodeValue}) {
              $self->{hrefComponentGrpMap}->{$nodeValue} =
                $valueOfNameAttribute;

              # Extract the first word of the namespace, using it as a key store
              # the namespace in the array pointed by array reference in the
              # value.
              if ($nodeValue =~ m/^(\w+)/) {
                push(@{ $self->{hrefComponentNamespaceKey}->{$1} }, $nodeValue);
              }
              else {
                $currentTime = getTime();
                push(@{$self->{arefErrMessages}}, "$currentTime ERROR ".
                    "$nodeValue component namespace do not start with word\n");
                $specificationFileWellFormed = 0;
                return $specificationFileWellFormed;
              }
            }
            else {
              $currentTime = getTime();
              push(@{$self->{arefErrMessages}}, "$currentTime ERROR: ".
                  "$nodeValue belongs to more than one group: ".
                  "$self->{hrefComponentGrpMap}->{$nodeValue}, ".
                  "$valueOfNameAttribute\n");
              $specificationFileWellFormed = 0;
              return $specificationFileWellFormed;
            }
          }
        }
      }

      # Iterate over each element of a component group having value
      # UsesCOGroup
      foreach my $elementOfUsesCOGroup
        ($coGroup->getElementsByTagName($tagUsesCOGroup)) {

        # Iterate over each child node of element.
        foreach my $valueOfUsesCOGroup
          ($elementOfUsesCOGroup->getChildNodes()) {

          # Check if it is TEXT_NODE.
          if ($valueOfUsesCOGroup->nodeType() == $textNode) {

            # Get node value of TEXT_NODE.
            my $nodeValue = $valueOfUsesCOGroup->nodeValue();

            # Remove starting and trailing spaces
            $nodeValue =~ s/^\s+//;
            $nodeValue =~ s/\s+$//;

            # Store used group name in an array
            push(@usesCOGroup,$nodeValue);
          }
        }
      }

      # Add array reference to hash. Hash value is an array reference that
      # in turn contains array references to contained groups, contained
      # namespaces, used namespaces and value of attribute disableChecking.
      push(@{ $self->{hrefComponentRule}->{$valueOfNameAttribute} },
        \@containsCOGroup);
      push(@{ $self->{hrefComponentRule}->{$valueOfNameAttribute} },
        \@containsNamespace);
      push(@{ $self->{hrefComponentRule}->{$valueOfNameAttribute} },
        \@usesCOGroup);
      push(@{ $self->{hrefComponentRule}->{$valueOfNameAttribute} },
        $valueOfAttrDisableChk);
    }

    # Initialize variable with 0 i.e. no dummy namespace.
    my $dummyNamespace = 0;

    # Check each namespace that it is dummy or not, with every other namespace.
    # If dummy namespaces are found, log the error.    my $interfaceNamespace;
    foreach my $currentComponentNamespace (keys( %{$self->{hrefComponentGrpMap}} )) {
      foreach my $componentNamespace (keys( %{$self->{hrefComponentGrpMap}} )) {
        if ($currentComponentNamespace ne $componentNamespace) {
          if ($componentNamespace =~ m/^$currentComponentNamespace(\W+)/) {
            $currentTime = getTime();
            push(@{$self->{arefErrMessages}}, "$currentTime ERROR Group ".
                "specification file contains component namespace ".
                "$currentComponentNamespace more than once: ".
                "$componentNamespace\n");

            # Assign 1 to variable as there is dummy namespace.
            $dummyNamespace = 1;
          }
        }
      }
    }

    # Return if dummy namespaces are found.
    if ($dummyNamespace == 1) {
      $specificationFileWellFormed = 0;
      return $specificationFileWellFormed;
    }

    # Assign parent group. Top most groups that are not contained in any group
    # will not have parent group and such group names will not appear as key of
    # the below mentioned hash.
    foreach my $keyContainedGroup (keys %hContainedGroupParentGroupMap) {

      # Check that the group is defined.
      if (exists $self->{hrefComponentRule}->{$keyContainedGroup}) {

        # Assign the parent group.
        push(@{ $self->{hrefComponentRule}->{$keyContainedGroup} },
          $hContainedGroupParentGroupMap{$keyContainedGroup});
      }
      else {
        $currentTime = getTime();
        push(@{$self->{arefErrMessages}}, "$currentTime ERROR ".
            "$keyContainedGroup not defined. It is only included in ".
            "$hContainedGroupParentGroupMap{$keyContainedGroup}\n");
        $specificationFileWellFormed = 0;
        return $specificationFileWellFormed;
      }
    }
  }
  return $specificationFileWellFormed;
}

=item parseExceptionsFile()

 This sub-routine parses the exception file passed to it.
 @param exceptionFile - name of the file containing list of exceptions.
 @return 0 - error while parsing the file.
 @return 1 - no error in parsing the file.

=cut
sub parseExceptionsFile
{
  my $self = shift;
  my $exceptionFileParsed = 0;
  my $line;
  my $fileName;
  my $exceptionStr;
  my $currentTime;
  my $scanFile;
  my $sectionStart;
  my $sectionEnd;

  undef @{$self->{arefErrMessages}};

  # Check that one parameter is passed or not.
  if (@_ != 1) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR ".
        "parseExceptionsFile() expects name of file containing exception ".
        "list\n");
    return $exceptionFileParsed;
  }

  my $exceptionFile = shift;
  chomp($exceptionFile);
  $exceptionFile =~ s/^\s+//;
  $exceptionFile =~ s/\s+$//;

  # Check that file exists and is readable.
  if ((not -e $exceptionFile) || (not -r $exceptionFile)) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR Can not read ".
        "$exceptionFile\n");
    return $exceptionFileParsed;
  }

  $scanFile = 0;
  $sectionStart = q(CHECKACCESSRULE EXCEPTIONS BEGIN);
  $sectionEnd = q(CHECKACCESSRULE EXCEPTIONS END);
  open(my $fileHandle, $exceptionFile) or croak("$exceptionFile: $!");
  LOOP_WHILE:
  while($line = <$fileHandle>) {

    if ($line =~ m/^$sectionStart$/) {
      $scanFile = 1;
      next LOOP_WHILE;
    }
    elsif ($line =~ m/^$sectionEnd$/) {
      $scanFile = 0;
      last LOOP_WHILE;
    }

    if ($scanFile == 1) {
      # Line should not start with # or line should not be empty.
      if (($line !~ m/^\s*#/) && ($line !~ m/^\s*$/)) {

        # File name specified on single line.
        if ($line =~ m/^\*\s+(.*):$/) {
          $fileName = $1;
          chomp($fileName);
          $fileName =~ s/\s+$//;

          # Read exception string for the above file. Exception string may span
          # over multiple lines.
          LOOP_WHILE_EXP_STR:
          while(defined($line = <$fileHandle>)) {

            # Check if line is not comment or empty.
            if (($line !~ m/^\s*#/) && ($line !~ m/^\s*$/)) {

              # Validation - line should not start with "*".
              if ($line =~ m/^\*/) {
                $currentTime = getTime();
                push(@{$self->{arefErrMessages}}, "$currentTime WARNING ".
                    "Exception file: $exceptionFile contains invalid syntax on".
                    " line - $line\n");
                close($fileHandle);
                return $exceptionFileParsed;
              }
              if ($line =~ m/^"(.*)"$/) {
                $exceptionStr = $1;
                last LOOP_WHILE_EXP_STR;
              }
              elsif ($line =~ m/^"(.+)/) {
                $exceptionStr = $1;
            }
            elsif ($line =~ m/(.+)"$/) {
              $exceptionStr .= $1;
            last LOOP_WHILE_EXP_STR;
            }
              else {
                $exceptionStr .= $line;
              }
            }
          }

          # Add exception string to hash.
          $self->{hrefExceptionMap}->{$fileName}->{"$exceptionStr"} = 0;
        }
        else {
          $currentTime = getTime();
          push(@{$self->{arefErrMessages}}, "$currentTime WARNING Exception ".
              "file: $exceptionFile contains invalid syntax on line - $line\n");
          close($fileHandle);
          return $exceptionFileParsed;
        }
      }
    }
  }
  close($fileHandle);
  $exceptionFileParsed = 1;
  return $exceptionFileParsed;
}

=item getIdlList()

 This sub-routine returns the list of .idl files present in object's directory
 and returns the array of file names.
 @return idlFiles - array containing name of the .idl files found in search.

=cut
sub getIdlList
{
  my $self = shift;
  my $searchPath = $self->{dir};
  my $searchFiles = q("*.idl");

  # Prepare a command to find idl files.
  my $searchCommand = "find $searchPath -follow -iname $searchFiles 2>/dev/null";

  # Search $WORKSPACE/IDL/ for .idl files
  my @idlFiles = `$searchCommand`;
  return @idlFiles;
}

=item getCppHppList()

 This sub-routine finds .c, .cpp, .h, .hpp files in the object's directory upto
 maximum depth 1 and returns the array of file names.
 @return filesCppHpp - array containing name of the source, header files found 
 in search.

=cut
sub getCppHppList
{
  my $self = shift;
  my $searchDir = $self->{dir};

  # Files to be searched.
  my @searchFiles = qw("*.c" "*.h" "*.cpp" "*.hpp");
  my $ignorePaths = "/geninc/|/Configuration/|/TestBed/|/TestBedTemplate/|".
                    "/\.setting/";

  # Prepare a command to find files.
  my $findCommand = "find $searchDir -iname $searchFiles[0] -or ".
                    "-iname $searchFiles[1] -or -iname $searchFiles[2] -or ".
                    "-iname $searchFiles[3] 2>/dev/null | ".
                    "grep -v -E \"$ignorePaths\"";

  # Execute find command and store result in an array.
  my @filesCppHpp = `$findCommand`;
  return @filesCppHpp;
}

=item getCurrentNamespace()

 This sub-routine determines the current namespace from the directory name that
 is provided at the time of object creation.
 @return presentNamespace - namespace of the object's directory.

=cut
sub getCurrentNamespace
{
  my $self = shift;
  my $presentDir = $self->{dir};
  my $presentNamespace;

  # Extract namespace of object's directory.
  if ($presentDir =~ m/workspace\/(.*)\/$/) {
    $presentNamespace = $1;

    # Replace "/" with "::"
    $presentNamespace =~ s/\//::/g;
    return $presentNamespace;
  }
  return;
}

=item isGroupDefined()

 This sub-routine checks whether group for object's directory is defined in the
 group specification file or not. This sub-routine is used for all, except
 $WORKSPACE/IDL descendents.
 @return 1 - if group is defined in group specification file.
 @return 0 - if group is not defined in group specification file.

=cut
sub isGroupDefined
{
  my $self = shift;
  my $presentNamespace = shift;
  my $flagGroupDefined = 0;
  my $namespaceInGrpFile;

  # Get corresponding namespace in group specification file.
  $namespaceInGrpFile =
    _mapToGrpSpecificationNamespace($self->{hrefComponentNamespaceKey},
        $presentNamespace);

  # Check if corresponding namespace is found.
  if (defined $namespaceInGrpFile) {
    $flagGroupDefined = 1;
  }
  return $flagGroupDefined;
}

=item validateAccess()

 This sub-routine accepts a file name, scans it for current and used namespaces
 and checks access guide lines.
 @param fileName - name of the file to be scanned and checked for guide lines.
 @return 3 - not executed
 @return 1 - file follows access guidelines.
 @return 0 - otherwise.

=cut
sub validateAccess
{
  my $self = shift;
  my $validAccess = 0;
  my $errMessage;
  my $currentTime;

  # Empty the array that will contain error messages.
  undef @{$self->{arefErrMessages}};

  # Check if a parameter is passed or not.
  if (@_ != 1) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR validateAccess() ".
         "expects name of a file (idl/header/source)\n");
    return $validAccess;
  }

  my $fileName = shift;
  chomp($fileName);
  $fileName =~s/^\s+//;
  $fileName =~s/\s+$//;

  # Initialize variables
  my $interfacegroup = q(interface);
  my $componentgroup = q(component);

  # Check if file exists and is readable.
  if ((not -e $fileName) || (not -r $fileName)) {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR Can not read ".
        "$fileName\n");
    return $validAccess;
  }

  my $currentNamespace;
  my @usedNamespaces;
  my $mappedCurrentNamespace;
  my @mappedUsedNamespaces;

  # Check file type is idl.
  if (($fileName =~ m/\.idl$/i) && ($self->{parsedGroups} eq $interfacegroup)) {

    # Get current and used namespaces.
    ($currentNamespace, @usedNamespaces) = _scanIdl($fileName);
    if (defined $currentNamespace)  {

      # Get corresponding namespace of current namespace.
      $mappedCurrentNamespace =
        _mapToGrpSpecificationNamespace($self->{hrefInterfaceNamespaceKey},
          $currentNamespace);
      if (defined $mappedCurrentNamespace) {

        # Check if disableChecking is true.
        my $grpOfCurNamespace =
          $self->{hrefInterfaceGrpMap}->{$mappedCurrentNamespace};

        if ($self->{hrefInterfaceRule}->{$grpOfCurNamespace}[3] eq "false") {
          if (scalar @usedNamespaces > 0) {

            # Get corresponding namespaces of used namespaces.
            @mappedUsedNamespaces =
            _mapToGrpSpecificationNamespace($self->{hrefInterfaceNamespaceKey},
              @usedNamespaces);
            if (scalar @mappedUsedNamespaces > 0) {

              # Check guide lines.
              $validAccess =  _checkRules($fileName, $self->{hrefInterfaceRule},
                  $self->{hrefInterfaceGrpMap}, $self->{hrefExceptionMap},
                  $self->{arefErrMessages}, $mappedCurrentNamespace,
                  @mappedUsedNamespaces);
            }

            # Used namespaces are not defined in group specification file which
            # is valid.
            else {
              $validAccess = 1;
            }
          }

          # If file do not contain used namespaces.
          elsif(scalar @usedNamespaces == 0) {
            $validAccess = 1;
          }
        }
        else {
          $validAccess = 3;
        }
      }

      # Else group specification file do not contain mapping namespace for idl
      # file.
      else {
        $errMessage = "Group specification file do not contain group for ".
                      "namespace $currentNamespace";
        my $errMsgFoundInExceptionList = 0;
        LOOP_FOREACH_EXP:
        foreach my $exceptionStr (keys %{ $self->{hrefExceptionMap}->{$fileName} }) {
          if ($errMessage eq $exceptionStr) {
            $self->{hrefExceptionMap}->{$fileName}->{"$exceptionStr"} = 1;
            $errMsgFoundInExceptionList = 1;
            $validAccess = 1;
            last LOOP_FOREACH_EXP;
          }
        }
        if ($errMsgFoundInExceptionList == 0) {
          $currentTime = getTime();
          push(@{$self->{arefErrMessages}}, "$currentTime WARNING ".
              "$errMessage\n");
        }
      }
    }

    # If file do not contain current namespace.
    else {
      $currentTime = getTime();
      push(@{$self->{arefErrMessages}}, "$currentTime ERROR unable to ".
          "determine current namespace for $fileName\n");
    }
  }

  # Check file type is .h or .hpp
  elsif (($fileName =~ m/\.h(?:pp|)/i) &&
         ($self->{parsedGroups} eq $componentgroup)) {

    # Get current and used namespaces.
    ($currentNamespace, @usedNamespaces) = _scanHeader($fileName);

    # Get corresponding namespace of current namespace.
    $mappedCurrentNamespace =
       _mapToGrpSpecificationNamespace($self->{hrefComponentNamespaceKey},
         $currentNamespace);

    if (scalar @usedNamespaces > 0) {

      # Get corresponding namespaces of used namespaces.
      @mappedUsedNamespaces =
        _mapToGrpSpecificationNamespace($self->{hrefComponentNamespaceKey},
          @usedNamespaces);

      # Check if corresponding namespaces for current and used namespaces found.
      if (scalar @mappedUsedNamespaces > 0) {

        # Check guide lines.
        $validAccess = _checkRules($fileName, $self->{hrefComponentRule},
          $self->{hrefComponentGrpMap}, $self->{hrefExceptionMap},
          $self->{arefErrMessages}, $mappedCurrentNamespace,
          @mappedUsedNamespaces);
      }

      # Used namespaces are not defined in group specification file which is
      # valid.
      else {
        $validAccess = 1;
      }
    }

    # If file do not contain used namespaces.
    else {
      $validAccess = 1;
    }
  }

  # Check file type is .c or .cpp
  elsif (($fileName =~ m/\.c(?:pp|)/i) &&
         ($self->{parsedGroups} eq $componentgroup)) {

    # Get current and used namespaces.
    ($currentNamespace, @usedNamespaces) = _scanSource($fileName);

    # Get corresponding namespace of current namespace.
    $mappedCurrentNamespace =
      _mapToGrpSpecificationNamespace($self->{hrefComponentNamespaceKey},
        $currentNamespace);

    if (scalar @usedNamespaces > 0) {

      # Get corresponding namespaces of used namespaces.
      @mappedUsedNamespaces =
        _mapToGrpSpecificationNamespace($self->{hrefComponentNamespaceKey},
          @usedNamespaces);

      # Check if corresponding namespaces for current and used namespaces found.
      if (scalar @mappedUsedNamespaces > 0) {

        # Check guide lines.
        $validAccess = _checkRules($fileName, $self->{hrefComponentRule},
          $self->{hrefComponentGrpMap}, $self->{hrefExceptionMap},
          $self->{arefErrMessages}, $mappedCurrentNamespace,
          @mappedUsedNamespaces);
      }

      # Used namespaces are not defined in group specification file which is
      # valid.
      else {
        $validAccess = 1;
      }
    }

    # If file do not contain used namespaces.
    else {
      $validAccess = 1;
    }
  }

  # If file is not cpp, hpp, or idl then log error message.
  else {
    $currentTime = getTime();
    push(@{$self->{arefErrMessages}}, "$currentTime ERROR $fileName not a ".
        "valid file. File name should be .idl/.c/.cpp/.h/.hpp\n");
  }
  return $validAccess;
}

=item printErrorMessages()

 This sub-routine prints the error messages.

=cut
sub printErrorMessages
{
  my $self = shift;
  if (@{$self->{arefErrMessages}}) {
    foreach my $errMsg (@{$self->{arefErrMessages}}) {
      print($errMsg);
    }
  }
}

=item checkUnneededExceptions()

 This sub-routine checks if there are any unnecessary exceptions mentioned for
 the file name passed to it.
 @param fileName - name of the file for which unnecessary exceptions are
 searched.
 @return 1 - if the file contains unneeded exceptions.
 @return 0 - otherwise.

=cut
sub checkUnneededExceptions
{
  my $self = shift;
  my $fileName = shift;
  my $unneededExpPresent = 0;

  if (exists $self->{hrefExceptionMap}->{$fileName}) {
    undef @{$self->{arefErrMessages}};

    # Check in hash of exceptions that all exceptions are encountered or not.
    foreach my $exceptionStr (keys %{$self->{hrefExceptionMap}->{$fileName} }) {
      if ($self->{hrefExceptionMap}->{$fileName}->{"$exceptionStr"} == 0) {
        push(@{$self->{arefErrMessages}}, "$exceptionStr\n");
        $unneededExpPresent = 1;
      }
    }
  }
  return $unneededExpPresent;
}

=item isPathExcluded()

 This sub-routine checks if the directory path of the object contains any path
 mentioned in the list of excluded paths.
 @return 1 - if the object's directory path contains excluded path.
 @return 0 - otherwise.

=cut
sub isPathExcluded
{
  my $self = shift;

  my $excludePath = 0;
  my $hkeyPath = q(Exclude path);

  if (exists $self->{hrefExceptionMap}->{$hkeyPath}) {

    # Check whether object's directory is present in list of excluded paths.
    LOOP_FOREACH_EXCLUDE_PATH:
    foreach my $path (keys %{$self->{hrefExceptionMap}->{$hkeyPath}}) {
      if ($self->{dir} =~ $path) {
        $excludePath = 1;
        last LOOP_FOREACH_EXCLUDE_PATH;
      }
    }
  }
  return $excludePath;
}

=item isCheckingDisabled()

 This sub-routine checks whether value of disableChecking attribute of the group
 corresponding to the namespace passed to it is set to true.
 @return 0 - if disableChecking attribute of the group is either not specified
 or set to false.
 @return 1 - if disableChecking attribute of the group is set to true.

=cut
sub isCheckingDisabled
{
  my $self = shift;
  my $namespace = shift;
  my $flag = 0;
  my $namespaceInGrpFile;

  # Get corresponding namespace in group specification file.
  $namespaceInGrpFile =
    _mapToGrpSpecificationNamespace($self->{hrefComponentNamespaceKey},
        $namespace);

  if (defined $namespaceInGrpFile) {

    # Get corresponding group from group specification file.
    my $grpName = $self->{hrefComponentGrpMap}->{$namespaceInGrpFile};

    # Check if disableChecking is true for this group.
    if ($self->{hrefComponentRule}->{$grpName}[3] eq "true") {
      $flag = 1;
    }
  }
  return $flag;
}

# This sub-routine accepts an array of namespaces (or a namespace) and
# returns their corresponding namespaces from group specification file. This is
# internal sub-routine. It should not be called from outside of this module.
# @param namespacesArr - one or more namespaces that should be mapped to
# namespaces in group specification file.
# @return namespaceInGrpFile - array of mapped namespaces.
sub _mapToGrpSpecificationNamespace
{
  my ($hrefNamespaceKey, @namespacesArr) = @_;
  my $startToken;
  my $flagNamespaceFound;
  my $currentTime;

  # This array will contain corresponding namespaces in group specification
  # file.
  my @namespaceInGrpFile;
  my %hNamespaceInGrpFile;

  # Loop over each namespace.
  foreach my $namespaceInArr (@namespacesArr) {

    # If the namespace contains "_", replace it with "::"
    $namespaceInArr =~ s/_/::/g;

    # Extract first/starting word of the namespace.
    if ($namespaceInArr =~ m/^(\w+)/) {
      $startToken = $1;

      # Initialize the flag to 0.
      $flagNamespaceFound = 0;

      # Loop over each key (i.e. starting word of namespace that is stored while
      # parsing group specification file) to check that if it matches to first
      # token
      LOOP_USEDNAMESPACE:
      foreach my $namespace (@{$hrefNamespaceKey->{$startToken}}) {

        # Check that namespaces starting with the key match with the beginning
        # of the namespaces passed as parameter to the sub-routine.
        if ($namespaceInArr =~ m/^$namespace(:|)/) {

          # Set the flag to 1 as match is found.
          $flagNamespaceFound = 1;

          # Store the namespace from group specification file as a hash key and
          # break the loop.
          $hNamespaceInGrpFile{"$namespace"} = 1;
          last LOOP_USEDNAMESPACE;
        }
      }
    }
    else {
      # Code flow is not expected to reach here as after the namespace is
      # scanned, if it is prefixed with "::", then the prefix is removed.
      $currentTime = getTime();
      print("$currentTime ERROR Namespace $namespaceInArr do not ".
            "start with word\n");
    }
  }

  # Store namespaces in an array.
  @namespaceInGrpFile = keys(%hNamespaceInGrpFile);

  # If array contains only one namespace, return it as scalar else return the
  # array.
  if (scalar @namespaceInGrpFile == 1) {
    return $namespaceInGrpFile[$#namespaceInGrpFile];
  }
  elsif(@namespaceInGrpFile) {
    return (@namespaceInGrpFile);
  }
  return;
}

# This sub-routine scans an idl file to find current and used namespaces. This is
# internal sub-routine. It should not be called from outside of this module.
sub _scanIdl
{
  my $idlFileName = shift;

  my $line;
  my $currentNamespace;
  my @usedNamespaceLines;
  my %hUsedNamespaces;

  # Open idl file.
  open(my $idlFileHandle, $idlFileName)or croak "$idlFileName: $!";

  # Loop while there are more lines.
  while (<$idlFileHandle>) {

    # Assign the line to a variable.
    $line = $_;

    # Check if line contains start of multiline comment. i.e. should not start
    # with /*
    if ($line =~ m/^\s*\/\*/) {

      # Read all lines unless there is end of multiline comment. i.e. */
      while (defined($line = <$idlFileHandle>) && ($line !~ m/\*\//)) {

        # Do nothing.
      }
    }

    # Line should not be single line comment. i.e. should not start with //
    elsif ($line !~ m{^\s*\/\/}) {

      # Find "module" keyword in a line to determine current namespace.
      if ($line =~ m/\s*module\s*(.*?)\s*\{\s*$/) {
        $currentNamespace .= $1.'::';
      }

      # Find "interface" keyword in a line to determine used namespaces.
      elsif ($line =~ m/^\s*interface\s+.*/) {
        chomp($line);
        push(@usedNamespaceLines, $line);

        # Used namespace may be spanned over multiple lines, so scan such lines
        # upto semicolon or opening brace and store these lines in an array.
        while ($usedNamespaceLines[-1] !~ m/[;|\{]/) {
          $line = <$idlFileHandle>;
          chomp($line);
          $usedNamespaceLines[-1] .= $line;
        }
      }
    }
  }

  # Close idl file.
  close($idlFileHandle);

  # Remove "::" at the end of the current namespace.
  if (defined $currentNamespace) {
    $currentNamespace =~ s/::\s*$//;
  }

  # Extract used namespaces.
  foreach my $namespace (@usedNamespaceLines) {
    if($namespace =~ m/((\w*::)+\w+)/){
      $namespace = $1;

      # Remove trailing ::word as it is interface name.
      $namespace =~ s/(::\w+){1}$//;

      # If namespace contains :: at beginning, remove it.
      $namespace =~ s/^:://;

      # Store namespace as key of a hash so that repeated namespaces are
      # reported only once.
      $hUsedNamespaces{$namespace} = 1;
    }
  }

  # Store all key in an array and return it.
  my @usedNamespaces = keys(%hUsedNamespaces);
  return($currentNamespace, @usedNamespaces);
}

# This sub-routine scans a source (.c or .cpp) file to find current and used
# namespaces. This is internal sub-routine. It should not be called from outside
# of this module.
sub _scanSource
{
  my $sourceFileName = shift;

  my $line;
  my $currentNamespace;
  my $namespace;
  my %hUsedNamespaces;

  # Find current namespace from path of the file. Current namespace is hierarchy
  # between WORKSPACE and Main directory.
  $currentNamespace = $sourceFileName;
  if ($currentNamespace =~ m/workspace\/(.*)\/.*?$/) {
    $currentNamespace = $1;
    $currentNamespace =~ s/\//::/g;
  }

  # Scan source file to find used namespaces.
  open(my $sourceFileHandle, $sourceFileName)or croak("$sourceFileName: $!");

    while (<$sourceFileHandle>) {
      $line = $_;

      # Check if line contains start of multiline comment. i.e. should not start
      # with /*
      if ($line =~ m/^\s*\/\*/) {

        # Read all lines unless there is end of multiline comment. i.e. */
        while ((defined($line = <$sourceFileHandle>) && $line !~ m/\*\//)) {

          # Do nothing.
        }
      }
      # Line should not be single line comment. i.e. should not start with //
      elsif ($line !~ m{^\s*\/\/}) {

        # Extract "using namespace" to determine used namespaces.
        if ($line =~ m/^\s*using\s+(namespace|)\s*(.*)\s*;\s*$/) {
          $namespace = $+;

          # Remove starting ::xoc:: pattern.
          $namespace =~ s/^\s*:://;
          $namespace =~ s/^xoc//;
          $namespace =~ s/^(::|_)//;
          $namespace =~ s/\s+$//;

          # Check namespace length. If it's more than zero, add namespace to
          # array.
          if (length($namespace) > 0) {

            # Store namespace as key of a hash so that repeated namespaces are
            # reported only once.
            $hUsedNamespaces{$namespace} = 1;
          }
        }
      }
    }
  close($sourceFileHandle);

  # Store all key in an array and return it.
  my @usedNamespaces = keys(%hUsedNamespaces);
  return($currentNamespace, @usedNamespaces);
}

# This sub-routine scans a header (.h or .hpp) file to find current and used
# namespaces. This is internal sub-routine. It should not be called from outside
# of this module.
sub _scanHeader
{
  my $headerFileName = shift;
  my $line;
  my $currentNamespace;
  my $namespace;
  my $token;
  my %hUsedNamespaces;

  # Find current namespace from path of the file. Current namespace is hierarchy
  # between WORKSPACE and Main directory.
  $currentNamespace = $headerFileName;
  if ($currentNamespace =~ m/workspace\/(.*)\/.*?$/) {
    $currentNamespace = $1;
    $currentNamespace =~ s/\//::/g;
  }

  # Scan header file to find used namespaces
  open(my $headerFileHandle, $headerFileName)or croak("$headerFileName: $!");
  while(<$headerFileHandle>) {
    $line = $_;

    # Check if line contains start of multiline comment. i.e. should not start
    # with /*
    if ($line =~ m/^\s*\/\*/) {

      # Read all lines unless there is end of multiline comment. i.e. */
      while (defined($line = <$headerFileHandle>) && ($line !~ m/\*\//)) {

        # Do nothing
      }
    }
    # Line should not be single line comment. i.e. should not start with //
    elsif ($line !~ m{^\s*\/\/}) {

      # Extract "using namespace" to determine used namespaces.
      if ($line =~ m/^\s*using\s+(namespace|)\s*(.*)\s*;\s*$/) {
        $namespace = $+;
        $namespace =~ s/^\s*:://;
        $namespace =~ s/^xoc//;
        $namespace =~ s/^(::|_)//;
        $namespace =~ s/\s+$//;
        if (length($namespace) > 0) {
          # Store namespace as key of a hash so that repeated namespaces are
          # reported only once.
          $hUsedNamespaces{$namespace} = 1;
        }
      }

      # Extract "optional word :: word" pattern to determine used namespaces.
      elsif ($line =~ m/.*?((\w*::\w+)+)/) {
        chomp($line);
        my @namespaceArray = ();

        # Extract each namespace that appears on a line. There can be more than
        # one namespace on a line.
        while ($line =~ m/.*?((\w*::\w+)+)/) {
          $token = $1;
          $line =~ s/$token//;

          # Remove trailing ::word pattern. It is interface name.
          $token =~ s/\s*(.*)::.*?$/$1/;

          # Remove starting ::xoc:: or xoc_ pattern.
          $token =~ s/^:://;
          $token =~ s/^xoc//;
          $token =~ s/^(::|_)//;

          # Check namespace length. If it's more than zero,
          # add namespace to array.
          if (length($token) > 0) {
            push(@namespaceArray, $token);
          }
        }

        # Store each namespace found on a line in the array.
        foreach $namespace (@namespaceArray) {
          # Store namespace as key of a hash so that repeated namespaces are
          # reported only once.
          $hUsedNamespaces{$namespace} = 1;
        }
      }
    }
  }
  close($headerFileHandle);

  # Store all keys in an array and return it.
  my @usedNamespaces = keys(%hUsedNamespaces);
  return($currentNamespace, @usedNamespaces);
}

# This sub-routine returns 1 if the namespace appears in contained namespaces or
# contained groups or used groups of a group. This sub-routine searches contained
# groups and used groups of a group recursively to check whether the namespace
# belongs to that group. If the namespace belongs to that group 1 is returned.
# In case of failure 0 is returned. This is internal sub-routine. It should not
# be called from outside of this module.
# @param hrefRules - reference to the hash containing groups.
# @param currentGroupName - this group will be searched for used namespace.
# @param usedNamespaces - used namespace.
# @return validAccess - 0 - namespace not found; 1 - namespace found.
sub _checkNamespaceGroup
{
  my $hrefRules = shift;
  my $currentGroupName = shift;
  my $usedNamespace = shift;
  my $validAccess = 0;

  # Check contained namespaces of current group.
  LOOP_CONTAINEDNAMESPACE:
  foreach my $containedNamespace (@{ $hrefRules->{$currentGroupName}[1] }) {
    if ($usedNamespace eq $containedNamespace) {
      $validAccess = 1;
      last LOOP_CONTAINEDNAMESPACE;
    }
  }

  # Check contained groups recursively.
  if ($validAccess == 0) {
    LOOP_CONTAINEDGROUP:
    foreach my $containedGroup (@{ $hrefRules->{$currentGroupName}[0] }) {
      $validAccess = _checkNamespaceGroup($hrefRules, $containedGroup,
                                          $usedNamespace);
      if ($validAccess == 1) {
        last LOOP_CONTAINEDGROUP;
      }
    }
  }

  # Check used groups recursively
  if ($validAccess == 0) {
    LOOP_USEDGROUP:
    foreach my $usedGroup (@{ $hrefRules->{$currentGroupName}[2]}) {
      $validAccess = _checkNamespaceGroup($hrefRules, $usedGroup, $usedNamespace);
      if ($validAccess == 1) {
        last LOOP_USEDGROUP;
      }
    }
  }
  return $validAccess;
}

# This sub-routine checks whether group specification rules are followed or not.
# This is internal sub-routine. It should not be called from outside of this
# module.
# @param fileName - name of the file.
# @param hrefRules - hash reference containing used group reference
# @hrefGrpMap - hash reference containing map of namespace to group.
# @hrefException - hash reference containing array reference of exceptions.
# @arefErrMessages - array reference pointing to array of error messages.
# @currentNamespace - namespace for which guide lines are checked.
# @return accessValidity - 1 - valid access, otherwise 0.
sub _checkRules
{
  my $fileName = shift;
  my $hrefRules = shift;
  my $hrefGrpMap = shift;
  my $hrefException = shift;
  my $arefErrMessages = shift;
  my $currentNamespace = shift;
  my @usedNamespaces = @_;
  my $validAccess;
  my $currentGroup;
  my $usedGroup;
  my $grpOfUsedNamespace;
  my $currentTime;
  my $errMessage;

  # This variable is returned by this sub-routine. It is initialized to 1
  # i.e. valid access. If it is found that current namespace is accessing used
  # namespace that is not allowed by access rules in group specifications, this
  # variable is set to 0.
  my $accessValidity = 1;

  # Check that group for namespace exists.
  if (not exists $hrefGrpMap->{$currentNamespace}) {
    $errMessage = "Group specification file do not contain group for namespace".
                  " $currentNamespace";

    # Check in hash of exceptions that error message is mentioned there.
    foreach my $exceptionStr (keys %{ $hrefException->{$fileName} }) {
      if ($errMessage eq $exceptionStr) {
        $accessValidity = 1;
        $hrefException->{$fileName}->{"$exceptionStr"} = 1;
        return $accessValidity;
      }
    }
    $currentTime = getTime();
    push(@{$arefErrMessages}, "$currentTime WARNING $errMessage\n");
    $accessValidity = 0;
    return $accessValidity;
  }

  # Get group name of current namespace.
  $currentGroup = $hrefGrpMap->{$currentNamespace};
  chomp($currentGroup);

  # Iterate over each used namespace.
  LOOP_USEDNAMESPACES:
  foreach my $usedNamespace (@usedNamespaces) {
    $validAccess = 0;

    # Check that group for namespace exists.
    if (not exists $hrefGrpMap->{$usedNamespace}) {
      $errMessage = "Group specification file do not contain group for ".
                    "namespace $usedNamespace";

      # Check in hash of exceptions that error message is mentioned there.
      foreach my $exceptionStr (keys %{ $hrefException->{$fileName} }) {
        if ($errMessage eq $exceptionStr) {
          $hrefException->{$fileName}->{"$exceptionStr"} = 1;
          next LOOP_USEDNAMESPACES;
        }
      }
      $currentTime = getTime();
      push(@{$arefErrMessages}, "$currentTime WARNING $errMessage\n");
      $accessValidity = 0;
      next LOOP_USEDNAMESPACES;
    }

    $usedGroup = $hrefGrpMap->{$usedNamespace};

    # Check if disableCheck attribute is set to true for used group.
    # If disableCheck is true then that group is allowed to be used by
    # anyother namespace.
    if ($hrefRules->{$usedGroup}[3] eq "true") {
      $validAccess = 1;
    }

    # Check if current namespace is equal to used namespace.
    if ($validAccess == 0) {
      if ($currentNamespace eq $usedNamespace) {
        $validAccess = 1;
      }
    }

    # If current namespace is not equal to used namespace, then check current
    # groups contained namespaces, contained groups, used groups for used
    # namespace.
    if ($validAccess == 0) {
      $validAccess = _checkNamespaceGroup($hrefRules, $currentGroup,
                                           $usedNamespace);
    }

    # If used namespace is not found in current group,
    # find parent's used groups.
    if ($validAccess == 0) {
      my $scval = scalar (@{$hrefRules->{$currentGroup}});

      # Check that the array for current group contains 5 elements.
      # i.e. check if current group has parent group.
      if (scalar (@{ $hrefRules->{$currentGroup} }) == 5) {

        # Get parent group's name.
        my $parentOfCurrentGroup = $hrefRules->{$currentGroup}[4];

        # Check while there is parent group for current group.
        LOOP_WHILEPARENT:
        while (defined $parentOfCurrentGroup) {

          # Check each used group of parent group.
          foreach my $usedGrpOfParent
            (@{ $hrefRules->{$parentOfCurrentGroup}[2] }) {
            $validAccess = _checkNamespaceGroup($hrefRules, $usedGrpOfParent,
                                                $usedNamespace);
            if ($validAccess == 1) {
              last LOOP_WHILEPARENT;
            }
          }

          # Check if parent group has parent.
          if (scalar (@{$hrefRules->{$parentOfCurrentGroup}}) == 5) {
            $parentOfCurrentGroup = $hrefRules->{$parentOfCurrentGroup}[4];
          }
          else {
            undef $parentOfCurrentGroup;
          }
        }
      }
    }

    # Print error message.
    $errMessage = "$currentGroup($currentNamespace) is not allowed to access".
                  " $usedGroup($usedNamespace)";

    # Check in array of exceptions that error message is mentioned there.
    foreach my $exceptionStr (keys %{ $hrefException->{$fileName} }) {
      if ($errMessage eq $exceptionStr) {
        $validAccess = 1;
        $hrefException->{$fileName}->{"$exceptionStr"} = 1;
      }
    }
    if($validAccess == 0) {
      $currentTime = getTime();
      push(@{$arefErrMessages}, "$currentTime ERROR $errMessage\n");
      $accessValidity = 0;
    }
  }# End for each used namespace of current namespace.
  return $accessValidity;
}

# This sub-routine returns current local time.
# This is internal sub-routine. It should not be called from outside of this
# module.
# @return nowTime - current local time.
sub getTime
{
  # Assign path of get_time.sh file to a variable.
  my $getCurTime = $ENV{WORKSPACE}.q(/CMF-tools/quality_assurance/).
    q(dependency_check/lbin/tools/get_time.sh);
  my $nowTime = qx/$getCurTime/;
  chomp($nowTime);
  return $nowTime;
}

1;

=back

=head1 AUTHOR

 PSL

=cut
