#!/bin/bash

shopt -s extglob

. /bstd_tools/contrib/lib/TIME_FUNCTIONS

CURRENT_TIME="$(time_get_date [  ])"
echo $CURRENT_TIME
