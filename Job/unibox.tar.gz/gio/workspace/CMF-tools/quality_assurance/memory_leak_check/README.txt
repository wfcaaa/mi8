
Automated Valgrind Tests : README (v0.2)

Index

1. General overview
2. How to use the utility
3. Implementation details
4. Notes


1. General overview

   The Do_MemoryLeakCheck_test.sh script is used to perform memory leak
   checks for all Zenith components and report the results to the user.
   The checking is performed using the valgrind tool which is integrated
   in the Zenith component test framework.

2. How to use the utility

   To use the utility, simply execute the Do_MemoryLeakCheck_test.sh
   located at:
   $WORKSPACE/CMF-tools/quality_assurance/memory_leak_check/lbin

   Usage: Do_MemoryLeakCheck_test.sh [OPTION]

   OPTION:
   -h, --help          Print usage of the utility.


   2.1. The script can be executed from any directory after having set a
        Clearcase view.
   2.2. The activity log and the report of the memory check report can
        be located under
        measured_results/MemoryLeakCheckResult_<baseline>_<date +%Y%m%d>:
        Activity log       : ActivityReport.log
        Memory Check report: MemoryLeakCheckResult_<baseline>_<date +%Y%m%d>.html


3. Implementation details

   The utility is implemented as a KSH script. It performs the following
   steps:
   3.1. Remove all existing log.vgrind.* files
   3.2. Perform clobber at WORKSPACE level
   3.3. Perform a debug build at WORKSPACE level
   3.4. Set the environment to use valgrind (export XOC_PROGRAM_CHECKER=vg)
   3.5. Execute all the test components in the WORKSPACE using texec
   3.6. Analyze generated log.vgrind.* files to extract statistics of
        memory related issues.
   3.7. Generate a report containing the statistics of the memory related
        issues.
   3.8. All new log.valgrind.* files are copied to the measured_results
        directory.

   The directory structure for this tool is as follows:
      memory_leak_check/
       |
       +--lbin/
       |   |
       |   +--Do_MemoryLeakCheck_test.sh
       |   
       +--measured_results/
           |
           +--MemoryLeakCheckResult_<baseline>_<date +%Y%m%d>/
                |
                +--ActivityReport.log
                +--MemoryLeakCheckResult_<baseline>_<date +%Y%m%d>.html
                +--Valgrind log files

4. Notes

   4.1. When the script is started, it will remove all existing log.vgrind.*
        files present in the workspace.
   4.2. The script performs memory leak checks for the entire workspace only.
        Individual components are not yet supported.

