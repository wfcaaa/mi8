#!/bin/bash

#
#   To use the utility, simply execute the Do_MemoryLeakCheck_test.sh
#   located at:
#     $WORKSPACE/CMF-tools/quality_assurance/memory_leak_check/lbin
#
#   Usage: Do_MemoryLeakCheck_test.sh [OPTION]
#
#   OPTION:
#   -h, --help          Print usage of the utility.
#
#   1. The script can be executed from any directory after having set a
#      Clearcase view.
#
#   2. The activity log and the report of the memory check report can
#      be located under
#      measured_results/MemoryLeakCheckResult_<baseline>_<date +%Y%m%d>:
#      Activity log       : ActivityReport.log
#      Memory Check report: MemoryLeakCheckResult_<baseline>_<date +%Y%m%d>.html
#
#  WARNING: The script removes any existing log.vgrind.* files in the
#           workspace.
#

shopt -s extglob

. /bstd_tools/contrib/lib/TIME_FUNCTIONS


logMessage()
{
    # $1 => Message to be dumped along with timestamp
    # $2 => File to which the message should be dumped (appended)

    echo $(time_get_date [ STANDARD_DATE_FORMAT ])" : "$1 >> $2
    echo $1
}


printReportHeader()
{
    # $1 => Path of the report
    # $2 => View name

    echo "<html>" > $1
    echo "<h2 align=center>Valgrind Analysis report for "$2"</h2>" >> $1
    echo "<br>" >> $1
    echo "Please note that this report can be best viewed only in Mozilla Firefox." >> $1
    echo "<hr>" >> $1
    echo "<h3>Summary</h3>" >> $1
    echo "__REPLACE_WITH_SUMMARY__" >> $1
    echo "<hr>" >> $1
    echo "<h3>Details</h3>" >> $1
    echo "<table border=2 cellspacing=0 align=center width=80%>" >> $1
    echo "<tr>" >> $1
    echo "<th>Sr. Nr.</th>" >> $1
    echo "<th>Test Component</th>" >> $1
    echo "<th>Memory related Issues</th>" >> $1
    echo "</tr>" >> $1
}


analyzeLog()
{
    # $1 => Serial number of the component
    # $2 => Path of the report
    # $3 => Path of the valgrind log file
    # $4 => Component name

    # Check if the file can be opened for reading
    test -r $3
    if [ $? -eq 0 ]
    then
        totalErrorTypes=0
        errCount=0
        errorInfo=""

        i=0
        while [ $i -lt ${#vgErrorList[*]} ]
        do
            errCount=`grep -c -e "<kind>"${vgErrorList[$i]}"</kind>" $3`
            if [ $errCount -ne "0" ]; then
                errorInfo="$errorInfo <tr><td width=80%>${vgErrorList[$i]}</td><td bgcolor=#FF6666>$errCount</td></tr>"
                totalErrorTypes=`expr $totalErrorTypes + 1`
                errSum[$i]=`expr ${errSum[$i]} + $errCount`
            fi
            ((i=i+1))
        done

        # Search separately for Leak_PossiblyLost
        errCount=`grep -c -e "<kind>Leak_PossiblyLost</kind>" $3`
        if [ $errCount -ne "0" ]; then
            errorInfo="$errorInfo <tr><td width=80%>Leak_PossiblyLost</td><td>$errCount</td></tr>"
            totalErrorTypes=`expr $totalErrorTypes + 1`
            errSum[14]=`expr ${errSum[14]} + $errCount`
        fi

        # Replace / with _ and append extension as .xml
        vgLogPath=`echo $3 | sed 's/\//_/g' | sed 's/\..*/.xml/'`
        /bin/cp $3 $logDir/$vgLogPath

        # Add component name in xml file.
        sed -i -e "s,<valgrindoutput>,&<ComponentName>$4</ComponentName>," $logDir/$vgLogPath 2>/dev/null

        if [ $totalErrorTypes -ne 0 ]
        then
            errorInfo="<tr><td bgcolor=#FF6666>$1</td><td><a href=$showLog_htm?valgrindFile=$vgLogPath>$4</a><br/><a href=$vgLogPath>XML View</a></td><td><table width=100% border=1 cellspacing=0>$errorInfo</table></td></tr>"
        else
            errorInfo="<tr><td bgcolor=#00FF00>$1</td><td>$4<br/><a href=$vgLogPath>XML View</a></td><td colspan=15>No errors found</td></tr>"
        fi
    else
        errorInfo="<tr><td bgcolor=#FFFF00>$1</td><td><a href=$3>$4</a></td><td colspan=15>Valgrind log file is not readable</td></tr>"
    fi
    echo $errorInfo >> $2
}


printReportFooter()
{
    # $1 => Path of the report

    echo "</table>" >> $1
    echo "</html>" >> $1
}


printSummary()
{
    # $1 => Path of the report

    summaryTxt="<table\\ border=2\\ cellspacing=0\\ align=center\\ width=80%>"
    summaryTxt="${summaryTxt}""<tr><td>Total\\ number\\ of\\ components<\\/td><td>$compNum<\\/td><\\/tr>"
    i=0
    while [ $i -lt ${#vgErrorList[*]} ]
    do
        summaryTxt="${summaryTxt}""<tr><td>Total\\ occurrences\\ of\\ ${vgErrorList[$i]}<\\/td><td>${errSum[$i]}<\\/td><\\/tr>"
        ((i=i+1))
    done
    summaryTxt="${summaryTxt}""<tr><td>Total\\ occurrences\\ of\\ Leak_PossiblyLost<\\/td><td>${errSum[14]}<\\/td><\\/tr>"
    summaryTxt="${summaryTxt}""<\\/table><br>"
    sed -e "s/__REPLACE_WITH_SUMMARY__/${summaryTxt}/g" $1 > $1.tmp
    mv $1.tmp $1
}

printUsage()
{
  if [ $# -eq 1 ]
  then
    case $1 in
      -h|--help) echo "Usage: Do_MemoryLeakCheck_test.sh [OPTION]"
              echo "Automated Test Valgrind Analysis"
              echo ""
              echo "This utility executes all the Zenith test components and reports results of
memory leak analysis performed using valgrind."
              echo ""
              echo "OPTION:"
              echo "  -h, --help          Print usage of the utility"
              echo "";;
      *) echo "Illegal argument : Type $WORKSPACE/CMF-tools/quality_assurance/code_coverage/lbin/Do_MemoryLeakCheck_test.sh --help for usage";;
    esac
  else
    echo "Illegal arguments : Type $WORKSPACE/CMF-tools/quality_assurance/code_coverage/lbin/Do_MemoryLeakCheck_test.sh --help for usage"
  fi
}


doExit()
{
    exit $1
}


# Check for proper arguments
if [ $# -ne 0 ]
then
    printUsage $*
    doExit $exitNotExecuted
fi

# Initialize required variables and constants
viewName=`basename $CLEARCASE_ROOT`
vgConfig=""
zCompTest="z_comp_test.ksh"
vgLogPrefix=$(date "+vglog_%Y%m%d_%H%M%S_pid_")
vgLogFilter="*.vgrind.xml"

texecPath="/bstd_tools/contrib/lbin/texec"
toolDir="$WORKSPACE/CMF-tools/quality_assurance/memory_leak_check"
excludeComponents="-e /services/session/SessionMode -e /services/configsystem/ConfigSystem -e /services/dependencydb/DependencyDb -e /examples/"
showLog_htm="ShowLog.htm"
cmdStatus=0
exitPassed=0
exitFail=1
exitCrash=2
exitNotExecuted=3

# Initialize array of valgrind error types and counters for each.
vgErrorList=( InvalidFree MismatchedFree InvalidRead InvalidWrite InvalidJump Overlap InvalidMemPool UninitCondition UninitValue SyscallParam ClientCheck Leak_DefinitelyLost Leak_IndirectlyLost Leak_StillReachable )
errSum=( 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 )

# Generate necessary file names
baseline=`cleartool catcs | grep -m 1 -A 1 mkbranch  | tail -1 | cut -d" " -f4`
currentDate=`date +%Y%m%d`
logName="MemoryLeakCheckResult_"$baseline"_"$currentDate
logDir="$toolDir/measured_results/$logName"
logFilePath="$logDir/ActivityReport.log"
reportPath="$logDir/$logName.html"

# Save the current working directory
oldWorkingDir=`pwd`

# Remove existing log directory and create the new log directory
rm -rf $logDir
mkdir -p $logDir

logMessage "Automated valgrind analysis for view : "$viewName $logFilePath
logMessage "Log file location : "$logFilePath $logFilePath
logMessage "Starting automated valgrind analysis ..." $logFilePath

# Cleanup all existing log.vgrind.* files
logMessage "Removing existing valgrind reports ..." $logFilePath

# Get the list of all test components
testCompList=`find -L $WORKSPACE -type f -name $zCompTest -exec dirname '{}' \; 2> /dev/null | grep -v "/ucomp/" | grep --invert-match $excludeComponents`

for vglogFileDir in $testCompList
do
    vgLogFiles=`/bin/ls $vglogFileDir/$vgLogFilter 2> /dev/null`
    if [ "$vgLogFiles" != "" ]
    then
        /bin/rm -f $vgLogFiles 2> /dev/null
        if [ $? -ne 0 ]
        then
            logMessage "ERROR: Error while deleting valgrind logs under $vglogFileDir" $logFilePath
            doExit $exitFail
        fi
    fi
done

# Build the workspace and instrument the code for valgrind analysis
logMessage "Compiling workspace ..." $logFilePath
cd $WORKSPACE
export XOC_PROGRAM_CHECKER=vg

# Zenith debug build
zbd -c
zbd

cmdStatus=`echo $?`
if [ $cmdStatus -ne 0 ]
then
    logMessage "ERROR: Compilation failed." $logFilePath
    doExit $exitNotExecuted
else
    logMessage "Compilation succeeded." $logFilePath
fi

# Execution of test of all Zenith components
export SM_STARTER_PRE_ARGS_VALGRIND="--xml=yes --xml-file=../${vgLogPrefix}%p.vgrind.xml"
logMessage "Running texec ..." $logFilePath
$texecPath
logMessage "texec completed" $logFilePath

# If execution was not successful , we exit
cmdStatus=`echo $?`
if [ $cmdStatus -eq $exitNotExecuted ]
then
    doExit $exitNotExecuted
fi

# Start report generation
logMessage "Generating valgrind analysis report ..." $logFilePath

# Copy ShowLog.htm and valgrind.xsl in log directory.
/bin/cp $toolDir/lbin/tools/$showLog_htm $logDir
/bin/cp $toolDir/lbin/tools/valgrind.xsl $logDir

printReportHeader $reportPath $viewName
compNum=0
for vglogFileDir in $testCompList
do
    vglogFile=`/bin/ls --sort=time $vglogFileDir/$vgLogFilter 2> /dev/null | head -1`
    if [ "$vglogFile" = "" ]
    then
        logMessage "No valgrind log in "$vglogFileDir $logFilePath
    else
        compNum=`expr $compNum + 1`
        logMessage "Analyzing "$vglogFile $logFilePath
        analyzeLog $compNum $reportPath $vglogFile $vglogFileDir
    fi
done
printReportFooter $reportPath

# Add the summary obtained from the analysis
printSummary $reportPath

# Give read permissions to all for the log directory.
chmod -R +r $logDir

logMessage "Valgrind analysis report generation completed." $logFilePath
logMessage "Automated valgrind analysis completed." $logFilePath
logMessage "Valgrind Analysis log file location : "$logFilePath $logFilePath
logMessage "Valgrind Analysis report location : "$reportPath $logFilePath

# Open the browser to display the report
mozilla $reportPath 2> /dev/null &

# Restore the saved working directory
cd $oldWorkingDir

doExit $exitPassed
