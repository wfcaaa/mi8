#!/opt/ruby-1.8.7/bin/ruby
#!/usr/bin/env zruby
#
#-rdebug
#
# == Overview
#
# RubyTestFramework is implemented for Integration Test Frameworks
#
# Author::    Zhiwei Xu, 03.09.2012
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#
# = Usage
#   Precondition: Call this script from $XOC_SYSTEM/bin/run
#   It will reuse smartest instance if possible or shutdown/start smartest
#   and execute ruby unit tests located at ENV['ZTF_RUBY_TEST_CASES_DIR']
#
#   An integration test should export following variables
#     ZTF_TEST_MODE or ZTF_INTEG_TEST_MODE:  online, offline
#     ZTF_OFFLINE_MODEL_FILE: fullpath of the model file used for the test
#

$VERBOSE=nil
STDOUT.sync = true
STDERR.sync = true

require "timeout"
require "#{File.dirname(__FILE__)}/integtestframework"

class RubyTestFramework < ZTF::IntegTestFramework::IntegTestImpl
  include SystemUtil
  STANDARD_OFFLINE_MODEL_FILE="#{ENV['WORKSPACE']}/integtests/models/model_ps1066_standard"

  def initialize
    init_basic_variables
    process_arguments
    set_validate_variables
    super(@test_dir,@model_file,@offline_mode,@reuse_smartest,@quick_mode)
  end

  def print_usage
    ZTF::LOG.puts %Q{Executing a ruby integration test.
Usage: z_integ_test.ksh [options]
  [ on | online / offline | of ]    Optional, specify the hardware state
  [ -b <board_name> ]               Optional, the board to be used in ONLINE mode, e.g. -b ps1066
  [ -kill_smartest_after | -ksa ]   Optional, Kill SmarTest after test execution
  [ /path/of/target/model/file ]    Optional, test will execute with given model file
  [ -log=STRING ]                   Optional, set the log level [debug info warn error fatal]
  [ -help | -h ]                    Optional, print Help
  [ -version ]                      Optional, print version
  [ -q | -quick_mode ]              Optional, skip most checks before executing tests, except preparation of TestBed

Notes:
1. If the script is executed without any argument, then by default it sets:
   - If only one test mode is set in ZTF_TEST_MODE, that value will be taken
   - Otherwise, offline is taken.
2. If a model file is given, the test will be executed with the given model file.
   Model files will be ignored in online mode.
3. If the environment variable ZTF_REUSE_SMARTEST is set to 'FALSE',
   the test will not re-use existing SmarTest instance.
4. If the environment variable XOC_TEST_ONLY is set, e.g. ':TestSuite.testA:TestSuite.testB:',
   only listed test cases will be executed. This feature only works with a fresh startup of SmarTest.
5. If the environment variable XOC_PRODUCT_EDITION is set, SmarTest will start with the specified edition.}
  end

  def print_header
    @version="1.4.0"
    ZTF::LOG.puts %Q{
*****************************************
*    Ruby Integration Test Framework    *
*            Version #{@version}              *
*****************************************
}
    ZTF::LOG.puts "Running Integration test in '#{@test_dir}'" if @test_dir
  end

  # Here by default it is set to 10 minutes if ZTF_TEST_TIMEOUT is not set.
  def max_exec_time
    t = ENV.fetch("ZTF_TEST_TIMEOUT","10").to_f
    t = 10 if t<0
    return t*60
  end

  def init_basic_variables
    if ENV['ZTF_TEST_MODE']!=nil and !ENV['ZTF_TEST_MODE'].strip.empty?()
      @test_mode=ENV['ZTF_TEST_MODE'].strip.downcase
    elsif ENV['ZTF_INTEG_TEST_MODE']!=nil and !ENV['ZTF_INTEG_TEST_MODE'].strip.empty?()
      @test_mode=ENV['ZTF_INTEG_TEST_MODE'].strip.downcase
    end
    @test_mode ||= "offline"
    @model_file = ENV['ZTF_OFFLINE_MODEL_FILE'] || STANDARD_OFFLINE_MODEL_FILE

    @reuse_smartest=true
    @reuse_smartest=false if ENV['ZTF_REUSE_SMARTEST'] and ENV['ZTF_REUSE_SMARTEST'].strip.downcase=="false"
    @max_exec_time = max_exec_time
    @board = nil # the board used in online mode
    @quick_mode = false
  end

  def process_arguments
    board_value_flag = false # use this flag to get value of "-b <board_name>"
    for argument in ARGV do
      arg = argument.downcase
      case
        when (arg == "offline" or arg == "of")
          if not defined?(@hardware_state)
            @hardware_state="offline"
          else
            ZTF::LOG.error "hardware mode is already set to #{@hardware_state}. It's not allowed to set it twice"
            print_usage()
            exit(1)
          end
        when (arg == "online" or arg == "on")
          if not defined?(@hardware_state)
            @hardware_state="online"
          else
            ZTF::LOG.error "hardware mode is already set to #{@hardware_state}. It's not allowed to set it twice"
            print_usage()
            exit(1)
          end
        when (arg == "-ksa" or arg == "-kill_smartest_after")
          ZTF::LOG.info "Smartest will shutdown automatically after test execution!"
          at_exit { kill_smartest_after() }
        when (arg =="-q" or arg == "-quick_mode")
          ZTF::LOG.info "Enabled quick mode, skip all checks for Smartest related steps"
          @quick_mode = true
        when (arg == "-info")
          # print out json format
          prod_edition = ENV['XOC_PRODUCT_EDITION'] || ''
          session_to_use = ENV['ZTF_START_SMARTEST'] || 'smartest'
          ZTF::LOG.puts %Q{ {\
"TEST_TYPE" : "INTEG_TEST",
"TEST_MODE" :  "#{@test_mode}",
"OFFLINE_MODEL_FILE" : "#{@model_file}",
"XOC_PRODUCT_EDITION" :  "#{prod_edition}",
"SESSION_TO_USE" : "#{session_to_use}",
"ZTF_REUSE_SMARTEST" : "#{@reuse_smartest}" } }
          exit(0)
        when (arg == "-version" or arg == "--version" or arg == "-ver" or arg == "--ver" or arg == "-v")
          print_header
          exit(0)
        when (arg == "-help" or arg == "--help" or arg == "-h" or arg == "--h")
          print_usage()
          exit(0)
        when (arg.index("-log=") == 0)
          level = arg.sub("-log=","").strip.upcase
          allowed_levels = ['DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL']
          if allowed_levels.include?(level)
            ZTF::LOG.level = ZTF::ZenithLogger.const_get(level)
          else
            ZTF::LOG.error "wrong log level given: #{argument}, only #{allowed_levels.join(" ")} are allowed!"
            print_usage()
            exit(1)
          end
        when (arg =~ /^-b/) # -b ps1066
          board_value_flag = true
        else
          if board_value_flag
            @board = argument
          else
            # we consider this arg is a model file
            file=argument
            file=File.join(Dir.getwd(),file) if file.index("/") != 0
            if File.readable?(file)
              @model_file = realpath(file)
            else
              ZTF::LOG.error "unknown argument '#{argument}'"
              print_usage()
              exit(1)
            end
          end
      end
    end
    ARGV.clear

    # if test_mode is only offline or online, then it is clear that the user
    # want to execute in that mode by default
    # if test_mode is only offline or online, then it is clear that the user
    # want to execute in that mode by default
    if not defined?(@hardware_state)
      if @test_mode.split(",").size == 1
        @hardware_state = @test_mode.strip
        ZTF::LOG.info "Assume hardware state='#{@hardware_state}', since it is not set."
      else
        @hardware_state="offline"
      end
    end
    # verify whether the target hardware state is consistent with the test mode
    if not @test_mode.include?(@hardware_state)
      ZTF::LOG.info "Test is ignored since the test mode='#{@test_mode}', however hardware state='#{@hardware_state}'."
      exit(0)
    end
    if @board and @hardware_state=="offline"
      ZTF::LOG.warn "parameter '-b #{@board}' is ignored because the test will run in #{@hardware_state} mode"
    end
  end

  #
  # set variables needed, and verify the correctness
  #
  # ZTF_TEST_MODE or ZTF_INTEG_TEST_MODE  "offline, online"
  # ZTF_OFFLINE_MODEL_FILE
  # ZTF_REUSE_SMARTEST  "FALSE"
  #
  def set_validate_variables
    if @hardware_state=="online"
      @offline_mode = false
    else
      @offline_mode = true
    end


    @test_dir=Dir.getwd

    # model file is only used in offline mode
    # multiple model_file is not allowed here, needs to support it!
    (ZTF::LOG.error "model file #{@model_file} is not readable!"; exit(1)) if @offline_mode and @model_file!="" and (not File.readable?(@model_file))

    raise TestConfigError, "ERROR: test case directory '#{ENV['ZTF_RUBY_TEST_CASES_DIR']}' doesn't exist.", caller unless File.directory?(ENV['ZTF_RUBY_TEST_CASES_DIR'])

    ENV['ZTF_QUICK_TEST_MODE'] = 'TRUE' if @quick_mode
  end

  def setup_world
    super
    @test_runner=File.join(ENV['ZTF_RUBY_TEST_CASES_DIR'],"rubyIntegTester.rb")
    raise TestConfigError, "ERROR: cannot find ruby test runner '#{@test_runner}'", caller unless File.exist?(@test_runner)
    print_header
  end

  def run_test
    # switch pwd to testbed before tests run, @testbed is defined in base class
    Dir.chdir(@testbed)
    ENV['PWD'] = @testbed
    if @offline_mode
      runtest_cmd="#{@test_runner} RUBY_INTEG_TEST TL_INTEG_ALL OFFLINE #{ZTF::LOG.level_to_s}"
    else
      runtest_cmd="#{@test_runner} RUBY_INTEG_TEST TL_INTEG_ALL ONLINE #{ZTF::LOG.level_to_s}"
    end

    begin
      Timeout::timeout(@maxExecTime) do
        @pipe = IO.popen(runtest_cmd+" 2>&1")
        @pipe.each { |line| puts line }
        @pipe.close
        @exit_value = $?.exitstatus
      end
    rescue Timeout::Error
      ZTF::LOG.puts ""
      ZTF::LOG.error "test execution exceeds time limit of #{@max_exec_time}s, force terminate the test!"
      Process.waitall
      @pipe.close unless @pipe.closed?
      @exit_value = ExitValue::KILLED # timeout is treated as a fatal instead of failure
    end
  end

  def kill_smartest_after()
    require "#{File.dirname(__FILE__)}/smartestutil"
    if ZTF.smartest_running?()
      ZTF::LOG.info "Shutting down SmarTest since argument '-kill_smartest_after' is given"
      ZTF.shutdown_smartest()
    end
  end

end

