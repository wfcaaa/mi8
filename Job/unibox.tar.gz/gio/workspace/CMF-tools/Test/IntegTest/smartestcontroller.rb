#
# = overview
#
# this file is a mimic of file startSmarTest.ksh
# It is used by integtestframework to handel the behavior of SmarTest
# * Methods require_smartest will guarantee that SmarTest with specified
#   configuration is ready for testing
# * Methods release_smartest MUST be called after test execution.
#
# Author::    Zhiwei Xu
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#
require "#{File.dirname(__FILE__)}/smartestutil"
internal_dir = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal")
require "#{internal_dir}/zenith_test_libs"

module ZTF
  class SmarTestController
    include SystemUtil, Execute
    SYSTEM_CALL_TIMEOUT = 600 #TODO: change to 5 mins
    #
    # = arguments
    # test_dir: the root directory of a integration test, it is an anchor for
    #           an integration test.
    #           It assumes that TestBed is located at <test_dir>/TestBed
    #
    def initialize(test_dir,model_file="",offline_mode=true,reuse_smartest=true)
      ZTF.envset?()
      raise TestConfigError, "ERROR: Test Directory \"#{test_dir}\" doesn't exist!", caller if not File.directory?(test_dir)

      @test_dir = test_dir || Dir.getwd()
      @testbed  = File.join(test_dir,"TestBed")
      @testbedtemplate= File.join(test_dir,"TestBedTemplate")
      @logdir   = File.join(@testbed,"log")
      @reuse_smartest = reuse_smartest
      @offline_mode   = offline_mode
      @model_file     = model_file || ""    # model file is empty string if not predefined

      if ENV['ZTF_RUN_BY_ART'] and ENV['ZTF_RUN_BY_ART'].upcase == "TRUE"
        @featbuild_mode = true
      else
        @featbuild_mode = false
      end
    end

    #
    # this method makes sure that smartest is ready for usage
    # It will control the behavior of smartest depending on configuratios
    # e.g. model file, reuse, etc.
    # = Note
    #   1. Call release_smartest after usage of smartest
    #   2. If env var ZTF_START_SMARTEST is defined, smartest will not
    def require_smartest
      if ENV['ZTF_START_SMARTEST']
        ZTF.shutdown_smartest if smartest_running?()
        # before we call the users script,
        # we ensure that session manager is available
        # since shutdown_smartest script may kill session manager.
        ZTF.start_sessionmanager()
        execute_command(ENV['ZTF_START_SMARTEST'], SYSTEM_CALL_TIMEOUT,@featbuild_mode)
      else
        get_smartest_instance()
      end
    end

    #
    # this method MUST be called after the usage of smartest.
    # It release the program previously started before quitting a test.
    # By default, it doesn't shutdown smartest
    # - unless force is set to true
    #
    def release_smartest(force=false)
      if ENV['ZTF_START_SMARTEST']
        if ENV['ZTF_KILL_SMARTEST']
          execute_command(ENV['ZTF_KILL_SMARTEST'], SYSTEM_CALL_TIMEOUT,@featbuild_mode)
          return $?.success?
        end
      elsif force # if this is true, we shutdown smartest
        ZTF.shutdown_smartest()
        @smartest_running=false
      end
      return true
    end

    ###=======================private block==========================##
    private
    # return true if smartest is running
    # @smartest_running is set as well!
    def smartest_running?
      @smartest_running=ZTF.smartest_running?
    end

    def shutdown_smartest?
      return false if not smartest_running?()
      if not @reuse_smartest
        ZTF::LOG.info "Need to shutdown SmarTest since reuse mode is disabled."
        return true
      end
      if not ZTF.same_product_edition?(ENV['XOC_PRODUCT_EDITION'])
        ZTF::LOG.info "Need to shutdown SmarTest since the target $XOC_PRODUCT_EDITION is different from the one current SmarTest used.";
        return true
      end
      # we only check the consistency of smartest session and target test mode
      # in interactive mode, for the sake of test efficiency
      unless @featbuild_mode
        smartest_offline_mode = ZTF_smartest_offline_mode?()
        if smartest_offline_mode != @offline_mode
          smartest_offline_mode_str = "online"
          smartest_offline_mode_str = "offline" if smartest_offline_mode
          target_mode_str = "online"
          target_mode_str = "offline" if @offline_mode
          ZTF::LOG.info "Need to shutdown SmarTest since SmarTest is in #{smartest_offline_mode_str} mode however target test mode is #{target_mode_str}!"
          return true
        end
=begin # TODO: enable this part
        if not smartest_offline_mode
          if @board # in online mode and user specify the board to execute
            current_board = ZTF.current_board_in_use
            if current_board != @board
              ZTF::LOG.info "Need to shutdown SmarTest since the target board #{@board} is different from the one current board #{current_board} used in SmarTest.";
              return true
            end
          end
        end
=end
      end
      if @offline_mode
        begin
          if @model_file==""
            @model_file = ZTF.get_model_file()
          else
            if not ZTF.same_model_file?(@model_file)
              ZTF::LOG.info "Need to shutdown SmarTest due to different model file will be used."
              return true
            end
          end
        rescue Exception => e
          ZTF::LOG.error exception2str(e,$DEBUG)
          ZTF::LOG.info "failed to check the consistency of target model file and the one SmarTest is using! Shutting down SmarTest now!"
          return true
        end
        return false
      end
    end

    def get_smartest_instance
      # do not start Eclipse UI during tests in FeatBuild mode
      ENV['XOC_EWC_OFF_FOR_TEST'] = "TRUE" if @featbuild_mode

      (ZTF.shutdown_smartest() ; @smartest_running=false) if shutdown_smartest?()
      if not @smartest_running
        prepare_system_dir()
        ZTF::LOG.info "Start Smartest with Eclipse UI because it is NOT in FeatBuild Mode" unless @featbuild_mode
        ZTF.start_smartest(@offline_mode,@model_file)
      else
        ZTF::LOG.info "Reusing current SmarTest instance"
      end
    end

    #
    # make sure $XOC_SYSTEM is prepared
    #
    def prepare_system_dir
      config_system_dir="#{ENV['XOC_SYSTEM']}/bin/run -Qx0"
      system(config_system_dir)
      if $?.exitstatus != 0
        raise TestRunTimeError, "ERROR: system error when executing 'run -Qx0', test terminate!", caller
      end
    end

  end
end
