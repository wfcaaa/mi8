#
# = overview
#
# It contains useful SmarTest relevant methods, e.g. get_product_edition
# * it can be required by other ruby files,
# * the methods can be executed directly in a shell as well,
#   e.g. `ruby smartestutil.rb -help` to see the available methods
#        `ruby smartestutil.rb start_sessionmanager` to start session manager
#        `ruby smartestutil.rb get_product_edition` to get current product edition
# * all methods are defined in module ZTF
#
# Author::    Zhiwei Xu
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#
require 'rexml/document'
require 'fileutils'
require 'set'

internal_dir = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal")
require "#{internal_dir}/zenith_test_libs"

$VERBOSE=nil

#============================================================================

# return true if current smartest session is on offline mode
# return false otherwise
# throw RuntimeError if any error occurs
# If there is no session at the time you call this script, UnoBridge throws exception
def ZTF_smartest_offline_mode?
  require "#{ENV['WORKSPACE']}/CMF-tools/Test/IntegTest/smartest_hw_mode"
  return ZTF.smartest_hw_mode()=="offline"
end

#============================================================================

module ZTF
  WORKSPACE = ENV.fetch("WORKSPACE")
  NONSHIPMENT_ROOT = ENV.fetch("NONSHIPMENT_ROOT")
  SHIPMENT_ROOT = ENV.fetch("SHIPMENT_ROOT")
  XOC_SYSTEM = ENV.fetch("XOC_SYSTEM")
  SESSIONCONSOLE = "#{XOC_SYSTEM}/bin/sessionconsole"
  SHUTDOWN_SMARTEST="#{NONSHIPMENT_ROOT}/fw/TEST_TOOLS/lbin/shutdown_SmarTest"
  MCD_IGNORE = "/etc/#{SHIPMENT_ROOT}/MCDIgnore"
  PRESENT_BOARDS = "/etc/#{SHIPMENT_ROOT}/presentBoards"

  #
  # check whether set_envrionment is called
  # raise Runtime Exception if env is not set
  #
  def self.envset?
    setenv_flag="FLAG_81519d0d_f267_47f2_8deb_fe2d491dd7c5"
    if(!ENV[setenv_flag])
      raise TestConfigError, "ERROR: set_envrionment needs to be called first!", caller
    end
    true
  end

  # return an array of available sessions
  # return an empty array if there is no session
  #
  def self.sessions()
    sessions=`#{SESSIONCONSOLE} -list 2>&1`.split()
    return [] if $?.exitstatus!=0
    return sessions
  end

  #
  # return session id of available SmarTest
  # return nil if there is no session running
  # = NOTE
  # it return nil even if there is a smartest running but it is on the other display
  #--
  # result of sessionfinder.ksh is reliable if and only if there are multiple session running
  # if only one session running, it just output the existing session id, which is not correct
  #
  def self.get_smartest_session()
    self.sessions().each do |session|
      # this is the case that smartest is running
      if (ENV['DISPLAY_HP83000'] and session.include?(ENV['DISPLAY_HP83000'])) or
      ( ENV['DISPLAY'] and session.include?(ENV['DISPLAY']) )
        return session
      end
    end
    return nil
  end

  #
  # return the product edition of current smartest instance
  #
  def self.get_product_edition()
    sessionid = get_smartest_session()
    productEditionKey = "ProductEdition"
    productEditionValue = ""
    exitValue = 1
    if File.executable?(SESSIONCONSOLE) and sessionid
      start_sessionmanager() #ensure session manager is running(need by sessionconsole)
      cmd="#{SESSIONCONSOLE} -describe #{sessionid}"
      output = `#{cmd}`
      returnV = $?.exitstatus
      if returnV!=0
        ZTF::LOG.error "occurs when calling \"#{cmd}\"\n"+output
        exitValue = returnV
      else
        output.each_line do |line|
          line.strip!()
          if line.include?(productEditionKey) and line.index(productEditionKey) == 0
            arr = line.split(":")
            if arr.size == 2
              productEditionValue = arr[1].strip()
              ZTF::LOG.debug "Get product Edition of SmarTest instance '#{sessionid}': "+productEditionValue
            else
              ZTF::LOG.debug "No Product Edition Info of SmarTest instance '#{sessionid}'!"
            end
            exitValue = 0
            break
          end
        end # end of output.each_line
      end
    end
    return productEditionValue, exitValue
  end

  #
  # return true if target product edition is the same as the one smartest is using
  # = NOTE
  # exception raised if smartest is not running
  #
  def self.same_product_edition?(expected_edition)
    expected_edition = "" if expected_edition == nil
    product_edition_value, exitValue = get_product_edition()
    information =
    "Product edition of current SmarTest instance is '#{product_edition_value}', expected product edition is '#{expected_edition}'"
    if exitValue == 0
      listA = product_edition_value.strip().split(",")
      listB = expected_edition.strip().split(",")
      if listA.size == listB.size
        listA.each_index do |i|
          if listA[i].strip() != listB[i].strip()
            ZTF::LOG.info information
            return false
          end
        end
        return true
      end
    end
    return false
  end

  #
  # check whether the expected model file is the same as the one used by SmarTest
  # return true     if the content of both is the same,
  # return false    if not
  # raise exception if error occurs
  #
  def self.same_model_file?(expected_file)  
    begin
      return FileUtils.cmp(get_model_file(), expected_file)
    rescue Exception => e
      ZTF::LOG.error "occurs in #{this_method_name()}\n"+exception2str(e,$DEBUG)
      return false
    end
  end

  #
  # get the model file used by smartest
  # make sure SmarTest is running before call it
  #
  def self.get_model_file()    
    
    sessionid=get_smartest_session()
    raise TestRunTimeError, "ERROR: failed to get session id of current HPSmarTest.", caller unless sessionid
    smartest_model_file="/var#{ENV['HP83000_ROOT']}/model_#{sessionid}"
    
    raise TestConfigError, "ERROR: file '#{smartest_model_file}' is not readable!", caller if not File.readable?(smartest_model_file)    
    
    return smartest_model_file
  end

  #
  # TODO: 1. Is there a easy way of abstract the reset method from 'FWTest'?
  #       2. what is the return value of reset in FW stands for?
  # NOTE: require 'FWTest' is a terrible idea, because this script include many
  #       many methods in to current naming space, and it has "at_exit" methods as well.
  def self.reset_smartest
    ZTF::LOG.info "Resetting SmarTest..."
    `ruby #{ENV['WORKSPACE']}/CMF-tools/Test/IntegTest/reset_smarTest.rb`
    return $?.exitstatus
  end

  # Start session manager if it is not running
  # raise TestRunTimeError if it can not start session manager
  #--
  # it takes 0.1 sec to get the result if session manager is running or not
  # so it is okay that it is always called each time before programs, which
  # relies on session manager, is executed
  def self.start_sessionmanager
    result = `#{SESSIONCONSOLE}`
    if $?.exitstatus!=0
      ZTF::LOG.info "The Session Manager is not running. The program is trying to start it ..."
      system("#{ENV['WORKSPACE']}/system/bin/run -x0")
      if $?.exitstatus!=0
        raise TestRunTimeError, "ERROR: failed to start session manager!", caller
      else
        ZTF::LOG.info "The Session Manager is running now!"
      end
    end
  end

  # return true if given session is running, otherwise return false
  # = NOTE
  # If sessionmanager is not running, which is required by sessionconsole,
  # this function will try to start session manager
  #
  def self.session_running?(sessioname)
    start_sessionmanager
    return false unless self.sessions().include?(sessioname)
    session_info = `#{SESSIONCONSOLE} -describe #{sessioname} 2>&1`
    return false unless $?.success?
    # if session info is empty, it means smartest info is unknown
    # and it is an indication of crash.
    return (not session_info.strip.empty?)
  end

  # return true if smartest is running
  # = NOTE
  # If sessionmanager is not running, which is required by sessionconsole,
  # this function will try to start session manager
  #
  def self.smartest_running?
    start_sessionmanager
    sessionname = get_smartest_session() # it return a session id if smartest running on current display
    return false if sessionname.nil?
    if session_running?(sessionname)
      # this is needed when require libservices_ruby_UnoBridge
      # TODO: is there a better way?
      if ENV['RUBY_XOC_SESSION'].nil?
        ENV['RUBY_XOC_SESSION']=sessionname
      end
      return true
    else
      return false
    end
  end

  # return true if current smartest session is on offline mode
  # return false otherwise
  # throw RuntimeError if any error occurs
  def self.smartest_offline_mode?
    return ZTF_smartest_offline_mode?()
  end

  def self.shutdown_smartest
    system(SHUTDOWN_SMARTEST)
    if $?.exitstatus != 0
      raise TestRunTimeError, "ERROR: Failed to shutdown SmarTest! Program terminates immediately!", caller
    end
    return true
  end

  #
  # call SmartConfig, default is offline configuration
  # = Arguments
  # mode: online, on, offline, of
  # args: additional arguments passed to SmartConfig
  #       e.g. -offline_hardware cs800
  # = Note
  # once SmartConfig is called, dir /var$HP83000_ROOT/ is overwritten
  # Side affect is model_<sessionid>.xml is deleted, and we lost model file used
  # for all running SmarTest instances.
  #
  def self.smartconfig(mode='offline', *args)
    case mode.downcase
    when 'offline', 'of'
      offline_mode=true
    when 'online', 'on'
      offline_mode=false
    else
      raise TestConfigError, "unknow mode '#{mode}', only  online, on, offline, of is accepted", caller
    end

    smart_config = "/bstd_tools/contrib/lbin/SmartConfig"
    if ENV["ENV_USE_SCM"] && ENV["ENV_USE_SCM"] = "GIT"
      scm_tools_root=ENV['ENV_ATE_TOOLS_ROOT']
      scm_tools_root="/opt/ate/tools" unless scm_tools_root
      smart_config = "#{scm_tools_root}/bin/SmartConfig"
    end

    ENV['TOOLS_LIBRARY_PATH']="#{scm_tools_root}/bstd_tools/contrib/lib" if not ENV['TOOLS_LIBRARY_PATH']

    ZTF::LOG.info "Running SmartConfig ..."
    if offline_mode
      smartconfig_cmd="#{smart_config} -offline #{args.join(' ')} 2>&1"
    else
      smartconfig_cmd="#{smart_config} -online #{args.join(' ')} 2>&1"
    end
    ZTF::LOG.info smartconfig_cmd
    result=`#{smartconfig_cmd}`
    (ZTF::LOG.error result; raise TestRunTimeError, "ERROR: occurs while running '#{smartconfig_cmd}'", caller) if $?.exitstatus!=0
  end

  # = Note
  # 1. it does not check whether there is a existing smartest instance
  #    call ZTF.smartest_running? before calling this script
  # 2. raise exception if modelfile error or failing to start smartest
  # 3. SmartConfig will not be called here, developer needs to call it if needed
  # = Arguments
  # offline_mode: true or false
  # board: specify the board want to run in online mode. e.g. ps6800
  #        If board is given, it creates a MCDIgnore file and then starts SmarTest
  #
  def self.start_smartest(offline_mode=true,modelfile="",board=nil)

    #start_smartest_cmd_option = "#{ENV['SHIPMENT_ROOT']}/pws/bin/hp83000 -v -G"
    start_smartest_cmd_option = "#{ENV['SHIPMENT_ROOT']}/prod_env/bin/HPSmarTest -t -G "
    start_smartest_cmd_option += " -o" if offline_mode
    # we always use incorruptus as the default workspace for testing, -D stands for data
    start_smartest_cmd_option += " -D#{ENV['WORKSPACE']}/integtests/devices/incorruptus "

    start_smartest_cmd="#{ENV['WORKSPACE']}/CMF-tools/Test/IntegTest/start_SmarTest -cmd '#{start_smartest_cmd_option}'"

    start_sessionmanager() #ensure sessionmanager is running since start_SmarTest depends on it
    # = Note
    # SmartConfig will not be called here, developer needs to call it if needed
    if offline_mode
      if modelfile!=""
        raise TestConfigError, "ERROR: #{this_method_name}: model file #{modelfile} does not exist!", caller if not File.exist?(modelfile)
        export_modelfile="export V93000_MODEL=\"#{modelfile}\" ; "
      else
        export_modelfile=""
      end
      ZTF::LOG.info "Using default model file" if modelfile==""
      ZTF::LOG.info "Using model file '#{modelfile}'" if modelfile!=""
      system(export_modelfile+start_smartest_cmd)
    else #online mode
      #TODO: enable this
      # self.createMCDIgnore(board) if board
      system(start_smartest_cmd)
    end
    if $?.exitstatus != 0 or not self.smartest_running?()
      raise TestConfigError, "ERROR: #{this_method_name}: failed to start SmarTest. Exit status: #{$?.exitstatus}", caller
    end
    return true
  end


  # == Precondition
  # make sure PRESENT_BOARDS is available, smartest is running in online mode
  # == overview
  # it return the board in use of a running smartest online instance, e.g. ps1066
  # return the first board in PRESENT_BOARDS if no MCDIgnore file
  # raise exception if PRESENT_BOARDS doesn't exist
  # return nil if it can't find the board from PRESENT_BOARDS based on the MCDIgnore
  # How it is calculated : presentBoards - MCDIgnoreBoards
  #--
  # format of presentBoards looks like this:
  # ps6800 301:HSBoard 302:none 303:none 304:none
  #
  # TODO: it rely on the logic that MCDIgnore is created before smartest starts
  # can we query from smartest directly?
  def self.current_board_in_use
    presentBoards = Hash.new
    presentBoards['first_board'] = nil
    File.readlines(PRESENT_BOARDS).each do |l|
      next if l.strip! =~ /^#/  # skip comments
      a = l.split
      # default board is the first board appeared in the PRESENT_BOARDS
      presentBoards['first_board'] = a[0] unless presentBoards['first_board']
      # e.g. "301 302 303 304" => "ps6800"
      boards = a[1..-1].collect { |b| b.split(":")[0] }.join(" ")
      presentBoards[boards] = a[0]
    end
    return presentBoards['first_board'] unless File.exist?(MCD_IGNORE)
    mcd_ignore = File.readlines(MCD_IGNORE).collect {|l| l.strip }.join(" ")
    used_boards = []
    presentBoards.each_pair do |k,v|
      used_boards << k unless mcd_ignore.include?(v)
    end
    return used_boards if used_boards.size > 0
    ZTF::LOG.warn "inconsistent data between presentBoards and MCDIgnore"
    ZTF::LOG.warn "MCDIgnore : #{mcd_ignore}"
    ZTF::LOG.warn "presentBoards : #{presentBoards.inspect}"
    return nil
  end

  # == Precondition
  # make sure PRESENT_BOARDS is available
  # == overview
  # It creates the MCDIgnore file
  # There is a script /vobs/a93k/fw/lbin/createMCDIgnore.rb does the same thing
  # But I decided to implment my own because I need extra features,
  # e.g.
  def self.createMCDIgnore(board)
    ZTF::LOG.info "Creating MCDIgnore for board #{board}"
    # keep udps cards active (Follow the pattern of FW_TEST)
    cmd = "#{NONSHIPTMENT_ROOT}/fw/lbin/createMCDIgnore.rb #{board} udps"
    ZTF::LOG.error "execution of '#{cmd}' failed!" unless system(cmd)
  end

  # return the path: $WORKSPACE/system/log
  # raise TestRunTimeError if it can not find XOC_LOG_DIR
  def self.system_log_path
    return ENV['XOC_LOG_DIR'] if ENV.include?('XOC_LOG_DIR')
    return ENV['XOC_SYSTEM'] + "/log" if ENV.include?('XOC_SYSTEM')
    systemlog = `$WORKSPACE/system/bin/run -Qx /usr/bin/ksh -- 'echo $XOC_LOG_DIR'`.chomp!
    if $?.exitstatus==0
      ENV['XOC_LOG_DIR'] = systemlog
    else
      raise TestRunTimeError, "ERROR: failed to execute run script, unalbe to get env variable $XOC_LOG_DIR!", caller
    end
    return systemlog
  end
end

if __FILE__ == $0
  include SystemUtil
  exit execute_ZTF_method
end

