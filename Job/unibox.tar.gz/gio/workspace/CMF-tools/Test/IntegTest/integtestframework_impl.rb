# = Overview
#
# IntegTestImpl is the base class designed for Integration Test Frameworks
#
# Author::    Zhiwei Xu, 03.09.2012
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#
# == Usage
#   This class implements the base structure of a integration test
#   When a new integration test framework needs to be invented,
#   it should derive from this class, and overwrite following methods
#     setup_world
#     run_test
#     teardown_world
#   Tests (defined in run_test) will be executed automatically.
#   The behavior of SmarTest, preparation of TestBed, etc. are handled by the
#   base class
# == NOTE
#  It is better to call the wrapper from run script, since it defines many
#  env variables, e.g. XOC_LOG_DIR

require "#{File.dirname(__FILE__)}/smartestutil"
require "#{File.dirname(__FILE__)}/smartestcontroller"
internal_dir = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal")
require "#{internal_dir}/zenith_test_libs"

require 'fileutils'

# TODO;
# UnoBridge is not used here, since there is a bug inside
# It can not be required from a method of a class
# require "#{ENV['WORKSPACE']}/lib/libservices_ruby_UnoBridge"

module ZTF
  module IntegTestFramework
    class IntegTestImpl
      attr_reader :logdir
      include SystemUtil
      #
      # = Arguments
      #     test_dir: the root directory of a integration test, it is an anchor
      #               for an integration test.
      #               It assumes that TestBed is located at <test_dir>/TestBed
      def initialize(test_dir,model_file="",offline_mode=true,reuse_smartest=true,quick_mode=false)
        @test_dir   = test_dir
        @model_file = model_file
        @offline_mode   = offline_mode
        @reuse_smartest = reuse_smartest
        @quick_mode     = quick_mode
        if ENV['ZTF_RUN_BY_ART'] and ENV['ZTF_RUN_BY_ART'].upcase == "TRUE"
          @featbuild_mode = true
        else
          @featbuild_mode = false
        end
        @testbed = File.join(@test_dir,"TestBed")
        @testbed += "_online" unless @offline_mode
        @testbedBackup = @testbed+"1"
        @logdir  = File.join(@testbed,"log")
        @testbedtemplate = File.join(@test_dir,"TestBedTemplate")
        @jacocoLib = ENV['ENV_DEVTOOLS_ROOT'] + "/src/jacoco/lib/jacocoagent.jar"
        @jacocoDir = ENV['WORKSPACE'] + "/ate/ext/prog/java_test_framework/integtest_results"
        @jacocoFile = File.join(@jacocoDir, File.dirname(@test_dir).gsub(ENV['WORKSPACE'] + "/", "").gsub("/", ".") + ".exec")
        ENV['ZTF_TESTBED_DIR'] = @testbed # this is used by integration tests
      end

      #
      # magic hook: will be called automatically by the framework
      # the return value will be the exit value of the test
      #
      def run
        begin
          verify_env_set unless @quick_mode  # private, should not overwrite normally
          setup_world       # OVERWRITE IT: empty method
          setup_TestBed     # private, should not overwrite normally
          start_smartest unless @quick_mode  # private, should not overwrite normally
          run_test          # OVERWRITE IT: empty method
        ensure
          teardown_world    # can be overwritten
        end
          # if any exception raised here, it means something went wrong with the
          # framework, nothing to do with the test
      rescue SystemExit => e
        @exit_value = e.status
      rescue TestConfigError, TestRunTimeError => e
        @exit_value = ExitValue::ERROR
        ZTF::LOG.error exception2str(e,ZTF::LOG.level == ZTF::ZenithLogger::DEBUG)
        cleanup_mess # something goes wrong, cleanup before leave the test
      rescue Exception => e
        @exit_value = ExitValue::ERROR
        ZTF::LOG.error exception2str(e,ZTF::LOG.level == ZTF::ZenithLogger::DEBUG)
        ZTF::LOG.puts "You could check log '#{@logdir}' to identify reasons!" if @testbed_ready
        cleanup_mess # something goes wrong, cleanup before leave the test
      ensure
        return @exit_value
      end

      #
      # Verify necessory env is set, e.g. set_envrionment must be called
      #
      def verify_env_set
        ZTF.envset?
        verify_var
        # make sure dir $XOC_SYSTEM is ready to use
        prepare_system_dir
        prepare_jcov_dir
      end
      private :verify_env_set

      # different test frameworks may have their own mandatory variables
      # these vars need to be checked as well.
      def verify_var
        unless  @test_dir.kind_of?(String) and
            @model_file.kind_of?(String)   and
            (@offline_mode.kind_of?(FalseClass) or @offline_mode.kind_of?(TrueClass)) and
            (@reuse_smartest.kind_of?(FalseClass) or @reuse_smartest.kind_of?(TrueClass))
          raise "ERROR: #{this_method_name()}: there are mandatory variables not defined properly!"
        end
        raise TestConfigError, "ERROR: model file '#{@model_file}' doesn not exist!", caller if @offline_mode and @model_file!="" and (not File.readable?(@model_file))
      end
      private :verify_var

      def prepare_system_dir
        # we only prepare the $XOC_SYSTEM in interactive mode,
        # for the sake of test efficiency
        unless @featbuild_mode
          config_system_dir="#{ENV['XOC_SYSTEM']}/bin/run -Qx0"
          system(config_system_dir)
          raise TestRunTimeError, "ERROR: system error when executing 'run -Qx0', test terminate!", caller if $?.exitstatus != 0
        end
      end
      private :prepare_system_dir

      def prepare_jcov_dir
        if not File.directory?(@jacocoDir)
          FileUtils.mkdir(@jacocoDir,:mode=>0777)
        end
        # see $WORKSPACE/ate/ext/prog/JavaTestMethodController/Main/ZSJavaTestMethodController.cpp
        javaAgent = "-javaagent:" + @jacocoLib + "=destfile=" + @jacocoFile + ",append=true,jmx=true,includes=xoc.*:ate.*:com.advantest.*"
        ENV['XOC_JAVA_TM_COVERAGE'] = javaAgent
      end
      private :prepare_jcov_dir

      def setup_world
      end

      def setup_TestBed
        if @quick_mode
          ZTF::LOG.info "Only backup '#{File.basename(@testbed)}/log' to '#{File.basename(@testbedBackup)}/log' in quick test mode!"
          backup_TestBed_log
          ZTF::LOG.info "Leave '#{File.basename(@testbed)}' unchanged in quick test mode! "
        else
          ZTF::LOG.info "Backing up '#{File.basename(@testbed)}' to '#{File.basename(@testbedBackup)}'"
          retry_it(1,ZTF::LOG) { backup_TestBed() }
          ZTF::LOG.info "Preparing directory '#{File.basename(@testbed)}'"
          retry_it(1,ZTF::LOG) { cleanup_TestBed() }
          # Delete previous Java coverage file, if exist
          if File.exist?(@jacocoFile)
            File.delete(@jacocoFile)
          end
        end
        # setup TestBed/log directory
        unless File.directory?(@logdir)
          FileUtils.mkdir_p(@logdir, :mode=>0777)
        end
        # take a snapshot of log before test starts
        take_dir_snapshot(ZTF.system_log_path,@logdir)
        take_reportwindow_snapshot(@logdir)

        @testbed_ready=true
        copy_testbedtemplate unless @quick_mode
      end
      private :setup_TestBed

      # remove everything except log dir in @testbed
      def cleanup_TestBed
        if File.exist?(@testbed)
          FileUtils.remove_entry(@testbed,true)
        end
        FileUtils.mkdir_p(@testbed, :mode=>0777)
      end
      private :cleanup_TestBed

      def backup_TestBed
        if File.exist?(@testbedBackup)
          FileUtils.remove_entry(@testbedBackup,true)
        end
        if File.exist?(@testbed)
          FileUtils.mkdir_p(@testbedBackup, :mode=>0777)
          toMove = Dir.entries(@testbed)- [".", ".."]
          toMove.each do |item|
            FileUtils.move(File.join(@testbed,item),File.join(@testbedBackup,item),:force => true)
          end
        end
      end
      private :backup_TestBed

      def backup_TestBed_log
        if File.exist?(@testbedBackup)
          FileUtils.remove_entry(@testbedBackup,true)
        end
        if File.exist?(@testbed)
          FileUtils.mkdir_p(@testbedBackup, :mode=>0777)
          FileUtils.move( File.join(@testbed,'log'), File.join(@testbedBackup,'log'), :force => true)
        end
      end
      private :backup_TestBed_log

      # It copies @testbedtemplate to @testbed
      def copy_testbedtemplate
        return if not File.directory?(@testbedtemplate)
        has_custom_config=false
        each_file_under(@testbedtemplate) do |file|
          has_custom_config=true
          break
        end
        if has_custom_config
          ZTF::LOG.info "copying '#{File.basename(@testbedtemplate)}' to '#{File.basename(@testbed)}'"
          FileUtils.copy_entry(@testbedtemplate,@testbed)
        end
      rescue Exception => e
        ZTF::LOG.error "failed to copy '#{@testbedtemplate}' to '#{@testbed}'!"
        ZTF::LOG.error(e)
      end
      private :copy_testbedtemplate

      # it monitors the changes of the report window file
      # and generates the appended data to the target dir.
      # before the program exits.
      def take_reportwindow_snapshot(target_dir)
        # fm = SystemUtil::FileMonitor.new(reportwindow)
        at_exit do
          begin
            reportwindow = "/tmp/ReportWindow.dump"
            # call dump window so that report window is write to
            # the reportwindow file
            cmd = "#{ENV['NONSHIPMENT_ROOT']}/segments/eclipse/test_framework/ReportWindowDump/bin/ReportWindowDump"
            if ZTF.smartest_running?
              ZTF::LOG.info "Trying to dump report window."
              `#{cmd} 2>&1`
              #TODO: clear window if dump succeeded
              if $? == 0
                sleep(2) # give dump sometime to write the content
              else
                ZTF::LOG.warn "Dumping report window failed."
              end
            end
            if File.exist?(reportwindow)
              FileUtils.copy_file(reportwindow,File.join(target_dir,File.basename(reportwindow)))
            end
          rescue Exception => e
            ZTF::LOG.warn "Dumping report window failed. \n#{e.inspect}\n#{e.backtrace.join("\n")}"
          end
        end
      end
      private :take_reportwindow_snapshot

      #
      # it monitors changes of all files in given directory
      # and output newly generated data to target directory before program exits
      #
      def take_dir_snapshot(orig_dir,target_dir)
        dm = SystemUtil::DirMonitor.new(orig_dir)
        at_exit do
          ZTF::LOG.info "Generating log under '#{target_dir}': "
          output_files = dm.output_appended_data(target_dir)
          ZTF::LOG.info "FINISHED"
          # If there is file ending with .[[::digit::]], e.g. CompleteSystem.slg.1
          # it means old files are renamed from CompleteSystem.slg to CompleteSystem.slg.1
          # the generated logs here are not correct anymore!
          # So let's print a msg in this case
          renamed_file = output_files.select { |file| file=~/\.\d+$/ }
          if renamed_file.size > 0
            # we get a list of files which has renamed, e.g. CompleteSystem.slg!
            renamed_file.map! { |file| file.gsub(/\.\d+$/,"") }.uniq!
            ZTF::LOG.info "the content of following generated files isn't correct," +
                              " since they reaches MaxFileSize and are split to multiple fragments!\n"+
                              "      #{renamed_file.join("\n      ")}"
            ZTF::LOG.info "please either clean-up system log directory or increase the MaxFileSize in SystemLogger.conf!"
          end
        end
      end
      private :take_dir_snapshot

      # here smartest will be started
      # detection of smartest_crash? and teardown_smartest will be called automatically when program exits
      def start_smartest
        if @offline_mode
          test_mode_msg = "offline mode"
        else
          test_mode_msg = "online mode"
          # exported in intex
          test_mode_msg += " on board #{ENV['ZTF_ONLINE_BOARD']}" if ENV['ZTF_ONLINE_BOARD']
        end
        ZTF::LOG.info "Running tests in #{test_mode_msg}"
        @smartest_controller = ZTF::SmarTestController.new(@test_dir,@model_file,@offline_mode,@reuse_smartest)
        @smartest_controller.require_smartest()
        at_exit do
          # since now smartest starts, we need to check if it crashes at the end
          if smartest_crash?
            @exit_value = ExitValue::FATAL
            # if smartest crashes, we need to make sure it is really gone
            # otherwise, SmarTest may not able to start up properly for later tests.
            ZTF.shutdown_smartest
          else
            teardown_smartest() # private
          end
        end
      end
      private :start_smartest

      def smartest_crash?
        # if ZTF_START_SMARTEST is set, then we check if the specific session is there
        # otherwise, we check whether smartest is running
        if ENV['ZTF_START_SMARTEST']
          if ENV['RUBY_XOC_SESSION'].nil?
            ZTF::LOG.warn "RUBY_XOC_SESSION is not set, the test could not check if specific session is still running or not!"
          else
            if not ZTF.session_running?(ENV['RUBY_XOC_SESSION'])
              ZTF::LOG.fatal "the test caused session #{ENV['RUBY_XOC_SESSION']} CRASHED !"
              return true
            end
          end
        else
          if not ZTF.smartest_running?
            ZTF::LOG.puts "" # make sure following line "FATAL: ..." will start with a new line
            ZTF::LOG.fatal "the test caused 93k CRASHED !"
            return true
          end
        end
        return false
      end
      private :smartest_crash?

      # define the test to be run when smartest is ready to use
      def run_test
        ZTF::LOG.warn "no test is executed since #{this_method_name()} is not overwritten"
      end

      # smartest may be shutdown depending on certain conditions:
      def teardown_smartest
        @smartest_controller.release_smartest() if defined?(@smartest_controller)
      end
      private :teardown_smartest

      # define actions after test executed
      def teardown_world
        @exit_value = ExitValue::PASS unless defined?(@exit_value)
      end

      # it should be called when exception raises during test execution,
      # we need to cleanup the mess before leave the test, e.g. shutdown smartest
      def cleanup_mess
        # it only cleanup in FeatBuild mode.
        # In interactive mode, it doesn't do it because developer may debug it
        if @featbuild_mode
          # when @smartest_controller is initialized, it means smartest is touched
          # by the framework, and we should shut it down.
          if defined?(@smartest_controller)
            @smartest_controller.release_smartest(true)
          end
        end
      end
      private :cleanup_mess

    end #IntegTestImpl
  end
end
