#! /usr/bin/env zruby
$VERBOSE=nil
#$LOAD_PATH << "#{ENV['WORKSPACE']}/CMF-tools/Test/IntegTest"
require "#{File.dirname(__FILE__)}/integtestframework"
internal_dir = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal")

class DocuTestFramework < ZTF::IntegTestFramework::IntegTestImpl
  include SystemUtil

  def initialize
    init_basic_variables()
    set_validate_variables()
    process_arguments()
    super(@test_dir,@device_dir,@model_file,@offline_mode,@reuse_smartest,@reuse_device)
  end

  def print_usage
    ZTF::LOG.puts %Q{Executing a documentation test.
Usage: z_docu_test.ksh [options]
    [ on | online / offline | of ]    Optional, specify the hardware state
    [ -kill_smartest_after | -ksa ]   Optional, Kill SmarTest after test execution
    [ /path/of/target/model/file ]    Optional, test will exeucete with given model file
    [ -help | -h ]                    Optional, print Help
    [ -version ]                      Optional, print version
Notes:
1. If the script is executed without any argument, then by default it sets:
   - If only one test mode is set in ZTF_TEST_MODE, that value will be taken
   - Otherwise, offline is taken.
2. If a model file is given, the test will be executed with the given model file.
   Model files will be ignored in online mode.
3. If the environment variable ZTF_REUSE_SMARTEST is set to 'FALSE',
   the test will not re-use existing SmarTest instance.
4. If the environment variable XOC_TEST_ONLY is set, e.g. ':TestSuite.testA:TestSuite.testB:',
   only listed test cases will be executed. This feature only works with a fresh startup of SmarTest.
5. If the environment variable XOC_PRODUCT_EDITION is set, SmarTest will start with the specified edition.}
  end

  def print_header
    @version="1.0"
    ZTF::LOG.puts "*****************************************"
    ZTF::LOG.puts "*     Documentation Test Framework      *"
    ZTF::LOG.puts "*            Version #{@version}                *"
    ZTF::LOG.puts "*****************************************"
    ZTF::LOG.puts ""
    ZTF::LOG.puts "Running document test in '#{@test_dir}'" if @test_dir
  end

  def init_basic_variables
    @test_mode=ENV['ZTF_TEST_MODE'].strip.downcase if ENV['ZTF_TEST_MODE'] and !ENV['ZTF_TEST_MODE'].strip.empty?()
    @test_mode ||= "offline"

    @reuse_smartest=true
    @reuse_smartest=false if ENV['ZTF_REUSE_SMARTEST'] and ENV['ZTF_REUSE_SMARTEST'].chomp.downcase=="false"
    # in docutest, device have to be reload, because the testmethod in device changes all the time
    @reuse_device  =false

    @model_file = ENV['ZTF_OFFLINE_MODEL_FILE']
    @model_file ="" if not @model_file
  end

  def process_arguments
    for arg in ARGV do
      case arg.downcase
      when "offline", "of"
        if not defined?(@hardware_state)
          @hardware_state="offline"
        else
          ZTF::LOG.error "hardware mode is already set to #{@hardware_state}. It's not allowed to set it twice"
          print_usage()
          exit(1)
        end
      when "online", "on"
        if not defined?(@hardware_state)
          @hardware_state="online"
        else
          ZTF::LOG.error "ERROR: hardware mode is already set to #{@hardware_state}. It's not allowed to set it twice"
          print_usage()
          exit(1)
        end
      when "-ksa", "-kill_smartest_after"
        ZTF::LOG.info "Smartest will shutdown automatically after test execution!"
        at_exit { kill_smartest_after() }
      when "-info"
        ZTF::LOG.puts "Documentation Test"
        exit(0)
      when "-get_model_file"
        ZTF::LOG.puts "#{@model_file}"
        exit(0)
      when "-get_test_mode"
        ZTF::LOG.puts "#{@test_mode}"
        exit(0)
      when "-version", "--version", "-ver", "--ver", "-v"
        print_header
        exit(0)
      when "-help", "--help", "-h", "--h"
        print_usage()
        exit(0)
      else
        file=arg
        file=File.join(Dir.getwd(),arg) if arg.index("/") != 0
        if File.readable?(file)
          @model_file = realpath(file)
        else
          ZTF::LOG.error "unknown argument '#{arg}'"
          print_usage()
          exit(1)
        end
      end
    end
    # if test_mode is only offline or online, then it is clear that the user
    # want to execute in that mode by default
    if not defined?(@hardware_state)
      if @test_mode.split(",").size == 1
        @hardware_state = @test_mode.strip
        ZTF::LOG.info "Assume hardware state='#{@hardware_state}', since it is not set."
      else
        @hardware_state="offline"
      end
    end
    # verify whether the target hardware state is consistent with the test mode
    if not @test_mode.include?(@hardware_state)
      ZTF::LOG.info "Test is ignored since the test mode='#{@test_mode}', however hardware state='#{@hardware_state}'."
      exit(0)
    end
  end

  #
  # set variables needed, and verify the correctness
  #
  # ZTF_TEST_MODE "offline, online"
  # ZTF_TEST_DEVICE_DIR
  # ZTF_OFFLINE_MODEL_FILE
  # ZTF_REUSE_SMARTEST  "FALSE"
  #
  def set_validate_variables
    if @hardware_state=="online"
      @default_device ="#{ENV['NONSHIPMENT_ROOT']}/test/devices/online"
      @offline_mode=false
    else
      @default_device ="#{ENV['NONSHIPMENT_ROOT']}/test/devices/offline"
      @offline_mode=true
    end

    @device_dir=ENV['ZTF_TEST_DEVICE_DIR']
    if not @device_dir
      @device_dir=@default_device
      ZTF::LOG.info "env variable ZTF_TEST_DEVICE_DIR is not set, set it to default device '#{@device_dir}'"
    end

    @test_dir=Dir.getwd

    # model file is only used in offline mode
    (ZTF::LOG.error "model file #{@model_file} is not readable!"; exit(1)) if @offline_mode and @model_file!="" and (not File.readable?(@model_file))
    # device is used in both offline and online mode
    (ZTF::LOG.error "device #{@device_dir} does not exist!"; exit(1)) if @device_dir!="" and (not File.directory?(@device_dir))

    validate_test_site_config
  end

  #
  # validate if test site relevant variables are set correctly before a test runs
  # ZTF_TEST_SITE_CONFIG "0000, 1000, 1100, 0101 ,1111"
  # ZTF_TEST_SITE_NUMBER "1"
  # ZTF_TEST_FLOW_NAME   "CodeSnippetTest"
  #
  def validate_test_site_config
    @site_config = ENV['ZTF_TEST_SITE_CONFIG'].strip if ENV['ZTF_TEST_SITE_CONFIG']
    ( ZTF::LOG.error "environment variable ZTF_TEST_SITE_CONFIG is not set."; exit(1)) if not @site_config
    @site_number = ENV['ZTF_TEST_SITE_NUMBER'].strip if ENV['ZTF_TEST_SITE_NUMBER']
    ( ZTF::LOG.error "environment variable ZTF_TEST_SITE_NUMBER is not set."; exit(1)) if not @site_number
    @loadtestflow = ENV['ZTF_TEST_FLOW_NAME'].strip   if ENV['ZTF_TEST_FLOW_NAME']
    ( ZTF::LOG.error "environment variable ZTF_TEST_FLOW_NAME is not set."; exit(1)) if not @loadtestflow
    if not @site_config.gsub(/[ ,]/,'') =~ /^[0-9]+$/
      ZTF::LOG.error "format of ZTF_TEST_SITE_CONFIG is not correct. Only digits and comma is allowed!"
      exit(1)
    end
    if not @site_number =~ /^[0-9]+$/ or @site_number.to_i >= @site_config.split(',').size
      ZTF::LOG.error "ZTF_TEST_SITE_NUMBER is not set correctly. Site number should be in range [0, MAX_OF_SITES-1]!"
      exit(1)
    end
    if not File.readable?(File.join(@device_dir,"testflow",@loadtestflow))
      ZTF::LOG.error "could not find test flow '#{@loadtestflow}' in device '#{@device_dir}'"
      exit(1)
    end
  end

  def setup_world
    super()
    @docutest_log="/tmp/DocuTest.log#{ENV['DISPLAY']}"
    @docutest_runner="#{ENV['NONSHIPMENT_ROOT']}/testmethod/TEST/docutest/Tools/Testflow_runner/testflow_runner "
    print_header
  end

  def run_test
    ZTF::LOG.info "starts to load test flow '#{@loadtestflow}' into SmarTest and execute tests"
    ZTF::LOG.puts "======================================================================"
    runtest_cmd = %Q{#{@docutest_runner}} +
                  %Q{ -c "#{@site_config}"} +
                  %Q{ -n "#{@site_number}"} +
                  %Q{ -d "#{@device_dir}"} +
                  %Q{ -f "#{@loadtestflow}"}
    ZTF::LOG.puts "Run commad: "+runtest_cmd

    FileUtils.rmdir(@docutest_log) if File.directory?(@docutest_log) #should happen very rare
    File.new(@docutest_log,'w').close()
    tailR=system("tail -s 0.5 --retry --follow=name '#{@docutest_log}' --pid #{$$} &")
    system(runtest_cmd)
    @exit_value = $?.exitstatus
    ZTF::LOG.fatal "the test (#{runtest_cmd}) caused 93k CRASHED !" if not ZTF.smartest_running?
  end

  def kill_smartest_after()
    require "#{File.dirname(__FILE__)}/smartestutil"
    if ZTF.smartest_running?()
      ZTF::LOG.info "Shutting down SmarTest since argument '-kill_smartest_after' is given"
      ZTF.shutdown_smartest()
    end
  end

  def log_docutest_result
    target=File.join(@test_dir,"TestBed/log",File.basename(@docutest_log))
    copy_dir(@docutest_log,target)
    @docutest_log = target
  end

  #
  # To make sure test result reliable, we need to compare the log of a test
  # with the reference log file.
  #
  def verify_docutest_result(result)
    envtag='ZTF_TEST_RESULT_REFERENCE'
    reference_log= ENV["ZTF_TEST_RESULT_REFERENCE"]
    (ZTF::LOG.info "verification of test log is ignored since #{envtag} is not defined."; return true) unless reference_log
    (ZTF::LOG.error "can not find reference file '#{reference_log}'!"; return false) unless File.exist?(reference_log)
    (ZTF::LOG.error "can not find log '#{result}'!"; return false) unless File.exist?(result)
    referenceA = extract_testcase_result_from(reference_log)
    referenceB = extract_testcase_result_from(result)
    if referenceA == referenceB
      ZTF::LOG.info "compared test execution log with reference file, PASSED"
      return true
    else
      ZTF::LOG.error "the test execution log '#{File.basename(result)}' is different from reference file '#{File.basename(reference_log)}'"
      return false
    end
  end

  #
  # Return the "+TEST ..." in a log file, because this is what we care
  #
  def extract_testcase_result_from(file)
    arr = []
    IO.readlines(file).each do |l|
       if l =~ /^\+TEST\ /
         # typically each test case result is something like:
         # +TEST ElementaryTests.testInstantiation : PASSED (0.000082s)
         # needs to strip the (0.000082s) part
         l_without_time=l.gsub(/\(([0-9]|\.)+s\)/,'').strip
         arr << l_without_time
       end
     end
     return arr
  end

  # * write generated log files to local TestBed
  # * validate the test flow log and reference log
  #--
  # TODO:
  #  display the post-test message (currently set by val/cachegrind mode)
  #
  def teardown_world
    super()
    log_docutest_result()
    unless verify_docutest_result(@docutest_log)
      @exit_value = ExitValue::FAIL if @exit_value == ExitValue::PASS
    end
    @exit_value = ExitValue::PASS if @exit_value.class != Fixnum
  end
end

