# = usage
#
# 1. use this script to check whether smartest session is offline mode or not
# it return true if it runs in offline mode
# it returns false if not
# it throws RuntimeError in case of error
# == Note
# If there is no session at the time you call this script, UnoBridge will throw exception
#
# Author::    Zhiwei Xu, 20.05.2013
# Copyright:: Copyright (c) 2013 Advantest Europe GmbH
#
#require "XocSession.rb"
#XocSession.autoselectQuiet()
require "#{ENV['WORKSPACE']}/lib/libservices_ruby_UnoBridge"
internal_dir = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal")
require "#{internal_dir}/zenith_test_libs"


module ZTF
  # return string "offline" if current smartest session is in offline mode
  # return string "online" if it is in online mode
  # throw RuntimeError if any error occurs
  def self.smartest_hw_mode
    tag = RubyUNO::xocGetImplementer("xoc.svc.pref.ZPreferencesFactory")
    sPreferences = tag.getRootNode()
    if sPreferences == nil
      return "offline"
    end
    mcd_args = sPreferences.getNode("mcd_args")
    unless mcd_args
      raise TestRunTimeError,
        %Q{ERROR: occurs when fetching value via sPreferences.getNode("mcd_args")},
        caller
    end
    returnV, isOffline = mcd_args.getKey("offline", "")
    if returnV!=0
      raise TestRunTimeError,
        %Q{ERROR: occurs when fetching value via mcd_args.getKey("offline", "")},
        caller
    end
    return "offline" if isOffline.downcase == "true"
    return "online"
  rescue Exception => e
    raise TestRunTimeError.new(e, "error occurs in method #{this_method_name()}")
  end
end # end of module ZTF


if __FILE__ == $0
  $VERBOSE = nil
  ZTF::LOG.puts ZTF.smartest_hw_mode()
end