#!/usr/bin/env zruby
#
# Usage: processLogFiles.rb oldDir newDir outputDir
# The program goes through the newDir, compare all files under the directory
# with files under oldDir line by line, and output the newly generated content
# of newDir (comparing with oldDir) to outputDir with the same file names.

require 'pathname'
require 'pp'

internal_lib = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal/lib")
require "#{internal_lib}/exitvalue"
require "#{internal_lib}/zenith_logger"

def vputs(str)
  puts str if false
end

def printHelp(needExit=false)
  puts "Usage: processLogFiles.rb oldDir newDir outputDir"
  puts "  This program goes through the newDir, compares all files under this directory"
  puts "  with files under oldDir line by line, and outputs the newly generated content "
  puts "  of newDir (comparing with oldDir) to outputDir with the same file names."
  if needExit
    exit 1
  end
end

def getCompletePath(path)
  if path.index("/") != 0
    path = File.join(Dir.pwd, path)
  end
  return path
end

def ERR(s)
  ZTF::LOG.error(s)
end

def verify_argument
  if ARGV.size == 3
    if not (File.directory?(ARGV[0]) and File.directory?(ARGV[1]) and File.directory?(ARGV[2]))
      errordir = ""
      for arg in ARGV
        errordir += " "+arg unless File.directory?(arg)
      end
      ERR("ERROR: argument '#{errordir}' of your input '#{File.basename(__FILE__)} #{ARGV.join(" ")}' is not a directory")
      printHelp(true)
    end
  else
    ERR("Error: wrong number of arguments!")
    printHelp(true)
  end
end

def traverseDir(dir, baseDir, files)
  vputs "traverseDir #{dir}"
  if baseDir.rindex("/") != baseDir.size-1
    baseDir += "/"
  end
  dir = getCompletePath(dir)

  Dir.foreach(dir) do |item|
    if item == ".." or item == "."
      next
    else
      itemPath = File.join(dir,item)
      vputs "item: #{itemPath}"

      if File.directory?(itemPath)
        #puts "--subDir: #{item}"
        traverseDir(itemPath, baseDir, files)
      else
        #puts File.join(dir, item)
        files.push(itemPath.sub(baseDir,""))
      end
    end
  end
end

begin
  verify_argument
  originalDir = getCompletePath(ARGV[0])
  newDir      = getCompletePath(ARGV[1])
  outputDir   = getCompletePath(ARGV[2])
  File.umask(0000)
  files = Array.new
  # generate file list containing all names of files existing in newDir
  traverseDir(newDir, newDir, files)
  vputs "-------All log files in the #{newDir}-----------"
  vputs files

  files.each do |file|
    ## assert(File.file?(File.join(originalDir,file)))
    oldFilePath = File.join(originalDir,file)
    newFilePath = File.join(newDir,file)
    targetFilePath = File.join(outputDir, file)
    vputs "oldFilePath    #{oldFilePath}"
    vputs "newFilePath    #{newFilePath}"
    vputs "targetFilePath #{targetFilePath}"
    ## assert(File.file?(newFilePath))
    newFile = IO.readlines(newFilePath)
    oldFile = [""]
    if File.readable?(oldFilePath)
      oldFile = IO.readlines(oldFilePath)
    end
    targetFileDirPath = File.dirname(targetFilePath)
    if not File.directory?(targetFileDirPath)
      Dir.mkdir(targetFileDirPath)
    end
    newString = newFile-oldFile
    if newString.to_s.chomp != ""
      File.open(targetFilePath,"w") { |f| f.write(newString) }
      vputs "write to #{targetFilePath}"
    end
  end
rescue SystemExit => e
  exit(e.status)
rescue Exception => e
  ERR "#{e.message} (#{ e.class })!"
  ERR e.backtrace
  ERR "Execution of '#{File.basename(__FILE__)} #{ARGV.join(" ")}' failed!"
  $stderr.flush
  exit(e.status)
end

