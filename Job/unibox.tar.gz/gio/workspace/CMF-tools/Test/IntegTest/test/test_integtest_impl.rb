require 'test/unit'
$NONSHIPMENT_ROOT=ENV.fetch("NONSHIPMENT_ROOT")
$WORKSPACE=ENV.fetch("WORKSPACE")

require "#{$WORKSPACE}/CMF-tools/Test/IntegTest/integtestframework_impl"
require "#{$WORKSPACE}/CMF-tools/Test/IntegTest/smartestcontroller"
require "#{$WORKSPACE}/CMF-tools/Test/IntegTest/smartestutil"
require "#{$WORKSPACE}/CMF-tools/Test/internal/zenith_test_libs"

class IntegTestImplTest < Test::Unit::TestCase
  def setup
    unless defined?(@@settedup)
      @@settedup=true
      @@testdir="/tmp/_integtest"
      Dir.mkdir(@@testdir) if not File.exist?(@@testdir)
      @@test = ZTF::IntegTestFramework::IntegTestImpl.new(@@testdir)
    end
  end

  def test_verify_env
    assert_nothing_raised do
      @@test.send(:verify_env_set)
    end
  end

  def test_start_with_a_cleansystem
    `#{$WORKSPACE}/system/.clean-on-build/clean_system.sh filename`
    assert_equal(@@test.run,0)
  end

  def teardown
    unless defined?(@@teardowned)
      @@teardowned=true
      at_exit do
        ZTF.shutdown_smartest()
        ZTF::LOG.puts "cleanup #{@@testdir}"
        `/bin/rm -rf #{@@testdir}`
      end
    end
  end
end


class SmarTestControllerOfflineTest < Test::Unit::TestCase

  def test_variables
    integtest="/tmp"
    t = ZTF::SmarTestController.new(integtest,nil,false,false)
    u = ZTF::SmarTestController.new(integtest)
    assert_equal(t.instance_variable_get(:@reuse_smartest),false)
    assert_equal(t.instance_variable_get(:@offline_mode),false)
    assert_equal(t.instance_variable_get(:@model_file),"")

    assert_equal(u.instance_variable_get(:@reuse_smartest),true)
    assert_equal(u.instance_variable_get(:@offline_mode),true)
    assert_equal(u.instance_variable_get(:@model_file),"")
  end

  def test_initialize
    assert_raise TestConfigError do
      ZTF::SmarTestController.new("/tmp/notexist")
    end
  end
end

class SmarTestUtilTest < Test::Unit::TestCase

  def test_cmdline_setenv
    `ruby #{$WORKSPACE}/CMF-tools/Test/IntegTest/smartestutil.rb envset?`
    assert_equal($?.exitstatus,0)
  end

  def test_smartest_production
    if not ZTF.smartest_running?()
      ZTF.start_smartest
    end
    assert_equal(ZTF.same_product_edition?(""),true)
    assert_equal(ZTF.same_product_edition?("__"),false)
  end

  def test_start_smartest
    assert_nothing_raised do
      ZTF.shutdown_smartest()
      assert_equal(ZTF.smartest_running?,false)
      ZTF.start_smartest()
      assert_equal(ZTF.smartest_running?,true)
      ZTF.shutdown_smartest()
      assert_equal(ZTF.smartest_running?,false)
      end
  end

  def test_correct_modelfile
    ZTF::LOG.puts "-------------------------#{this_method_name()}-----------------------"
    assert_nothing_raised do
      ZTF.shutdown_smartest()
      model="#{$NONSHIPMENT_ROOT}/test/system/offline/model.cs800"
      ZTF.start_smartest(true,model)
      assert_equal(ZTF.same_model_file?(model),true)
    end
  end

end

class SystemUtilTest < Test::Unit::TestCase
  include SystemUtil
  def test_get_all_files_under
    testdir="#{$NONSHIPMENT_ROOT}/test/system/"
    # testdir="#{$WORKSPACE}/examples/ruby/RubyIntegTest/TestBedTemplate"
    systemcmd="/usr/bin/find %s -type f -follow | wc -l" % testdir
    n=0
    each_file_under(testdir) {|i| n+=1}
    assert_equal(n.to_s,`#{systemcmd}`.chomp )
  end

  def test_copy_file
    to="/tmp/_0123_test/fileto"
    from="/tmp/_0123_test/filefrom"
    FileUtils.remove_entry(to) if File.exist?(to)
    FileUtils.remove_entry(from) if File.exist?(from)
    assert_equal(copy_file(from,to),false)
    FileUtils.mkdir(File.dirname(from)) unless File.exist?(File.dirname(from))
    `touch #{from}`
    FileUtils.mkdir(to)
    assert_equal(copy_file(from,to),false)
    FileUtils.remove_dir(to)
    assert_equal(copy_file(from,to),true)
    FileUtils.remove_entry(File.dirname(from))
  end

end

class CodeExampleTest < Test::Unit::TestCase
  def test_run_docutest
    basebin="#{$NONSHIPMENT_ROOT}/testmethod/TEST/docutest/TestProgram/codeSnippetTest"
    system("#{basebin}/z_docu_test.ksh")
    assert_equal($?.exitstatus,0)
    system("#{basebin}/z_docu_test.ksh '#{$NONSHIPMENT_ROOT}/testmethod/TEST/docutest/devices/model' offline -ksa")
    assert_equal($?.exitstatus,0)
  end
end
