# == Overview
#
# If anyone wants to use the IntegTestFramework infrastructure, he needs to
# require this file, define its own class by deriving from
# ZTF::IntegTestFramework::IntegTestImpl and implements necessary methods
# defined in  ZTF::IntegTestFramework::IntegTestImpl.
#
# Author::    Zhiwei Xu, 03.09.2012
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#
#--
#TODO: add signal trap to systemutil, and pass a block from here
#

module ZTF
  module IntegTestFramework
    # If set to false ZTF::Framework will not automatically run at exit.
    def self.run=(flag)
      @run = flag
    end

    # Automatically run tests at exit?
    def self.run?
      @run ||= false
    end

  end
end

at_exit do
  unless $! || ZTF::IntegTestFramework.run?
    exit ZTF::IntegTestFramework::TestRunner.run
  end
end

require "#{File.dirname(__FILE__)}/integtestrunner"
require "#{File.dirname(__FILE__)}/integtestframework_impl"
