# = overview
# 
# this script 
# * finds all classes derived from ZTF::IntegTestFramework::IntegTestImpl
# * creates a instance for each of them
# * call magic method run for each of the instance 
#
# Author::    Zhiwei Xu, 03.09.2012, 
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#

module ZTF
  module IntegTestFramework
    
    class TestRunner
      def self.run
        runner = TestRunner.new()
        collection = runner.get_instance
        tests  = []
        collection.each do |klass|
          tests << Kernel.const_get(klass.to_sym).new
        end
        returnV=0 
        tests.each do |t|
          returnvalue = t.run
          returnV = returnvalue if returnvalue != 0
        end
        return returnV
      end
      
      def get_instance
        collection = []
        ObjectSpace.each_object(Class) do |klass|
          collection << klass.to_s  if(klass < ZTF::IntegTestFramework::IntegTestImpl)
        end
        collection
      end
    end

  end
end

require "#{File.dirname(__FILE__)}/integtestframework_impl"
