#!/opt/ruby-1.8.7/bin/ruby
#!/usr/bin/env zruby
#
#-rdebug
#
# == Overview
#
# JavaIntegTestFramework is implemented for Integration Test Frameworks
#
# Author::    Zhiwei Xu, 31.10.2013
# Copyright:: Copyright (c) 2013 Advantest Europe GmbH
#
# = Usage
#   Precondition: Call this script from $XOC_SYSTEM/bin/run
#   It will reuse smartest instance if possible or shutdown/start smartest
#   and execute unit tests located at ENV['ZTF_TEST_CASES_DIR']
#
#   An integration test should export following variables
#     ZTF_TEST_MODE :  online, offline
#     ZTF_OFFLINE_MODEL_FILE: fullpath of the model file used for the test
#

$VERBOSE=nil
STDOUT.sync = true
STDERR.sync = true

require "timeout"
require "#{File.dirname(__FILE__)}/integtestframework"
internal_dir = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal")
require "#{internal_dir}/zenith_test_attribute"
require "#{internal_dir}/lib/execute"
require "#{internal_dir}/lib/zexception"

class JavaIntegTestFramework < ZTF::IntegTestFramework::IntegTestImpl
  include SystemUtil, Execute

  def initialize
    init_basic_variables
    process_arguments
    set_validate_variables
    set_test_attributes
    super(@test_dir,@model_file,@offline_mode,@reuse_smartest)
  end

  def print_usage
    ZTF::LOG.puts %Q{Executing a java integration test.
Usage: z_java_integ_test.ksh [options]
  [ on | online / offline | of ]    Optional, specify the hardware state
  [ -kill_smartest_after | -ksa ]   Optional, Kill SmarTest after test execution
  [ /path/of/target/model/file ]    Optional, test will execute with given model file
  [ -log=STRING ]                   Optional, set the log level [debug info warn error fatal]
  [ -help | -h ]                    Optional, print Help
  [ -version ]                      Optional, print version
Notes:
1. If the script is executed without any argument, then by default it sets:
   - If only one test mode is set in ZTF_TEST_MODE, that value will be taken
   - Otherwise, offline is taken.
2. If a model file is given, the test will be executed with the given model file.
   Model files will be ignored in online mode.
3. If the environment variable ZTF_REUSE_SMARTEST is set to 'FALSE',
   the test will not re-use existing SmarTest instance.
4. If the environment variable XOC_TEST_ONLY is set, e.g. ':TestSuite.testA:TestSuite.testB:',
   only listed test cases will be executed. This feature only works with a fresh startup of SmarTest.
5. If the environment variable XOC_PRODUCT_EDITION is set, SmarTest will start with the specified edition.}
  end

  def print_header
    @version="0.0.1"
    ZTF::LOG.puts %Q{
*****************************************
*    Java Integration Test Framework    *
*            Version #{@version}              *
*****************************************
}
    ZTF::LOG.puts "Running Integration test in '#{@test_dir}'" if @test_dir
  end

  def init_basic_variables
    if ENV['ZTF_TEST_MODE']!=nil and !ENV['ZTF_TEST_MODE'].strip.empty?()
      @test_mode=ENV['ZTF_TEST_MODE'].strip.downcase
    elsif ENV['ZTF_INTEG_TEST_MODE']!=nil and !ENV['ZTF_INTEG_TEST_MODE'].strip.empty?()
      @test_mode=ENV['ZTF_INTEG_TEST_MODE'].strip.downcase
    end
    @test_mode ||= "offline"
    @model_file = ENV['ZTF_OFFLINE_MODEL_FILE'] || ""

    @reuse_smartest=true
    @reuse_smartest=false if ENV['ZTF_REUSE_SMARTEST'] and ENV['ZTF_REUSE_SMARTEST'].strip.downcase=="false"
    @max_exec_time = 10 * 60 # max 10 mins execution time

    if ENV['XOC_JAVA_HOME']
      ENV['PATH']="#{ENV['XOC_JAVA_HOME']}/bin:#{ENV['PATH']}"
    else
      ZTF::LOG.error "XOC_JAVA_HOME is not defined!"
      exit(1)
    end
    ENV['LD_LIBRARY_PATH']="""#{ENV['LD_LIBRARY_PATH']}:\
#{ENV['XOC_JAVA_HOME']}/jre/lib/:\
#{ENV['XOC_JAVA_HOME']}/lib:\
#{ENV['WORKSPACE']}/system/lib:\
#{ENV['WORKSPACE']}/system/bin:\
#{ENV['NONSHIPMENT_ROOT']}/com/sh_lib:\
#{ENV['NONSHIPMENT_ROOT']}/pws/sh_lib:\
#{ENV['NONSHIPMENT_ROOT']}/hpl/sh_lib:\
#{ENV['NONSHIPMENT_ROOT']}/system/lib:\
#{ENV['NONSHIPMENT_ROOT']}/segments/eclipse/eclipseRE/xulrunner:\
/usr/local/lib:\
/opt/hp93000rt/el5/x86_64/berkeley-db4/lib"""
    ENV['ANT_HOME']="#{ENV['ENV_DEVTOOLS_ROOT']}/src/apache-ant-1.8.3"
    ENV['ANT']="#{ENV['ANT_HOME']}/bin/ant"
  end

  def process_arguments
    for argument in ARGV do
      arg = argument.downcase
      case
      when (arg == "offline" or arg == "of")
        if not defined?(@hardware_state)
          @hardware_state="offline"
        else
          ZTF::LOG.error "hardware mode is already set to #{@hardware_state}. It's not allowed to set it twice"
          print_usage()
          exit(1)
        end
      when (arg == "online" or arg == "on")
        if not defined?(@hardware_state)
          @hardware_state="online"
        else
          ZTF::LOG.error "hardware mode is already set to #{@hardware_state}. It's not allowed to set it twice"
          print_usage()
          exit(1)
        end
      when (arg == "-ksa" or arg == "-kill_smartest_after")
        ZTF::LOG.info "Smartest will shutdown automatically after test execution!"
        at_exit { kill_smartest_after() }
      when (arg == "-info")
        ZTF::LOG.puts "Java Integration Test"
        exit(0)
      when (arg == "-get_model_file")
        ZTF::LOG.puts "#{@model_file}"
        exit(0)
      when (arg == "-get_test_mode")
        ZTF::LOG.puts "#{@test_mode}"
        exit(0)
      when (arg == "-version" or arg == "--version" or arg == "-ver" or arg == "--ver" or arg == "-v")
        print_header
        exit(0)
      when (arg == "-help" or arg == "--help" or arg == "-h" or arg == "--h")
        print_usage()
        exit(0)
      when (arg.index("-log=") == 0)
        level = arg.sub("-log=","").strip.upcase
        allowed_levels = ['DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL']
        if allowed_levels.include?(level)
          ZTF::LOG.level = ZTF::ZenithLogger.const_get(level)
        else
          ZTF::LOG.error "wrong log level given: #{argument}, only #{allowed_levels.join(" ")} are allowed!"
          print_usage()
          exit(1)
        end
      else
        # we consider this arg is a model file
        file=argument
        file=File.join(Dir.getwd(),file) if file.index("/") != 0
        if File.readable?(file)
          @model_file = realpath(file)
        else
          ZTF::LOG.error "unknown argument '#{argument}'"
          print_usage()
          exit(1)
        end
      end
    end
    ARGV.clear

    # if test_mode is only offline or online, then it is clear that the user
    # want to execute in that mode by default
    # if test_mode is only offline or online, then it is clear that the user
    # want to execute in that mode by default
    if not defined?(@hardware_state)
      if @test_mode.split(",").size == 1
        @hardware_state = @test_mode.strip
        ZTF::LOG.info "Assume hardware state='#{@hardware_state}', since it is not set."
      else
        @hardware_state="offline"
      end
    end
    # verify whether the target hardware state is consistent with the test mode
    if not @test_mode.include?(@hardware_state)
      ZTF::LOG.info "Test is ignored since the test mode='#{@test_mode}', however hardware state='#{@hardware_state}'."
      exit(0)
    end
  end

  #
  # set variables needed, and verify the correctness
  #
  # ZTF_TEST_MODE or ZTF_INTEG_TEST_MODE  "offline, online"
  # ZTF_OFFLINE_MODEL_FILE
  # ZTF_REUSE_SMARTEST  "FALSE"
  #
  def set_validate_variables
    if @hardware_state=="online"
      @offline_mode = false
    else
      @offline_mode = true
    end


    @test_dir=Dir.getwd

    # model file is only used in offline mode
    # multiple model_file is not allowed here, needs to support it!
    (ZTF::LOG.error "model file #{@model_file} is not readable!"; exit(1)) if @offline_mode and @model_file!="" and (not File.readable?(@model_file))

    raise TestConfigError, "ERROR: test case directory '#{ENV['ZTF_TEST_CASES_DIR']}' doesn't exist.", caller unless File.directory?(ENV['ZTF_TEST_CASES_DIR'])
  end

  # Although java integ test don't have the concept of online/offline execution
  # mode for each test suite, we keep it as the same as ruby integ. test
  def set_test_attributes
    ZTF::TEST_ATTR.test_type = ZTF::TestAttribute::RUBY_INTEG_TEST
    if @offline_mode
      ZTF::TEST_ATTR.testLevel = /[spr]/
      ZTF::TEST_ATTR.testMode = /o/
      #runtest_cmd="#{@test_runner} TL_INTEG_ALL OFFLINE"
    else
      ZTF::TEST_ATTR.testLevel = /[spr]/
      ZTF::TEST_ATTR.testMode = /h/
      #runtest_cmd="#{@test_runner} TL_INTEG_ALL ONLINE"
    end
  end

  def setup_world
    super()
    @test_runner=File.join(ENV['ZTF_TEST_CASES_DIR'],"test.xml")
    raise TestConfigError, "ERROR: cannot find java unit test runner '#{@test_runner}'", caller unless File.exist?(@test_runner)
    print_header
  end

  # TODO: it's a duplicate from zenith_test_executor.rb, refactor it
  # it builds the SmarTest workspace
  # e.g. convert DSL -> xml
  def buildWorkspace
    smartest_workspace_project_map = "projects.map"
    # The workspace has been set explicitly in z_integ_test.ksh"
    # Build only this workspace
    smarTestWorkspace = ENV['ZTF_INTEG_TEST_WORKSPACE_DIR'] # TODO: update document
    # if not set, we search from current directory
    if smarTestWorkspace
      unless Dir.entries(smarTestWorkspace).include?(smartest_workspace_project_map)
        raise TestConfigError, "Given SmarTest workspace #{smarTestWorkspace} defined as env var ZTF_INTEG_TEST_WORKSPACE_DIR doesn't contain #{smartest_workspace_project_map}"
      end
    else
      Find.find(@testbed) do |path|
        if(File.basename(path) == smartest_workspace_project_map )
          smarTestWorkspace = File.dirname(path)
        end
      end
    end
    if smarTestWorkspace
      builder_cmd = "#{ENV['WORKSPACE']}/system/bin/tplc #{smarTestWorkspace} #{smarTestWorkspace}"
      execute_command("rm -rf "+ File.join(smarTestWorkspace, ".metadata")) # TODO: use ruby way
      execute_command(builder_cmd)
    else
      ZTF::LOG.warn "No SmarTest workspace found under #{ENV['PWD']}, skip buildworkspace step!"
    end
  end


  def run_test
    # switch pwd to testbed before tests run, @testbed is defined in base class
    Dir.chdir(@testbed)
    junit_path = "#{@testbed}/log/junit"
    FileUtils.mkdir(junit_path,:mode=>0777)
    
    buildWorkspace #TODO: be careful if smartest is not available,
      
    runtest_cmd="#{ENV['ANT']} -v -f #{@test_runner} coverage | tee -a #{junit_path}/junit.log"
    begin
      ZTF::LOG.info "Start executing the tests..."
      Timeout::timeout(@max_exec_time) do
        system(runtest_cmd) # This will load all tests and execute all tests
      end
    rescue Timeout::Error
      ZTF::LOG.puts ""
      ZTF::LOG.error "test execution exceeds time limit of #{@max_exec_time}s, force terminate the test!"
      Process.waitall
      @exit_value = ExitValue::KILLED # timeout is treated as a fatal instead of failure
    end
  end

  def kill_smartest_after()
    require "#{File.dirname(__FILE__)}/smartestutil"
    if ZTF.smartest_running?()
      ZTF::LOG.info "Shutting down SmarTest since argument '-kill_smartest_after' is given"
      ZTF.shutdown_smartest()
    end
  end

end

