#!/usr/bin/env zruby
begin
    $NONSHIPMENT_ROOT=ENV.fetch("NONSHIPMENT_ROOT","/opt/93000/src")
    require "#{$NONSHIPMENT_ROOT}/fw/TEST_TOOLS/RUBY/FWTest"

    #reset smarTest
    reset("*RST")
end