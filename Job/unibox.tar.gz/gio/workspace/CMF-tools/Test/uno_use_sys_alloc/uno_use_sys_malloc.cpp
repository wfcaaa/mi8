#include <cstdlib>
#include <cstring>

#include <rtl/alloc.h>

void *SAL_CALL rtl_allocateMemory(sal_Size Bytes) throw ()
{
  return malloc(Bytes);
}
void *SAL_CALL rtl_reallocateMemory(void *Ptr, sal_Size Bytes) throw ()
{
  return realloc(Ptr, Bytes);
}
void SAL_CALL rtl_freeMemory(void *Ptr) throw ()
{
  free(Ptr);
}
void *SAL_CALL rtl_allocateZeroMemory(sal_Size Bytes) throw ()
{
  return calloc(Bytes, 1);
}
void SAL_CALL rtl_freeZeroMemory(void *Ptr, sal_Size Bytes) throw ()
{
  memset(Ptr, 0, Bytes);
  free(Ptr);
}
