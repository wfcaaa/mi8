#/bin/bash
for i in $*
do
  if [[ "x"$XOC_MEMSCAPE_PROCESS = "x"$i ]]; then
    EXEC=$1
    shift 1
    exec /usr/contrib/bin/tview -mem ${EXEC} -a $*
  fi
done
exec $*
