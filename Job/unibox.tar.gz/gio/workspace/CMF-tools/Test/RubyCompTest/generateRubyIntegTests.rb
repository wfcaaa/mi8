#!/usr/bin/env zruby
# argv[0]:  output directory giving by users, relative directory
# argv[1]:  verbose: : true/false
# argv[2]:  force overwrite files: true/false
# $fileDir: full path of directory argv[0]

class GenerationRubyCompTests

def initialize
    locateDirectory
    ### no need to adapt makefile/scons anymore ###
    ### they are obsolete and replaced by botm. ###
    # editMakefileLocal
    # editScons
    ###############################################
    generate_ruby_integ_test_ksh
    generate_rubyIntegTester_rb
    generate_TestCase_Sample
end

def printErrorMsg(msg)
    puts "Error: #{msg}, generation of ruby integration test failed!"
end

def printInfo(msg)
    if ARGV[1] == "-verbose"
        puts(msg)
    end
end

def makeSureDirectoryExist(path)
    if !File.exist?(path)
        printErrorMsg("path '#{path}' does not exist")
        exit(false)
    end
end

def locateDirectory
    rubyDir = "#{ENV['COMPONENT_DIR']}/#{ARGV[0]}"
    if File.directory?(rubyDir)
        $fileDir = rubyDir
    elsif File.directory?(ARGV[0])
        $fileDir = ARGV[0]
    else
        printErrorMsg("path '#{ARGV[0]}' does not exist")
        exit(false)
    end
    slash = "/"
    if $fileDir!=nil and $fileDir[$fileDir.length-1] != slash
        $fileDir += slash
    end# $NONSHIPMENT_ROOT/test/system/offline/model.cs800"

end

def generateExecFile(filePath,filePrintPath,content,forceOverwrite)
    fileExist = File.exist?(filePath)
    begin
        if fileExist and forceOverwrite == "false"
            printInfo("Skip generating '#{filePrintPath}', file already exists!")
        else
            if fileExist
                printInfo("Overwriting '#{filePrintPath}'")
            else
                printInfo("Generating '#{filePrintPath}'")
            end
            f = File.open(filePath,"w")
            f << content
            f.close
            File.chmod(0775,filePath)
        end
    rescue Exception => e
        printErrorMsg(e.message)
        exit(false)
    end
end

def generate_ruby_integ_test_ksh
  # EOF style is not used bcz #{ENV['WORKSPACE']} is not treated as raw string
  content = '#! /bin/ksh
script_name=$0
test_dir=$(dirname $script_name)

# Change the current working directory to Test directory
cd $test_dir

# Defines where ruby test cases locate
export ZTF_RUBY_TEST_CASES_DIR="$PWD/Main"

#============================================================================#
# ZTF_TEST_MODE: specify required test modes, i.e. offline, online
# The test is executed if and only if hardware state and test mode matches.
#----------------------------------------------------------------------------#
export ZTF_TEST_MODE="offline"
# export ZTF_TEST_MODE="online"
# export ZTF_TEST_MODE="offline, online"

#============================================================================#
# ZTF_TEST_DEVICE_DIR: specify the device directory
# Otherwise, default value is configured by Featbuild
#----------------------------------------------------------------------------#
# export ZTF_TEST_DEVICE_DIR="$NONSHIPMENT_ROOT/test/devices/offline/"

#============================================================================#
# ZTF_OFFLINE_MODEL_FILE: specify the model file used in offline mode
# Otherwise, default value is configured by Featbuild
#----------------------------------------------------------------------------#
# export ZTF_OFFLINE_MODEL_FILE="$NONSHIPMENT_ROOT/test/system/offline/model.cs800"


$WORKSPACE/CMF-tools/Test/IntegTest/ruby_integ_test_global.ksh  $*

'
  filePath = "#{$fileDir}/z_integ_test.ksh"
  filePrintPath = "#{ARGV[0]}/z_integ_test.ksh"
  generateExecFile(filePath,filePrintPath,content,ARGV[2])
end

def generate_rubyIntegTester_rb
    # EOF style is not used bcz #{ENV['WORKSPACE']} is not treated as raw string
    content = %q{#!/usr/bin/env zruby
begin
require "#{ENV['WORKSPACE']}/CMF-tools/Test/RubyCompTest/ZenithTestFramework"

# For instructions see
# http://eshare.verigy.net/display/Disciplines/RubyIntegrationTestFramework

###########################################################################
#  This file is developer maintained.                                     #
#  The initial version file is generated automatically by a set of style  #
#  sheets, but requires manual changes for implementation specifics.      #
#  Warning, regenerating the file will require manual merging.            #
###########################################################################

##--Define your own WorldFixture approach using the following structure--##

=begin
class WorldFixture
  def self.setUpWorld
    # Implement your own setUpWorld method"
  end
  def self.tearDownWorld
    # Implement your own tearDownWorld method"
  end
end
=end

##----DONOT DELETE THE FOLLOWING LINES, WHICH LOAD AND RUN ALL TESTS----##
ZTF.runner(File.basename(__FILE__))

rescue Exception => e
  puts "\nERROR: #{e.class} exception raised with message: '#{e.to_s}'"
  puts "\nBacktrace: #{e.backtrace.join("\n\t")}\n"
  exit(1)
end
##-----------------------------END OF FILE-----------------------------##

}
    filePath = "#{$fileDir}/Main/rubyIntegTester.rb"
    filePrintPath = "#{ARGV[0]}/Main/rubyIntegTester.rb"
    generateExecFile(filePath,filePrintPath,content,ARGV[2])
end

def generate_TestCase_Sample
    content = '#!/usr/bin/env zruby
require "test/unit"

# For instructions see
# http://eshare.verigy.net/display/Disciplines/RubyIntegrationTestFramework

###########################################################################
#  This file is developer maintained.                                     #
#  The initial version file is generated automatically by a set of style  #
#  sheets, but requires manual changes for implementation specifics.      #
#  Warning, regenerating the file will require manual merging.            #
###########################################################################

class TestSuiteSample < Test::Unit::TestCase
  ### define your own implementation whether this test suite can run online
  ### return true if the test suite can run in online mode
  # def self.canRunOnline?
  # end

  def setup
    # define your own setup for each test method
  end
  def teardown
    # define your own teardown for each test method
  end

  # Names of member functions with pattern /^test*/ are test cases.
  def test_method_sample
    # user code
  end

  # This function will not be executed,
  # because its name doesn\'t start with "test"
  def ztestDummyTest
    # user code
  end
end

'
    filePath = "#{$fileDir}Main/testCaseSample.rb"
    filePrintPath = "#{ARGV[0]}/Main/testCaseSample.rb"
    generateExecFile(filePath,filePrintPath,content,ARGV[2])
end

end # end of class GenerationRubyCompTests

GenerationRubyCompTests.new
