#!/usr/bin/env zruby
#
# == Overview
#
# This file customizes ruby Test::Unit so that it behaviors similar to
# Cpp Component Test.
#
# All test cases in Ruby Component tests, Ruby Integration tests require this file
#
# Author::    Zhiwei Xu, 03.09.2012
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#

$VERBOSE=nil
STDOUT.sync = true
STDERR.sync = true

internal_dir = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal")
require "#{internal_dir}/zenith_test_libs"
require "#{internal_dir}/zenith_test_attribute"
require "#{internal_dir}/zenith_opt_paser"
require "#{internal_dir}/zenith_test_case"
require "#{internal_dir}/zenith_test_suite"
require "#{internal_dir}/zenith_test_runner"
require "#{internal_dir}/zenith_test_executor"

# UnoBridge is needed for every ruby test
require "#{ENV['WORKSPACE']}/lib/libservices_ruby_UnoBridge"
# some methods are used by users, e.g. reloadDevice

#module ZenithTestFramework in Ruby
module ZTF
  # This method is called in each individual test, e.g. Test*/Main/rubyIntegTester.rb
  def self.runner(exceptionFile)
    begin
      TestExecutor.new(exceptionFile).runner
    rescue TestConfigError => e
      ZTF::TEST_ATTR.exitvalue = ExitValue::ERROR
      ZTF::LOG.error exception2str(e)
    rescue Exception => e #TODO: should I rescue all?
      ZTF::TEST_ATTR.exitvalue = ExitValue::ERROR
      ZTF::LOG.error exception2str(e)
    ensure
      if ZTF::TEST_ATTR.test_type != ZTF::TEST_ATTR.class::RUBY_COMP_TEST and ENV['ZTF_START_SMARTEST'] == nil
      # we only do it when smartest is used in the test
        sAteRm2 = RubyUNO::xocGetService("xoc.ate.cor.rm2.ZAteResourceManager","xoc.ate.cor.rm2.ZSAteResourceManager")
        sAteRm2.setFwSiteStrategy(::Xoc::Ate::Cor::Rm2::FwSiteStrategy::FWMULTISITE)

        # check if UDA lock is released
        # TODO: move it to a better place, such kind of final check is growing
        uda_lock_manager = RubyUNO::xocGetImplementer("xoc.ate.cor.uda.ZUdaLockManager")
        if uda_lock_manager.breakLock
          ZTF::LOG.error "UDA lock was not released within test"
          ZTF::LOG.info "the UDA lock is now broken but the test has to be assessed as failed"
        end
        if uda_lock_manager.breakDebugLock
          ZTF::LOG.error "UDA debug lock was not released within test"
          ZTF::LOG.info "the UDA debug lock is now broken but the test has to be assessed as failed"
        end
      end
    end
 end

  # return true if current test mode is online
  def self.onlineMode?
    raise "Error: test mode is not defined yet!" if TEST_ATTR.testMode.nil?
    return true if TEST_ATTR.testMode == /h/
    return false
  end

  # return true if current test mode is offline
  def self.offlineMode?
    return (not ZTF.onlineMode?)
  end
end # end of module ZenithTestFramework in Ruby


# firstly guarantee that the last thing program does is it exits with expected value
# need to register it at the very beginning because other rb files may set
# at_exit ahead of it, which leads to incorrect exit value, e.g. FWTest.rb
at_exit { exit(ZTF::TEST_ATTR.exitvalue) }

# it parse options and save it to ZTF::TEST_ATTR
zenith_opt_parser(ARGV,ZTF::TEST_ATTR)
ARGV.clear
