#!/usr/bin/env zruby
require "test/unit/ui/console/testrunner"
require "#{ENV['WORKSPACE']}/lib/libservices_ruby_UnoBridge"

$listOfTests = Array.new
# default test level and mode
# $testLevel = 'r'
# $testMode = 'o'

# Overwrite method: Test::Unit::TestCase.suite & Test::Unit::TestCase.run
module Test
  module Unit
    class TestCase
      def self.suite
        method_names = public_instance_methods(true)
        tests = method_names.delete_if {|method_name| method_name !~ /^test./}
        suite = TestSuite.new(name)
        tests.sort.each do |test|
          catch(:invalid_test) do
            suite << new(test) if $listOfTests.empty? or $listOfTests.include?(name+'.'+test)
          end
        end
        # if (suite.empty?)
        # 	catch(:invalid_test) do
        # 		suite << new("default_test")
        # 	end
        # end
        return suite
      end

      def run(result)
        yield(STARTED, name)
        @_result = result
        begin
          setup
          __send__(@method_name)
        rescue AssertionFailedError => e
          add_failure(e.message, e.backtrace)
        rescue Exception
          raise if PASSTHROUGH_EXCEPTIONS.include? $!.class
          add_error($!)
        ensure
          begin
            teardown
          rescue AssertionFailedError => e
            add_failure(e.message, e.backtrace)
          rescue Exception
            raise if PASSTHROUGH_EXCEPTIONS.include? $!.class
            add_error($!)
          end
        end
        result.add_run
        @sArm.setFwSiteStrategy(::Xoc::Ate::Cor::Rm2::FwSiteStrategy::FWMULTISITE)
        yield(FINISHED, passed?) #overwrite standard 'yield(FINISHED, name)'
      end

      def name
        "#{self.class.name}.#{@method_name}"
      end
    end#end of class
  end
end

# Overwrite class Test::Unit::UI::Console::TestRunner
module Test
  module Unit
    module UI
      module Console
        class TestRunner
          extend TestRunnerUtilities
          @elapsedTime = @beginTime = 0
          def test_started(name)
            print "+TEST "+name + " : "
            @beginTime = Time.now
          end

          def test_finished(passed)
            @elapsedTime = Time.now - @beginTime
            if passed
              puts "PASSED (#{@elapsedTime}s)"
            else
              puts "FAILED (#{@elapsedTime}s)"
            end
            # output_single(".", PROGRESS_ONLY) unless (@already_outputted)
            # nl(VERBOSE)
            # @already_outputted = false
          end

          def add_fault(fault)
            @faults << fault
            # output_single(fault.single_character_display, PROGRESS_ONLY)
            @already_outputted = true
          end

          def started(result)
            @result = result
            output("Started")
          end

          def finished(elapsed_time)
            nl
            puts "----------------------------------------------------------------------"
            puts ("#{@result}, finished in #{elapsed_time}s.")
            puts "All Tests OK!\n======================================================================"  if @faults.empty?
            #print out fault tracing back info
            @faults.each_with_index do |fault, index|
              nl
              puts "----------------------------------------------------------------------"
              puts ("%3d) %s" % [index + 1, fault.long_display])
              puts "======================================================================"
            end
            nl
          end
        end #end of class TestRunner
      end #end of module Console
    end #end of module UI
  end #end of module Unit
end #end of module Test

class WorldFixture
  def self.setUpWorld
  end

  def self.tearDownWorld
  end
end

class RubyCompTester
  def self.initTestCaseSelection
    tag = ':'
    testCases = ENV['XOC_TEST_ONLY']
    if testCases!=nil
      if testCases[0]==tag[0] and testCases[testCases.size-1]==tag[0]
        $listOfTests = testCases[1..-1].split(tag)
        # $listOfTests.sort!
        # pp $listOfTests
      else
        warning = "Warning: syntax error in XOC_TEST_ONLY '"+ENV['XOC_TEST_ONLY']+"', executing all qualified tests."
        puts warning
        puts "----------------------------------------------------------------------"
      end
    else
      puts "XOC_TEST_ONLY not set, executing all qualified tests."
      puts "----------------------------------------------------------------------"
    end
  end

  def self.parseArg
    if ARGV[0]=="TL_INTEG_SUBPROJECT"
      $testLevel = /s/
    elsif ARGV[0]=="TL_INTEG_PROJECT"
      $testLevel = /p/
    elsif ARGV[0]=="TL_INTEG_RELEASE"
      $testLevel = /r/
    elsif ARGV[0]=="TL_INTEG_USER"
      $testLevel = /u/
    elsif ARGV[0]=="TL_INTEG_ALL"
      $testLevel = /[spr]/
    end

    if  ARGV[2]=="OFFLINE"
      $testMode = /o/
    elsif ARGV[2]=="ONLINE"
      $testMode = /h/
    end
    # puts $*
    # puts "Init result: "+$testLevel.to_s+" "+$testMode.to_s
  end

  # all test cases are added here
  def self.centralTestSuite
    suite = Test::Unit::TestSuite.new
    ObjectSpace.each_object(Class) do |obj|
      if Test::Unit::TestCase  > obj
        suite << obj.suite if RubyCompTester.runTest?(obj.to_s)
      end
    end
    return suite
  end

  def self.runTest?(classname)
    fullNotation  = /_Q([urpsoh]*)Q/i
    levelTag = /[urps]/i
    modeTag  =/[oh]/i

    #no _Q[level]Q sign found or only _QQ found, run always
    if classname.scan(/_Q\w+Q/).empty?
      return true
    end

    arr_status = classname.scan(fullNotation)
    status = arr_status[arr_status.length-1].to_s

    if status.empty?  #has _QQ sign, but has error inside
      puts classname+": has QQ sign, but exists error"
      return false
      # two situations cause not running the test suite
      # quality level is set, but test state and quality level don't match
      # hardware mode is set, but test state and hardware mode don't match
    elsif (status.index(levelTag)!=nil and status.index($testLevel)==nil) or \
    (status.index(modeTag)!=nil and status.index($testMode)==nil)
      return false

    else
      return true
    end
  end

  def self.loadTests(exceptionFile)
    dir = File.expand_path(ENV['RUBY_COMP_TEST_CASES_DIR']+'/*.rb')
    puts "Loading test suites: "
    Dir[dir].each do |file|
      if exceptionFile != File.basename(file)
        require file
        puts file
      end
    end
    puts "----------------------------------------------------------------------"
  end

  def self.runTests(exceptionFile)
    puts "\nTesting service #{ENV['SERVICE_NAME']}"
    puts "======================================================================"
    self.loadTests(exceptionFile)
    self.initTestCaseSelection()
    self.parseArg()

    WorldFixture.setUpWorld()
    runner = Test::Unit::UI::Console::TestRunner.run(self.centralTestSuite, Test::Unit::UI::PROGRESS_ONLY)
    WorldFixture.tearDownWorld()
  end

  def self.runner(exceptionFile)
    runTests(exceptionFile)
  end
end #end of class RubyCompTester