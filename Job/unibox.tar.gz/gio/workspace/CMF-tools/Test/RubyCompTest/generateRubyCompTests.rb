#!/usr/bin/env zruby
# argv[0]:  output directory giving by users, relative directory
# argv[1]:  verbose: : true/false
# argv[2]:  force overwrite files: true/false
# $fileDir: full path of directory argv[0]

class GenerationRubyCompTests

def initialize
  locateDirectory
  ### no need to adapt makefile/scons anymore ###
  ### they are obsolete and replaced by botm. ###
  # editMakefileLocal
  # editScons
  ###############################################
  generate_ruby_comp_test_ksh
  generate_rubyCompTester_local_rb
  generate_TestCase_Sample
end

def printErrorMsg(msg)
  puts "Error: #{msg}, generation of ruby component test failed!"
end

def printInfo(msg)
  if ARGV[1] == "-verbose"
    puts(msg)
  end
end

def makeSureDirectoryExist(path)
  if !File.exist?(path)
    printErrorMsg("path '#{path}' does not exist")
    exit(false)
  end
end

def locateDirectory
  rubyDir = "#{ENV['COMPONENT_DIR']}/#{ARGV[0]}"
  if File.directory?(rubyDir)
    $fileDir = rubyDir
  elsif File.directory?(ARGV[0])
    $fileDir = ARGV[0]
  else
    printErrorMsg("path '#{ARGV[0]}' does not exist")
    exit(false)
  end
  slash = "/"
  if $fileDir!=nil and $fileDir[$fileDir.length-1] != slash
    $fileDir += slash
  end
end

def generateExecFile(filePath,filePrintPath,content,forceOverwrite)
  fileExist = File.exist?(filePath)
  begin
    if fileExist and forceOverwrite == "false"
      printInfo("Skip generating '#{filePrintPath}', file already exists!")
    else
      if fileExist
        printInfo("Overwriting '#{filePrintPath}'")
      else
        printInfo("Generating '#{filePrintPath}'")
      end
      f = File.open(filePath,"w")
      f << content
      f.close
      File.chmod(0775,filePath)
    end
  rescue Exception => e
    printErrorMsg(e.message)
    exit(false)
  end

end

def generate_ruby_comp_test_ksh
  zCompDir = "#{$fileDir}z_comp_test.ksh"
  if File.exist?(zCompDir)
    printInfo("Adapting #{ARGV[0]}/z_comp_test.ksh")
    contentArr = Array.new
    makeSureDirectoryExist(zCompDir)
    File.open(zCompDir) do |file|
      file.each_line do |line|
        if line.include?("TEST_SERVICE_NAME") or line.include?("# Test component used to test the above component")
          #contentArr << "# It is obsolete in ruby component test\n"
          #contentArr << 'export TEST_SERVICE_NAME=" "'
          #contentArr << "\n"
          ;
        elsif line.include?("$WORKSPACE/CMF-tools/Test/z_comp_test_global.ksh")
          contentArr << "export ZTF_RUBY_TEST_CASES_DIR=\"$PWD/Main\" \n\n"
          contentArr << "$WORKSPACE/CMF-tools/Test/RubyCompTest/ruby_comp_test_global.ksh  $* \n"
        else
          contentArr << line
        end
      end
    end
    begin
      f = File.open(zCompDir,"w")
      contentArr.each { |line| f << line.to_s }
      f.close
      # File.chmod(0555,zCompDir)
    rescue Exception => e
      printErrorMsg(e.message)
      exit(false)
    end
  end
end

def generate_rubyCompTester_local_rb
  # EOF style is not used bcz #{ENV['WORKSPACE']} is not treated as raw string
  content = %q{#!/usr/bin/env zruby
begin
require "#{ENV['WORKSPACE']}/CMF-tools/Test/RubyCompTest/ZenithTestFramework"

# For instructions see
# http://socweb01.verigy.net/radix/bin/view/Test/RubyComponentTestFramework

###########################################################################
#  This file is developer maintained.                                     #
#  The initial version file is generated automatically by a set of style  #
#  sheets, but requires manual changes for implementation specifics.      #
#  Warning, regenerating the file will require manual merging.            #
###########################################################################

##--Define your own WorldFixture approach using the following structure--##

=begin
class WorldFixture
  def self.setUpWorld
    # Implement your own setUpWorld method
  end
  def self.tearDownWorld
    # Implement your own tearDownWorld method
  end
end
=end


##----DONOT DELETE THE FOLLOWING LINES, WHICH LOAD AND RUN ALL TESTS----##
ZTF.runner(File.basename(__FILE__))

rescue Exception => ex
  puts "\nERROR: #{e.class} exception raised with message: '#{e.to_s}'"
  puts "\nBacktrace: #{ex.backtrace.join("\n\t")}\n"
  exit(1)
end
##-----------------------------END OF FILE-----------------------------##

}
  filePath = "#{$fileDir}/Main/rubyCompTester.rb"
  filePrintPath = "#{ARGV[0]}/Main/rubyCompTester.rb"
  generateExecFile(filePath,filePrintPath,content,ARGV[2])
end

def generate_TestCase_Sample
  content = '#!/usr/bin/env zruby
require "test/unit"

# For instructions see
# http://eshare.verigy.net/display/Disciplines/RubyComponentTestFramework

###########################################################################
#  This file is developer maintained.                                     #
#  The initial version file is generated automatically by a set of style  #
#  sheets, but requires manual changes for implementation specifics.      #
#  Warning, regenerating the file will require manual merging.            #
###########################################################################

class TestSuiteSample < Test::Unit::TestCase
  def setup
  # define your own setup for each test method
  end
  def teardown
  # define your own teardown for each test method
  end

  # Names of member functions with pattern /^test*/ are test cases.
  def test_method_sample
    # user code
  end

  # This function will not be executed,
  # because its name doesn\'t start with "test"
  def ztestDummyTest
    # user code
  end
end

'
  filePath = "#{$fileDir}Main/testCaseSample.rb"
  filePrintPath = "#{ARGV[0]}/Main/testCaseSample.rb"
  generateExecFile(filePath,filePrintPath,content,ARGV[2])
end

######################################################################################################
############################### The following 2 functions are obsolete ###############################
# def editMakefileLocal
# 	printInfo("Adapting #{ARGV[0]}/TestBed/Makefile.local")
# 	if $fileDir != nil
# 		makefileDir = $fileDir+"TestBed/Makefile.local"
# 		contentArr = Array.new
# 		makeSureDirectoryExist(makefileDir)
# 		File.open(makefileDir) do |file|
# 			file.each_line do |line|
# 				if line.include?("TEST_LIB")
# 					contentArr << "TEST_LIB                = \n"
# 				else
# 					contentArr << line
# 				end
# 			end
# 		end
# 		begin
# 			f = File.open(makefileDir,"w")
# 			contentArr.each { |line| f << line.to_s }
# 			f.close
# 		rescue Exception => e
# 			printErrorMsg(e.message)
# 			exit(false)
# 		end
# 	end
# end
#
# def editScons
# 	printInfo("Adapting #{ARGV[0]}/TestBed/SConscript.local.py")
# 	if $fileDir != nil
# 		sconsDir = $fileDir+"TestBed/SConscript.local.py"
# 		outputComments = true
# 		contentArr = Array.new
# 		# read scons.local to array, and seperate { and } to independent lines
# 		makeSureDirectoryExist(sconsDir)
# 		File.open(sconsDir) do |file|
# 			file.each_line do |line|
# 				pos = line.index(/[{}]/)
# 				if pos != nil
# 					# remove the key 'TEST_LIB' since not needed in rubyCompTest
# 					if line.include?("'TEST_LIB'")
# 						if line.include?("{")
# 							contentArr << "{\n"
# 						else
# 							contentArr << "}\n"
# 						end
# 					else
# 						pos = 1 if pos == 0
# 						contentArr << line[0,pos]+"\n"
# 						contentArr << line[pos,line.length]
# 					end
# 				else
# 					contentArr << line
# 				end
# 			end
# 		end
# 		contentArr.each_index do |lineNum|
#  			contentArr[lineNum].lstrip!
# 			#if } is a seperate line, then make sure the line above don't end with comma ','
# 			if contentArr[lineNum].index("}") == 0
# 					contentArr[lineNum-1].rstrip!
# 					contentArr[lineNum-1].chomp!(",")
# 					contentArr[lineNum-1] += "\n"
# 					contentArr[lineNum] += "\n"
# 			elsif contentArr[lineNum].include?("# Don't forget to re-compile it(TestBed) after you modified this file")
# 				outputComments = false
# 			# remove CODE GENERATOR CHECKSUM in scons ==> comment out bcz the ksh-generation script will not overwrite scons.local
# 			# if checksum is removed, a scons.local.generated is created instead.
# 			# elsif contentArr[lineNum].include?("CODE GENERATOR CHECKSUM")
# 			# contentArr.delete_at(lineNum)
# 			end
# 		end
# 		begin
# 			f = File.open(sconsDir,"w")
# 			contentArr.each { |line| f << line.to_s }
# 			if outputComments
# 				f << "\n"
# 				f << "# Add co-components to key 'COMMON_LIBS', e.g. \n"
# 				f << "# Add library path of 'libservices_Md5Hasher.so' if you want to use component Md5Hasher.\n"
# 				f << "# 'COMMON_LIBS': ['#system/lib/libservices_Md5Hasher.so'] \n"
# 				f << "# Key 'TEST_LIB' is not needed, which is different from zenith component test in CxxTest.\n"
# 				f << "# Don't forget to re-compile it(TestBed) after you modified this file.\n"
# 				f << "\n"
# 			end
# 			f.close
# 		rescue Exception => e
# 			printErrorMsg(e.message)
# 			exit(false)
# 		end
# 	end
# end
######################################################################################################
end # end of class

GenerationRubyCompTests.new
