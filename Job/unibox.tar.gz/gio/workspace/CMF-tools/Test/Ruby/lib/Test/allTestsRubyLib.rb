#!/usr/bin/env ruby
# File: allTestsRubyLib.rb

require 'test/unit'

# list of all test cases ..
# @todo: generate this list ..
require 'tc_RunExecutable.rb'
