#!/usr/bin/env ruby
# ------------------------------------------- #
# RubyLib.rb:   supplies ruby utility classes #
# ------------------------------------------- #
require 'open3'

# see http://mentalized.net/journal/2010/03/08/5-ways-to-run-commands-from-ruby/
# runs executable, connects stdin, stdout & stderr
class RunExecutable
  attr_accessor :stdin, :stdout, :stderr
def initialize(exePathNameAndParams)
  @stdin, @stdout, @stderr = Open3.popen3("#{exePathNameAndParams}")
end
end # RunExecutable
