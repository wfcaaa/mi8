# tc_migration_cmd_query.rb
require "test/unit"
require "../RubyLib"

class TestRunExecutable < Test::Unit::TestCase
  def test_echo
    echo = RunExecutable.new(   "echo ok\n")
    assert_equal(               ["ok\n"],       echo.stdout.readlines)
  end
  def test_echo
    echo = RunExecutable.new(   ">&2 echo error\n")
    assert_equal(               [],             echo.stdout.readlines)
    assert_equal(               ["error\n"],    echo.stderr.readlines)
  end
end
