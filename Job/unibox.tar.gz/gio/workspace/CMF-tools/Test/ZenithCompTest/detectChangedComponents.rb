#! /usr/bin/env ruby
# Usage:
# 1.  This class is used for detecting changed component packages in current view in Zenith,
#     as well as the potential UnitTest directories which are changed or belonging to thoese changed components.
#     1.1. Note: component packages includes: jar, so, rdb
#     1.2  These UnitTest directories are kept in "listUnitTestsDirs" formed by 2 parts:
#          a. those UnitTests themselves which are changed.
#          b. If C++ Component packages, C++ Utility libraries or C++ libraries are changed, it means
#             UnitTests belonging to them should be executed as well. Thus the root directories of these
#             libs are added to "listUnitTestsDirs" as well.
#          c. This scheme is based on the assumption that all C++ UnitTests are located under the root dir
#             of their libraries under test.
#          d. The paths of directories are real paths, e.g. /vobs/zenith/service
# 2.  The detection is based on branched files, and a changed list is generated.
# 3.  This is designed for dynamic testing in Zenith Component Test.
# 4.  How to use it:
#       d = DetectChangedComponents.new()
#       puts ":::::::::Print result of Changed Components:::::::::"
#       d.listChangedComponents.each { |e| puts e.inspect }
#       puts ":::::::::Unit Test directories to be searched:::::::::"
#       d.listUnitTestsDirs.each     { |e| puts e.inspect }
# 5.  If utility libs are changed, then all component tests should be executed,
#     so use listChangedComponents=["__ALL_COMPONENTS__"] to present this scenario.
#####################################################################################################
#
#####################################################################################################
require 'pathname'
require 'set'
require 'pp'

## shut the warning of ruby up by this
$VERBOSE=nil

def vputs(str)
    if false
        puts str
    end
end

#########################################################################
#
class DetectChangedComponents
    attr_reader :listChangedComponents, :listUnitTestsDirs
    def initialize()
        @workspacePath  = ENV.fetch("WORKSPACE")
        @sconsName      = "SConscript.local.py"
        @testEverything = false
        @listChangedComponents = Set.new()
        @listUnitTestsDirs     = Set.new()
        @listChangedFiles      = Set.new()

        grep_changed_files()
        @listChangedFiles.each { |e| find_binded_component_dir(e) }
        # This means that all tests have to be run
        if @testEverything
            @listChangedComponents.clear
            @listChangedComponents.add("__ALL_COMPONENTS__")
        end
    end

    def grep_changed_files()
        if ENV['ENV_USE_SCM'] == "GIT"
          changed_files = `/opt/ate/tools/bin/gitate feature-changed-files`
          unless $? == 0
            $stderr.puts "ERROR: can not determine changed files, " +
                         "error msg is: #{changed_files}"
            exit 1
          end
          workspace_root = ENV.fetch('ENV_SCM_WORKSPACE_ROOT')
          changed_files.each_line { |line| @listChangedFiles << File.join(workspace_root, line.strip) }
        else
          bstdlibPath = ENV.fetch("TOOLS_LIBRARY_PATH","/bstd_tools/contrib/lib")
          changed_files = `#{bstdlibPath}/../lbin/lsenv -br`
          changed_files.each_line { |line|
              @listChangedFiles << line.split("@@")[0].strip
          }
        end
        #pp @listChangedFiles
    end

    def find_binded_component_dir(filePath)
        path        = filePath
        found_cdef  = false
        found_scons = false
        # Forget about legacy , here we only consider Zenith
        # Use /vobs/zenith because clearcase only provides physical path.
        while path.include?("vobs/zenith/") # or path =~ /^\/opt\/93000\/src\//
            vputs "Tracing back:  "+path
            parent_path = File.dirname(path)
            parent_dir  = Pathname.new(parent_path)

            # In some cases, source codes are located in 'src' directory,
            # however the scons file is located in 'Main'.
            # In such scenario, it should jump to Main directory so as to
            # find the real changed component pacakage.
            # e.g. hw/cor/HwResourceManager
            if File.basename(parent_path) == "src"
                found_src_dir = false
                vputs "=======Find src directory"
                grandpa_path = File.dirname(parent_path)
                files_under_grandpa_path = Dir[grandpa_path+"/*"].collect { |i| File.basename(i) }
                if files_under_grandpa_path.include?('Main')
                  found_src_dir = true
                  path = Dir[grandpa_path+"/Main/*"][0]
                  vputs "=======Find src directory, jump to some file in Main: #{path}"
                end
                next if found_src_dir
            end
            if parent_dir.exist?
              parent_dir.children(false).each do |item|
                if item.to_path == @sconsName
                  found_scons = true
                  vputs "found SCons: #{item.to_path} in #{path}"
                  break
                elsif item.to_path =~ /.cdef$/
                  found_cdef = true # ==> found cdef indicates a component dir
                  vputs "found cdef: #{item.to_path} in #{path} "
                  break
                end
              end
            end
            path = parent_path
            break if found_cdef or found_scons
        end
        if found_scons
            vputs "looking :"+path
            scons_local_py_path = path+'/'+@sconsName
            scons_cache = eval_scons_file(scons_local_py_path)
            if scons_cache == nil
                exit 1
            end

            # it is an array, not a string
            project_type = scons_cache['PROJECT_TYPE'].join.strip
            project_name = scons_cache['NAME'].join.strip
            case project_type
                when "cpp_component", "cpp_component_test"
                    lib_name = "lib#{project_name}.so"
                    # Found a changed componnet, add the root path
                    # so that Unit Tests under this path can be executed later on
                    @listUnitTestsDirs << File.dirname(path)
                when "java_component_package", "java_ant_jar"
                    lib_name = "#{project_name}.jar"
                when "rdb_package"
                    lib_name = "#{project_name}.rdb"
                when "cpp_component_exe"
                    # If it is a Unit Test, then no need to test everything
                    if scons_cache['CXXTEST_FILE'].nil? or scons_cache['CXXTEST_FILE'].join.strip == ""
                        # It means that it is a C++ Unit Test
                        @testEverything = true
                    else
                        # Found a unit test, add the root path of the test
                        # so that the test can be executed later on.
                        @listUnitTestsDirs << File.dirname(path)
                    end
                when "c_program"
                    @listUnitTestsDirs << File.dirname(path)
                    vputs "Found a c_program is changed, add it to Unit Test candidate list!"
                # These are C++ libs, Unit Tests may exists.
                when "utility_library", "shared_library"
                    @listUnitTestsDirs << File.dirname(path)
                    @testEverything = true
                when "utility_library_uno_ruby", "java_component_exe", "java_component_utility"
                    # run all tests
                    @testEverything = true
                when "hand_made"
                    puts "INFO: Can't believe you changed 'hand_made' project, don't tell me you are not Horst Perner?"
                when "ignore_RubyStandalone"
                    vputs "Deteced changes in PROJECT_TYPE 'ignore_RubyStandalone', the tool simply ignores it."
                else
                    $stderr.puts "WARNING: Found unknown PROJECT_TYPE '#{scons_cache['PROJECT_TYPE']}' in '#{scons_local_py_path}'"
            end
            @listChangedComponents << lib_name if lib_name

        elsif found_cdef
            vputs "looking :"+path
            Pathname.new(path).children(false).each { |item|
                vputs "...........#{item.to_path}"
                itemPath = item.to_path
                if itemPath =~ /.jar$/ or itemPath =~ /.rb$/ or itemPath =~ /.so$/
                    @listChangedComponents << itemPath #path+"/"+itemPath #.relative_path_from(@workspacePath)
                end
            }
        end
    end

    def eval_scons_file(scons_file_path)
        vputs "eval file: #{scons_file_path}"
        if not File.exists?(scons_file_path)
            $stderr.puts "ERROR: '#{scons_file_path}' does not exist!"
            return nil
        end
        f = File.open(scons_file_path,'r')
        cache = f.read
        cache.gsub!(":","=>")
        cache.gsub!(" ","")
        #IMPORTANT: format of certain scons files are not correct
        # need this to handle the case, e.g.
        # hw/cor/HwDependencies/Main/SConscript.local.py
        cache.gsub!("\n,",",")
        scons_cache = eval(cache)
        if scons_cache == nil
            $stderr.puts "ERROR: error occurs when processing scons file '#{scons_file_path}'!"
        end
        f.close()
        return scons_cache
    end
end

=begin
d = DetectChangedComponents.new
puts ":::::::::Print result of Changed Components:::::::::"
d.listChangedComponents.each { |e| puts e.inspect }
puts ":::::::::Unit Test directories to be searched:::::::::"
d.listUnitTestsDirs.each     { |e| puts e.inspect }
=end

################################################################################
#
################################################################################
