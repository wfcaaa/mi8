#!/usr/bin/env ruby
# This file is required in /bstd_tools/contrib/lib as well.

require 'pathname'

# ENV.expand_variables("$WORKSPACE") will expand the string
ENV.instance_eval do
  VAR_REGEX = /\$([a-zA-Z_]+[a-zA-Z0-9_]*)|\$\{(.+)\}/
  def expand_variables(s)
    s.gsub(VAR_REGEX) { self[$1||$2] }
  end
end

# Here by default it is set to 30 minutes if ZTF_TEST_TIMEOUT is not set.
def setmaximumtestexecutionduration()
    t = ENV.fetch("ZTF_TEST_TIMEOUT","30").to_i
    t = 30 if not t>0
    return t*60
end

# This function provide the feature of getting
# the name of current member function
module Kernel
# private
    def this_method_name
        caller[0] =~ /`([^']*)'/ and $1
    end
end

# Add kill function to class IO
# After a IO is opened, it is necessory to kill it if
# the parent process is also killed.
# Otherwise zombie process will occur!
module OwnIO
    #wait for children, prevent zombie processes
    def waitall
        Process.waitall
    end
end

class IO #add my own IO module to the normal IO class
    include OwnIO
end

def ERR(str)
    $stderr.puts str
end

# File.readlink does not work
# So here we need to re-implement it by myself
def readlink(path)
    return Pathname.new(path).realpath.to_s
end

# Return: 0 if session manager starts properly
# Otherwise certain error occurs
def ensure_session_manager_is_running()
    workspace = ENV.fetch("WORKSPACE","/vobs/zenith/workspace")
    # configure SystemLogger.conf for sessionconsole
    # set XOC_SYSTEM to services/session/sessionconsole/Test/TestBed
    # Because $W/system/etc is not available if legacy is not build
    xoc_system = File.join(workspace,"services/session/sessionconsole/Test/TestBed/")
    # configure SystemLogger.conf for sessionconsole
    prepareSystemLogger(xoc_system)
    check_if_running_session_manager = "XOC_SYSTEM=#{xoc_system} && #{workspace}/system/bin/sessionconsole > /dev/null"

    #    run_session_manager = "#{workspace}/system/bin/run -x /bin/true"
    run_session_manager = "#{workspace}/CMF-tools/bin/launchSessionmanagerRd -f > /dev/null"
    ps_session_manager  = "ps h -o pid -C xoc_session_manager"
    kill_session_manager  = "#{ps_session_manager} | xargs --no-run-if-empty kill"
    count_session_manager = "#{ps_session_manager} | wc -l"

    `#{check_if_running_session_manager}`
    status = $?.exitstatus
    if (status==0)
    # means session manager is running
        puts "The session manager is running"
        return 0
    elsif (status == 2)
    # means it is a incompatible session manager detected, kill it
        puts "Incompatible session manager detected. Killing xoc_session_manager..."
        `#{kill_session_manager}`
        sleep 3
        num = `#{count_session_manager}`.to_i
        if (num != 0)
            $stderr.puts "ERROR: could not kill incompatible xoc_session_manager."
            return 2
        end
    end
    # start session_manager now.
    puts "Start session manager now..."

    system(run_session_manager)
    status = $?.exitstatus
    sleep 3
    if status != 0
        $stderr.puts "ERROR: execution of '#{run_session_manager}' failed, please check your system configuration and re-run the program again!"
    end
    return status
end

# return the number of processors of current workstation
def processor_count
    return `cat /proc/cpuinfo | grep processor | wc -l`.to_i
end

# In some very rare cases, external programs do not exit properly after the
# ruby program terminated, which make them as zombie processes
# e.g. 'starter' process may exists even when comp_test is terminated.
def has_zombie_process?(name)
    # the min. value is 2, because following 2 processes always exist.
    #  25609 pts/11   S+  0:00 sh -c ps a|grep starter
    #  25611 pts/11   S+  0:00 grep starter
    sleep 2
    return `ps a |grep #{name} |wc -l`.to_i > 2
end

# prepare etc/SystemLogger.conf
# xoc_system: xoc_system/etc/SystemLogger.conf
# directories xoc_system/etc and xoc_system/log are created
# file xoc_system/etc/SystemLogger.conf is copied from template
def prepareSystemLogger(xoc_system)
    require 'fileutils'
    workspace = ENV.fetch("WORKSPACE","/vobs/zenith/workspace")
    logDir = File.join(xoc_system, "log")
    if not File.exist?(logDir)
        FileUtils.mkdir_p(logDir)
    end

    loggerSourcePath = File.join(workspace, "CMF-tools/Test/TestBedTemplate/etc/SystemLogger.conf")
    loggerDestDir = File.join(xoc_system, "etc")
    loggerDestPath = File.join(loggerDestDir, "SystemLogger.conf")
    if not File.exist?(loggerDestPath)
        FileUtils.mkdir_p(loggerDestDir)  if not File.exist?(loggerDestDir)
        if File.exist?(loggerSourcePath)
            FileUtils.copy_file(loggerSourcePath, loggerDestPath) #=> not work if path is a link
            #`/bin/cp #{loggerSourcePath} #{loggerDestPath}`
        else
            ERR("WARN: '#{loggerSourcePath}' does not exist, failed to copy it to '#{loggerDestPath}'!")
        end
    end
end

# check if set_envrionment script is called
def envset?()
  setenv_flag="FLAG_81519d0d_f267_47f2_8deb_fe2d491dd7c5"
  if(!ENV[setenv_flag])
    raise "ERROR: set_envrionment needs to be called first!"
  end
  true
end

def pid_alive?(pid)
  begin
    Process.getpgid( pid )
    true
  rescue Errno::ESRCH
    false
  end
end