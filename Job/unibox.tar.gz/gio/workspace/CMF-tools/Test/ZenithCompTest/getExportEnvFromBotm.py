#! /usr/bin/env python
# 1. This script reads the given botm file, and generate shell cmd which exports
# necessary env virables according to the botm file.
# 2. Other scripts can use eval command to execute these commands.
# The output looks like following:
# export UNO_JAVA_JFW_ENV_CLASSPATH=true;export CLASSPATH="/vobs/zenith/workspace/IDL/IdlInterfaces.jar"
#
# Such design is used because subprocess can not modify environment variables of
# parent processes and our parent script is shell not python
################################################################################

import os, sys
from TestMaterialDB import TestMaterialDB

def getRelativeAbsPath(path):
    dirPath = path
    if not os.path.isdir(path):
        dirPath = os.path.dirname(path)
    p = os.popen("cd "+dirPath+" && pwd")
    absPath = p.read().rstrip("\n")
    p.close()
    if not os.path.isdir(path):
        absPath = os.path.join(absPath, os.path.basename(path))
    return absPath

def usage():
    print "Usage: %s <BOTM_Path> " % __file__
    print "       BOTM_Path:  the path of botm file"

################################################################################
if __name__ == '__main__':
    if len(sys.argv) != 2:
        usage()
        sys.exit(1)
    else:
        # sys.argv[0] is the script itself
        arg = sys.argv[1]
        if arg.endswith(".botm"):
            BotmPath = getRelativeAbsPath(arg)
            if not os.access(BotmPath,os.F_OK):
                sys.exit("Error: bill-of-test-materials '%s' does not exist!\n" % BotmPath)
        else:
            usage()
            sys.exit(1)

    testMaterialDB = TestMaterialDB(BotmPath)
    uclList        = testMaterialDB.getUclList()
    utlList        = testMaterialDB.getUtlList()
    jarList =  [item for item in utlList if item.endswith(".jar")]
    jarList += [item for item in uclList if item.endswith(".jar")]
    ## tell UNO to use the CLASSPATH
    unoExport="export UNO_JAVA_JFW_ENV_CLASSPATH=true;"

    classpath = os.getenv("CLASSPATH")
    if classpath == None:
        jarExport = ":".join(jarList)
        exportString = unoExport+"export CLASSPATH='"+jarExport+"'"
    else:
        classpathList = classpath.split(":")
        for b in classpathList:
            try:
                jarList.remove(b)
            except ValueError:
                ""
        jarExport = ":".join(jarList)
        exportString = unoExport+'export CLASSPATH="'+os.getenv("CLASSPATH")+':'+jarExport+'"'
    print exportString
