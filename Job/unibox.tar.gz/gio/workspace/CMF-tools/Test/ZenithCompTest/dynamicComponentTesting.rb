#!/opt/rh-ng/ruby-200/root/usr/bin/ruby
# Usage:
# dynamicComponentTesting.rb [-mat package1.so package2.so]
#                            [-dir /some/place /somewhere/else]
#                            [-num 4]
#                            [-v | -verbose]
#                            [-log /path/to/log/file]
#                            [-debug]
#                            [-run_all_tests]
# All parameters are optional
# -mat: specify materials (component packages, utility libraries) to be tested
#        [default]: auto detect according to branched files in current view.
# -dir:  specify directories where to find component tests.
#        [default]: $WORKSPACE is always searched.
# -num:  number of threads can be used for running tests in parallel
#        [default]: number of processors on current workstation
# -log:  specify the path of log of testing result.
#        [default]: placed to $NONSHIPMENT_ROOT/com/release/dynamicComponentTest_<timestamp>.log
# -a | -all_tests | -run_all_tests:   run all unit/component tests
# Note: the fullpath of a component package is not necessory,
#       only the name of shared-object-file is enough.
#       It is also possible to just give keywords (instead of component names)
#       to select tests, e.g. hvmapi.
#       The trick is the program check whether the given lib-arguments matches
#       the fullpath of each component in botm file.
#       e.g. $WORKSPACE/integration/cor/hvmapi/HvmFacade/Test/libintegration_cor_hvmapi_HvmFacade.so
#       matches 'hvmapi', then this test is executed.
#
# 1. If file '$WORKSPACE/SConstruct.modules.py' exists, it is used as a cache of components.
#    BOTM files are located according to it and dependent tests are selected by BOTM files.
# 2. Apart from cache, it also searches directories so as to find depending tests additionally.
# 3. If -mat is not given, it will detect changed components automatically based on branched files
#    in current view (`lsenv -br`). Thus, all relevant tests will be executed automatically.
#    Moreover, changed unit tests and those unit tests located under the root directory of
#    changed components will be executed as well.
# 4. If -num is not given, it takes the number of processes of the current workstation.
#    Tests which are not listed in "$WORKSPACE/CMF-tools/Test/ZenithCompTest/parallel_component_testing_exceptions"
#    will be executed in parallel with the number of threads.
# 5. Each test has a max. running duration, it is hard coded to 30 minutes.
# 6. -debug: is used internally to print a complete execution information
# 7. Export env. variable ZTF_TEST_TIMEOUT to set the max. test execution time.
#    (Unit:minutes) e.g. export ZTF_TEST_TIMEOUT=10, means each test is allowed
#    to execute at most 10 minutes.
#####################################################################################################

require 'pathname'
require 'set'
require 'thread'
require 'timeout'
require "#{File.dirname(__FILE__)}/source_common_func"
require "#{File.dirname(__FILE__)}/detectChangedComponents"

# ruby output warning like "Insecure world writable dir" which is annoying
# set the global $VERBOSE=nil, to turn off the warning
verbose_backup = $VERBOSE
$VERBOSE = nil
STDOUT.sync = true
STDERR.sync = true

class DCTConfig
  class << self
    attr_accessor :workspace, :nonshipment_root, :sequentialTestsList, :generateRC
    attr_accessor :maxRunningTests, :maxTestExecTime, :allthreads
    attr_accessor :forceTerminate, :hasTestFail
  end
  self.workspace = ENV.fetch("WORKSPACE")
  self.nonshipment_root = ENV.fetch("NONSHIPMENT_ROOT")
  self.sequentialTestsList = "#{File.dirname(__FILE__)}/parallel_component_testing_exceptions"
  self.generateRC = "#{self.workspace}/CMF-tools/Test/ZenithCompTest/generateRCfromBOTM.py"
  # This value is either set by user
  # or equals to the number of processors of the machine
  self.maxRunningTests = processor_count()
  # Define the max. time in sec for each test
  # Test will be terminated by force when timeout
  self.maxTestExecTime = setmaximumtestexecutionduration()
  self.allthreads = []
  # Only set to true when users force terminate it
  self.forceTerminate = false
  self.hasTestFail = false

end

#########################################################################
# This class provides some static variables and methods
# so that it can be shared by inherited classes, e.g.
#   all followings are class variables:
#     dependLibs: an array including all materials to be tested
#     logFile: the file name for logging test results
#     verbose: whether to output verbose information
#     alreadyExecutedTests: prevent executing tests multiple times
#     countExecutedTests:   used for print summary
#     countFailingTests:    used for print summary
#
class DynamicTestingBasic
  def initialize(dependLibs, logFile, verbose=false, debug_mode=false, run_all_tests=false)
    # dependLibs, verbose, logFile shouldn't be modified by inherited classes
    @@dependLibs = dependLibs
    @@verbose    = verbose
    @@logFile    = logFile
    @@runAllTests= run_all_tests
    # set debug mode with command is not supported
    # Only used internally by hard code
    @@debugMode  = debug_mode
    @@generateRC = DCTConfig.generateRC
    @@sharedBOTMs= Set.new()

    @@mutex                = Mutex.new
    @@alreadyExecutedTests = Set.new()
    @@countExecutedTests   = 0
    @@countFailingTests    = 0
    @@numberOfRunningTests = 0

    @@waitingConcurrentTests = Queue.new
    @@waitingSequentialTests = Queue.new
    @@sequentialTestsList    = DCTConfig.sequentialTestsList
    # this is generated according to @sequentialTestsList
    @@sequentialTestsWhiteList = []
    init_sequential_tests_list
  end

  def init_sequential_tests_list()
    if File.exist?(@@sequentialTestsList)
      f = File.open(@@sequentialTestsList, 'r')
      f.each_line { |l|
        if l.strip! == "" or l.index("#") == 0
          next
        else
          @@sequentialTestsWhiteList << ENV.expand_variables(l)
        end
      }
    end
  end

  # botmPath: full path of a botm file
  def find_test_and_execute(botmPath)
    botmfiles = Set.new
    if is_relevant_test(botmPath,botmfiles)
      ksh = File.join(File.dirname(botmPath), "z_comp_test.ksh")
      if File.exist?(ksh) and is_offline_test?(ksh)
        execute_test(ksh, botmPath)
      else
        puts("Test does not exist: "+ksh) if @@verbose
      end
    end
  end

  def is_relevant_test(botm,botmfiles)
    if not botm =~ /.botm$/
      return false
    end
    # prevent recursive botm files
    if botmfiles.include?(botm)
      return false
    else
      botmfiles << botm
    end

    return true if @@runAllTests

    File.open(botm, "r") do |infile|
      while (line = infile.gets)
        if line =~ /#/
          next
        end
        data = line.split
        if not data.size==4 or not data[3]=="y"
          next
        end
        if not data[0].upcase=="BOTM"
          # get the fullpath of the material of each line
          # check whether it matches the materials specified by the user
          libFullPath = get_file_fullpath(line.split()[1,2])
          if lib_included(libFullPath, @@dependLibs)
            return true
          end
        else
          nestedBotm = get_file_fullpath(data[1,2]) # i.e. data[1] & data[2]
          # Note:
          # NestedBotm files are normally shared by many component tests
          # Thus, these RDBs must be generated ahead of running tests in parallel!!!
          # Update: nestedBotm are generated in DynamicTestingBySconsCache
          #   so comment the following line out
          # generate_rc_from_botm(nestedBotm)
          if nestedBotm != nil and is_relevant_test(nestedBotm,botmfiles)
            return true
          end
        end
      end # end of while
    end #end of File open

    return false
  end

  # dynamicComponentTesting only supports offline tests
  # since there are limited online tests and there is no good reason to have
  # online dynamic component testing at the moment
  def is_offline_test?(ksh)
    value= `#{ksh} -get_test_mode`.split("\n")
    if $?!=0 or value == nil or value.size == 0
      return true
    else
      return value[0].include?("offline")
    end
  end

  # Full path of botm is manditory
  # For those RDBs shared by many component tests,
  # they must be generated ahead of running tests in parallel!!!
  # Moreover, they are listed as a nested BOTM entry in BOTM files.
  # So these nested BOTMs must be created ahead!
  def generate_rc_from_botm(botmPath)
    if @@sharedBOTMs.add?(botmPath)
      command = @@generateRC + " " + botmPath + " 2>&1 1>/dev/null"
      puts "Executing #{command} ..." if @@debugMode
      system(command)
      if $? != 0
        $stderr.puts "ERROR: error occurs during execution of #{command}, terminate the testing!"
        exit(1)
      end
    end
  end

  # In BOTM: path in legacy is a full path,
  #          path in zenith is not, workspace is missing
  # Here it receive a pathArray,
  # Return the fullpath if it exists, 'nil' otherwise
  def get_file_fullpath(pathList)
    fullpath = ""
    if pathList.instance_of?(String)
      fullpath = pathList
    elsif pathList.instance_of?(Array)
      fullpath = pathList.join("/")
    else
      puts "WARN: #{self.class.name}::#{self.this_method_name}: type #{pathList.class} is not supported!"
      return nil
    end
    if fullpath.index('/')!=0
      fullpath = File.join(DCTConfig.workspace, fullpath)
    end
    if File.exist?(fullpath)
      return fullpath
    else
      puts "WARN: #{self.class.name}::#{self.this_method_name}: file #{fullpath} does not exist." if @@verbose
      return nil
    end
  end

  # find whether a string includes any element of a given array
  def lib_included(string, array)
    if string != nil
      array.each do |item|
        if string.include?(item)
          return true
        end
      end
    end
    return false
  end

  # command for component test always consists two parts, "z_comp_test.ksh  *.botm"
  # command for unit test only have one part, z_comp_test.ksh
  def format_command_to_output(command, timeStart,exitstatus)
    comm_arr = command.split
    pretty_test_runner =  comm_arr[0].sub("/z_comp_test.ksh", "")
    pretty_test_runner.sub!(DCTConfig.nonshipment_root, "$NONSHIPMENT_ROOT")
    pretty_test_runner.sub!(DCTConfig.workspace, "$WORKSPACE")
    if comm_arr.size == 1 # means it is a unit test
      info = "+UNIT_TEST '#{pretty_test_runner}'".ljust(100)
    else
      # reduce info, do not print standard botm info
      test_botm_name = File.basename(comm_arr[1]).sub("bill-of-test-materials.botm", "")
      pretty_test_runner = "#{pretty_test_runner}  #{test_botm_name}".strip
      info = "+COMP_TEST '#{pretty_test_runner}'".ljust(100)
    end
    test_result = "(#{(Time.now-timeStart).round(1)}s)"
    test_result += "\n" if @@verbose

    if exitstatus != 0
      test_result = "#{info}: FAILED "+test_result
      DCTConfig.hasTestFail=true
    else
      test_result = "#{info}: PASSED "+test_result
    end
    return test_result
  end

  def write_to_file(log)
    f=File.open(@@logFile,"a")
    f.write(log)
    f.close()
  end

  # format of command:
  # /path/to/z_comp_test.ksh  /path/to/name.botm
  def run_test(command)
    @@mutex.lock
    @@countExecutedTests   += 1
    @@numberOfRunningTests += 1
    @@countFailingTests    += 1 #==> we first assume tests fails
    @@mutex.unlock
    #puts "executing a test #{ksh}, current number #{$numberOfRunningTests}, executed tests #{$executedTests}"

    command += " -verbose" if @@verbose
    Thread.current[:timeStart] = Time.now

    # not only save the log as a string, but also output to terminal
    Thread.current[:testLog] = ""
    exitstatus = 1
    begin
      Timeout::timeout(DCTConfig.maxTestExecTime) {
        pipe = IO.popen(command+" 2>&1")
        #pipe = IO.popen("echo '"+command+" 2>&1' && sleep 1")
        Thread.current[:io] = pipe
        pipe.each do |line|
          Thread.current[:testLog] += line
          puts command.split("/")[-3]+"::"+line if @@debugMode
        end
        pipe.close
        exitstatus = $?.exitstatus
      }
    rescue Timeout::Error
      Thread.current[:testLog] += "\nERROR: timeout for test execution, force terminate the test!\n"
      Thread.current[:io].waitall
    end
    test_result = format_command_to_output(command, Thread.current[:timeStart], exitstatus)

    @@mutex.lock
    if exitstatus != 0
      puts Thread.current[:testLog] if not DCTConfig.forceTerminate
    else
      @@countFailingTests -= 1
    end
    puts test_result  #+", waitingConcurrentTests size: #{@waitingConcurrentTests.size}"
    write_to_file(Thread.current[:testLog]+test_result)
    @@numberOfRunningTests -= 1
    @@mutex.unlock
    $stdout.flush
  end

  def run_test_in_subprocess()
  if @@numberOfRunningTests < DCTConfig.maxRunningTests and
     @@waitingConcurrentTests.size > 0
      DCTConfig.allthreads << Thread.new {
        Thread.current[:ksh]    = @@waitingConcurrentTests.pop
        run_test(Thread.current[:ksh])
        run_test_in_subprocess() if not DCTConfig.forceTerminate
      }
    end
  end

  # It checks whether a test is exectued before
  # and push new tests to $waitingConcurrentTests so that
  # test-execution thread can run them sequentially
  def execute_test(ksh, botm)
    real_ksh_path = Pathname.new(ksh).realpath.to_path
    real_botm_path = Pathname.new(botm).realpath.to_path
    real_command = real_ksh_path + " " + real_botm_path
    command = ksh + " " + botm

    @@mutex.lock
    if @@alreadyExecutedTests.include?(real_command)
      @@mutex.unlock
      puts "Skip duplicate test: #{command}" if @@debugMode
      return
    else
      @@alreadyExecutedTests.add(real_command)
      @@mutex.unlock
      if not sequential_test?(ksh, botm)
        @@waitingConcurrentTests.push(command)
        run_test_in_subprocess()
      else
        @@waitingSequentialTests.push(command)
      end
    end
  end

  # Some comp. tests cannot be executed concurrently
  # These tests have to be executed after running of concurrent tests finishes.
  def sequential_test?(ksh, botm)
    return matched_sequential_tests_whitelist?(ksh)
  end

  def matched_sequential_tests_whitelist?(ksh)
    @@sequentialTestsWhiteList.each { |item|
      if ksh.index(item) != nil
        puts "Found '#{ksh}' which needs to be run sequentially!" if @@debugMode
        return true
      end
    }
    return false
  end

  def run_sequential_tests()
    puts "Start running following tests sequentially ...." if @@waitingSequentialTests.size > 0
    until @@waitingSequentialTests.size == 0
      run_test(@@waitingSequentialTests.pop)
    end
  end

  def show_result(testBeginTime)
    summary = "\n=====> Summary: #{@@countFailingTests} tests failed, executed #{@@countExecutedTests} tests, spent #{((Time.now-testBeginTime)/60).round} min"
    puts summary
    if File.exists?(@@logFile)
      result = "\n\n=====> Execution Result of: dynamicComponentTest.ksh " + ARGV.join(" ")
      write_to_file(result+summary)
      puts "=====> Check log '#{@@logFile}' for the details."
    else
      puts "=====> No log generated."
    end
  end
end

class DynamicTestingBySconsCache < DynamicTestingBasic
  # dependLibs: Array including all component packages to be tested
  # searchDirs: Array including all paths to be searched
  # blackListOfDirs: directories matches this will be ignored
  #                  => speed up the search duration
  # verbose: output verbose information
  def initialize(scons_cache)
    @scons_cache = scons_cache
    @compList = []
    begin
      if not File.exists?(scons_cache)
        return
      end
      f = File.open(scons_cache,'r')
      cache = f.read
      cache.gsub!(":","=>")
      comp_cache = eval(cache)
      # eval may fails if Scons-cache is empty or has error
      if not comp_cache
        return
      end
      for key in comp_cache.keys()
        # TODO: ====> in furture, prjoect type "test" will be gone
        if key != "test"
          @compList.concat(comp_cache[key])
        end
      end
      f.close()
    rescue StandardError => e
      puts "Ooo...: #{e}"
      return
    end

    # before executing tests in parallel, we need to generate RC for embeded botm files
    generateAllEmbededRC(@compList)

    puts "INFO: starting to execute tests"
    for l in @compList
      fullpath = get_file_fullpath(l)
      if fullpath==nil
        next
      end
      # Sconscript is under 'Test/Main/Sconscript',
      # botm is in grandparent dir.
      botm_dir = File.dirname(File.dirname(fullpath))
      Dir.foreach(botm_dir) do |file|
        find_test_and_execute(botm_dir+'/'+file)
      end
    end
  end

  def generateAllEmbededRC(dirlist)
    puts "INFO: generating central botm files"
    @generatedBotmList = Set.new
    dirlist.each do |dir|
      fullpath = get_file_fullpath(dir)
      if fullpath==nil
        next
      end
      # Sconscript is under 'Test/Main/Sconscript',
      # botm is in grandparent dir.
      botm_dir = File.dirname(File.dirname(fullpath))
      Dir.entries(botm_dir).select { |f| f=~ /.botm$/ }.each do |file|
        botmfile = File.join(botm_dir,file)
        generateEmbededBOTM(botmfile)
      end
    end
  end

  # return an Array of botm files with fullpath
  def generateEmbededBOTM(botmfile)
    File.open(botmfile, "r") do |infile|
      while (line = infile.gets)
        if line =~ /#/
          next
        end
        data = line.split
        if not data.size==4 or not data[3]=="y"
          next
        end
        if data[0].upcase=="BOTM"
          nestedBotm = get_file_fullpath(data[1,2]) # i.e. data[1] & data[2]
          if nestedBotm != nil and @generatedBotmList.add?(nestedBotm)
            puts "INFO: generate rc from botm #{nestedBotm}" if @@verbose
            generate_rc_from_botm(nestedBotm)
          end
        end
      end # end of while
    end #end of File open
  end
end

################################################################################
# This class search dependend test executors of given component packages in
# given directories, which is done by reading the BOTM files.
#
# For all dependent tests, they are executed in a seperate thread sequentially.
# It is not suitable to execute tests concurrently with multiple threads, since
# the session manager may not work properly in such scenario.
#
# It also executes all C++ Unit Tests, which based on @unittestSearchDirs
# generated by:
# 1. the analysis result of Changed components script. The script detects
#    directories of changed unit tests and root directories of changed
#    components, utility libs and shared libs, where UnitTests could exist!
# 2. the material given by users. It assumes that the material's path is also
#    the path of unit tests. So it tries to complete the path of given material:
#    2.1  If "mat" specified is a path of directory, simply add it to the list
#    2.2  If a path of ".so" file, add the parent directory to the list
#    2.3  If a relative path, then it assumes that $WORKSPACE is omitted
#         the complete path is added.
#         NOTE: simply add the relative path to the list is wrong, e.g.
#         services/Md5Hasher
#         A path of Unit Test is always using the physical path, so the path of
#         a unit test of Md5Hasher is $WORKSPACE/services/Md5Hasher/UnitTest
#         ==> which does not match the relative path "services/Md5Hasher"
#    2.3  If only "*.so" without a path, it tries to find the complete path
#         of the library and add the directory to the list
#    2.4  In other cases, e.g. only keywords are given, like "session", they are
#         also added to the list
#   NOTE: During the program searches directories, it checks whether the path of
#         a unit test matches the @unittestSearchDirs. The test is executed only
#         if it matches.
#   NOTE: It assume that all UnitTests locates under the root dir of the component
#         under test.

class DynamicTestingBySearchingDirs < DynamicTestingBasic
  # searchDirs: Array including all paths to be searched
  # blackListOfDirs: directories matches this will be ignored
  #                  => speed up the search duration
  def initialize(searchDirs, unittestSearchDirs, blackListOfDirs)
    @searchDirs      = searchDirs
    @blackListOfDirs          = blackListOfDirs
    #puts "Searching dependent tests for materials \"#{@@dependLibs.join(" ")}\" in directories \"#{@searchDirs.join(" ")}\""
    ## Note: dirs in @unittestSearchDirs are physical paths.
    @unittestSearchDirs      = unittestSearchDirs

    search_dependent_tests()
  end

  def search_dependent_tests()
    @searchDirs.each { |dir| all_files_under(dir) }
  end

  def is_unittest?(path)
    ksh = path
    if ksh =~ /\/z_comp_test.ksh$/ and is_unittest_included?(ksh)
      result = `#{ksh} -info`
      if result.split("\n").size > 0
        if result.split("\n")[0].include?("C++ Unit Test")
          return true
        end
      else
        puts "INFO: found a non-Standard test, #{ksh}, which is neither a Unit Test nor a Component Test." if @@verbose
      end
    end
    return false
  end

  # the unit test should be included in the @unittestSearchDirs
  # not all unit tests should be executed!
  def is_unittest_included?(ksh)
    @unittestSearchDirs.each do |e|
      realKsh = readlink(ksh)
      if ksh.include?(e) or (realKsh and realKsh.include?(e))
        return true
      end
    end
    return false
  end

  # Overwrite the Base class method
  # It checks whether it is a Unit Test instead of componet test
  def find_test_and_execute(path)
    super # run super -> find_test_and_execute(path)
    if is_unittest?(path)
      execute_unittest(path)
    end
  end

  def execute_unittest(ksh)
    real_command = Pathname.new(ksh).realpath.to_path
    command = ksh

    @@mutex.lock
    if @@alreadyExecutedTests.include?(real_command)
      puts "Skip duplicate test: #{command}" if @@debugMode
      @@mutex.unlock
      return
    else
      @@alreadyExecutedTests.add(real_command)
      @@mutex.unlock
      @@waitingConcurrentTests.push(command)
      run_test_in_subprocess()
    end
  end

  def all_files_under(*paths)
    paths.flatten!
    paths.delete_if { |d| File.directory?(d) and matched_blacklist_of_dirs?(d.to_s) }
    paths.map! { |p| Pathname.new(p) }
    paths.each do |item|
      if item.file?()
        find_test_and_execute(item.to_path)
        next
      end
      begin
        if item.symlink?
          # The following one is not elegent, use the rb method instead
          # realPath = `/usr/bin/readlink -f #{item} 2>/dev/null`.strip
          realPath = item.realpath.to_path
          orginPath = File.join(item.dirname.realpath.to_path,item.basename)
          if realPath.empty? or orginPath.index(realPath)==0
            puts "WARN: find recursive link #{item.to_path} --- #{realPath}" if not realPath.empty? and @@debugMode
            next
          end
        end
      rescue Errno::ENOENT => e
        #mostly these errors are "No such file or directory" errors
        puts e if $VERBOSE
      rescue SystemCallError => e
        #mostly these errors are "No such file or directory" errors
        puts e if @@debugMode
      rescue StandardError => e
        puts e.inspect, e
      end
      begin
        all_files_under(item.children) if item.directory?()
      # exception could raise during item.children
      rescue Errno::ENOENT => e
        puts e if @@debugMode
      end
    end # end of paths.each
  end

  def matched_blacklist_of_dirs?(dir)
    @blackListOfDirs.each { |item|
      if dir.index(item)
        return true
      end
    }
    return false
  end
end

##############################################################################
# This class parses the arguments and generate a inital set of data, feeding
# them to the real testing class.
#
class PrepareExecution
  attr_reader :debugMode, :verbose, :dependLibs, :unitTestsDirs, \
  :searchDirs, :blackListOfDirs, :logName, :testAllComponent
  def initialize(scons_cache)
    @sconsCachePath  = scons_cache
    @testAllTag      = "__ALL_COMPONENTS__"
    @testAllComponent= false
    @verbose         = false
    @debugMode       = false
    @dependLibs      = []
    @searchDirs      = []
    # @unitTestsDirs only contains physical paths
    @unitTestsDirs   = []
    @blackListOfDirs = []
    @startTime       = Time.now
    current_time_name = @startTime.strftime("%Y%m%d_%H%M%S")

    if ENV['ENV_USE_SCM'] == "GIT"
      workspace_root = ENV.fetch('ENV_SCM_WORKSPACE_ROOT')
      @logName  = "#{DCTConfig.nonshipment_root}/com/release/dynamicComponentTest#{workspace_root.gsub("/","-")}_#{current_time_name}.log"
    else
      current_view_name = `cleartool pwv -s`.chomp
      # the default log path
      @logName  = "#{DCTConfig.nonshipment_root}/com/release/dynamicComponentTest_#{current_view_name}_#{current_time_name}.log"
    end
    indicator = :mat
    # It stores the fullpath of each "cpp library"
    @cpplibraryPathSet = Set.new()
    ARGV.each do |arg|
      if arg =~ /^-/
        if    arg == "-mat"
          indicator =:mat
        elsif arg == "-dir"
          indicator =:dir
        elsif arg == "-log"
          indicator =:log
        elsif arg == "-num"
          indicator =:num
        elsif arg == "-v" or arg == "-verbose"
          @verbose  = true
        elsif arg == "-debug"
          @debugMode= true
          @verbose  = true
        elsif arg == "-run_all_tests" or arg == "-a" or arg == "-all_tests"
          @testAllComponent = true
          # if run all tests, we run all legacy tests as well
          legacy = ENV['NONSHIPMENT_ROOT']
          @searchDirs.push(legacy) if legacy and not @searchDirs.include?(legacy)
        elsif arg == "-h" or arg == "-help"
          help_info()
        else
          help_info("Unkown parameter: #{arg}")
        end
      else
        insert(indicator,arg)
      end
    end
    # Prevent that users both set -mat and -run_all_tests
    if @testAllComponent
      @dependLibs = []
    end

    # Here it provide a default search directory, i.e. $WORKSPACE
    init_search_dirs()

    # If users donot specify any lib, find all changed libs automatically
    # otherwise prepare given materials and unit tests dirs.
    detect_components_under_test()

    init_other_variables()

    if @debugMode
      pp "Unit Tests paths are: ",@unitTestsDirs
      pp "dependLibs are: ",@dependLibs
      pp "searchDirs are: ",@searchDirs
      pp "blackListOfDirs are: ",@blackListOfDirs
    end
    $stdout.flush
  end

  # init @blackListOfDirs and $maximumRunningTests.
  # There are certain directories are completely not worthing to search,
  # They are ignored during searching so as to speed up the duration
  def init_other_variables()
    @blackListOfDirs.push("lost+found")
    @blackListOfDirs.push(DCTConfig.workspace+"/system/")
    @blackListOfDirs.push(DCTConfig.workspace+"/include/")
    @blackListOfDirs.push(DCTConfig.workspace+"/lib/")
    @blackListOfDirs.push(DCTConfig.workspace+"/CMF-tools/")
    @blackListOfDirs.push("/TestBed/")
    @blackListOfDirs.push("/TestBed1/")
    @blackListOfDirs.push("/TestBed_online/")
    @blackListOfDirs.push("/TestBed_online1/")
  end

  # Since $WORKSPACE is always considered,
  # any path under $WORKSPACE specified by users is not necessary and can be deleted.
  def init_search_dirs()
    new_search_dirs = [DCTConfig.workspace]
    @searchDirs.each { |item|
      if item.index('/')!=0
        item = File.join(ENV['PWD'], item)
      end
      if item.index(DCTConfig.workspace)!=0
        new_search_dirs.push(item)
      end
    }
    @searchDirs = new_search_dirs
  end

  def detect_components_under_test()
    if @dependLibs.size==0
      if not @testAllComponent
        puts "INFO: no material is specified, detecting changed materials automatically for you ..."
        detect_changed_components = DetectChangedComponents.new()
        detect_changed_components.listChangedComponents.each { |item| @dependLibs    << item }
        detect_changed_components.listUnitTestsDirs.each     { |item| @unitTestsDirs << item }
        if @dependLibs == [ @testAllTag ]
          puts "Detected that all component tests should be executed."
          @testAllComponent = true
          starting_info = "Running all component tests"
        elsif @dependLibs.size > 0
          print "Detected the following changed components: "
          @dependLibs.each { |item| print item+"  " }
          puts ""
          starting_info = "Running dependent tests for materials \"#{@dependLibs.join(" ")}\""
          starting_info += " and unit tests #{@unitTestsDirs.join(' ')}" if @unitTestsDirs.size > 0
        else
          puts "No test need to be run, since no material is specified or changed!"
        end
      else
        starting_info = "Running all unit/component tests"
        # Unit Tests need to be executed as well since the user speficfies "run all tests" mode
        # @unitTestsDirs only use physical path
        @searchDirs.each { |dir| @unitTestsDirs << readlink(dir) }
      end
    else
      generate_cpplibraryset()
      # Try to find the complete path of each given material
      # And treat each existing path as a Unit Test Directory.
      @dependLibs.each { |item|
        path = find_mat_path_for_unittest(item)
        @unitTestsDirs << path if path
      }
      @unitTestsDirs.flatten!

      if contain_utility_lib?()
        @testAllComponent = true
        starting_info = "Found that a utility library is specified, so all component tests will be run"
      else
        starting_info = "Running dependent tests for materials \"#{@dependLibs.join(" ")}\""
      end
    end
    puts starting_info+" in directory \"#{@searchDirs.join(" ")}\" on #{@startTime.to_s}." if starting_info
  end

  # This method tries to find out the fullpath of the directory of an item
  # Return: directory of the item or nil
  # Try to find the complete path of each given material,
  # And treat each existing path as a Unit Test Directory.
  def find_mat_path_for_unittest(item)
    if item.index("/")!=0 # means it is a relative path
      path = File.join(DCTConfig.workspace, item)
      if File.exist?(path)
        ## means the user gives a "relative complete" path of the material under test
        if not File.directory?(path)
          path = File.dirname(path) #remove the "*.so" part
        end
        return readlink(path)
      else
        ## means the material user given is not a "relative complete" path
        ## e.g. only the lib name is given, libMd5Hasher.so
        ## or   Md5Hasher/libMd5Hasher.so
        pathset = Set.new()
        @cpplibraryPathSet.each { |e|
          if e.include?(item)
            pathset << readlink(File.dirname(e))
          end
        }
        pathset << item if pathset.size==0
        return pathset.to_a
      end
    else # means it should be a complete path
      path = item
      if not File.directory?(item)
        path = File.dirname(item) #remove the "*.so" part
      end
      return readlink(path)
    end
  end

  # It parses scons cache file
  # stores each cpp library or program as the key, the location as the value
  def generate_cpplibraryset()
    comp_cache = eval_scons_file(@sconsCachePath)
    # eval may fails if Scons-cache is empty or has error
    return if not comp_cache
    for key in comp_cache.keys()
      for value in comp_cache[key]
        local_scons_path = File.join(DCTConfig.workspace, value+".local.py")
        local_scons = eval_scons_file(local_scons_path)
        next if not local_scons
        project_type = local_scons['PROJECT_TYPE'].join.strip
        case project_type
        when "cpp_component", "utility_library", "shared_library"
          dirpath = File.dirname(File.dirname(local_scons_path))
          @cpplibraryPathSet << File.join(dirpath, "lib"+local_scons['NAME'].join+".so")
        when "cpp_component_exe", "c_program"
          dirpath = File.dirname(File.dirname(local_scons_path))
          @cpplibraryPathSet << File.join(dirpath, local_scons['NAME'])
        end
      end
    end
  end

  # Read the scons file and return the HashTable
  def eval_scons_file(scons_file_path)
    puts "eval file: #{scons_file_path}" if @debugMode
    if not File.exists?(scons_file_path)
      $stderr.puts "WARNING: '#{scons_file_path}' does not exist!" if @debugMode
      return nil
    end
    f = File.open(scons_file_path,'r')
    cache = f.read
    cache.gsub!(":","=>")
    cache.gsub!(" ","")
    #IMPORTANT: format of certain scons files are not correct
    # need this to handle the case, e.g.
    # hw/cor/HwDependencies/Main/SConscript.local.py
    cache.gsub!("\n,",",")
    # Following 2 lines deal with raw string in python
    cache.gsub!("r'","'")
    cache.gsub!('r"','"')
    begin
      scons_cache = eval(cache)
    rescue Exception => detail
      puts detail if @debugMode
      scons_cache = nil
    end
    if scons_cache == nil
      $stderr.puts "ERROR: error occurs when processing scons file '#{scons_file_path}'!"
    end
    f.close()
    return scons_cache
  end

  def insert(indicator, value)
    case indicator
    when :mat
      @dependLibs.push(value) if not @dependLibs.include?(value)
    when :dir
      if not File.exist?(value)
        puts "WARN: directory #{value} does not found!"
        return
      end
      @searchDirs.push(value) if not @searchDirs.include?(value)
    when :log
      @logName = value if not value
    when :num
      DCTConfig.maxRunningTests = value.to_i if value.to_i > 0
    end
  end

  def contain_utility_lib?()
    utility_libs = get_utility_libs(@sconsCachePath)
    if utility_libs==nil
      puts "WARN: error occurs when reading #{@sconsCachePath}! "+ \
      "The tool can not judge whether a component package is a utility library or not, " +\
      "thus the dependency checking might not be accurate!"
      return false
    end
    @dependLibs.each { |lib|
      libname = lib.split('/')[-1]
      if utility_libs.include?(libname)
        return true
      end
    }
    return false
  end

  def get_utility_libs(sconsCachePath)
    scons_cache = get_scons_file(sconsCachePath)
    # eval may fails if Scons-cache is empty or has error
    if scons_cache==nil
      return
    end
    utility_libs = Set.new()
    scons_cache["utility_library"].each do |value|
      path = value+".local.py";
      if not path.index("/")==0
        path = DCTConfig.workspace+"/"+path
      end

      comp_scons = get_scons_file(path)
      if comp_scons==nil
        next
      end
      utility_libs.add("lib"+comp_scons['NAME'][0]+".so")
    end
    #pp utility_libs
    return utility_libs
  end

  def get_scons_file(filePath)
    if not File.exists?(filePath)
      return
    end
    f = File.open(filePath,'r')
    cache = f.read
    cache.gsub!(":","=>")
    comp_cache = eval(cache)
    f.close()
    return comp_cache
  end

  # here the usage help shows 'dynamicComponentTest.ksh'
  # because this script is called by that ksh script internally.
  def help_info(msg=nil)
    puts msg if msg
    puts "Note: "
    puts "This script searches and runs dependent Zenith Offline Unit and Component Tests dynamically."
    puts "It is able to detect changed materials in zenith in a view."
    puts "Relevant Unit and Component Tests are executed afterwards (concurrently from 7.2)."
    puts "Usage: "
    puts "dynamicComponentTest.ksh [-mat component_package_name /comp/package/path]"
    puts "                         [-dir /some/place /somewhere/else]"
    puts "                         [-num N]"
    puts "                         [-a | -run_all_tests]"
    puts "                         [-verbose]"
    puts "  -mat: specify the materials to be tested."
    puts "        [default]: All modified materials in Zenith will be detected automatically,"
    puts "                   e.g. component packages, utility libraries, IDL."
    puts "  -dir: specify directories where to search component tests apart from $WORKSPACE"
    puts "        [default]: $WORKSPACE ($WORKSPACE is always considered.)"
    puts "  -num: specify the maximum number of tests running in parallel"
    puts "        [default on branch 7.1]  : 1"
    puts "        [default from branch 7.2]: the number of processors of the machine"
    puts "  -a | -run_all_tests:  run all unit/component tests"
    puts "NOTE: "
    puts "1. If a test is not suitable for running in a concurrent manner, please add it to file "
    puts "   '$WORKSPACE/CMF-tools/Test/ZenithCompTest/parallel_component_testing_exceptions'"
    puts "2. The maximum execution time of a test is 30 minutes by default, you can change it by "
    puts "   exporting env. variable ZTF_TEST_TIMEOUT, e.g. export ZTF_TEST_TIMEOUT=10, means each test"
    puts "   should be finished in at most 10 minutes. A test is treated as failure otherwise."
    exit!(0)
  end
end

################################################################################
begin
  time_begin = Time.now
  scons_cache = File.join(DCTConfig.workspace,"SConstruct.modules.py")
  pre = PrepareExecution.new(scons_cache)
  exit(0) if pre.dependLibs.size == 0 and not pre.testAllComponent

  exit(1) if ensure_session_manager_is_running() != 0

  # increase session creation timeout for parallel execution due to high workstation load factor
  ENV['XOC_SESSION_CREATION_TIMEOUT']='60'

  run_base   = DynamicTestingBasic.new(pre.dependLibs, pre.logName, pre.verbose, pre.debugMode, pre.testAllComponent)
  run_scons  = DynamicTestingBySconsCache.new(scons_cache)
  run_search = DynamicTestingBySearchingDirs.new(pre.searchDirs, pre.unitTestsDirs, pre.blackListOfDirs) if pre.searchDirs.size > 0

  #    run_base.run_test_in_subprocess()
  DCTConfig.allthreads.each { |t| t.join }
  run_base.run_sequential_tests
rescue SignalException
  # Raised by users to force termiate the program.
  puts "--- cleanup ---"
  puts "Please wait until the program kills all processes"
  puts "and cleanup your environment. This may take some minutes!"
  puts "  #################################################"
  puts "  #     DO NOT PRESS CTRL-C AGAIN OR KILL IT!     #"
  puts "  #################################################"
  $stdout.flush
  DCTConfig.forceTerminate=true
  exit(1)
rescue SystemExit => e
  # Raised by exit to initiate the termination of the script.
  exit(e.status)
rescue Exception => e
  puts e, "\t"+e.backtrace.join("\t\n")
  exit(1)
ensure
  DCTConfig.allthreads.each { |t|
    # t.status == false means it terminated normally
    if t.status != false
      testResult = run_base.format_command_to_output(t[:ksh], t[:timeStart], 1)
      t[:testLog] = "" if t[:testLog] == nil
      t[:testLog] += "\nERROR: test is explicitly killed!\n"
      run_base.write_to_file(t[:testLog]+testResult)
      puts t[:testLog] if not DCTConfig.forceTerminate
      puts testResult
      t.kill
      t[:io].waitall
      $stdout.flush
    end
  }
  run_base.show_result(time_begin) if run_base
  $VERBOSE = verbose_backup
  if has_zombie_process?("starter")
    puts "WARN: zombie processes 'starter' may exist in the system!"
    puts "      Please use command `ps a | grep starter` to check if there is any zombie process!"
  end
  $stdout.flush
  if DCTConfig.hasTestFail
    exit(1)
  end
end

################################################################################
#
# The script can be divided to 3 parts:
# 1) searches dependent test executors of given material in given directories
#    and run them in parallel.
# 2) reading SCONS cache info (SConstruct.modules.py), find dependent tests,
#    and run tests. Separate thread is not necessory since the processing of
#    cache is instant, wheareas searching dirs is time consuming.
# 3) searches and runs C++ Unit Tests.
#
# This dependency analysis is done by reading files '*.botm' of tests.
# These files are containing the dependencies in the form of lists of libraries
# representing component packages. If a package name given in the list will be
# found in the BOTM of a test and is set to active status, the test is adopted to
# be dependent.
#
# Beside of checking the BOTM of the tests there is a general build
# script describing a general subset of components needed by all component
# tests. these components are taken into account too.
#
# The detection of changed components and unit tests are relied on another script
# "detectChangedComponents.rb".
################################################################################
