#! /usr/bin/python
# Class TestMaterialDB keeps all kinds of data of botm files
# If the format of a botm file is incorrect, it will exit the program immediately
# with exit code 1.
# Typical usage:
#    testMaterialDB = TestMaterialDB(BotmPath)
#    uclList        = testMaterialDB.getUclList()
#    utlList        = testMaterialDB.getUtlList()
#
import os, sys
#from sets import Set

class TestMaterial:
    # This is mimic of enum for this TestMaterial List
    # BOTMfile: the path of botm file
    # basePath: the path of output directory 'TestBed' or 'TestBed_sth'
    def __init__(self, BOTMfile):
        # Test of material has 4 major types at the moment:
        # 1. registried libs: including 3 types -- so, jar, rb
        # 2. Local Type Registries: replace the default UNO Type, i.e. "IDL/zenith.rdb"
        # 3. Local Implementation Registries: replace the default UNO Implementation, i.e.
        #    "services/misc/componentTestSupport/additionalTypeRegistries/default/cache/Stubbed.rdb"
        # 4. Component Configuration Data: the Null Components, which only have configs inside,
        #    e.g. DataExtensionPoints/null
        # 5. The additional common libs, which is located at $WORKSPACE/services/misc \
        #    /componentTestSupport/additionalTypeRegistries/ default/bill-of-test-materials
        #    NOTE: this item should always be there in botm
        self._parseSuccess = True
        self._BOTMfile = str(BOTMfile)
        self._testMaterial = {'SO': [], 'JAR': [], 'RB': [], 'NULL': [], 'IDL': [], 'BOTM': [],'UTL': []}
        self.__parseBOTM__()
        if not self._parseSuccess:
            sys.exit(1)

    # arg[0]: path of BOTM file
    # arg[1]: path of TestBed directory, rc/rdb files are generated in TestBed/cache/zenith.rc
    # Return: a object which contain a set of array, seperating all materials into its own group
    def __parseBOTM__(self):
        f = open(self._BOTMfile,'r')
        for line in f:
            if line.strip().startswith("#") or line.isspace():
                continue
            item = line.split()
            if len(item)!=4:
                sys.stderr.write("ERROR: format error in BOTM '%s': %s \n" % (self._BOTMfile, item))
                self._parseSuccess = False
                continue
            # skip not-actived components
            if item[3]!='y':
                continue
            # libPath = ""
            # for path in legacy, full path is specified
            # for path in zenith, relative path to WORKSPACE/development is specified

            # this will expand environment variables in the path, e.g. ${NONSHIPMENT_ROOT}
            item[1] = os.path.expandvars(item[1])

            if item[1].startswith("/"):
                libPath = item[1]+"/"+item[2]
            else:
                libPath = os.getenv("WORKSPACE")+"/development/"+item[1]+"/"+item[2]

            # Check the availability at the given location libPath. If there is no object/file
            # availabable then we choose the standard location $WORKSPACE/development/lib.

            #if not os.path.exists(libPath) :
            if not (os.path.isfile(libPath) and os.access(libPath, os.R_OK)) :
                libPath = os.getenv("WORKSPACE")+"/"+item[1]+"/"+item[2]
                if (os.path.isfile(libPath) and os.access(libPath, os.R_OK)) :
                    sys.stderr.write("INFO: Using '%s'\n" % (libPath))
                else:
                    libPath = os.getenv("WORKSPACE")+"/development/lib/"+item[2]
                    sys.stderr.write("INFO: Using '%s'\n" % (libPath))

            if os.access(libPath, os.R_OK):
                #e.g. __appendMaterial__("UCL",path/to/libA.jar)
                self.__appendMaterial__(item[0],libPath)
                ## Exception: Null Components i.e. Configuration Data,
                ## e.g. DataExtensionPoints/null
            elif item[0].strip().upper() == "UCL" and \
                libPath.endswith("/null") and \
                os.access(os.path.dirname(libPath), os.R_OK):
                self.__appendMaterial__(item[0],libPath)
            else:
                sys.stderr.write("ERROR: library '%s' does not exist, please re-check BOTM '%s'!\n" % (libPath,self._BOTMfile))
                self._parseSuccess = False
        f.close()

    def __appendMaterial__(self, elmType, path):
        key = elmType.strip()
        if key.upper() == "UCL":
            self.__addUCL__(path)
        else:
            door = self.getMaterial(key)
            if door==None:
                return
            if path not in door:
                door.append(path)
            else:
                sys.stderr.write("WARN: find duplicate item '%s' in BOTM '%s'.\n" % (path,self._BOTMfile) )

    def __addUCL__(self, libPath):
        door = libPath.strip().lower()
        item = libPath.strip()
        # type = ""
        if door.endswith(".so"):
            type = "SO"
        elif door.endswith(".jar"):
            type = "JAR"
        elif door.endswith(".rb"):
            type = "RB"
        elif door.endswith("/null"):
            type = "NULL"
        else:
            materials = libPath.split("/")
            material  = materials[len(materials)-1]
            sys.stderr.write("ERROR: find invalid type of material name '%s' in BOTM '%s'.\n" % (material,self._BOTMfile))
            self._parseSuccess = False
        if not self._parseSuccess:
             return
        if libPath not in self.getMaterial(type):
            self.getMaterial(type).append(libPath)
        else:
            sys.stderr.write("WARN: find duplicate item '%s' in BOTM '%s'.\n" % (item,self._BOTMfile))

    # return combined List of key, e.g. JAR
    def getMaterial(self, key):
        door = key.strip().upper()
        if self._testMaterial.has_key(door):
            return self._testMaterial[door]
        else:
            sys.stderr.write("ERROR: find invalid type '%s' in BOTM '%s'.\n" % (key,self._BOTMfile))
            self._parseSuccess = False
            return None

    def getBOTMPath(self):
        return self._BOTMfile

    def getRdbPath(self, key):
        door = key.strip().upper()
        if door=="SO":
            return "cache/Stubbed.rdb"
        elif door=="JAR":
            return "cache/StubbedJ.rdb"
        elif door=="RB":
            return "cache/StubbedRb.rdb"
        else:
            sys.stderr.write("ERROR: invalid key %s in BOTM '%s'.\n" % (key,self._BOTMfile))
            self._parseSuccess = False
            return NonTestBedPathe

    def getKeys(self):
        return self._testMaterial.keys()

    def printMaterial(self):
        print self._testMaterial


# BOTM file can include other BOTM files,
# The TestBed path is fixed: 'dirname(BOTMfile)/TestBed_pattern'.
class TestMaterialDB:
    def __init__(self, BOTMfile):
        self._db={}
        # Parse BOTM files recursively and store all materials in a big array
        self.__getAllBOTMs__(BOTMfile,self._db)
        self._testMaterialDB = self._db.values()

        # generate the rdb lists
        self.__generateRdbStatement__()
        self.__generateUclList__()
        self.__generateIdlList__()
        self.__generateUtlList__()

    # It get all botm files and stores them in db
    # == Arguments:
    # [in]  botmFile: fullpath of a botm file
    # [out] db:  directory, TestMaterial of the botm file is stored to here
    def __getAllBOTMs__(self,botmFile,db):
        if db.has_key(botmFile):
            # people don't link warnings, so I disable it.
            # sys.stderr.write("WARN: botm file '%s' is already included.\n" % botmFile)
            return
        db[botmFile] = TestMaterial(botmFile)
        for eachBOTM in db[botmFile].getMaterial("BOTM"):
            self.__getAllBOTMs__(eachBOTM,db)

    # retrun a Directory of Directories, including all rdbs needs to be registied.
    # 'path/to/bill-of-test-material-1.botm' :
    #              'path/to/stubbed.rdb' : ['path/A.so', 'path/B.so']
    #              'path/to/stubbedRB.rdb' : ['path/A.rb', 'path/B.rb']
    # 'path/to/bill-of-test-material-2.botm' :
    #              'path/to/stubbed.rdb' : ['path/C.so', 'path/D.so']
    def __generateRdbStatement__(self):
        self._rdbStatement = {}
        for each in self._testMaterialDB:
            botmPath = each.getBOTMPath()
            self._rdbStatement[botmPath] = {}
            # sum up all so, jar, rb
            for key in self.getRdbLibKeys():
                # skip empty ones
                if len(each.getMaterial(key))==0:
                    continue
                # the instance of testMaterial only provides "cache/Stubbed.rdb"
                # the parent directory is provided here according to the path of BOTM
                testBedPath = self.defineTestBedName(each.getBOTMPath())
                rdbPath = os.path.join(testBedPath, each.getRdbPath(key))
                self._rdbStatement[botmPath][rdbPath] = each.getMaterial(key)

    def __collectItems__(self, keys, list):
        for each in self._testMaterialDB:
            # sum up all 'so, jar, rb, null'
            for key in keys:
                if len(each.getMaterial(key))==0:
                    continue
                for item in each.getMaterial(key):
                    if item in list:
                        # in case of embeded botm files, sometimes you can not avoid duplication.
                        #sys.stderr.write("WARN: find duplicate item '%s' in BOTM.\n" % item)
                        continue
                    list.append(item)

    def __generateIdlList__(self):
        self._idlList = []
        key="IDL"
        self.__collectItems__([key],self._idlList)

    def __generateUclList__(self):
        self._uclList = []
        self.__collectItems__(self.getUclKeys(),self._uclList)

    def __generateUtlList__(self):
        self._utlList = []
        key="UTL"
        self.__collectItems__([key],self._utlList)

    # keys for all libraries, including null components
    def getUclKeys(self):
        return ['SO', 'JAR', 'RB', 'NULL']

    # Keys needed for registration of rdb
    def getRdbLibKeys(self):
        return ['SO', 'JAR', 'RB']

    def getUclList(self):
        return self._uclList

    def getIdlList(self):
        return self._idlList

    def getRdbStatement(self):
        return self._rdbStatement

    def getUtlList(self):
        return self._utlList

    # Each BOTM file has its target Output directory, i.e. TestBed.
    # By default: there is only one TestBed directory, however this is not true if there are more than one BOTM file.
    # A TestBed_something will be created if there is an additional BOTM file.
    # The naming schema is: e.g.
    #     bill-of-test-materials.botm ==> TestBed
    #     complete_different_name.botm ==> TestBed_complete_different_name
    def defineTestBedName(self, BOTMfile):
        fileName = os.path.basename(BOTMfile)
        dirName  = str(os.path.dirname(BOTMfile))
        suffix  = fileName.replace(".botm","").replace("bill-of-test-materials","")
        if suffix =="":
            testBedName = "TestBed"
        else:
            testBedName = "TestBed_" + suffix
            #prefix = ("%s" % suffix[0])
            #if prefix.isalpha() or prefix.isdigit():
                #testBedName = "TestBed_" + suffix
            #else:
                #testBedName = "TestBed" + suffix
        return str(os.path.join(dirName, testBedName))

    def printMaterial(self):
        for each in self._testMaterialDB:
            each.printMaterial()
