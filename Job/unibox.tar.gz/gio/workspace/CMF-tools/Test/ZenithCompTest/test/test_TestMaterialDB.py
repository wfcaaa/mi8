#!/usr/bin/env python

import unittest
import sys, os

WORKSPACE=os.getenv("WORKSPACE", "/vobs/zenith/workspace")

sys.path.append( os.path.dirname(os.path.dirname(__file__)) )
from TestMaterialDB import TestMaterial, TestMaterialDB
from generateRCfromBOTM import *

class Test_TestMaterial(unittest.TestCase):

    def testGetmaterials1(self):
        botmPath=WORKSPACE + "/CMF-tools/Test/ZenithCompTest/test/TestBed/test1.botm"
        rootMaterial = TestMaterial(botmPath)
        print rootMaterial.printMaterial()
        self.assertEqual(len(rootMaterial.getMaterial("UTL")),2)
        self.assertEqual(len(rootMaterial.getMaterial("BOTM")),1)
        self.assertEqual(len(rootMaterial.getMaterial("SO")),6)
        nestedBotm = TestMaterial(rootMaterial.getMaterial("BOTM").pop())
        print nestedBotm.printMaterial()
        self.assertEqual(len(nestedBotm.getMaterial("IDL")),1)
        self.assertEqual(len(nestedBotm.getMaterial("UTL")),0)
        self.assertEqual(len(nestedBotm.getMaterial("BOTM")),0)
        self.assertEqual(len(nestedBotm.getMaterial("JAR")),0)
        self.assertEqual(len(nestedBotm.getMaterial("SO")),12)

    def testGetmaterials2(self):
        botmPath=WORKSPACE + "/CMF-tools/Test/ZenithCompTest/test/TestBed/test2.botm"
        rootMaterial = TestMaterial(botmPath)
        self.assertEqual(len(rootMaterial.getMaterial("UTL")),2)
        self.assertEqual(len(rootMaterial.getMaterial("BOTM")),2)
        self.assertNotEqual(len(rootMaterial.getMaterial("SO")),0)
        for botm in rootMaterial.getMaterial("BOTM"):
            if botm.find("test1.botm")>=0:
                nestedBotm = TestMaterial(botm)
                self.assertEqual(len(nestedBotm.getMaterial("IDL")),0)
                self.assertEqual(len(nestedBotm.getMaterial("UTL")),2)
                self.assertEqual(len(nestedBotm.getMaterial("BOTM")),1)
                self.assertEqual(len(nestedBotm.getMaterial("JAR")),0)
                self.assertNotEqual(len(nestedBotm.getMaterial("SO")),0)

class Test_TestMaterialDB(unittest.TestCase):

    def testGetmaterials1(self):
        botmPath=WORKSPACE + "/CMF-tools/Test/ZenithCompTest/test/TestBed/test1.botm"
        db=TestMaterialDB(botmPath)
        self.assertEqual(len(db.getIdlList()),1)
        self.assertEqual(len(db.getUclList()),16)

class Test_generateRCfromBOTM(unittest.TestCase):
    def setUp(self):
        print "----------------------------------------------------"

    def test_getFilesUnderDir(self):
        workspacelib=WORKSPACE + "/lib"
        for file in getFilesUnderDir(workspacelib):
            self.assertEqual(file.find(WORKSPACE + ""),0)

    def test_getRealPath(self):
        threadlib = WORKSPACE + "/lib/libthreads.so"
        self.assertEqual(getRealPath(threadlib),WORKSPACE + "/services/threads/libthreads.so")

    def test_generateLocalUtlLib0(self):
        utlLibs=[]
        testBedPath=WORKSPACE + "/examples/cpp/ComponentSample/Test/TestBed"
        generateLocalUtlLib(utlLibs,testBedPath)
        self.assertTrue(os.access(testBedPath+"/lib",os.R_OK))
        self.assertEqual(len(os.listdir(testBedPath+"/lib")),0)

if __name__ == '__main__':
    unittest.main()
