#! /usr/bin/env python
# usage:  generateRCfromBOTM.py BotmPath [TestBedPath] [-v] [-clobber]
#         default TestBedPath: dirname(BotmPath)/TestBed_$pattern
# Output: TestBedPath/cache
#           zenith.rc, Stubbed.rc, [Stubbed.rdb, StubbedJ.rdb, StubbedRb.rdb]
# More:   Configuration Data will be prepared in TestBedPath/config,
#         merging process will be triggered if file name conflicts
###########################################################################################

import os, sys, filecmp, sha, shutil
from sets import Set
from TestMaterialDB import TestMaterialDB

def getRelativeAbsPath(path):
    dirPath = path
    if not os.path.isdir(path):
        dirPath = os.path.dirname(path)
    p = os.popen("cd "+dirPath+" && pwd")
    absPath = p.read().rstrip("\n")
    p.close()
    if not os.path.isdir(path):
        absPath = os.path.join(absPath, os.path.basename(path))
    return absPath

def vprint(log):
    if "-v" in sys.argv:
        print log

# When rb components are registered, additional command is needed,
# It specifies the correct "so-components rdb (Stubbed.rdb)" to where it should attach.
# Typically in TestBed/cache: Stubbed.rdb is for cpp components
#                             StubbedRb.rdb is for ruby components
# StubbedRb.rdb is attached to Stubbed.rdb during generation.
def getRegcomp_loader_opt(rdbPath):
        door = rdbPath.strip()
        if door.endswith("Stubbed.rdb"):
            return ""
        elif door.endswith("StubbedJ.rdb"):
            return ""
        elif door.endswith("StubbedRb.rdb"):
            # NOTE:
            # This is a bit ugly: since other rdb files(except rdb of so-libs: Stubbed.so)
            # is attached to a SO-lib.
            # Here assume that Stubbed.so in the same directory of other rdb exists all the time
            soRdbPath = os.path.join(os.path.dirname(rdbPath), "Stubbed.rdb")
            return ' -br %s -l "xoc.svc.rubyloader.ZSRubyLoader"' % soRdbPath
        else:
            sys.stderr.write('WARN: invalid libType %s\n' % key)
            #print "WARN: invalid libType "+key
            return None


# Do registration process, 3 types of libs are registered as 3 different rdb
# so -> Stubbed.rdb, jar -> StubbedJ.rdb, rb -> StubbedRb.rdb
# Return generatedRDBList: continuesly append generated rdb files to it.
def generateRegistryBuilder( targetRDBPath, uclList):
    # $TARGET hw/ext/variants/E8013GULPogoCable/Test/TestBed/cache/Stubbed.rdb
    impRegistryBuilder =   '/bin/rm -rf $TARGET' + ' && \n' + \
                           'mkdir -p ${TARGET.dir}' + ' && \n' + \
                           'regcomp -register ' + \
                           '-br $XOC_UNO_URE_ROOT/share/misc/services.rdb ' + \
                           '-br $XOC_UNO_URE_ROOT/share/misc/types.rdb ' + \
                           '-r $TARGET ' + \
                           '$REGCOMP_LOADER_OPT ' + \
                           '-c \"${libsList}\"'
    libStringTemplate =  'file://%s;'
    XOC_UNO_URE_ROOT = os.getenv("XOC_UNO_RE_DIR")

    libString = ""
    for item in uclList :
        libString = libString + libStringTemplate % item

    buildRdbCommand = impRegistryBuilder.replace("$REGCOMP_LOADER_OPT", getRegcomp_loader_opt(targetRDBPath))            \
                                        .replace("$XOC_UNO_URE_ROOT",XOC_UNO_URE_ROOT)                                   \
                                        .replace("$TARGET", targetRDBPath)                                               \
                                        .replace("${TARGET.dir}", os.path.dirname(targetRDBPath))                        \
                                        .replace("${libsList}", libString)                                               \
                                        .rstrip(';"') + '"'    #===> replace the ending ';"' with '"', i.e. remove ';'
    buildRdbCommand += " 2>&1 "
    print buildRdbCommand
    #result = os.system(buildRdbCommand)

    p = os.popen(buildRdbCommand)
    details = p.read().rstrip("\n")
    result = p.close()

    if result!=None:
        sys.stderr.write("ERROR: register libs failed for '"+BotmPath+"', Error Nr. ="+"%s\n" % result)
        # comment out the error msg because we use other tool to detect reasons
        # sys.stderr.write("More details from 'regcomp' are shown in the following:\n"+details+"\n")
        # debug/print which lib(s) lead to the failure
        checkUnoComponents(uclList)
        return False
    else:
        print details
        print "INFO: register libs completed for %s" % targetRDBPath
    return True

# This method uses script checkUnoComponent.ksh to validate the correctness of a
# UNO component. 
# It is called when the registration fails, which provide more info to users
def checkUnoComponents(uclList):
    sys.stderr.write("#####----- INFO: try to identify why the registration failed using checkUnoComponent.ksh! -----#####\n")
    checkUnoComponent = os.path.join(os.getenv('WORKSPACE'),"CMF-tools/bin/checkUnoComponent.ksh")
    for item in uclList:
        p = os.popen(checkUnoComponent+" "+item+" 2>&1 ")
        details = p.read()
        result  = p.close()
        if result == None:
            sys.stderr.write("INFO: check %s : PASSED \n" % item)
        else:
            # If error detects, run it again with "-keep" to get output result
            # we don't do it for normal libs since it will generate many useless files under /tmp/
            p = os.popen(checkUnoComponent+" -keep "+item+" 2>&1 ")
            details = p.read()
            result  = p.close()
            sys.stderr.write("INFO: check %s : FAILED \n" % item)
            sys.stderr.write("INFO: the complete output is the following:\n%s\n" % details)
            

# we also need UNO RC files, look a bit like 'ini' files and tell
# the runtime wher to look for type/implementation registries
# they look like this:
#=============================================================================================
# [Bootstrap]
# UNO_TYPES=file:///opt/hp93000rt/.../types.rdb file:///vobs/zenith/workspace/IDL/zenith.rdb
# UNO_SERVICES=file:///opt/hp93000rt/.../services.rdb file:///vobs/.../cache/Stubbed.rdb
#=============================================================================================
# (only three lines, but maybe long ones)
#
# testMaterialDBList is the  Material DataBase, instance of TestMaterialDB
# generatedRDBList is the list of all implementation rdb files will be combined in rc file.
# targetFileName is full path of cache/zenith.rc
#
def generateTestRCWriter(sourceTypeRegNodes, generatedRDBList, targetFileName):
    # we will need the ure root and the workspace as URL heads
    ureRoot = 'file://' + os.getenv('XOC_UNO_RE_DIR')
    if not ureRoot.endswith('/'):
        ureRoot += '/'
    workspace = 'file://' + os.getenv('WORKSPACE') + '/'
    if not workspace.endswith('/'):
        workspace += '/'
    # the UNO types are fixed
    # We have a default UNO type registry which is always attached.
    utypes=[]
    utypes.append(ureRoot + 'share/misc/types.rdb')
    # either use libs given by user or take the default one
    if len(sourceTypeRegNodes)>0:
        utypes.extend([str("file://"+item) for item in sourceTypeRegNodes])
    #else:
        #utypes.append(workspace + 'IDL/zenith.rdb')

    # What does the following lines mean?
    # the local types are taken from the environment and might be overwritten
    #for localTypeRegisty in env['DEFAULT_TYPE_REGISTRIES']:
        #utypes.append(workspace + localTypeRegisty)
    # we have a fixed implementation registry and the given ones
    uimps=[]
    uimps.append(ureRoot + 'share/misc/services.rdb')
    # Add the local TestBed/cache rdbs into rc file
    if len(generatedRDBList)>0:
        uimps.extend([str("file://"+item) for item in generatedRDBList])

    # make the ini-file lines
    iniFileLines = ['[Bootstrap]']
    iniFileLines.append('UNO_TYPES=' + ' '.join(utypes))
    iniFileLines.append('UNO_SERVICES=' + ' '.join(uimps))
    ## we might need to make the target directory
    rcFileName = str(targetFileName)
    rcFileDirName = os.path.split(rcFileName)[0]
    if not os.path.exists(rcFileDirName):
        os.mkdir(rcFileDirName)
    # write the file
    rcFile = open(rcFileName,'w')
    rcFile.write('\n'.join(iniFileLines))
    rcFile.close()

####################################################################################################################
# The following two methods do preparing of linking configuration data process.                                    #
# 1. Component Configuration Data(CCD) which are listed in BOTM, will be visible in TestBedPath/config directory   #
#    by providing symbolic links.                                                                                  #
# 2. During this procedure, merging will be triggered if two files from different CCD have the same name, i.e.     #
#    files will be renamed using pattern: originalName-renamed_1,  originalName-renamed_2, .....                   #
#    Note: if the content of the conflict files are identical, the merging process is ignored.                     #
####################################################################################################################

# If there is conflicts of target file name, meanwhile the content of source file will be linked
#    and conflict target file are the same ==> return None
# Else: return a unique file name
def Find_unique_name(targetDir, filename, source_name):
    newFileName = ""
    if not os.access(os.path.join(targetDir, filename),os.F_OK):
        newFileName = filename
    elif filecmp.cmp(source_name, os.path.join(targetDir, filename)):
        # content of linked file and the existing file are the same, ignor it
        print "INFO: find identical file for: %s" % os.path.join(targetDir, filename)
        return None
    else:
        print "INFO: found name conflicts for: %s" % os.path.join(targetDir, filename)
        # There is a existing file, so let's find a new name:
        # e.g. old.name ==> old-1.name or configData ==> configData-1
        fileNameList = filename.rsplit(".",1)
        vprint(fileNameList)
        if len(fileNameList)==1:
            newNameTemplate = fileNameList[0] + '%s'
        else:
            newNameTemplate = fileNameList[0] + '%s.' + fileNameList[1]
        i = 0
        while 1:
            i += 1
            newFileName = newNameTemplate % ("-renamed_" + str(i))
            vprint("Trying new file name: " + newFileName )
            if not os.access(os.path.join(targetDir,newFileName),os.F_OK):
                break
    return os.path.join(targetDir,newFileName)

# Directories in TestBedPath/config are created, files in each directory are provided by soft links
# Componenet Configuration Data includes every item of UCL type:
# 1. All Configuration Directory in Component Packages listed in BOTM
# 2. NULL Component Package
def prepareConfigurationLinksForComponenetTest(uclList,TestBedPath):
    print "Preparing Component Configuration Data:"
    for item in uclList:
        configDir = os.path.join(os.path.dirname(item),"Configuration")
        if os.access(configDir ,os.R_OK):
            print "Linking CCD '"+configDir+ "' to '"+os.path.join(TestBedPath, "config")+"'"
            for root, dirs, files in os.walk(configDir):
                for filename in files:
                    rootArr = root.split("/Configuration/")
                    if len(rootArr)==1:
                        configSubDir=""
                    else:
                        configSubDir=rootArr[len(rootArr)-1]
                    targetDir = os.path.join(TestBedPath, "config", configSubDir)
                    # Note: in some cases, TestBedTemplate provides links to other Configuration directory,
                    # We should not follow these links and creates files there
                    # These links in TestBedTemplate should be somehow forbidden!
                    if os.path.islink(targetDir):
                        sys.stderr.write("WARN: found link '%s' in TestBed directory, which should be a direcotry.\n" % targetDir)
                        break
                    if not os.access(targetDir,os.F_OK):
                        os.makedirs(targetDir)

                    source_name = os.path.join(root, filename)
                    linked_name = Find_unique_name(targetDir,filename, source_name)
                    if linked_name != None:
                        vprint("targetDir: " + targetDir )
                        vprint("Making symbolic link: " + linked_name+ "--> " + source_name)
                        os.symlink(source_name, linked_name)
        else:
#            mainDir = os.path.join(os.path.dirname(item),"Main")
#            if not os.access(mainDir,os.R_OK):
            componentRootDir = os.path.dirname(item)
            # we only check this rule for zenith components
            # And we don't check for ruby components and null
            if componentRootDir.startswith(os.getenv('WORKSPACE')) and \
            (not item.endswith(".rb")) and (not item.endswith("/null")):
                componentDirCorrect = False
                for each in os.listdir(componentRootDir):
                    # some stubs uses Main_* as the directory name
                    if each.startswith("Main") and os.path.isdir(os.path.join(componentRootDir,each)):
                        componentDirCorrect = True
                # it possibly means the component path in BOTM is not using the root dir of the component
                # in this case "Configuration" directory will not be linked
                # we should print a warning here
                if not componentDirCorrect:
                    sys.stderr.write("WARNING: the Configuration Data of "
                    "Component '%s' will not be prepared for this test, "
                    "because '%s' is not the root directory of the component!\n"
                     % (item,os.path.dirname(item)))

# The hase-value is kept as a file ".$target"
def getHashFilePath(targetPath):
    fileName = "."+os.path.basename(targetPath)
    dirName = os.path.dirname(targetPath)
    return os.path.join(dirName,fileName)

# The hase-value is kept as a file ".$target"
def getFileSignaturePath(targetPath):
    fileName = "."+os.path.basename(targetPath)+"_signature"
    dirName = os.path.dirname(targetPath)
    return os.path.join(dirName,fileName)

# The hash-value-file is generated under the same directory
# of target object and named as ".$target"
# targetPath: full path of the target object which wants to
#             generated a hash file
def generateHashFile(targetPath):
    f = open(getHashFilePath(targetPath),'w')
    f.write(sha.new(open(targetPath).read()).hexdigest())
    f.close()

# return list of cdef files in a given directory (not recursive)
def getCdefList(dirpath):
    cdefList = []
    for file in os.listdir(dirpath):
        if file.endswith(".cdef"):
              cdefList.append(os.path.join(dirpath,file))
    return cdefList

# The signature is formed by:
# FilePath:size:modificationDate
# stat[6]: file size
# stat[8]: st_mtime - time of most recent content modification
def generateItemSignature(source):
    stat = os.stat(source)
    signature = "%s:%s:%s\n" % (source, stat[6], stat[8])
    return signature

# check whether the signature of target file and
# newly generated signature are equal
def signatureEqual(target, newSign):
    signPath = getFileSignaturePath(target)
    if not os.access(signPath, os.F_OK):
        returnValue = False
    else:
        oldSign = open(signPath,"r").read()
        if newSign == oldSign:
            returnValue = True
        else:
            returnValue = False
    return returnValue

# make sure directory exists for a file
def ensure_dir(file):
    d = os.path.dirname(file)
    if not os.path.exists(d):
        os.makedirs(d)

# Generate a signature file for each RC/RDB
# target:  the fullpath of rc/rdb file
# newSign: the signatures writes to a file
def generateFileSignature(targetFilePath, materialList):
    signatures = []
    signPath = getFileSignaturePath(targetFilePath)
    ensure_dir(signPath)
    for item in materialList:
        if os.access(item, os.F_OK): # should always true
            signatures.append(generateItemSignature(item))
        else:
            # should never occur
            sys.exit("ERROR: '%s' does not exist which is used for generating '%s'" % (item, targetFilePath))
    f = open(signPath,"w")
    f.write("".join(sorted(signatures)))
    f.close()

# get the real path of a file, file could be a link
# It can also handle the case that the link is pointed to a relative link
# the realpath will return.
# typical scenario:
#    getRealPath("$WORKSPACE/lib/lib*.so") --> $WORKSPACE/*/*/lib*.so
def getRealPath(file):
    if not os.path.islink(file):
        return getRelativeAbsPath(file)
    realpath = os.readlink(file)
    if not realpath.find("/")==0:
        realpath=os.path.normpath(os.path.join(os.path.dirname(file),realpath))
    return getRelativeAbsPath(realpath)

# it returns a list of all real paths of files under a directory
def getFilesUnderDir(dir):
    files = []
    for file in os.listdir(dir):
        path = os.path.join(dir,file)
        if os.path.islink(path):
            files.append(getRealPath(path))
        else:
            files.append(path)
    return files
#
# To support UTL for component tests:
# If user defined UTL in botm, then
#    1. a <TestBed>/lib directory is created
#    2. links to all declared UTLs will be created under <TestBed>/lib
# Otherwise, a link <TestBed>/lib to $WORKSPACE/lib is created
#
def generateLocalUtlLib(utlLibs,testBedPath):
    workspaceLibDir = os.path.join(os.getenv('WORKSPACE'),"lib")
    testBedLibDir = os.path.join(testBedPath,"lib")

    # first make sure <TestBed>/lib is there and is a directory
    if os.path.islink(testBedLibDir):
        os.unlink(testBedLibDir)
    if not os.access(testBedLibDir, os.R_OK):
        os.makedirs(testBedLibDir)

    # if UTL is not defined, we make sure <TestBed>/lib is clean
    if len(utlLibs)==0:
        os.system("/bin/rm -rfv %s/*" % testBedLibDir)
        return

    # if UTL is defined in BOTM, we need to link all needed libs in the following
    oldTestBedLibs= set(getFilesUnderDir(testBedLibDir))
    newTestBedLibs= set(utlLibs)
    # need to remove old libs which are not in newTestBedLibs
    retainTestBedLibs = oldTestBedLibs & newTestBedLibs
    if len(retainTestBedLibs) == 0:
        os.system("/bin/rm -fv %s/*" % testBedLibDir)
    else:
        for lib in os.listdir(testBedLibDir):
            fullpath = os.path.join(testBedLibDir,lib)
            if not getRealPath(fullpath) in retainTestBedLibs:
                print "====rm %s " % fullpath
                os.system("/bin/rm -fv %s" % fullpath)
    linkTestBedLibs = newTestBedLibs - retainTestBedLibs
    for lib in linkTestBedLibs:
        target = os.path.join(testBedLibDir,os.path.basename(lib))
        os.symlink(lib, target)


#################################################################################################
# It decides whether generating rdb files
# re/generate does not happen when following conditions are fulfilled:
#   a.    rdb exists
#   b.    the signature of libraries composed the rdb equals to
#         the existing rdb's signature
#         Note:   name of signature is; .($rdb-name)_signature
#   c.    the SHA value of rdb content matches the existing SHA file.
#         Note: name of SHA-file is: .($rdb-name)
#   d.    -clobber is not set
#  Otherwise, it is necessory to regenerate rdb when
#
# source, target, materialList: full path is required
# materialList of rdb is: all components organizing the rdb, which is obtained by botm file.
#
def regenerateRDB(source, target, materialList):
    signatures = []
    if os.access(target, os.F_OK) and clobber!="true":
        for item in materialList:
            if os.access(item, os.F_OK): # should always true
                signatures.append(generateItemSignature(item))
            else:
                return True # should never happen
        newSig = ""
        if signatureEqual(target, newSig.join(sorted(signatures))):
          # Check whether the target is modified by someone (happen very rare)
          if os.stat(source)[8] < os.stat(target)[8]:
              hashFile = getHashFilePath(target)
              if os.access(hashFile, os.F_OK):
                  value = open(getHashFilePath(target),'r').read()
                  if value == sha.new(open(target).read()).hexdigest():
                      return False
    #any other cases, regenerate it
    return True

#################################################################################################
# It decides whether generating RC file
# re/generate does not happen when following conditions are fulfilled:
#   a.    rc exists
#   b.    the signature of materials composed the rc(IDL & rdb) equals to
#         the existing rdb's signature
#         Note:   name of signature is; .($rc-name)_signature
#   c.    the SHA value of rc content matches the existing SHA file.
#         Note: name of SHA-file is: .($rc-name)
#  Otherwise, it is necessory to regenerate rdb when
#
# source, target, materials: full path is required
#
def regenerateRC(source, target, materials):
    return regenerateRDB(source, target, materials)


def usage():
    print "Usage: generateRCfromBOTM.py BOTM [TestBed_Dir] [-clobber]"
    print "    BOTM:  the path of botm file"
    print "    [TestBed_Dir]: the output directory of generated RC/RDB files."
    # Maybe in some unknow cases, generated rdb files are not correct, although timestamps of botm, rdb files and cdef-files of all relevant components are compared.
    # -cloober is a quick fix in such scenario, which should not be used frequently.
    print "    [-clobber]: force re-register all rdb files."
    print "    Note: the output dir of RC/RDB is always located at 'TestBed_Dir/cache' directory."
    print "          The name of TestBed dir is generated based on name of BOTM file if TestBed_dir is not given."

#################################################################################################################
if __name__ == '__main__':
    BotmPath    = ""
    testBedPath = ""
    clobber     = "false"

    if len(sys.argv) ==1 or len(sys.argv) >4:
        usage()
        sys.exit(1)
    else:
        # sys.argv[0] is the script itself
        for arg in sys.argv[1:]:
            if arg == "-clobber":
                clobber = "true"
            elif arg.endswith(".botm"):
                BotmPath = getRelativeAbsPath(arg)
                if not os.access(BotmPath,os.F_OK):
                    sys.exit(("Error: bill-of-test-materials '%s' does not exist!\n" % BotmPath)+\
                     "Please create the file before executing component tests. Take a look at radix or contact Xu, Zhi Wei if you need further support!")
            else:
                testBedPath = arg
                if not os.access(testBedPath,os.F_OK):
                    sys.exit("Error: TestBed path '%s' does not exist!" % testBedPath)
                #print "Specified a testBed "+testBedPath

    vprint("BotmPath:" + BotmPath)

    testMaterialDB = TestMaterialDB(BotmPath)
    if testBedPath == "":
        testBedPath    = testMaterialDB.defineTestBedName(BotmPath)

    rdbDirectory   = testMaterialDB.getRdbStatement()
    uclList        = testMaterialDB.getUclList()
    idlList        = testMaterialDB.getIdlList()
    utlList        = testMaterialDB.getUtlList()
    # It makes sure UTL defined in BOTM are available
    # in TestBed/lib, and which may needed when registering rdbs
    # Precondition is LD_LIBRARY_PATH includes TestBed/lib
    generateLocalUtlLib(utlList,testBedPath)
    zenithRcPath   = os.path.join(testBedPath, "cache/zenith.rc")
    stubbedRcPath  = os.path.join(testBedPath, "cache/Stubbed.rc")
    # This is the sum of all rdbs for the BOTM (including included BOTM),
    # no matter whether it will be registered successfully.
    # Even the registration fails, it does not harm that much.
    rdbList = []

    # testMaterialDB.printMaterial()

    for eachBOTM in rdbDirectory.keys():
        # Sort rdb files, because Stubbed.rdb should be generated ahead of others,
        # e.g. StubbedRb.rdb or StubbedJ.rdb, otherwise the registration fails.
        for eachRdb in sorted(rdbDirectory[eachBOTM].keys()):
            rdbList.append(eachRdb)
            if regenerateRDB(eachBOTM, eachRdb, rdbDirectory[eachBOTM][eachRdb]):
                print "INFO: generating %s" % eachRdb
                result = generateRegistryBuilder(eachRdb, rdbDirectory[eachBOTM][eachRdb])
                if result != True:
                    # a incorrect rdb is generated although some libs are failed to register.
                    # So its better to clean up it before leave!
                    # os.remove(eachRdb)
                    sys.exit(1)
                # without hash file, the rdb file will be regenerated anyway
                # so remove rdb is not mandatory and commented out
                generateHashFile(eachRdb)
                generateFileSignature(eachRdb, rdbDirectory[eachBOTM][eachRdb])
            else:
                print "INFO: "+eachRdb + " is up to date."


    # Remove non-existing rdb files
    # prevent any failure registration of rdbs
    for rdb in rdbList:
        if not os.access(rdb, os.F_OK):
            rdbList.remove(rdb)

    # check whether to (re)generate RC file
    # re-generate the SHA file if RC is (re)generated
    if regenerateRC(BotmPath, zenithRcPath, idlList+rdbList):
        print "INFO: generating %s" % zenithRcPath
        generateTestRCWriter(idlList, rdbList, zenithRcPath)
        generateHashFile(zenithRcPath)
        generateFileSignature(zenithRcPath, idlList+rdbList)
    else:
        print "INFO: "+zenithRcPath + " is up to date."

    if regenerateRC(BotmPath, stubbedRcPath, idlList+rdbList):
        print "INFO: generating %s" % stubbedRcPath
        generateTestRCWriter(idlList, rdbList, stubbedRcPath)
        generateHashFile(stubbedRcPath)
        generateFileSignature(stubbedRcPath, idlList+rdbList)
    else:
        print "INFO: "+stubbedRcPath + " is up to date."

    prepareConfigurationLinksForComponenetTest(uclList, testBedPath)
