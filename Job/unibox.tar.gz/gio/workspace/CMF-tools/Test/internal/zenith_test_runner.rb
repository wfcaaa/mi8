#
# = test/unit.rb
#
# Overwrite the Ruby's standard unit testing library
#
# See Test::Unit for documentation.
#
require "test/unit/ui/console/testrunner"

# Overwrite class Test::Unit::UI::Console::TestRunner
module Test
  module Unit
    module UI
      module Console
        class TestRunner
          extend TestRunnerUtilities
          @elapsedTime = @beginTime = 0

          def test_started(name)
            RubyUNO::xocInfo("=====Enter #{name}=====") if defined?(RubyUNO)
            @beginTime = Time.now
            @testCaseName = name
          end

          def test_finished(passed)
            @elapsedTime = Time.now - @beginTime
            RubyUNO::xocInfo("=====Exit #{@testCaseName}=====") if defined?(RubyUNO)
            printTest = "\n+TEST "+ @testCaseName + " : "
            if passed
              ZTF::LOG.print printTest + ZTF::TestAttribute::PASSED + " (#{@elapsedTime}s) "
            else
              ZTF::LOG.print printTest + ZTF::TestAttribute::FAILED + " (#{@elapsedTime}s) "
            end
          end

          def add_fault(fault)
            @faults << fault
            @already_outputted = true
          end

          def started(result)
            @result = result
            output("Started")
          end

          def finished(elapsed_time)
            nl
            ZTF::LOG.print "\n----------------------------------------------------------------------"
            ZTF::LOG.print "\n#{@result}, finished in #{elapsed_time}s. "
            if @faults.empty?
              ZTF::LOG.print "\nAll Tests OK!\n======================================================================\n"
              ZTF::TEST_ATTR.exitvalue = ExitValue::PASS
            else
              ZTF::TEST_ATTR.exitvalue = ExitValue::FAIL
            end
            #print out fault tracing back info
            @faults.each_with_index do |fault, index|
              nl
              ZTF::LOG.print "\n----------------------------------------------------------------------"
              ZTF::LOG.print "\n%3d) %s" % [index + 1, fault.long_display]
              ZTF::LOG.print "\n======================================================================"
            end
            ZTF::LOG.puts ""
            nl
          end
        end #end of class TestRunner
      end #end of module Console
    end #end of module UI
  end #end of module Unit
end #end of module Test
