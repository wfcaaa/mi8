
# arguments are
# [ TL_INTEG_SUBPROJECT / TL_INTEG_PROJECT / TL_INTEG_RELEASE / TL_INTEG_USER / TL_INTEG_ALL ]
# [ online / offline ]
# it sets
#   ZTF::TEST_ATTR.testLevel , ZTF::TEST_ATTR.testMode
def zenith_opt_parser(args,data)
  ZTF::LOG.debug "Args of ZenithTestFramework.rb "+ARGV.join(" ")
  testlevelerror = "ERROR: multiple test level set, which is not allowed!"
  testmodeerror  = "ERROR: multiple test mode set, which is not allowed!"
  testtypeerror  = "ERROR: multiple test type set, which is not allowed!"
  args.each do |arg|
    case arg.upcase
      when "TL_INTEG_SUBPROJECT"
        raise TestConfigError, testlevelerror, caller unless data.testLevel.nil?
        data.testLevel = /s/
      when "TL_INTEG_PROJECT"
        raise TestConfigError, testlevelerror, caller unless data.testLevel.nil?
        data.testLevel = /p/
      when "TL_INTEG_RELEASE"
        raise TestConfigError, testlevelerror, caller unless data.testLevel.nil?
        data.testLevel = /r/
      when "TL_INTEG_USER"
        raise TestConfigError, testlevelerror, caller unless data.testLevel.nil?
        data.testLevel = /u/
      when "TL_INTEG_ALL"
        raise TestConfigError, testlevelerror, caller unless data.testLevel.nil?
        data.testLevel = /[spr]/
      when "OFFLINE"
        raise TestConfigError,testmodeerror, caller unless data.testMode.nil?
        data.testMode = /o/
      when "ONLINE"
        raise TestConfigError,testmodeerror, caller unless data.testMode.nil?
        data.testMode = /h/
      when "RUBY_COMP_TEST"
        raise TestConfigError,testtypeerror, caller unless data.test_type.nil?
        data.test_type = ZTF::TEST_ATTR.class::RUBY_COMP_TEST
      when "RUBY_INTEG_TEST"
        raise TestConfigError,testtypeerror, caller unless data.test_type.nil?
        data.test_type = ZTF::TEST_ATTR.class::RUBY_INTEG_TEST
      when "DEBUG"
        ZTF::LOG.level = ZTF::ZenithLogger::DEBUG
      when "INFO"
        ZTF::LOG.level = ZTF::ZenithLogger::INFO
      when "WARN"
        ZTF::LOG.level = ZTF::ZenithLogger::WARN
      when "ERROR"
        ZTF::LOG.level = ZTF::ZenithLogger::ERROR
      when "FATAL"
        ZTF::LOG.level = ZTF::ZenithLogger::FATAL
      else
      ZTF::LOG.error "unknown argument '#{arg}'"
      exit(1)
    end
  end
  data.testLevel = /[spr]/ if data.testLevel.nil?
  data.testMode = /o/ if data.testMode.nil?
  data.test_type = ZTF::TEST_ATTR.class::RUBY_INTEG_TEST if data.test_type.nil?
  ZTF::LOG.debug  "testLevel: #{data.testLevel}  testMode: #{data.testMode}"
end
