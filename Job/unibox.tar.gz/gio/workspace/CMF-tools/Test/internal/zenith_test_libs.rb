#
# It include all basic ruby libs
#
internal_lib = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal/lib")
require "#{internal_lib}/exitvalue"
require "#{internal_lib}/execute"
require "#{internal_lib}/zexception"
require "#{internal_lib}/systemutil"
require "#{internal_lib}/zenith_logger"