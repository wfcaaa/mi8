
require "#{ENV['WORKSPACE']}/CMF-tools/Test/internal/lib/exitvalue"

module ZTF
  # This class defines several class instance variables
  # which are used within the scope of each individual test
  # The value is singleton per test
  class TestAttribute
    module TestType
      RUBY_COMP_TEST = 0
      RUBY_INTEG_TEST = 1
      DOCU_TEST = 2
    end
    include TestType

    module TestResult
      PASSED  = "PASSED"
      FAILED  = "FAILED"
      SKIPPED = "NOT EXECUTED"
    end
    include TestResult

    attr_accessor :xocTestOnly, :testLevel, :testMode, :exitvalue, :skipAllTests, :test_type

    def initialize
      @xocTestOnly = nil # If XOC_TEST_ONLY is set, the tests are stored to xocTestOnly
      @testLevel = nil # default test level
      @testMode = nil  # default test mode
      @exitvalue = ExitValue::NONE # the exit value of the test
      @skipAllTests = false #if it set to true, all test cases will be skipped
      @test_type = nil  # possible values are in module TEST_TYPE
    end

  end # end of class TestAttributes
  TEST_ATTR = TestAttribute.new
end