#
# This file define the ZTF::TestExecutor class
# which will find all test cases in ENV['ZTF_RUBY_TEST_CASES_DIR']
# load them, filter out excluded tests (e.g. online, offline,  ENV['XOC_TEST_ONLY'])
# and run all tests.
#
internal_dir = File.join(ENV['WORKSPACE'],"CMF-tools/Test/internal")
require "#{internal_dir}/zenith_world_fixture"
require "#{internal_dir}/zenith_test_libs"
require "#{internal_dir}/lib/execute"
require "#{internal_dir}/lib/systemutil"


module ZTF
  class TestExecutor
    include Execute,SystemUtil

    def initialize(testrunner)
      @testfiles  = []
      @testrunner = testrunner
    end

    def loadTests
      dir = File.expand_path(ENV['ZTF_RUBY_TEST_CASES_DIR']+'/*.rb')
      ZTF::LOG.puts "Loading test files: "
      @testfiles = Dir[dir].delete_if { |file| File.basename(file) == @testrunner }
      @testfiles.sort! if ENV['ZTF_RUN_BY_ART']
      @testfiles.each do |file|
        ZTF::LOG.puts file
        require file
      end
      ZTF::LOG.puts "----------------------------------------------------------------------"
      return true
    rescue Exception => e # e.g. ruby syntax error when require file
      ZTF::LOG.error "occurs when requiring test files!"
      ZTF::LOG.error(e)
      TEST_ATTR.skipAllTests = true
      TEST_ATTR.exitvalue = ExitValue::FAIL
      return false
    end

    def initTestCaseSelection
      tag = ':'
      testCases = ENV['XOC_TEST_ONLY']
      if testCases
        ZTF::LOG.puts "XOC_TEST_ONLY is set to \n'#{testCases}'"
        if testCases[0]==tag[0] and testCases[testCases.size-1]==tag[0]
          TEST_ATTR.xocTestOnly = testCases[1..-1].split(tag)
          # TEST_ATTR.xocTestOnly.sort!
          # pp TEST_ATTR.xocTestOnly
        else
          ZTF::LOG.warn "syntax error in XOC_TEST_ONLY '"+ENV['XOC_TEST_ONLY']+"', executing all qualified tests."
        end
      else
        ZTF::LOG.puts "XOC_TEST_ONLY not set, executing all qualified tests."
      end
      ZTF::LOG.puts "----------------------------------------------------------------------"
    end

    # all test cases are added here
    def centralTestSuite
      suite = Test::Unit::TestSuite.new
      ObjectSpace.each_object(Class) do |obj|
        if Test::Unit::TestCase > obj
          suite << obj.suite if runTest?(obj.to_s)
        end
      end
      return suite
    end

    def runTest?(classname)
      fullNotation  = /_Q([usproh]*)Q/i
      levelTag = /[uspr]/i
      modeTag  =/[oh]/i

      # no _Q[level]Q sign found or only _QQ found,
      # then consider it as offline tests with test level "TL_INTEG_ALL"
      if classname.scan(/_Q\w+Q/).empty?
        return true if TEST_ATTR.testMode==/o/
        return false
      end

      arr_status = classname.scan(fullNotation)
      status = arr_status[arr_status.length-1].to_s
      (ZTF::LOG.error "\n"+classname+": has QQ sign, but exists error"; return false) if status.empty?
      status += "spr" if status.index(levelTag).nil? # assign default level
      status += "o"   if status.index(modeTag).nil?  # assign default mode

      # two situations cause not running the test suite
      # quality level is set, but test state and quality level don't match
      # hardware mode is set, but test state and hardware mode don't match
      return true if status.index(TEST_ATTR.testMode) and status.index(TEST_ATTR.testLevel)
      return false
    end

    # read the Smartest project map file
    # @return Hash contain key and value
    def read_property_file(path)
      file = IO.readlines(path).delete_if { |l| l =~ /^#/ or l.strip.size ==0 }.collect { |l| l.strip }
      property = Hash.new
      # The line could be like this: " project = project # this is a relative path""
      file.each do |line|
        k_v = line.split("=")
        property[k_v[0].strip] = k_v[1].strip.split(" ")[0]
      end
      property.each_pair do |k,v|
        if v =~ /^\//
          raise TestConfigError, "#{path} contains absolute path, which is not allowed in INTEG_TEST"
        elsif v =~ /^\$/
          # $(x) -> ENV['x']
          v1 = v.gsub('$','#{ENV').gsub("(","['").gsub(")","']}")
          v_erb_format = '<%= "' + v1 + '" %>'
          property[k] = ERB.new(v_erb_format).result
        end
      end
      return property
    end

    def generate_projects_map(smarTestWorkspace, path)
      workspace_name = smarTestWorkspace.split('/').last
      ZTF::LOG.info("Generating TestBed workspace based on #{path}")
      property = read_property_file(path)
      # first copy projects which are not relative
      absolute_paths = property.values.delete_if { |l| not l =~ /^\// }
      absolute_paths.each do |dir|
        target_dir = File.join(ENV['PWD'],workspace_name,File.basename(dir))
        ZTF::LOG.info("Copy reference project #{dir} to #{File.basename(ENV['PWD'])}/#{workspace_name}")
        not_copy_list = ["SConscript.local.py","SConscript","lock_file",".src-gen",".src-gen-flow"]
        retry_it(3,ZTF::LOG) { copy_without(dir, target_dir, not_copy_list) } # retry at most 3 times if it failed
      end

      if ZTF::LOG.level == ZTF::ZenithLogger::DEBUG
        option = {:verbose => true}
      else
        option = {}
      end
      #puts "chmod -R a+w #{File.join(ENV['PWD'],workspace_name)}"
      #system("chmod -R a+w #{File.join(ENV['PWD'],workspace_name)}") # TODO: replace it with ruby way
      chmod_recursive(File.join(ENV['PWD'],workspace_name),0666,ZTF::LOG,option)

      # 2nd: we generate the magic projects.map by replacing absolute path to relative path
      projects_map_content = "# AUTO GENERATED FILE based on #{path}\n"
      property.keys.each { |key| projects_map_content += "#{key}=#{key}\n" }
      target_projects_map = File.join(ENV['PWD'],workspace_name,@smartest_workspace_project_map)
      ZTF::LOG.info("Generate run time projects.map to #{target_projects_map}")
      f = File.new(target_projects_map,'w')
      f.write(projects_map_content)
    ensure
      f.close if f
    end

    # it builds the SmarTest workspace
    # e.g. convert DSL -> xml
    def buildWorkspace
      @smartest_workspace_project_map = "projects.map"

      # The workspace has been set explicitly in z_integ_test.ksh"
      # Build only this workspace
      smarTestWorkspace = ENV['ZTF_INTEG_TEST_WORKSPACE_DIR'] # TODO: update document
      # if not set, we search from current directory
      if smarTestWorkspace
        unless Dir.entries(smarTestWorkspace).include?(@smartest_workspace_project_map)
          raise TestConfigError, "Given SmarTest workspace #{smarTestWorkspace} defined as env var ZTF_INTEG_TEST_WORKSPACE_DIR doesn't contain #{@smartest_workspace_project_map}"
        end
        smarTestWorkspaces = [smarTestWorkspace]
      else
        smarTestWorkspaces = []
        Find.find(ENV['PWD']) do |path|
          if(File.basename(path) == @smartest_workspace_project_map )
            smarTestWorkspaces << File.dirname(path)
          end
        end
      end
      ZTF::LOG.info "No SmarTest workspace found under #{ENV['PWD']}, skip buildworkspace step!" if smarTestWorkspaces.empty?
      smarTestWorkspaces.each do |smarTestWorkspace|
        origin_projects_map = File.join(smarTestWorkspace,@smartest_workspace_project_map)
        # generate projects.map to TestBed
        generate_projects_map(smarTestWorkspace, origin_projects_map)
        builder_cmd = "#{ENV['WORKSPACE']}/system/bin/tplc #{smarTestWorkspace} #{ENV['PWD']}"
        #builder_cmd = "#{ENV['WORKSPACE']}/CMF-tools/Test/IntegTest/local_tplc #{smarTestWorkspace} #{ENV['PWD']}"
        execute_command("rm -rf "+ File.join(smarTestWorkspace, ".metadata")) # TODO: use ruby way
        execute_command(builder_cmd)
      end
    end

    def runTests
      # require libs ahead of loading tests because tests may already use methods
      # defined in libs while loading them
      # For ruby component tests, they don't need libs
      if TEST_ATTR.test_type == TEST_ATTR.class::RUBY_INTEG_TEST
        require "#{ENV['WORKSPACE']}/CMF-tools/Test/IntegTest/smartestutil"
        if ZTF.smartest_running?
          # This file can only be used when SmarTest is running, otherwise it will throw exception.
          require "#{ENV['WORKSPACE']}/CMF-tools/Test/lib/integtest_api"
        end
      end
      ZTF::LOG.puts "Testing service #{ENV['SERVICE_NAME']}" if ENV['SERVICE_NAME']
      ZTF::LOG.puts  "======================================================================"
      return false if not loadTests
      initTestCaseSelection

      begin
        begin
          WorldFixture.setUpWorld()
          # 1. we only buildworkspace in integration tests, which uses smartest
          # 2. skip the step in quick mode. this env var is set in ruby_integtestframework.rb
          if ZTF::TEST_ATTR.test_type != ZTF::TEST_ATTR.class::RUBY_COMP_TEST and ENV['ZTF_START_SMARTEST'].nil? and ENV['ZTF_QUICK_TEST_MODE'] != "TRUE"
            buildWorkspace
          end
	      rescue ExplicitExit => e
          # ExplicitExit indicates that some expected behavior occurs
          # and we should not continue running test cases
          ZTF::LOG.puts e.message()
          TEST_ATTR.skipAllTests = true
        end
        runner = Test::Unit::UI::Console::TestRunner.run(centralTestSuite, Test::Unit::UI::PROGRESS_ONLY)
        WorldFixture.tearDownWorld()
      rescue ExplicitExit => e
        ZTF::LOG.puts e.message()
      rescue Exception => e
        # if it is not expected exception, the program exit value should not be 0
        if TEST_ATTR.exitvalue == ExitValue::PASS
          TEST_ATTR.exitvalue = ExitValue::FAIL
        end
        raise e
      end
    end

    def runner
      runTests
    end
  end #end of class TestExecutor
end
