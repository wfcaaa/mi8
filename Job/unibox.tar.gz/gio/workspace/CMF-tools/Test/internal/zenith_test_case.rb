#
# = test/unit.rb
#
# Overwrite the Ruby's standard unit testing library
#
# See Test::Unit for documentation.
#
require "test/unit/testcase"

# Overwrite method: Test::Unit::TestCase.suite & Test::Unit::TestCase.run
module Test
  module Unit
    class TestCase
      def self.suite
        method_names = public_instance_methods(true)
        tests = method_names.delete_if {|method_name| method_name !~ /^test./}
        suite = TestSuite.new(name)
        # precondition_checker is normally used in online test mode
        # testers define the condition whether the test suite is runnable in online mode
        # if return false, the test suite will be skipped.
        if ZTF::TEST_ATTR.testMode==/h/ and respond_to?(:canRunOnline?) and (not __send__(:canRunOnline?))
          skipTestSuite = true
        end
        # ZTF::TEST_ATTR.skipAllTests is set to true if setUpWorld fails
        if skipTestSuite or ZTF::TEST_ATTR.skipAllTests
          tests.sort.each do |test|
            if ZTF::TEST_ATTR.xocTestOnly.nil? or ZTF::TEST_ATTR.xocTestOnly.include?(name+'.'+test)
              ZTF::LOG.print "\n+TEST #{name()}.#{test} : #{ZTF::TestAttribute::SKIPPED}"
            end
          end
        else
          tests.sort.each do |test|
            catch(:invalid_test) do
              # XOC_TEST_ONLY not set, we load all test cases
              if ZTF::TEST_ATTR.xocTestOnly.nil?
                suite << new(test)
              else
                # ZTF::TEST_ATTR.xocTestOnly contains the XOC_TEST_ONLY defined tests (Array)
                # it supports both format of only testsuite or testsuite.testcase
                # e.g. :TestSuiteA.testcase1:TestSuiteB:
                # it should execute testcase1 of TestSuiteA and all test cases of TestSuiteB
                if ZTF::TEST_ATTR.xocTestOnly.include?(name+'.'+test) or ZTF::TEST_ATTR.xocTestOnly.include?(name)
                  suite << new(test)
                end
              end
            end
          end
        end
        return suite
      end

      def run(result)
        yield(STARTED, name)
        @_result = result
        begin
          setup
          __send__(@method_name)
        rescue AssertionFailedError => e
          add_failure(e.message, e.backtrace)
        rescue Exception
          raise if PASSTHROUGH_EXCEPTIONS.include? $!.class
          add_error($!)
        ensure
          begin
            teardown
          rescue AssertionFailedError => e
            add_failure(e.message, e.backtrace)
          rescue Exception
            raise if PASSTHROUGH_EXCEPTIONS.include? $!.class
            add_error($!)
          end
        end
        result.add_run
        yield(FINISHED, passed?) #overwrite standard 'yield(FINISHED, name)'
      end

      def name
        "#{self.class.name}.#{@method_name}"
      end
    end #end of class TestCase
  end #end of module Unit
end #end of module Test
