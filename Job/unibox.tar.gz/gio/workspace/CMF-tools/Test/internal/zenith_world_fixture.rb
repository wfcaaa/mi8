
# A default WorldFixture which will be called,
# before/after all testsuites are executed
# Users should overwrite it in the local test runner file,
# if they need WordlFixture.
class WorldFixture
  def self.setUpWorld
  end

  def self.tearDownWorld
  end
end