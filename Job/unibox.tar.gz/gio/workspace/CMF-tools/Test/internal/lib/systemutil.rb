# == Overview
#
# It contains useful system relevant methods
# * it can be required by other ruby files,
#   <b>include module 'SystemUtil' before using the methods in it</b>
# * all methods are in module ZTF
#
# Author::    Zhiwei Xu
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#

require 'set'
require 'pathname'
require 'fileutils'
require 'find'
require 'pp'
require "#{File.dirname(__FILE__)}/zexception"
require "#{File.dirname(__FILE__)}/execute"

# Get the name of current function
module Kernel
private
    def this_method_name
      caller[0] =~ /`([^']*)'/ and $1
    end
end

module SystemUtil
  include Execute
  #
  # it goes though directories, and yield each file (NOT Directory)
  # a link to a file is treated as a file, and will be yield
  #
  def each_file_under(*paths, &block)
    paths.flatten!
    paths.map! { |p| Pathname.new(p) }
    paths.each do |item|
      if item.file?
        yield(item) if block_given?
        next
      end
      begin
        # next if matched_blacklist_of_dirs?(item.to_str)
        if item.symlink?
          realPath = item.realpath.to_str
          orginPath = File.join(Pathname.new(item.dirname).realpath.to_str,item.basename)
          if realPath.empty? or orginPath.index(realPath)==0
            # ZTF::LOG.debug "find recursive link #{item.to_str} --- #{realPath}" if not realPath.empty?
            next
          end
        end
        each_file_under(item.children,&block)
      rescue SystemCallError => e
        #mostly these errors are "No such file or directory" errors
        ZTF::LOG.debug exception2str(e,false)
      rescue StandardError => e
        ZTF::LOG.info exception2str(e)
      end
    end # end of paths.each
  end

  #
  # create the given directory
  # if the given path exists and is not a directory, it will be deleted
  #
  def create_directory(dir, mode=0777)
    if File.exists?(dir)
      return true if File.directory?(dir)
      File.delete(dir)
    end
    FileUtils.mkdir_p(dir, :mode=>mode)
    return true
  rescue Exception => e
    ZTF::LOG.error exception2str(e,false)
    return false
  end

  #
  # remove all materials under a directory
  #
  def cleanup_dir(target)
    FileUtils.remove_dir(target,true) if File.exist?(target)
  end

  #
  # copy things in a directory to another directory
  #
  def copy_dir(from,to)
    FileUtils.copy_entry(from,to,false,false,true)
  rescue Exception => e
    # try with hammer
    cmd = "/bin/cp -rf #{from.gsub(/\/$/,"")} #{to.gsub(/\/$/,"")}"
    execute_command(cmd)
  end

  # copy from one dir to another, but skip copying any file or dir name in blacklist
  # it remove files in destination before copy if it exists
  def copy_without(source_path, target_path, blacklist=[])
    Find.find(source_path) do |source|
      Find.prune if blacklist.include?(File.basename(source))
      target = source.sub(/^#{source_path}/, target_path)
      if File.directory?(source)
        FileUtils.mkdir(target) unless File.exist?(target)
      else
        FileUtils.rm_f(target) if File.exist?(target)
        FileUtils.copy(source,target)
      end
    end
  end

  @@retried_times = 0
  # it retry the given block additional times, if the block throw exception
  # example: SystemUtils.retry_method(3,log) { aaa('dfa') }
  # After retried x times, and the block still throws exception, it throws the exception
  def retry_it(times,log,&block)
    result = block.call
    @@retried_times = 0
    return result
  rescue Exception => e
    log.debug(exception2str(e))
    if @@retried_times < times
      @@retried_times += 1
      sleep 1
      log.info "the operation failed, let's try again, #{@@retried_times} time!"
      retry
    else
      @@retried_times = 0
      raise e
    end
  end

  # TODO: a better way
  def chmod_recursive(path,mod,log=nil,options = {})
    Find.find(path) do |file|
      begin
        if File.directory?(file)
          FileUtils.chmod(0777,file,options)
        else
          FileUtils.chmod(mod,file,options)
        end
      rescue Exception => e
        log.warn "chmod for #{file} failed. "
      end
    end
  end
  #
  # return the real path of a given file
  #
  def realpath(file)
    return Pathname.new(file).realpath.to_str
  rescue Exception => e
    raise TestConfigError, "ERROR: failed to get real path of '#{file}'!", caller
  end

  #
  # copy a file from A to B,
  # succeed: return true, otherwise false
  # If the parent directory of B doesn't exists, they will be created.
  #
  def copy_file(from,to)
    if not File.exist?(from)
      ZTF::LOG.error "#{this_method_name()}: failed to copy file '#{from}' to '#{to}' because '#{from}' doesn't exist!"
      return false
    end
    to_dir = File.dirname(to)
    if not File.exist?(to_dir)
      FileUtils.mkdir_p(to_dir)
    elsif File.directory?(to)
      ZTF::LOG.error "#{this_method_name()}: failed to copy file '#{from}' to '#{to}' because '#{to_dir}' exists and is a file!"
      return false
    end
    FileUtils.cp(from,to)
    return true
  end

  # It moves file, from orig -> dest
  # Or moves dir, from orig  -> dest
  def move_files(orig,dest)
    if orig == dest
      ZTF::LOG.info "#{this_method_name()}: don't need to backup files, since orig & dest is the same!"
      return true
    end
    File.rename(orig, dest)
    return true
  rescue SystemCallError => e
    ZTF::LOG.error "#{this_method_name()}: backup failed!\n"+exception2str(e,false)
    return false
  end

  #
  # = Usage
  # compute_diference oldDir newDir outputDir
  # The program goes through the newDir, compare all files under the directory
  # with files under oldDir line by line, and output the newly generated content
  # of newDir (comparing with oldDir) to outputDir with the same file names.
  #--
  # TODO: replace this by implementing it here.
  def compute_diference(oldDir, newDir, outputDir)
    cmd="#{ENV['WORKSPACE']}/CMF-tools/Test/IntegTest/processLogFiles.rb #{oldDir} #{newDir}  #{outputDir}"
    system(cmd)
  end

  #
  # print available methods in module <b>ZTF</b>
  #
  def ztf_cmd_usage()
    puts "Usage: #{$0} <method_to_call> <arguments_of_method>"
    puts "Available methods are: \n#{(ZTF.public_methods - Object.public_methods).sort.join(" ")}"
    exit(1)
  end

  #
  # = Usage
  # this method processes arguments and convert them to a method call in module <b>ZTF</b>
  #
  def execute_ZTF_method()
    ztf_cmd_usage() if $*.size==0
    method_name= $*[0]
    arguments  = $*[1,$*.size-1]
    if ZTF.respond_to?(method_name.to_sym)
      v = ZTF.send(method_name,*arguments)
      ZTF::LOG.print "[return value of '#{method_name}']: "
      pp v
      return 1 if v==nil or v==false or (v.kind_of?(Fixnum) and v!=0)
      return 0
    elsif method_name =~ /^ZTF_/ and private_methods.include?(method_name)
    # if method is not in module ZTF but defined as a private method
    # call it as well.
      v = send(method_name,*arguments)
      ZTF::LOG.print "[return value of '#{method_name}']: "
      pp v
      return 1 if v==nil or v==false or (v.kind_of?(Fixnum) and v!=0)
      return 0
    else
      ZTF::LOG.error "no such method \"#{method_name}\""
      ztf_cmd_usage()
    end
  rescue SystemExit => e
    exit(e.status)
  rescue TestConfigError, TestRunTimeError => e
    ZTF::LOG.error exception2str(e,false)
    exit(1)
  rescue Exception => e
    ZTF::LOG.error exception2str(e)
    exit(1)
  end

  #
  # It monitors content changes for a given file
  # - snapshot is taken when it is initialized or by calling method "save_end_pos"
  # - by calling method "output_appended_data", it output data to target directory
  #   which is generated after snapshot is taken
  # - example usage: integration test framework use it to generate local system log
  #
  class FileMonitor
    def initialize(file)
      @file_path = SystemUtil::realpath(file)
      @file_info = {}
      save_end_pos
    end

    # It saves the end position of the file into @file_info
    def save_end_pos
      if File.exist?(@file_path)
        f = File.new(@file_path)
        f.seek(0,IO::SEEK_END)
        @file_info[:end]=f.pos
        f.close
      else
        @file_info[:end] = 0
      end
    end

    #
    # This will output appended data of given <file> to directory <output_dir>
    # The starting point is the time when
    # * method save_end_pos is called
    # * this object is initialized
    # Files will be created in <output_dir> with the same file name
    #
    # == arguments
    # output_dir [String] the directory where to output appended data
    #
    def output_appended_data(output_dir)
      SystemUtil::create_directory(output_dir)
      return unless File.exist?(@file_path)
      output_dir = SystemUtil::realpath(output_dir)
      output_dir += '/' unless output_dir =~ /\/$/
      @output_file = File.join(output_dir,File.basename(@file_path))
      f = File.new(@file_path)
      f.pos = @file_info[:end]
      data = f.read()
      f.close
      new_file = File.new(@output_file,"w")
      new_file.write(data)
      new_file.close
    rescue Exception => e
      ZTF::LOG.error exception2str(e)
    ensure
      return @output_file
    end
  end

  #
  # It monitors file changes in given directory
  # - snapshot is taken when it is initialized or by calling method "save_end_pos"
  # - by calling method "output_appended_data", it output data to target directory
  #   which is generated after snapshot is taken
  # - example usage: integration test framework use it to generate local system log
  #
  # == Note
  # - symlinks are not followed and will be ignored
  # - The algorithm only works under the condition that files are always
  #   appended with new stream.
  #   In any other cases, like rename files, overwrite content, this will not work!
  #
  class DirMonitor
    # dir_info is a hash, where each element is a hash as well
    # dir_info[file_path] has following structure:
    # :end => integer, which is the position of EOF
    attr_reader :dir_info

    def initialize(dir_path)
      # make sure dir_path is a complete path
      @dir_path = SystemUtil::realpath(dir_path)
      # make sure dir_path ending with "/"
      @dir_path += '/' unless dir_path =~ /\/$/
      @dir_info = {}
      all_files = traverse_dir(@dir_path)
      # init @dir_info, each file as key attach with a hash
      all_files.each { |file| @dir_info[file] = {} }
      save_end_pos
    end


    # it returns an arrary of files of a given <dir>
    # symlinks will not be followed
    def traverse_dir(dir)
      if File.symlink?(dir)
        # attach with a '/' at the end, it will not be treated as a directory
        dir = dir + "/"
      end
      all_files=[]
      Find.find(dir) { |f| all_files << f if File.file?(f) }
  #    puts all_files
      # replace the relative path to absolute path
      all_files.map! do |f|
        if f.index("/") != 0
          File.join(Dir.pwd,f)
        else
          f
        end
      end
      return all_files
    end

    # It saves the end position of all files in @dir_info
    def save_end_pos
      @dir_info.each_key do |file|
        f = File.new(file)
        f.seek(0,IO::SEEK_END)
        @dir_info[file][:end]=f.pos
        f.close
      end
    end

    #
    # This will output appended data of given <files> to directory <output_dir>
    # The starting point is the time when
    # * method save_files_end_pos is called
    # * this object is initialized
    # Files will be created in <output_dir> with the same file names
    #
    # == arguments
    # output_dir [String] the directory where to output appended data
    #
    # == Note
    # if no appended data, then file will not be created
    #
    def output_appended_data(output_dir)
      @output_files = []
      SystemUtil::create_directory(output_dir)
      output_dir = SystemUtil::realpath(output_dir)
      output_dir += '/' unless output_dir =~ /\/$/
      # traverse the origin dir again, update file structure
      updated_all_files = traverse_dir(@dir_path)
      # generate files to this dir
      updated_all_files.each do |file|
        new_path = file.sub(@dir_path,output_dir)
        if @dir_info.has_key?(file)
          f = File.new(file)
          f.pos = @dir_info[file][:end]
          data = f.read()
          f.close
          if data.size == 0
            next
          else
            # create dir in case it doesn't exist in new dir
            SystemUtil::create_directory(File.dirname(new_path))
          end
          new_file = File.new(new_path,"w")
          new_file.write(data)
          new_file.close
        else
          SystemUtil::create_directory(File.dirname(new_path))
          FileUtils.copy_file(file,new_path)
        end
        @output_files << new_path
      end
    rescue Exception => e
      ZTF::LOG.error exception2str(e)
    ensure
      return @output_files
    end
  end

  module_function :create_directory, :realpath,:cleanup_dir,
    :copy_dir, :copy_file, :move_files

end # end of module

