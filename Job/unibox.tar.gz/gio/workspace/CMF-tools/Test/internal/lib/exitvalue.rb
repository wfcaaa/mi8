
# this module define the exit value of a program
# e.g. ExitValue::Pass == 0
# this is the same as in FeatBuild
module ExitValue
  PASS  = 0
  FAIL  = 1
  FATAL = 2
  KILLED = 3
  INCOMPLETE = 4
  ERROR = 5
  DISABLED = 6
  NONE = 7
end