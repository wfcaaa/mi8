require 'test/unit'
# /path/to/test/script_test.rb => /path/to/script.rb
require "#{__FILE__.sub(/test\/(.*)_test\.rb$/, '\1.rb')}"
# This test here doesn't check the result write to unobridge
# require "#{ENV['WORKSPACE']}/lib/libservices_ruby_UnoBridge"

class Write2FileTest < Test::Unit::TestCase
  def setup
    @file = '/tmp/__test__log.no'
    system("rm -f #{@file}")
    @log  = ZTF::ZenithLogger.new(@file)
  end

  def teardown
    @log.close
  end

  def test_set_level
    @log.level = ZTF::ZenithLogger::INFO
    assert_equal(@log.level,ZTF::ZenithLogger::INFO)
    msg = "This should not be print out!"
    @log.debug(msg)
    assert_equal(IO.readlines(@file).size, 1)
  end

  def test_all_severity
    msg = "hello"
    all_severity = [:debug, :info, :warn, :error, :fatal]
    all_severity.each do |method|
      @log.send(method, msg)
    end
    lines = IO.readlines(@file)
    lines.delete_at(0)# line 0 is the comment from logger
    lines.each_index do |index|
      matched_pattern(all_severity[index],msg,lines[index])
    end
  end

  # e.g.
  # DEBUG: "hello" [05-09-2013T09:39:19 #22546]
  def matched_pattern(severity,msg,formated_msg)
    content = formated_msg.split
    assert_equal(severity.to_s.upcase+":",content[0])
    assert_equal(%Q{#{msg}},content[1])
  end

  def test_puts_print
    msg = "hello"
    @log.print msg
    @log.puts msg
    lines = IO.readlines(@file)
    assert_equal( lines[1], msg+msg+"\n" )
  end
end





