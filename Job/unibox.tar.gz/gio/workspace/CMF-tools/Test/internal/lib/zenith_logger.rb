require 'logger'
require 'pp'
require 'set'

module ZTF
  #
  # it customize the default Logger to another short style
  # severity: msg time #programId, e.g.
  # DEBUG: "hello" [05-09-2013T09:39:19 #22546]
  #
  class PrettyLogger < Logger
    def initialize(logdev)
      super
      # @formatter is initialized in Logger
      @formatter = ZFormatter.new
    end

    def print(msg)
      if @logdev.respond_to?(:print)
        @logdev.print(msg2str(msg))
      else
        @logdev.write(msg2str(msg))
      end
    end

    def puts(msg)
      if @logdev.respond_to?(:puts)
        @logdev.puts(msg2str(msg))
      else
        @logdev.write(msg2str(msg)+"\n")
      end
    end

    def msg2str(msg)
      @formatter.msg2str(msg)
    end

    class ZFormatter
      Format = "%s: %s %s[%s#%d]\n"

      attr_accessor :datetime_format
      def initialize
        @datetime_format = "%d-%m-%YT%H:%M:%S "
      end

      def call(severity, time, progname, msg)
        progname = "-- "+progname+" " if progname
        Format % [severity, msg2str(msg), progname, format_datetime(time), $$ ]
      end

      def msg2str(msg)
        case msg
        when ::String
          msg
        when ::Exception
          "#{ msg.message } (#{ msg.class })\n" <<
          (msg.backtrace || []).join("\n")
        else
          msg.inspect
        end
      end

      private

      def format_datetime(time)
        time.strftime(@datetime_format)
      end
    end # class ZFormatter
  end # class PrettyLogger

  #
  # ZenithLogger prints message to 2 places
  # 1. given logdev with following formats
  #    severity: msg time #programId
  #    e.g. DEBUG: "hello PrettyLogger" [05-09-2013T09:39:19 #22546]
  # 2. write the msg (without format) to xoc logger via RubyUNO if it is available
  #
  # == HOWTOs
  #
  # === How to use it
  # logger = ZenithLogger.new(STDOUT)
  # logger.debug "hello" # DEBUG: "hello" [05-09-2013T09:39:19 #22546]
  # logger.info  "hello" # INFO: "hello" [05-09-2013T09:39:19 #22546]
  # logger.warn  "hello" # WARN: "hello" [05-09-2013T09:39:19 #22546]
  # logger.error "hello" # ERROR: "hello" [05-09-2013T09:39:19 #22546]
  # logger.fatal "hello" # FATAL: "hello" [05-09-2013T09:39:19 #22546]
  ### The following 2 methods are special ones without any format
  ### and they will call RubyUNO.xocInfo("hello")
  # logger.puts  "hello" # "hello"+"\n"
  # logger.print "hello" # "hello"
  #
  # === Setting severity threshold
  # logger.level = Logger::INFO
  #
  # DEBUG < INFO < WARN < ERROR < FATAL < UNKNOWN
  # 1. logger.puts is always printed without threshold
  #
  #--
  # The Logger in 1.8.7 doesn't support format customization
  # I have to implement a PrettyLogger inherited from Logger to customize the
  # formatter
  #
  class ZenithLogger < PrettyLogger

    LOGGING_METHOD = {
      :debug => :xocDebug,
      :info  => :xocInfo,
      :warn  => :xocWarn,
      :error => :xocError,
      :fatal => :xocFatal,
      :print => :xocInfo,
      :puts  => :xocInfo
    }

    LOGGING_METHOD.each do |method_name, rubyuno_name|
      define_method(method_name) do |args|
        begin
          super
          RubyUNO.send(rubyuno_name, msg2str(args)) if defined?(RubyUNO)
        rescue Exception
        end
      end
    end

    def initialize(logdev)
      super
    end

    def level_to_s
      str = ['DEBUG','INFO','WARN','ERROR','FATAL','UNKNOWN']
      return str[@level]
    end
  end # class ZenithLogger

  LOG = ZTF::ZenithLogger.new(STDOUT)
  LOG.level = ZTF::ZenithLogger::INFO
end

=begin
if $0 == __FILE__
  require "#{ENV['WORKSPACE']}/lib/libservices_ruby_UnoBridge"

  log = ZTF::LOG
  log.level = ZTF::ZenithLogger::INFO

  log.debug "hello"
  log.info "hello"
  log.warn "hello"
  log.error "hello"
  log.fatal("PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP"+"again")
  log.print "this has no format"
  log.puts  "\n"+'this has no format but with \n'
  log.print "this has no format"
  log.close
end
=end
