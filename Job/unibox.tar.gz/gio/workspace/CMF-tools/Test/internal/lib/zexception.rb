# == Overview
#
# It defines custom exceptions
#
# Author::    Zhiwei Xu, 03.09.2012
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#

#
# This class add an extra message "[String] reason"
# which can be added ahead of existing RuntimeError exception
# Usage:
#  begin
#    try_something_out
#  rescue RuntimeError => e
#    raise ZTestError.new(e, "because try_something_out doesn't work!")
#  end
#
class ZTestError < RuntimeError
  def initialize(exception,reason=nil)
    if reason
      @extra_msg = reason + "\n"
    else
      @extra_msg = ""
    end
    super(exception)
  end

  def to_s
    @extra_msg + super
  end
end

# it indicates that an error occurs because
# the configuration of a test is not correct
# most likely, it is a user's error
#
class TestConfigError < ZTestError
end

#
# it indicates that an error occurs during runtime due to some env issue
# most likely, it is not the user's fault
#
class TestRunTimeError < ZTestError
end

#
# It indicates that the user/framework want to exit the program explicitly
#
class ExplicitExit < ZTestError
end

# convert an exception to a string with class, message and
# ( backtrace , if set to true)
def exception2str(e,backtrace=true)
  str = "#{e.class} exception raised with following message:"+
    "\n#{e.message}"
  if backtrace
    str += "\nBacktrace: #{(e.backtrace || []).join("\n\t")}"
  end
  return str
end

##
# These exceptions are not caught in most cases.
Z_PASSTHROUGH_EXCEPTIONS = [NoMemoryError, SignalException, Interrupt, SystemExit]
