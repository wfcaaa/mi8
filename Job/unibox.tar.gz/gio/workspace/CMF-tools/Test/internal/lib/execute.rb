require 'timeout'

module Execute
  # Execption being raised if execution of any command produces non-zero exit status
  class ExecutionError < StandardError
  end

  # ######
  # Function to execute a shell command, a replacement of system()
  # If the shell commands returns a non-zero exit status an
  # ExecutionError exception is raised.
  def execute_command(command, timeout=0, cleanup=true, log = nil)
    log.debug( "Execute: #{command}" ) if log

    pid = fork { exec(command) }
    Timeout::timeout(timeout) do
      Process.wait(pid)
    end

    raise ExecutionError,
      "execution of cmd '#{command}' failed with exit code #{$?}",
      caller unless $?.success?
  ensure
    log.debug("Execute exit status: #{status.exitstatus}") if log
    if process_exist?(pid)
      if cleanup
        ZTF::LOG.info "killing process #{pid} started by '#{command}'"
        kill_process(pid)
      else
        ZTF::LOG.warn "process with pid #{pid} is still running, \
it is not killed since we are in debug mode! Please kill it manually!"
      end
    end
  end

  def process_exist?(pid)
    Process.getpgid(pid)
    return true
  rescue Errno::ESRCH # if pid doesn't exist, it raises this exception
    return false
  end

  def kill_process(pid)
    Process.kill("TERM", pid)
  end

end