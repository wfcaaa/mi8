#
# Overwrite the Ruby's standard unit testing library
#
# See Test::Unit for documentation.
#
require "test/unit/testsuite"

# Overwrite class: Test::Unit::TestSuite
# in order to support singeleton setup / teardown methods for each TestCase
#
module Test
  module Unit
    class TestSuite
      # Runs the tests and/or suites contained in this TestSuite.
      # NOTE: this method is called recursively
      # @tests is always an Array, so I have to use @tests[0] to get the object
      # 1st run: @tests contains a TestSuites which have multiple TestSuites internally.
      # 2nd level: @tests contains a TestCase
      #
      def run(result, &progress_block)
        yield(STARTED, name)
        self_setup_succeed = run_singeleton_method_in_testcase("setup") #TODO: obsolete this, replaced by setup_testcase
        setup_succeed = run_instance_method_in_testcase("setup_testcase")
        @tests.each do |test|
          if self_setup_succeed and setup_succeed
            test.run(result, &progress_block)
          else
            ZTF::LOG.puts "+TEST #{test} : #{ZTF::TestAttribute::SKIPPED} "
          end
        end
        run_instance_method_in_testcase("teardown_testcase")
        run_singeleton_method_in_testcase("teardown") #TODO: obsolete this, replaced by teardown_testcase
        yield(FINISHED, name)
      end

    private
      def run_instance_method_in_testcase(method_name)
        @tests[0].send(method_name.to_sym) if @tests[0].methods.include?(method_name)
        return true
      rescue Exception => e
        raise if Z_PASSTHROUGH_EXCEPTIONS.include?(e.class)
        ZTF::LOG.puts ""
        ZTF::LOG.error "exception raised when executing method #{@tests[0]}.#{method_name}"
        ZTF::LOG.puts exception2str(e)
        return false
      end

      def run_singeleton_method_in_testcase(method_name)
        if @tests[0].class.singleton_methods.include?(method_name)
          puts "ERROR: self.#{method_name} is obsolete, please replace it with #{method_name}_testcase! "
          @tests[0].class.send(method_name.to_sym)
        end
        return true
      rescue Exception => e
        raise if Z_PASSTHROUGH_EXCEPTIONS.include?(e.class)
        ZTF::LOG.puts ""
        ZTF::LOG.error "exception raised when executing method #{@tests[0].class}.#{method_name}"
        ZTF::LOG.puts exception2str(e)
        return false
      end
    end #end of class TestSuite
  end #end of module Unit
end #end of module Test
