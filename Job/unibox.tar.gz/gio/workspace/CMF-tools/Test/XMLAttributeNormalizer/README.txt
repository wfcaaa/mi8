XMLAttributeNormalizer tool , a command line tool which normalizes xml files so that it can be used for result verifications.
=============================================================================================================================

Procedure for making enhancements to this tool ::

-> Check out the relevant files under the Main directory for the code change
   viz. any of the XmlAttributeNormalizer.cpp, XmlAttributeNormalizer.hpp, main.cpp

-> Check out the executable XMLAttributeNormalizer

-> Build the tool after commiting the changes, and test it thoroughly.

-> Checkin all the checkout files.

