/**
 ****************************************************************************
 *
 * Implementation of class XmlAttributeNormalizer.
 *
 * Copyright by Agilent Technologies, 2006
 *
 * @file    XmlAttributeNormalizer.cpp
 *
 * @author  PSPL
 *
 * @date    09-08-2006
 *
 ****************************************************************************
 */
#include "XmlAttributeNormalizer.hpp"

using namespace ::std;

namespace
{
  /**
   * Replaces all occurrences of a one string with another string
   * in the specified string.
   *
   * NOTE: Input string is modified !
   *
   * @param strIn   String in which replacements have to be made.
   * @param pWhat   String which needs to be replaced.
   * @param pWith   Replacement for the string to be replaced.
   *
   */
  void findAndReplace(
      string& strIn, const char* pWhat, const char* pWith)
  {
    size_t pos     = 0;
    size_t lenWhat = strlen(pWhat);
    size_t lenWith = strlen(pWith);

    while(string::npos != (pos = strIn.find(pWhat, pos)))
    {
      strIn.replace(pos, lenWhat, pWith);
      pos += lenWith;
    }
  }

  /**
   * Replaces characters not allowed in XML attribute values with
   * valid characters.
   *
   * @param attrVal  String to be used as an XML attribute value
   *
   * @return String with invalid characters replaced.
   */
  string makeValidXmlAttributeValue(const string& attrVal)
  {
    string retVal = attrVal;

    findAndReplace(retVal, "&",  "&amp;");
    findAndReplace(retVal, "<",  "&lt;");
    findAndReplace(retVal, "\"", "&quot;");
    findAndReplace(retVal, "\'", "&apos;");

    return retVal;
  }
}

// Methods of class DefaultHandler

XmlAttributeNormalizer::XmlAttributeNormalizer(list<string> attributeList)
  :
  mNormalized(false),
  mConsiderComments(false)
{
  while(attributeList.size() > 0)
  {
    mSubIndexTable.insert(make_pair(attributeList.front(),0));
    attributeList.pop_front();
  }
}


XmlAttributeNormalizer::~XmlAttributeNormalizer()
{
  mSubstitutionTable.clear();
  mSubIndexTable.clear();
}


void XmlAttributeNormalizer::startDocument()
{
  mOutputStream << "<?xml version='1.0' encoding='UTF-8'?>\n";
}


void XmlAttributeNormalizer::startElement(
  const XMLCh* const uri,
  const XMLCh* const localname,
  const XMLCh* const qname,
  const Attributes& attrs)
{
  mOutputStream << '<' << XMLString::transcode(localname);

  int numOfAttrbs = attrs.getLength();
  if( numOfAttrbs > 0 )
  {
    map < string, string >::iterator substitutionTableItr;
    map < string, int >::iterator subIndexTableItr;
    string attribToCompare;
    string valToReplace;
    string valToSubstitute;
    for(int index = 0; index < numOfAttrbs; ++index)
    {
      // Check if the attribute value to be substituted is present in the
      // map, if yes then we take the corresponding substitution string from
      // from the substitution table and replace the value of the attribute
      // with it in the normalized output.
      attribToCompare = string(XMLString::transcode(attrs.getLocalName(index)));
      valToReplace = makeValidXmlAttributeValue(XMLString::transcode(attrs.getValue(index)));

      // If the attribute getting parsed is not the one intended, we keep its
      // value unchanged in the normalized output.
      valToSubstitute = valToReplace;

      // Check if the attribute encountered is the one to be normalized.
      subIndexTableItr = mSubIndexTable.find(attribToCompare);
      if(mSubIndexTable.end() != subIndexTableItr)
      {
        // Set the mNormalized flag
        mNormalized = true;

        // Check if the attribute value to be normalized is present in the
        // substitution table.
        valToReplace = valToReplace + "_" + attribToCompare;
        substitutionTableItr = mSubstitutionTable.find(valToReplace);
        if(mSubstitutionTable.end() != substitutionTableItr)
        {
          valToSubstitute = (*substitutionTableItr).second;
        }
        else
        {
          // If the attribute value to be normalized is not present then
          // construct the value to be replaced with.Add the same value in the
          // mSubstitutionTable and update the entry in the mSubIndexTable too.
          ostringstream oss;
          oss << ((*subIndexTableItr).second)++;
          valToSubstitute = attribToCompare + "_" + oss.str();
          mSubstitutionTable.insert(make_pair(valToReplace, valToSubstitute));
        }
      }
      mOutputStream << " " << attribToCompare << "=\""
        << valToSubstitute << "\"";
    }
  }
  mOutputStream << ">";
}


void XmlAttributeNormalizer::characters(
  const XMLCh* const chars,
  const unsigned int length )
{
  if(length > 0)
  {
    mOutputStream << XMLString::transcode(chars);
  }
}


void XmlAttributeNormalizer::ignorableWhitespace(
  const XMLCh* const chars,
  const unsigned int length )
{
  if(length > 0)
  {
    mOutputStream << XMLString::transcode(chars);
  }
}


void XmlAttributeNormalizer::endElement(
  const XMLCh* const uri,
  const XMLCh* const localname,
  const XMLCh* const qname )
{
  mOutputStream << "</" << XMLString::transcode(localname) << ">";
}


void XmlAttributeNormalizer::processingInstruction(
  const XMLCh* const target,
  const XMLCh* const data)
{
  mOutputStream << "<?" << XMLString::transcode(target);

  if(XMLString::stringLen(data) > 0)
  {
    mOutputStream << ' ' << XMLString::transcode(data);
  }

  mOutputStream << "?>";
}
void XmlAttributeNormalizer::comment(
  const XMLCh* const chars,
  const unsigned int length )
{
  if(mConsiderComments == true)
  {
    mOutputStream << "<!--";
    if(length > 0)
    {
      mOutputStream << XMLString::transcode(chars);
    }
    mOutputStream << "-->";
  }
}

void XmlAttributeNormalizer::startDTD(
  const XMLCh* const name,
  const XMLCh* const publicId,
  const XMLCh* const systemId )
{
  mOutputStream << "<!DOCTYPE " << XMLString::transcode(name);

  if(XMLString::stringLen(publicId) > 0)
  {
    mOutputStream << " PUBLIC \""<< XMLString::transcode(publicId) << "\"";
  }

  if(XMLString::stringLen(systemId))
  {
    mOutputStream << " SYSTEM \""<< XMLString::transcode(systemId) << "\"";
  }

  mOutputStream << " >\n\n";

  // Set the flag to false as we don't consider the comments in the DTD.
  mConsiderComments = false;
}

void XmlAttributeNormalizer::endDTD()
{
  // Set the flag to true. We consider the comments as we have now finished the
  // DTD processing.
  mConsiderComments = true;
}

void XmlAttributeNormalizer::setUp(string xmlFile)
{
  // initialize the mNormalized flag and the mXmlFile variable.
  mNormalized = false;
  mXmlFile = xmlFile;

  // Build output filename
  mTargetXmlFile = xmlFile;
  string::size_type nDotPos = mTargetXmlFile.rfind(".");
  if(string::npos == nDotPos)
  {
    mTargetXmlFile += "_normalized";
  }
  else
  {
    mTargetXmlFile.replace(nDotPos, 1, "_normalized.");
  }

  mOutputStream.open(mTargetXmlFile.c_str());

  cout << "Normalizing file : " << mXmlFile << endl;
}


void XmlAttributeNormalizer::tearDown( bool exceptionOccured)
{
  mOutputStream.close();

  if(!mNormalized || exceptionOccured)
  {
    if(remove(mTargetXmlFile.c_str()) == -1)
    {
      cout << "ERROR: Cannot remove file : " << mTargetXmlFile << endl;
    }
  }

  if(!mNormalized)
  {
    cout << "INFO: The attributes passed in as arguments that are to be\
 normalized don't exist in " << mXmlFile << " !!!" << endl;
  }
  else if(!exceptionOccured)
  {
    cout << "Done. Normalized file : " << mTargetXmlFile << endl;
  }
}
