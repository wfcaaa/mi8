#ifndef _XMLATTRIBUTENORMALIZER_HPP_
#define _XMLATTRIBUTENORMALIZER_HPP_
/**
 ****************************************************************************
 *
 * Header file with definition for class XmlAttributeNormalizer and normalize().
 *
 * Copyright by Agilent Technologies, 2006
 *
 * @file    XmlAttributeNormalizer.hpp
 *
 * @author  PSPL
 *
 * @date    09-08-2006
 *
 ****************************************************************************
 */
#include <xercesc/sax2/Attributes.hpp>
#include <xercesc/sax2/DefaultHandler.hpp>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLString.hpp>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <list>
#include <map>

XERCES_CPP_NAMESPACE_USE

class XmlAttributeNormalizer : public DefaultHandler
{
  public:
    XmlAttributeNormalizer( std::list<std::string> attributeList );

    virtual ~XmlAttributeNormalizer();

    // Methods of class DefaultHandler.

    void startDocument();

    void startElement(const XMLCh* const uri,
      const XMLCh* const localname,
      const XMLCh* const qname,
      const Attributes& attrs);

    void endElement(
      const XMLCh* const uri,
      const XMLCh* const localname,
      const XMLCh* const qname );

    void characters(
      const XMLCh* const chars,
      const unsigned int length );

    void ignorableWhitespace(
      const XMLCh* const chars,
      const unsigned int length );

    void processingInstruction( const XMLCh* const target,
      const XMLCh* const data);
    void comment(
      const XMLCh* const chars,
      const unsigned int length );

    void startDTD(
      const XMLCh* const name,
      const XMLCh* const publicId,
      const XMLCh* const systemId );

    void endDTD();


    /****************************************************************************
     *
     * sets the ofstreamInst ofstream with the passed in xml file.
     * and also sets the mNormalizd flag to true.
     *
     * @param string xmlFile
     *                 target xml file containing the normalized output.
     *
     * @author PSPL
     *
     ****************************************************************************
     */
    void setUp(::std::string xmlFile);

    /****************************************************************************
     *
     * Closes the ofstreamInst ofstream and also checks if any normalization
     * was carried out during the entire  parsing process.
     *
     * @author PSPL
     *
     * @param exceptionOccured  boolean argument specifying if at all any exception
     *                          was thrown at the time of parsing.
     *
     ****************************************************************************
     */
    void tearDown(bool exceptionOccured);

  private :

    // ofstream to write the normalized output into.
    ::std::ofstream mOutputStream;

    // Map that holds the attribute values and the corresponding substitution
    // done for the same.
    ::std::map < ::std::string, ::std::string > mSubstitutionTable;

    // Map that holds the Index to hold count of the number of entries respective to
    // to the corresponding attribute in the mSubstitutionTable map.
    ::std::map < ::std::string, int > mSubIndexTable;

    // Flag to check if file is normalized
    bool mNormalized;

    // Xml file to be normalized.
    ::std::string mXmlFile;

    // File containing normalized output.
    ::std::string mTargetXmlFile;

    // Flag to decide whether to consider comments during parsing
    bool mConsiderComments;

};

#endif //_XMLATTRIBUTENORMALIZER_HPP_

