# This file was generated from a Makefile.local
# Remove the '#GENERATED' first line if you edit it!
{
'PROJECT_TYPE' : ['c_program'] ,
'NAME' : ['XMLAttributeNormalizer'] ,
'DEST' : ['..'],
'LDFLAGS_LOCAL' : ['$LDFLAGS_XERCES'] ,
'CXXFLAGS_LOCAL' : ['$CXXFLAGS_XERCES', '-Wno-sign-compare']
}
# +++ map above generated from this Makefile.local:
#PROJECT_TYPE   = c_program
#NAME           = XMLAttributeNormalizer
#
#CXXFLAGS_LOCAL     = -Wno-sign-compare  # because of xerces warning
#INCLUDE_PATH_LOCAL = $(INCLUDE_PATH_XERCES)
#LDFLAGS_LOCAL  = $(LDFLAGS_XERCES)
#CXXFLAGS_LOCAL     = -Wno-sign-compare  # because of xerces warning
