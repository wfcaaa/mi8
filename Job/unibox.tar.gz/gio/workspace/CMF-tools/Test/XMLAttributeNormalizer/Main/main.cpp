#include "XmlAttributeNormalizer.hpp"
#include <xercesc/sax2/SAX2XMLReader.hpp>
#include <xercesc/sax2/XMLReaderFactory.hpp>
#include <sys/stat.h>

using namespace ::std;

/****************************************************************************
 *
 * Returns usage information
 *
 * @author PSPL
 *
 ****************************************************************************
 */
const char* usage()
{
  static const char message[]=
"===============================USAGE INFORMATION============================\n"
"NAME\n"
"\tXMLAttributeNormalizer- Normalizes the XML file(s)\n\n"
"SYNOPSIS\n"
       "\tXMLAttributeNormalizer -h\n"
       "\tXMLAttributeNormalizer -a Attribute [-a Attribute ...] File [File ...]\n\n"
"DESCRIPTION\n"
       "\tXMLAttributeNormalizer normalizes the named input FILE(S).\n"
       "\tSome XML files generated/dumped as part of the Zenith\n"
       "\tDevelopment/Test process which contain 'dynamic values'\n"
       "\t(e.g. addresses/locations).\n"
       "\tThese values changes with each execution cycle.\n"
       "\tThe process of Normalizing involves replacing the dynamic values\n"
       "\twith some identifier()numeric or string\n\n"
"OPTIONS\n\n"
       "\t-h|-H                        = Help.\n"
       "\t-a                           = Used to specify the Attribute Name.\n"
       "\tAttribute                    = Attribute Name Specified should "
       "be case sensitive.\n"
       "\txmlfilename1 xmlfilename2 .. = Space separated xml files.\n"
       "\n"
       ;
  return message;
}

/****************************************************************************
 *
 * Performs normalization for the specified XML file
 *
 * @author PSPL
 *
 * @param parser    Instance of parser to use for normalization.
 *
 * @param xmlFile   File to be normalized.
 *
 * @return 1 if exception is thrown else 0.
 *
 ****************************************************************************
 */
int normalize(SAX2XMLReader* parser, char* xmlFile)
{
  int retVal = 0;
  try
  {
    // Parse (normalize) it
    parser->parse(xmlFile);
  }
  catch(const SAXParseException& e)
  {
    char* message = XMLString::transcode(e.getMessage());
    cout << "Normalization failed for the file :" << xmlFile << "\n";
    cout << "Exception message is: \n" << message << "\n";
    XMLString::release(&message);
    retVal = 1;
  }
  catch(const XMLException& e)
  {
    char* message = XMLString::transcode(e.getMessage());
    cout << "Normalization failed for the file :" << xmlFile << "\n";
    cout << "Exception message is: \n" << message << "\n";
    XMLString::release(&message);
    retVal = 1;
  }
  catch(...)
  {
    cout << "Normalization failed for the file :" << xmlFile << "\n";
    cout << "Unexpected Exception\n";
    retVal = 1;
  }
  return retVal;
}

/****************************************************************************
 *
 * The Main function does the following things:
 * 1.	Separation, parsing and validation of command line arguments
 * 2.	Error handling for missing or unreadable files
 * 3.	Replacement of attribute values for attribute specified
 *     by the user with a certain specifiers i.e. attribute normalization
 *
 * @author  PSPL
 *
 ****************************************************************************
 */
int main(int argC, char* argV[])
{
  if(argC < 4)
  {
    cout << usage();
    return 1;
  }

  bool moreAttributes = true;
  int argVIndex = 1;
  list<string> attributeList;
  int retVal = 0;

  // form a list of all the attributes passed in as arguments
  for( ; (argVIndex < argC) && (true == moreAttributes); )
  {
    if(0 == strcasecmp("-a", argV[argVIndex]))
    {
      // check if any attribute is specified after the -a option
      if(argVIndex+1 < argC)
      {
        attributeList.push_back(argV[argVIndex+1]);

        // increment the argVIndex by 2 , to point to the next -a occurence in
        // passed in command line arguments.
        argVIndex = argVIndex + 2;
      }
      else
      {
        cout << usage();
        return 1;
      }
    }
    else
    {
      moreAttributes = false;
    }
  }

  // Call routines that will normalize the input file with respect to the
  // input attributes.

  // Check if atleast a single attribute and a file was passed in as arguments.
  if( (attributeList.size() > 0) && (argVIndex < argC) )
  {
    cout << "Attributes to be normalized: ";
    for(std::list<string>::iterator listIter = attributeList.begin();
        listIter != attributeList.end(); listIter++)
    {
      cout<<*listIter<<"   ";
    }
    cout<<endl;

    try
    {
      XMLPlatformUtils::Initialize();
    }
    catch(const XMLException& e)
    {
      char* message = XMLString::transcode(e.getMessage());
      cout << "Error during initialization! :\n" << message << "\n";
      XMLString::release(&message);
      return 1;
    }

    // Create the document handler instance
    XmlAttributeNormalizer* defaultHandler = new XmlAttributeNormalizer(attributeList);

    // Create the parser instance and initialize it
    SAX2XMLReader* parser = XMLReaderFactory::createXMLReader();
    parser->setFeature(XMLUni::fgSAX2CoreValidation, true);
    parser->setFeature(XMLUni::fgSAX2CoreNameSpaces, true);
    parser->setContentHandler(defaultHandler);
    parser->setErrorHandler(defaultHandler);
    parser->setLexicalHandler(defaultHandler);
    parser->setDTDHandler(defaultHandler);
    parser->setDeclarationHandler(defaultHandler);
    bool exceptionOccured = false;

    // Call normalize() on the passed in files.
    for(int indexFile = argVIndex; indexFile < argC; ++indexFile)
    {
      struct stat sBuf;
      if(stat(argV[indexFile], &sBuf))
      {
        cout << "ERROR: The file " << argV[indexFile]
          << " could not be found. Skipping this file.\n";
      }
      else
      {
        // Set the file to be normalized
        defaultHandler->setUp(string(argV[indexFile]));

        // Normalize the input file
        if(normalize(parser, argV[indexFile]) == 1)
        {
          exceptionOccured = true;
          retVal = 1;
        }

        // Close the output file
        defaultHandler->tearDown(exceptionOccured);
      }
    }

    delete defaultHandler;
    delete parser;

    XMLPlatformUtils::Terminate();
  }
  else
  {
    cout << usage();
    return 1;
  }
  return retVal;
}
