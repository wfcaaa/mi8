#!/usr/bin/env zruby
#
# = overview
# This file contains a set of module functions which are used by ruby integration
# Test.
#
# = Note
# At the time you require this file, please make sure that SmarTest is running.
# Otherwise, it will throw an exception.
#
# The usage is simple:
# 1. Require this file, e.g.
#    require "#{ENV['WORKSPACE']}/CMF-tools/Test/lib/integtest_api"
#    It is not necessary to require this file if you are using "Ruby Integration Test Framework"
# 2. Call the method you want, e.g. ZTF.method_name
# 3. If you want to see all available methods, use ZTF.singleton_methods to print all methods
#
# Author::    Zhiwei Xu
# Copyright:: Copyright (c) 2012 Advantest Europe GmbH
#
#
require "#{ENV['WORKSPACE']}/lib/libservices_ruby_UnoBridge"
require "#{ENV['WORKSPACE']}/CMF-tools/Test/internal/lib/zexception"
require "#{ENV['WORKSPACE']}/CMF-tools/Test/internal/lib/zenith_logger"

require "#{File.dirname(__FILE__)}/hwtag_utils"
# TODO: this following line should be deleted in furture
require "#{File.dirname(__FILE__)}/hwtag_utils_obsolete"
require "#{File.dirname(__FILE__)}/ruby_template_generator"
#
# module ZTF stands for Zenith Test Framework, which provides a set of useful
# functions for writing unit tests in ruby.
#
# Feel free to add more functions.

