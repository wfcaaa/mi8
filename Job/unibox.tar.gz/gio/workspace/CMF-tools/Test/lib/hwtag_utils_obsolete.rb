module ZTF
  # 
  # It initializes instance variables used in other module functions
  #
  # == Note
  # This function is called automatically when this file is required.
  #
  def self.init_zhwtag_utils # :nodoc:
    @tagController = RubyUNO::xocGetImplementer("xoc.hw.cor.rid.ZHwTagController")
    @idService =  RubyUNO::xocGetImplementer("xoc.svc.ZIDService")
    @logicalBoardId = @idService.getId("LogicalBoard")
    @channelId = @idService.getId("Channel")
    @obsolete_msg = "[DEPRECATION] method %s is deprecated.  Please use %s instead."
  end

  # 
  # return the value of tagController.createHwTagFromType(@idService.getId("LogicalBoard"))
  #
  def self.logicalBoard # :nodoc:
    logicalBoard = @tagController.createHwTagFromType(@logicalBoardId)
    if not logicalBoard
      raise ExplicitExit, "\nERROR: can not get LogicalBoards!", caller
    end
    return logicalBoard
  end

  #
  # return the value of tagController.createHwTagFromType(@idService.getId("Channel"))
  #
  def self.channels # :nodoc:
    channels = @tagController.createHwTagFromType(@channelId)
    if not channels
      raise ExplicitExit, "\nERROR: can not get channels!", caller
    end
    return channels
  end

  # 
  # converts iterator of ZHwTag to an array containing all elements
  #
  def self.iterator2Array(iter, iterType=:element) # :nodoc:
    array = []
    while iter.hasMoreElements
      if iterType == :subset
        iter.nextElement()
        array << iter.getCurrentSubsetValue
      elsif iterType == :element
        array << iter.nextElement()
      else
        raise "iterator Type #{iterType} is not supported!"
      end
    end
    return array
  end

  #
  # return an array of variant of all available boards
  #
  def self.all_boards # :nodoc:
    lbi = self.logicalBoard.getSubsetIteratorSimple(Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementVariantId)
    return self.iterator2Array(lbi,:subset)
  end

  #
  # return an array of names of all available boards
  #
  def self.all_boards_name # :nodoc:
    ab = self.all_boards
    bvn = ab.collect { |i| @idService.getString(i) }
    return bvn
  end


  #
  # return an array of variants of all available channels
  #
  def self.all_channels # :nodoc:
    lbi = self.channels.getSubsetIteratorSimple(Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementVariantId)
    return self.iterator2Array(lbi,:subset)
  end

  #
  # return an array of names of all available channels
  #
  def self.all_channels_name # :nodoc:
    ac = self.all_channels
    acn = ac.collect { |i| @idService.getString(i) }
    return acn
  end

  #
  # get all boards of specified variant(s)
  #
  # == deprecated
  # @deprecated Please use ZTF.logicalBoardHwTag instead
  #
  # == argument
  # @param [Array] a list of variant string, e.g. "Centipede"
  #
  # == return
  # @return one hwtag of containing all matching logical boards
  #
  def self.boardsOfVariant(*target_variants)
    warn @obsolete_msg % ["ZTF.boardsOfVariant","ZTF.logicalBoardHwTag"]
    result = nil
    target_variants.each do |variant|
      vid = @idService.getId(variant)
      tag = @tagController.createHwTagFromTypeAndVariant(@logicalBoardId,vid)
      result = tag if result == nil
      result.unite(tag) if result != nil
    end
    return self.iterator2Array(result.getElementIterator,:element)
  end

  #
  # get all channels of specified variant(s)
  #
  # == deprecated
  # @deprecated Please use ZTF.channelHwTag instead
  #
  # == argument
  # @param [Array] a list of variant string, e.g. "Centipede"
  #
  # == return
  # @return [Array] a list of channels
  #
  def self.channelsOfVariant(*target_variants)
    warn @obsolete_msg % ["ZTF.channelsOfVariant","ZTF.channelHwTag"]
    result = nil
    target_variants.each do |variant|
      vid = @idService.getId(variant)
      tag = @tagController.createHwTagFromTypeAndVariant(@channelId,vid)
      result = tag if result == nil
      result.unite(tag) if result != nil
    end
    return self.iterator2Array(result.getElementIterator,:element)
  end

  #
  # get all boards of specified subType(s)
  #
  # == deprecated
  # @deprecated Please use ZTF.subTypeOfLogicalBoardHwTag instead
  #
  # == argument
  # @param [Array] a list of subtype strings, e.g. "Digital"
  #
  # == return
  # @return [Array] a list of boards
  #
  def self.boardsOfSubType(*target_subTypes)
    # example: /vobs/zenith/workspace/hw/cor/HwResourceManager/Scripts/dumpInstalledHw.rb
    warn @obsolete_msg % ["ZTF.boardsOfSubType","ZTF.subTypeOfLogicalBoardHwTag"]
    result = nil
    target_subTypes.each do |subtype|
      filterList = @tagController.createHwTagFilterPropertyList
      filterList.addProperty(
        Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementSubTypeId,
        RubyUNO::Any.new(@idService.getId(subtype)),
        Xoc::Hw::Cor::Rid::ZHwTagFilterPropertyOperator::EqualsAny)
      filterList.addProperty(
              Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementTypeId,
              RubyUNO::Any.new(@logicalBoardId),
              Xoc::Hw::Cor::Rid::ZHwTagFilterPropertyOperator::EqualsAny)
      tag = @tagController.createHwTag(filterList)
      result = tag if result == nil
      result.unite(tag) if result != nil
    end
    return self.iterator2Array(result.getElementIterator,:element)
  end

  #
  # get all channels of specified subType(s)
  #
  # == deprecated
  # @deprecated Please use ZTF.subTypeOfChannelHwTag instead
  #
  # == argument
  # @param [Array] a list of subtype strings, e.g. "Digital"
  #
  # == return
  # @return [Array] a list of channels
  #
  def self.channelsOfSubType(*target_subTypes)
    warn @obsolete_msg % ["ZTF.channelsOfSubType","ZTF.subTypeOfChannelHwTag"]
    result = nil
    target_subTypes.each do |subtype|
      filterList = @tagController.createHwTagFilterPropertyList
      filterList.addProperty(
        Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementSubTypeId,
        RubyUNO::Any.new(@idService.getId(subtype)),
        Xoc::Hw::Cor::Rid::ZHwTagFilterPropertyOperator::EqualsAny)
      filterList.addProperty(
        Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementTypeId,
        RubyUNO::Any.new(@channelId),
        Xoc::Hw::Cor::Rid::ZHwTagFilterPropertyOperator::EqualsAny)
      tag = @tagController.createHwTag(filterList)
      result = tag if result == nil
      result.unite(tag) if result != nil
    end
    return self.iterator2Array(result.getElementIterator,:element)
  end
end

ZTF.init_zhwtag_utils

#require 'pp'
#
#pp ZTF.all_boards
#pp ZTF.all_boards_name
#pp ZTF.all_channels
#pp ZTF.all_channels_name
#puts ZTF.boardsOfVariant("Centipede", "DPS128HC", "MSDPS", "PDPS", "LPN").inspect
#puts ZTF.channelsOfVariant("Centipede", "DPS128HC").size
#puts ZTF.boardsOfSubType("Digital").size
#puts ZTF.channelsOfSubType("Digital").size
