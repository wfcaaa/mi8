require 'erb'

module ZTF

  # 
  # it substitutes #{xxx} to <%= xxx %>
  # a workaround to swith to erb solution
  #
  def self.convert2erb(s) # :nodoc:
    return s.gsub(/\#\{([^\}]*)\}/, '<%= \1 %>')
  end

  #
  # == arguments
  # @param [Array] an array of template files with full paths,
  # e.g. /path/to/configuration/file.template.rb is the template
  # NOTE:
  # 1. all template files must follow the naming pattern "*.rb"
  # 2. if last argument is a directory, files are generated to that given dir.
  #    e.g. generateFromTemplate("a.rb","b.rb","/output/dir")
  # 3. template files should follow ERB format
  #    http://www.ruby-doc.org/stdlib-1.8.6/libdoc/erb/rdoc/ERB.html
  #    In addition, expression substitution "#{ expr }" is supported but deprecated.
  #
  # == return
  # @return [boolean] true if generation of file(s) based on template files "*.rb" succeeds
  # e.g. /path/to/file.template is generated
  #
  def self.generateFromTemplate(*template_files)
    template_files.flatten!
    output_dir = nil
    # if last argument is a directory, then all template files will be
    # generated to that dir
    if template_files.size > 1 and File.directory?(template_files[-1])
      output_dir = template_files[-1] # last element is the output dir
      template_files = template_files[0..-2] # remove the last element
    end
    for file in template_files
      unless file =~ /\.rb$/
        ZTF::LOG.puts "" # ensure following line starts with a new line
        ZTF::LOG.error "the template file '#{file}' is not following the naming pattern '*.rb'!"
        return false
      end
      ss = IO.read(file)
      if (not output_dir.nil?)
        configSheetPath=File.join(output_dir,File.basename(file).gsub(/\.rb$/,""))
      else
        configSheetPath=file.gsub(/\.rb$/,"")
      end
      begin
        File.delete(configSheetPath)
      rescue Exception
      end
      begin
        #TODO: we can remove it after all templates are converted to erb format
        # with '<>', omit newline for lines with pattern <% %>
        result = ERB.new(self.convert2erb(ss),nil,'<>').result
        f=File.new(configSheetPath,'w',0666)
        f.write(result)
        f.close
        # using File.new(...,0666) seems not working,
        # the file permission is still set to 0664
        File.chmod(0666,configSheetPath)
      rescue Errno::EPERM, Errno::ENOENT, Errno::EACCES
        raise #something with environment, need user to debug
      rescue NoMethodError, Xoc::Exc::ZCorrectnessException => e
        ZTF::LOG.info "couldn't generate file based on '#{file}'"
        if ZTF::LOG.level != ZTF::ZenithLogger::DEBUG
          ZTF::LOG.info "execute test with argument '-log=debug' if you want to see the reason."
        end
        ZTF::LOG.debug(e)
        return false
      rescue SyntaxError, NameError => e
        raise TestConfigError.new(e,"There is some error in file '#{file}'")
      end
    end # end of for loop
    return true
  end

  #
  # == overview
  # It generates config sheet(s) based on ruby syntax template file(s).
  #
  # The difference from function generateFromRubyTemplate is that:
  # If the generation fails, it raises an exception "ExplicitExit" which allows
  # test exit immediately (The IntegTest framework handles this).
  # Moreover, this will not be reported as an error!"
  #
  # == arguments
  # @param [Array] an array of ConfigSheet ruby template files with full paths,
  # e.g. /path/to/configuration/Functional.conf.rb is the template
  # NOTE:
  # 1. all ConfigSheet ruby template files must follow the naming pattern "*.rb"
  # 2. if last argument is a directory, files are generated to that given dir.
  #    e.g. generateConfigSheet("a.rb","b.rb","/output/dir")
  #
  # == return
  # @return [boolean] true if generation of ConfigSheet(s) succeeds
  # e.g. /path/to/configuration/Functional.conf is generated
  #
  def self.generateConfigSheet(*template_files)
    if self.generateFromTemplate(*template_files)
      ZTF::LOG.info "Generation of config sheet(s) succeeds!"
    else
      ZTF::LOG.info "Generation of config sheet(s) fails!"
      raise ExplicitExit, "\nINFO: Installed HW does not fulfill HW needs of test => Test skipped", caller
    end
    return true
  end

  #
  # the implementation is the same as ZTF.generateConfigSheet
  #
  def self.generateLoadBoard(*template_files)
    if self.generateFromTemplate(*template_files)
      ZTF::LOG.info "Generation of load board(s) succeeds!"
    else
      ZTF::LOG.info "Generation of load board fails!"
      raise ExplicitExit, "\nINFO: Installed HW does not fulfill HW needs of test => Test skipped", caller
    end
    return true
  end

  #
  # the implementation is similar to ZTF.generateConfigSheet
  # == DIFFERENCE:
  # if generation fails, test reports it as an ERROR and exits immediately
  #
  def self.generateProgFile(*template_files)
    if self.generateFromTemplate(*template_files)
      ZTF::LOG.info "Generation of program file(s) succeeds!"
    else
      raise ExplicitExit, "\nERROR: Generation of program file(s) fails!"
    end
    return true
  end
end
