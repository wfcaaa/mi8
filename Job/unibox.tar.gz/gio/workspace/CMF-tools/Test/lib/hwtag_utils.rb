
require "#{ENV['WORKSPACE']}/lib/libservices_ruby_UnoBridge"
require "#{ENV['WORKSPACE']}/CMF-tools/Test/internal/lib/zexception"
require "#{ENV['WORKSPACE']}/CMF-tools/Test/internal/lib/zenith_logger"

module ZTF
  # it defines a list of singleton methods
  class << self
    #
    # get the hwTag containing all given channels
    # Example:
    #   hwtag = ZTF.channelHwTagOfVariant("Centipede","DPS128HC")
    #
    # == argument
    # @param [Array] a list of variant string, e.g. "Centipede"
    #
    # == return
    # @return a hwTag of containing all matching channels according to given variant
    #
    def channelHwTagOfVariant(*target_variants)
      result = nil
      target_variants.each do |variant|
        vid = @idService.getId(variant)
        tag = @tagController.createHwTagFromTypeAndVariant(@channelId,vid)
        tag = @tagController.createHwTagFromTypeAndVariant(@coreId,vid) if tag.isEmpty
        result = tag if result == nil
        result.unite(tag) if result != nil
      end
      return result
    end
    alias :channelHwTag :channelHwTagOfVariant

    #
    # get the hwTag containing all given logical boards
    # Example:
    #   hwtag = ZTF.logicalBoardHwTagOfVariant("DPS128HC","DPS128HV")
    #
    # == argument
    # @param [Array] a list of variant string, e.g. "Centipede"
    #
    # == return
    # @return a hwTag of containing all matching boards
    #
    def logicalBoardHwTagOfVariant(*target_variants)
      result = nil
      target_variants.each do |variant|
        vid = @idService.getId(variant)
        tag = @tagController.createHwTagFromTypeAndVariant(@logicalBoardId,vid)
        result = tag if result == nil
        result.unite(tag) if result != nil
      end
      return result
    end
    alias :logicalBoardHwTag :logicalBoardHwTagOfVariant

    #
    # get the hwTag containing all logical boards of given subType(s)
    # Example:
    #   hwtag = ZTF.logicalBoardHwTagOfSubType("Digital")
    #
    # == argument
    # @param [Array] a list of subtypes, e.g. "Digital"
    #
    # == return
    # @return  a hwTag of containing all matching logical boards according to given subType(s)
    #
    def logicalBoardHwTagOfSubType(*target_subTypes)
      result = nil
      target_subTypes.each do |subtype|
        filterList = @tagController.createHwTagFilterPropertyList
        filterList.addProperty(
          Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementSubTypeId,
          RubyUNO::Any.new(@idService.getId(subtype)),
          Xoc::Hw::Cor::Rid::ZHwTagFilterPropertyOperator::EqualsAny)
        filterList.addProperty(
                Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementTypeId,
                RubyUNO::Any.new(@logicalBoardId),
                Xoc::Hw::Cor::Rid::ZHwTagFilterPropertyOperator::EqualsAny)
        tag = @tagController.createHwTag(filterList)
        result = tag if result == nil
        result.unite(tag) if result != nil
      end
      return result
    end


    #
    # get the hwTag containing all channels of given subType(s)
    # Example:
    #   hwtag = ZTF.channelHwTagOfSubType("Digital")
    #
    # == argument
    # @param [Array] a list of subtypes, e.g. "Digital"
    #
    # == return
    # @return  a hwTag of containing all matching channels according to given subType(s)
    #
    def channelHwTagOfSubType(*target_subTypes)
      result = nil
      target_subTypes.each do |subtype|
        filterList = @tagController.createHwTagFilterPropertyList
        filterList.addProperty(
          Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementSubTypeId,
          RubyUNO::Any.new(@idService.getId(subtype)),
          Xoc::Hw::Cor::Rid::ZHwTagFilterPropertyOperator::EqualsAny)
        filterList.addProperty(
          Xoc::Hw::Cor::Rid::ZHwTagFilterProperties::HwElementTypeId,
          RubyUNO::Any.new(@channelId),
          Xoc::Hw::Cor::Rid::ZHwTagFilterPropertyOperator::EqualsAny)
        tag = @tagController.createHwTag(filterList)
        result = tag if result == nil
        result.unite(tag) if result != nil
      end
      return result
    end

    #
    # return the customer hardware specifier of given hwTag and index
    # Example:
    #   hwtag = ZTF.channelHwTag("Centipede")
    #   value = ZTF.getCustomerSpecifier(hwtag, 0)
    #
    # == argument
    # @param hwtag [ZHwTag] the hwtag object, e.g. ZTF.channelHwTag("Centipede")
    # @param index [Fixnum] the index of the element
    #
    def getCustomerSpecifier(hwtag, index)
      return hwtag.getHwElementAtIndex(index).getCustomerSpecifier
    end

    #
    # It initializes instance variables used in other module functions
    #
    # == Note
    # This function is called automatically when this file is required.
    #
    def init_hwtag_utils # :nodoc:
      @tagController = RubyUNO::xocGetImplementer("xoc.hw.cor.rid.ZHwTagController")
      @idService =  RubyUNO::xocGetImplementer("xoc.svc.ZIDService")
      @logicalBoardId = @idService.getId("LogicalBoard")
      @channelId = @idService.getId("Channel")
      @coreId = @idService.getId("Core")
    end
  end
end

module ZTF
  # this method is obsolete in smartest 8
  # we still have it here because existing code from other branches may still have it.
  def self.reloadDevice(device)
    puts "ERROR: ZTF.reloadDevice is obsolete in Smaretest 8, please delete this call in your integration test if you see this sentence!"
  end
end

ZTF.init_hwtag_utils

# examples:
#
# puts ZTF.getCustomerSpecifier(ZTF.logicalBoardHwTagOfSubType('Digital'),0)
# puts ZTF.logicalBoardHwTagOfSubType('Digital').getLength
#

