#
# Use this class to define TDC related standard methods commonly used in Integration Test environment
# TDC stands for Test Data Controller
#
module TDCUtils
  # Tell TDC that given file(s) is out-of-date and reload it
  # How to use:
  #   require "#{ENV['WORKSPACE']}/CMF-tools/Test/lib/tdc_utils"
  #   include TDCUtils
  #   reloadSetupFiles("/path/to/file")
  #   reloadSetupFiles("/path/to/fileA","/path/to/fileB")
  #
  # @param [string, array] path of the file, or an arry of files
  #
  # @todo exception handling and return value handling, don't implement it because I (Zhiwei Xu) have no deep knowledge of it.
  #
  def reloadSetupFiles(*changedFiles)
    # Access to the TestDataController, define only once
    @@sTDC ||= RubyUNO::xocGetService("xoc.ate.cor.td3.ZTestDataController","xoc.ate.cor.td3.ZSTestDataController")
    # in case [[a,b,c]] --> [a,b,c]
    changedFiles.flatten!
    @@sTDC.setupFilesHaveChanged(changedFiles)
    @@sTDC.synchronizeWithSetupFiles
  end
end
