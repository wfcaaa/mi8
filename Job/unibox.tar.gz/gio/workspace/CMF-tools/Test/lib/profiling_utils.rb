#!/usr/bin/env zruby

# For instructions see
# http://eshare.verigy.net/display/Disciplines/RubyIntegrationTestFramework


module ZTF_PROFILING
  # While executing the provided block, the time is measured for the execution.
  # The measured time is printed out with the provided description to stdout
  #
  # The parameter tag is used to enable callgrind control via the environment
  # variable ZTF_TEST_CG_TAGS.
  #
  # Usage example:
  #     profile 'puts_2_times', 'Time measurement of 2 times puts' do
  #       puts 'first line'
  #       puts 'second line'
  #     end
  def self.profile tag, description, &block
  
    cgTags = ENV["ZTF_TEST_CG_TAGS"]
    if ((cgTags != nil) && cgTags.include?(tag))
      callgrindControl("ATE-server-process", "-z")
      callgrindControl("ATE-server-process", "-i on")
    end
  
    start = Time.now
    block.call
    ende  = Time.now
  
    if ((cgTags != nil) && cgTags.include?(tag))
      callgrindControl("ATE-server-process", "-d")
      callgrindControl("ATE-server-process", "-i off")
    end
  
    dauer = ende - start
    puts description+': '+dauer.to_s+' seconds'
    $stdout.flush
  end


  # run "callgrind_control <callgrindOption> <pid>" for each pid of a process
  # which contains the pattern "-process <processName>" in the output of ps -ef. 
  def self.callgrindControl processName, callgrindOption
    psCommand = "ps -efww"
    filterForProcess = "| grep -e '-process #{processName}'"
    filterOutGrepItself = "| grep -v -e 'grep -e'"
    getProcessIds = "| awk '{print $2}'"
    processIds = `#{psCommand + filterForProcess + filterOutGrepItself + getProcessIds}`
    processIds.split.each { |pid| 
      system("callgrind_control #{callgrindOption} #{pid}")
    }
  end
 
end
