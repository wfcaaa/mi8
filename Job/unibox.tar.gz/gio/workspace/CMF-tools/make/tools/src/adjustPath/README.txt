the c/cpp binary of adjustPath is in legacy (non component world) 
and zenith (component world) the same. thus build it in 
/opt/93000/src/com/make/tools/src and copy it to
/opt/93000/src/com/make/tools/bin/adjustPath_c and
/vobs/zenith/workspace/CMF-tools/make/tools/bin/adjustPath_c
