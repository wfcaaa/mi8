# Don not use #! .../p e r l to preserv the replacement on HP83000_ROOT variable by CompileSys
# in TAPE environment

#-----------------------------------------------------------------------#
# Author : Josef Guettlein
# Owner  : Claus Stuemke 
# Date:    15.10.2008
#
# Perl script : check_files.pl
# Call :        /usr/bin/perl check_files $SRC_ROOT
#
# Checks all files in the working directory to find forbidden HP83000_ROOT variable definition
# and forbidden symbolic links  
#
#-----------------------------------------------------------------------#
#


sub check_files {
my $file_name =$_[0];
my @_matching; 
my @_array;

  #print "processing on file: $file_name \n";
  open(FH_IN, "< $file_name") or die "Couldn't read from datafile $file_name : $!\n";
  @_array = <FH_IN>;
  close FH_IN;
  # check code wich was geareted atomaticaly by code generator
  # check needed before remove comments pattern
  foreach $autogen_pattern (@AUTOGEN_PATTERN)
  {
     @_matching = grep { /$autogen_pattern/ } @_array;
     if (@_matching )
     {
       print "CHECK_GUIDELINES $file_name: Auto Generated Pattern $autogen_pattern found.\n";
     }     
  }

  my $iCount = @_array;
  my $iN=0;
  foreach ($k=0; $k < $iCount; $k++)
  {  
    $iN = $k;
    $iFlag = 0;
    
    # 'HP83000_ROOT_DIR=/opt/'  check this instance
    if ($_array[$iN] =~ /HP83000_ROOT_DIR\=\/opt\//)
    {
      $_array[$iN] ="";
      next;
    }
    # '// ...'  check this instance
    if ($_array[$iN] =~ /^\/\/.*/)
    {
      $_array[$iN] ="";
      next;
    }
    # '# ...'  check this instance
    if ($_array[$iN] =~ /^\#.*/)
    {
      $_array[$iN] ="";
      next;
    }
    # '" ...'  check this instance
    if ($_array[$iN] =~ /\".*/)
    {
      $_array[$iN] ="";
      next;
    }    
    # '/*   */' check this instance
    while(  (( ( $_array[$iN] =~ /^\/\*.*/) || ($_array[$iN] =~ /^.*\/\*.*/)
              ) && ($iN < $iCount) && ($iFlag == 0)
              ) || ($iFlag == 1) && ($iN < $iCount) )
    {    
      # check "/*"
      if (($_array[$iN] =~ /^\/\*.*/) || ($_array[$iN] =~ /^.*\/\*.*/))
      {
        $_array[$iN] ="";
      }
      # check "*/"
      if (($_array[$iN] =~ /.*\*\/$/) || ($_array[$iN] =~ /\*\//))
      {  
        $_array[$iN] ="";
        $iN++;
        $iFlag = 0;
        next;
      } 
      else
      {
        $_array[$iN] ="";
        $iN++;
        $iFlag = 1;
        next;
      }
      $k =$iN;
    } #end while 
  } #end for
  foreach $f_pattern (@FORBIDDEN_PATTERN)
  {
     @_matching = grep { /$f_pattern/ } @_array;
     #print "Matching pattern: @_matching \n";
     if (@_matching )
     {
       print "CHECK_GUIDELINES $file_name: Pattern $f_pattern found.\n";
     }     
  }
   
}# end function

sub check_makes {
my $file_name =$_[0];
my @_matching; 
my @_array;
  
  #print "processing on file: $file_name \n";
  open(FH_IN, "< $file_name") or die "Couldn't read from datafile $file_name : $!\n";
  while(<FH_IN>) {
    s/#.*//;                                             # ignore comments by erasing them
    next if /^(\s)*$/;                                   # skip blank lines 
    if ($HP83000_ROOT_PATTERN =~ /\/opt\/zenith\/workspace/) {
       s/^ifeq \(\$\(SRC_ROOT\),\/opt\/zenith\/workspace\)//;    # filtering SRC_ROOT  
    }
    if ($HP83000_ROOT_PATTERN =~ /\/vobs\/zenith\/workspace/) {
      s/^ifeq \(\$\(SRC_ROOT\),\/vobs\/zenith\/workspace\)//;     # filtering SRC_ROOT  
    }
    push @_array, $_;    
  }
  close FH_IN;
  foreach $f_pattern (@FORBIDDEN_PATTERN)
  {
     @_matching = grep { /$f_pattern/ } @_array;
     if (@_matching)
     {
       print "CHECK_GUIDELINES $file_name: Pattern $f_pattern found.\n";
     }     
  }
}# end function


### MAIN ###

use Cwd;
use File::Basename;
$| = 1; # autoflush

if (  defined $ARGV[0] )
{
  $Src_root_dir = $ARGV[0];
  if ( ! -d "$Src_root_dir" )
  {
    print "CHECK_GUIDELINES wrong path specified as parameter to check_files: \"$Src_root_dir\" \n" ;
    exit ;
  }
  #print "CHECK_GUIDELINES:$Src_root_dir:\n" ;
  if ($Src_root_dir =~ /\/vobs\/zenith\/workspace/) {
    $HP83000_ROOT_PATTERN="/opt/zenith/workspace";
  }
  else {
    $HP83000_ROOT_PATTERN="/vobs/zenith/workspace";
  }
}
else
{
  print "CHECK_GUIDELINES Error: parameters to check_files not specified \n";
  exit ;
}
@FORBIDDEN_PATTERN = ("$HP83000_ROOT_PATTERN","\/home\/","^\/view\/","\\\$HOME");
@AUTOGEN_PATTERN   = ("TODO_AUTO_GENERATED");
$CT="/usr/atria/bin/cleartool";
$max_file_size = 5242880; # set max file size to 5MB
$CHECK_BIG_TXT_FILES=$ENV{'CHECK_BIG_TXT_FILES'};
if ($CHECK_BIG_TXT_FILES eq "TRUE"){
  $max_file_size = 1073741824; # set max file size to 1GB
}
$dirname = cwd;
opendir(DIR, "$dirname") or die "can't opendir $dirname: $!";
while (defined($file = readdir(DIR))) {
 # do something with "$dirname/$file"
  my $empty    = -z "$dirname/$file";
  my $is_link  = -l "$dirname/$file";
  my $is_dir   = -d "$dirname/$file";
  my $is_txt   = -T "$dirname/$file";
  my $file_size= -s "$dirname/$file";
  
  my $not_empty_text_file = ($is_txt && !$empty && !$is_dir && !$is_link);
  if ($not_empty_text_file){
    if ($file_size < $max_file_size){ 
      if (($file =~ /readme/) || ($file =~ /README/) || ($file =~ /\.htm/) || ($file =~ /\.log/) || ($file =~ /\.generated/) || ($file =~ /\.keep/)) {
        next;
      }
      if ($file =~ /^[Mm]akefile/) {
        &check_makes("$dirname/$file");
      }
      else {
        &check_files("$dirname/$file");
      }
    }
    else {
      print "File: $dirname/$filesize $dirname/$file Big size: $max_file_size \n";
    }
  }  
  if ($is_link) {
    $followed_link= readlink("$dirname/$file");
    #print "CHECK_GUIDELINES link \"$dirname/$file\" has view related target: $followed_link \n"; 
    if ($HP83000_ROOT_PATTERN eq "/vobs/zenith/workspace") {
      if ($followed_link =~ /^\/vobs\/zenith\/workspace*/) {
        print "CHECK_GUIDELINES: link \"$dirname/$file\" has view related target --> $followed_link \n";
      }
      if ( $followed_link =~ /^\/vobs\/*/) {
  	print "CHECK_GUIDELINES: link \"$dirname/$file\" has VOB related target --> $followed_link \n";    
      }
    }
    if ($HP83000_ROOT_PATTERN eq "/opt/zenith/workspace") {
      my $object_kind=`$CT describe -fmt \"%[object_kind]p\n\" \"$dirname/$file\"`;
      chomp $object_kind;
      #print "CHECK_GUIDELINES object_kind: $object_kind\n";
      if ($object_kind eq "symbolic link") {
        if ($followed_link =~ /^\/opt\/zenith\/workspace*/) {
	  print "CHECK_GUIDELINES: $object_kind \"$dirname/$file\" has tape related target --> $followed_link \n"; 
	}  
	if ( $followed_link =~ /^\/vobs\/*/){
	  print "CHECK_GUIDELINES: $object_kind \"$dirname/$file\" has VOB related target --> $followed_link \n"; 
	}
      }	
    }
  }
}
closedir(DIR);

