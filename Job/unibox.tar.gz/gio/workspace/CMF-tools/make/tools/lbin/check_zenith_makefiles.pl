#!/usr/local/bin/perl
#-----------------------------------------------------------------------#
# Author : Alfred Schenn
# Date:    20.02.2001
#
# Perl script : check_makefiles.pl
# Call :        check_makefiles $SRC_ROOT
#
# Checks Makefile.local in the working directory to find system dependent
# tool options, forbidden C/C++ preprocessor defines and 'make' macros that
# must not be used in this makefile.
# Include lines are resolved recursivley (up to $Max_include_nesting level) 
#
# - system dependent options:
#   * a set of macros to be scanned for options is defined with
#     all options allowed to be used defined as regular expressions (%Allowed_opts)
#   * the makefile is scanned and the defined options are removed from macro values
#   * a message with the remaining macro value is displayed on standard output
#
# - forbidden macros:
#   * defined in $Forbidden_macros
#   * the makefile is scanned and found macros are displayed on standard output
#
# - forbidden preprocessor defines:
#   * defined in $Forbidden_defines
#   * the makefile is scanned and found defines are displayed on standard output
#
#-----------------------------------------------------------------------#
#


# Untaint to avoid error message when running with setuid root.
# (See http://www.perl.com/pub/doc/manual/html/pod/perlsec.html)
# @_[0] is the value of a variable.
# Return the untainted value of the variable.
sub untaint 
{
    $value = shift @_;

    $value =~ /^(.*)$/;
    return $1;
}

$ENV{CDPATH}=&untaint($ENV{CDPATH});
$ENV{PATH}=&untaint($ENV{PATH});
$ENV{ENV}=&untaint($ENV{ENV});


$Check_opts_f   = 1 ;
$Check_macros_f = 1 ;

$make_file      = "Makefile.local" ;

$Max_include_nesting = 10 ;
$Nest_count = 0 ;


&Get_options ;


# options allowed or forbidden in macros defined as regular expressions
# The macros to check for allowed or forbidden options are the keys of
# %Allowed_opts or @Forbidden_opts, respectively.
#
# The regular expression defining one option must never contain
# any space characters (' '), because space is used as option delimiter.
# Always use \s to specify a space character within an option definition.
#
# Each option specified for a macro must match one of the expressions listed
# in Allowed_opts and must not match any of the expressions listed
# in Forbidden_opts.

# options common to C and C++
$Allowed_opts{"CFLAGS_LOCAL"}    = '-g';
# Match -D<macro>
$Allowed_opts{"CFLAGS_LOCAL"}   .= ' -D(\w+)';
# Match -D<macro>="<value>", value may contain spaces
$Allowed_opts{"CFLAGS_LOCAL"}   .= ' -D(\w+)(=".*?")';
# Match -D<macro>=<value>, value does not contain spaces
$Allowed_opts{"CFLAGS_LOCAL"}   .= ' -D(\w+)=\S*';
$Allowed_opts{"CFLAGS_LOCAL"}   .= ' -U(\w+)' ;
$Allowed_opts{"CXXFLAGS_LOCAL"}  = $Allowed_opts{"CFLAGS_LOCAL"} ;
# allowed macros common to C and C++
$Allowed_opts_C_and_CXX    = ' \$\(CFLAGS_POSITION_INDEPENDENT_CODE\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_POSITION_INDEPENDENT_CODE2\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_MULTI_BYTE_CHARACTERS\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_OPTIMIZATION_LIMIT\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_OPTIMIZATION_LEVEL0\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_OPTIMIZATION_LEVEL1\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_OPTIMIZATION_LEVEL2\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_OPTIMIZATION_LEVEL3\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_OPTIMIZATION_LEVEL4\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_NULL_POINTER_DETECTION\)' ;
$Allowed_opts_C_and_CXX   .= ' \$\(CFLAGS_WARNINGS_AS_ERRORS\)' ;
$Allowed_opts{"CFLAGS_LOCAL"}  .= $Allowed_opts_C_and_CXX ;
#   For CXXFLAGS_LOCAL, we allow CFLAGS... as well as CXXFLAGS...
$Allowed_opts{"CXXFLAGS_LOCAL"}  .= $Allowed_opts_C_and_CXX ;
$Allowed_opts_C_and_CXX =~ s/CFLAGS/CXXFLAGS/g;
$Allowed_opts{"CXXFLAGS_LOCAL"}  .= $Allowed_opts_C_and_CXX ;
# C specific options
$Allowed_opts{"CFLAGS_LOCAL"}   .= ' \$\(CFLAGS_USE_EXTENDED_ANSII_MODE\)' ;
# C++ specific options
$Allowed_opts{"CXXFLAGS_LOCAL"} .= ' \$\(CXXFLAGS_USE_ANSI_CPP_FEATURES\)' ;
$Allowed_opts{"CXXFLAGS_LOCAL"} .= ' \$\(CXXFLAGS_KOENIG_LOOKUP_ON\)' ;
$Allowed_opts{"CXXFLAGS_LOCAL"} .= ' \$\(CXXFLAGS_NO_ANACHRONISTIC_CONSTRUCTS\)' ;
$Allowed_opts{"CXXFLAGS_LOCAL"} .= ' \$\(CXXFLAGS_ACC_NEW_STL\)' ;
#removed, not in .../CMF-tools/make/Makefile $Allowed_opts{"CXXFLAGS_LOCAL"} .= ' \$\(CXXFLAGS_OS_DEPENDENT\)' ;
$Allowed_opts{"CXXFLAGS_LOCAL"} .= ' \$\(CXXFLAGS_WARNINGS_AS_ERRORS\)' ;
$Allowed_opts{"CXXFLAGS_LOCAL"} .= ' \$\(CFLAGS_WOPTION_LIST\)' ;
# TCI specific options
#removed, not in .../CMF-tools/make/Makefile $Allowed_opts{"CFLAGS_LOCAL"}   .= ' \$\(CFLAGS_LOCAL_TCI\)' ;
#removed, not in .../CMF-tools/make/Makefile $Allowed_opts{"CXXFLAGS_LOCAL"} .= ' \$\(CXXFLAGS_LOCAL_TCI\)' ;
$Allowed_opts{"LDFLAGS_LOCAL"}   = '\$\(LDFLAGS_BIND_DEFERRED\)' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_BIND_IMMEDIATE\)' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_NULL_POINTER_DETECTION\)' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_EXPORT_DYNAMIC\)' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_ACC_NEW_STL\)' ;
#removed, not in .../CMF-tools/make/Makefile $Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_LOCAL_OS_DEPENDENT\)' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' -Bsymbolic' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' -g' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_STRIP_SYMBOLS\)' ;
#removed, not in .../CMF-tools/make/Makefile $Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_NO_UNDEFINED\)' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_XERCES\)' ;
#removed, not in .../CMF-tools/make/Makefile $Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_BEBOP\)' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_COMPONENT_LIB_PATHS\)' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_SYSTEM_LOGGER\)' ;
# For LDFLAGS_RPATH match $(LDFLAGS_RPATH)<path> where path does not contain spaces
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_RPATH\)\S*' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_INIT\)\S*' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_FINI\)\S*' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' \$\(LDFLAGS_ENCRYPT\)\S*' ;
# The following flags were added for Zenith.
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' -lLocationResolver -lSessionAccess  -lservices_zutils -lSystemLoggerHelper -lProcessConsole' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' -lservices_session_StarterLib' ;
$Allowed_opts{"LDFLAGS_LOCAL"}  .= ' -lExceptionSupport -lservices_session_UnoServiceHelper -lservices_zsignal -lDebuggerHooker -lSessionServiceManager' ;
#removed, test:$Allowed_opts{"LFLAGS_LOCAL"}    = '-l -i' ;
#removed, test:$Allowed_opts{"YFLAGS_LOCAL"}    = '-y' ;
# The following libraries are approved for use.ll
#removed, test: $Allowed_opts{"USED_SYS_LIBS"}      = '-ll -lm -lnsl -lcrypt -lX11 -lXt -lXext -lXmu -lMrm -lXm -lXi -ldl -lgtk -lgdk -lgmodule -lglib -lrt \$\(LIBXML2_SYS_LIBRARY\) -lpthread \$\(CORBA_LIBS\) \$\(LDFLAGS_STLPORT_LIB\) \$\(LDFLAGS_SYSTEM_LOGGER\) \$\(LDFLAGS_ACE\)' ;
# The following libraries are generated in Zenith. legacy is allowed to use them.
#removed, test: $Allowed_opts{"USED_SYS_LIBS"}  .= ' -lExceptionSupport -lDebuggerHooker -lLocationResolver -lSessionServiceManager -lByteSequenceHandler -llog4cxx -lthreads -lSystemLoggerHelper -lservices_session_UnoServiceHelper -lSessionAccess -lsalcpprt -lservices_zsignal -lservices_zutils' ;
#removed, test: $Allowed_opts{"USED_SYS_LIBS"}  .= ' \$\(BERKELEY_HOME\) \$\(LDFLAGS_COMPONENT_LIB_PATHS\) \$\(LDFLAGS_OPENOFFICE_LIB_PATHS\) \$\(LDFLAGS_SYSTEM_LOGGER_PATH\)' ;
#removed, test: $Allowed_opts{"CONTAINED_SYS_LIBS"} = $Allowed_opts{"USED_SYS_LIBS"};

# For each macro FOO_BAR we also allow $(XYZ_FOO_BAR) as an option for any XYZ and
# We check each definition of a macro ABC_FOO_BAR=... according to the rules
# for FOO_BAR.
# BUT NOTE: this convention would be ambiguous if we would also have rules
# for a macro BAR. Then we would have to allow FOO_BAR as value for BAR and
# FOO_BAR would have to obey the rules for BAR. Thus, no macro for
# which we check for allowed options should be a suffix of another one.
@checkForAllowed = keys %Allowed_opts;
foreach $macro (@checkForAllowed)
{
    $Allowed_opts{$macro} .= ' \$\([^_]*_' . $macro . '\)';
}


# Options not allowed to use in C*FLAGS_LOCAL macros
$Forbidden_opts{"CFLAGS_LOCAL"}  = "-DSYSV" ; # Don't specify System V behaviour
$Forbidden_opts{"CFLAGS_LOCAL"}  .= " -I" ; # -I options must be specified in INCLUDE_PATH_LOCAL
$Forbidden_opts{"CXXFLAGS_LOCAL"}  = $Forbidden_opts{"CFLAGS_LOCAL"} ;
# Don't use the following libraries
$Forbidden_opts{"USED_SYS_LIBS"} = "-lC -lbsdipc -lsicl";
$Forbidden_opts{"CONTAINED_SYS_LIBS"} = "-lC -lbsdipc -lsicl";


# macros forbidden to override in $make_file
# This list should essentially contain all macros listed in the section
# "Macros which usually SHOULD NOT BE OVERRIDDEN by Makefile.local"
# in Makefile.macros.
# However, there may be some macros from that section which we
# want to tolerate and other macros not contained in this section
# which don't want to tolerate.
$Forbidden_macros = "INCLUDE_PATH \
ARCHIVE_LIBRARY_SUFFIX \
SHARED_LIBRARY_SUFFIX \
PROGRAM_DEBUG_NO \
PROGRAM_DEBUG_YES \
PROGRAM \
PROGRAM_DEBUG \
ARCHIVE_LIBRARY \
SHARED_LIBRARY_DEBUG_NO \
SHARED_LIBRARY_DEBUG_YES \
SHARED_LIBRARY \
SHARED_LIBRARY_DEBUG \
RELOCATABLE_FILE \
CLOBBER_FILES \
OBJS \
CC \
CXX \
CFLAGS_RELEASE \
CFLAGS_SYMBOL \
CFLAGS_DEBUG \
CFLAGS \
CXXFLAGS_RELEASE \
CXXFLAGS_SYMBOL \
CXXFLAGS_DEBUG \
CXXFLAGS \
CFLAGS_POSITION_INDEPENDENT_CODE \
CFLAGS_POSITION_INDEPENDENT_CODE2 \
CFLAGS_USE_EXTENDED_ANSII_MODE \
CFLAGS_MULTI_BYTE_CHARACTERS \
CFLAGS_OPTIMIZATION_LIMIT \
CFLAGS_OPTIMIZATION_LEVEL0 \
CFLAGS_OPTIMIZATION_LEVEL1 \
CFLAGS_OPTIMIZATION_LEVEL2 \
CFLAGS_OPTIMIZATION_LEVEL3 \
CFLAGS_OPTIMIZATION_LEVEL4 \
CFLAGS_NULL_POINTER_DETECTION \
CFLAGS_WARNINGS_AS_ERRORS \
CXXFLAGS_USE_ANSI_CPP_FEATURES \
CXXFLAGS_KOENIG_LOOKUP_ON \
CXXFLAGS_NO_ANACHRONISTIC_CONSTRUCTS \
CXXFLAGS_ACC_NEW_STL \
LDFLAGS_GENERATE_DYNAMIC_LIBRARY \
LDFLAGS_BIND_IMMEDIATE \
LDFLAGS_BIND_DEFERRED \
LDFLAGS_NULL_POINTER_DETECTION \
LDFLAGS_EXPORT_DYNAMIC \
LDFLAGS_RPATH \
LDFLAGS_INIT \
LDFLAGS_FINI \
LDFLAGS_ACC_NEW_STL \
AR \
NEEDS_CPP_LINKAGE \
LD \
LDFLAGS_DEBUG_FLAG \
LDFLAGS_RELEASE \
LDFLAGS_SYMBOL \
LDFLAGS_DEBUG \
LDFLAGS \
W_FLAG_NEEDED \
WLCC_ \
CMM_ \
WLCC \
CMM \
LFLAGS \
YFLAGS \
SHELL \
PATH \
DEBUG_TOOLS \
TEST_CLASS_FILES \
JAVA_ROOT \
JAVA_RUNTIME \
SWING_CLASSPATH \
JAVADOC_IMAGES \
JUNIT_TESTRUNNER \
JUNIT_TESTUI \
TAGS_OPTIONS \
TAGSFILE \
TAGS_CMD \
LIB_DEP_ARCHIVES \
LIB_DEP_ARCHIVES_WITH_SUFFIX \
LIB_DEP_PATH \
LIB_DEP_RATH_linux \
LIB_DEP_SHARED \
LIB_DEP_SYS \
LIB_DEP_OBJS \
LIB_DEP_RELOCATABLE \
API_DOC_DIR \
FULL_DOC_DIR";


&Check_makefile ( $make_file )  if defined $Check_opts_f ;


exit ;


#------------------------------------------------------------------------------
# subroutines:


sub Check_makefile  
{
  my $make_file    = shift @_ ;
  my $state        = "" ;       # scanning state, used to resolve continuation lines (states: "", "continue", "done")
  my $macro        = "" ;       # name of the make macro currently processed
  my $macro_value  = "" ;
  my $check_macros = "" ;       # macros to check for options (keys of %Allowed_opts)
  my $continuation = "" ;       # to resolve continuation lines
  my @temp_arr     = () ;

  if ( defined open ( MFILE, "<$make_file" ) )
  {
    @checkForAllowed = keys %Allowed_opts ;
    @checkForForbidden = keys %Forbidden_opts ;
    @allMacrosToCheck = (@checkForAllowed, @checkForForbidden);
    $check_macros = join ' ', @allMacrosToCheck ;

    for ( <MFILE> ) 
    {
      if ( $state eq "" )
      {
        if ( /^\s*(\w+)\s*=\s*(.*?)\s*$/ )    # get macro name and value
        {
          $macro = $1 ;
          $macro_value = $2 ;
          # $macro_without_prefix becomes $macro with XYZ_-prefix removed.
          # This is done because if we have rules for a macros FOO_BAR, we 
          # also want to check these rules for macros XYZ_FOO_BAR.
          $macro_without_prefix = $macro;
          $macro_without_prefix =~ s/^[^_]*_/_/;

          # Check whether it is allowed to override this macro
	  if ( $Forbidden_macros =~ /\b$macro\b/ )
	  {
	    $pwd = `pwd` ;
	    chop $pwd ;
	    print "CHECK_GUIDELINES $pwd: macro $macro shouldn't be overridden in $make_file \n" ;
	  }

          if ( $check_macros =~ /\b$macro\b/ )
          {
            $macro_to_check = $macro;
          }
          else
          {
            if ( $check_macros =~ /\b$macro_without_prefix\b/ )
            {
              $macro_to_check = $macro_without_prefix;
            }
            else
            {
              # continue with next line if neither $macro nor
              # $macro_without_prefix is one of $check_macros
              next;
            }
          }

          if ( substr ( $macro_value, -1 ) eq '\\' )  # continuation line
          {
            chop $macro_value ;             # remove backslash
            $state = "continue" ;
          }
          else
          {
            $state = "done" ;
          }
        }
        elsif ( /^-?(include)\s+(.*?)\s*$/ ) # get include file path
        {
          &Process_include_file ( $2 );
        }
      }
      elsif ( $state eq "continue" )        # it's a continuation line
      {
        if ( /^\s*(.*)\s*/ )
        {
          $continuation = $1 ;

          if ( substr ( $continuation, -1 ) eq '\\' )
          {
            chop $continuation ;            # remove backslash
            $state = "continue" ;
          }
          else
          {
            $state = "done" ;
          }

          $macro_value .= " $continuation" ;
        }
      }


      # got macro value, check for allowed and forbidden options
      if ( $state eq "done" )
      {
        $state = "" ;
        &Filter_options ( $make_file, $macro, $macro_to_check, $macro_value );
      }
    } # for

    close  MFILE ;
  }

} # Check_makefile ()



sub Process_include_file
{
  my $include_file = shift @_ ;                         # path of the include file
  my $pattern      = "" ;

  $include_file = $2 ;
  $pattern = '\$(\(|\{)(' . 'SRC_ROOT' . ')(\)|\})' ;   # pattern to match SRC_ROOT macro

  $include_file =~ s/$pattern/$Src_root_dir/g ;         # replace SRC_ROOT macro

  if ( -r $include_file )
  {
    $Nest_count ++ ;

    if ( $Nest_count > $Max_include_nesting )
    {
      print "CHECK_GUIDELINES Warning: makefile include nesting level exceeded!\n" ;
    }
    else                                            # recursive call with included makefile
    {
      &Check_makefile ( $include_file );
    }
  }
  else
  {
    print "CHECK_GUIDELINES file not readable/wrong path: " . $include_file . "\n" ;
  }

# print "include path: '$include_file' \n" ;

} # Process_include_file ()



# remove allowed options from macro value in Makefile.local
# Check for options which are forbidden or not explicitely allowed.
sub Filter_options
{
  my $make_file    = shift @_ ;
  my $macro        = shift @_ ;       # name of the make macro currently processed
  my $macro_to_check = shift @_ ;     # name of the macro whose rules are applied ($macro or $macro_without_prefix)
  my $macro_value  = shift @_ ;
  my $pattern      = "" ;
  my @temp_arr     = () ;


  if ( ($Working_dir =~ /\/Test\//) || ($Working_dir =~ /\/Examples\//) )
  {
    print "CHECK_GUIDELINES $Working_dir: skip testing $make_file \n" ;
  }
  else
  {
  # check for forbidden options and remove them from $macro_value.
  # After that check for allowed options and remove them from $macro_value.
  # The remaining options are non-approved options
  for ( split / +/, $Forbidden_opts{$macro_to_check} )
  {
    while ( $macro_value =~ s/(\s+|^)($_)(\s+|$)/ / )
    {
      print "CHECK_GUIDELINES $Working_dir: ($make_file) forbidden option in $macro -> '$2' \n" ;
    }
  }

  # Remove all options matching allowed options
  for ( split / +/, $Allowed_opts{$macro_to_check} )
  {
    # We must use loop to do all replacements. We cannot use
    # global substitution, because matching patterns might overlap
    # and thus not all matches would be replaced.
    while ($macro_value =~ s/(\s+|^)($_)(\s+|$)/ /) {};
  }

  # If any options are remaining, these are non-approved
  if ( ($macro_value ne "") && ($macro_value =~ /\S/) )
  {
    print "CHECK_GUIDELINES $Working_dir: ($make_file) non-approved options in $macro -> '$macro_value' \n" ;
  }
  }
} # Filter_options ()



# the first argument ($ARGV[0]) is the source root directory
#
sub Get_options  
{
  my $h1 = 0 ;
  $Src_root_dir = "" ;

  $Working_dir = `pwd` ;
  chop $Working_dir ;

  $h1 = grep ( /-h|--help|-\?/, @ARGV );
  &Usage  if $h1 > 0 ;


  if ( ! defined $ARGV[0] )
  {
    print "CHECK_GUIDELINES Error: parameters to check_makefiles.pl not specified \n";
    &Usage ;
  }


  $Src_root_dir = $ARGV[0] ;

  if ( ! -d $Src_root_dir )
  {
    print "CHECK_GUIDELINES wrong path specified as parameter to check_makefiles.pl: " . $Src_root_dir . "\n" ;
    exit ;
  }

} # Get_options ()



sub Usage  
{
  print "\nUsage:  program  src_path \n" ;
  print "  src_path   source root directory \n\n" ;

  exit ;

} # Usage ()

