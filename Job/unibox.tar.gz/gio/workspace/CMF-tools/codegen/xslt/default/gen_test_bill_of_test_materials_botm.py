#! /usr/bin/python
# This file generate BOTM which replaces Test/TestBed/scons* or Test/TestBed/makefile*
# argv[1]: Target Path: /path/to/bill-of-test-materials.botm[.generated1,2,3]
# argv[2]: name: bill-of-test-materials.botm
# argv[3]: fullpath of ComponentDefinitionFile 
#
import os, sys
from sets import Set
from xml.dom.ext.reader import Sax2
from xml import xpath

def getPWD():
    p = os.popen("pwd")
    baseDir = p.read().rstrip("\n")
    p.close()
    return baseDir

def parse_xml(xmlfile):
    global botmStream
    #print "Parsing ", xmlfile
    doc = Sax2.FromXmlFile(xmlfile).documentElement
    dirname = os.path.dirname(xmlfile)
    # If there is a tag "client", it indicates that this is a test for a utility library
    # Utility libraries should not be listed in botm file. 
    if doc.getElementsByTagName("client"):
         return

    for name in xpath.Evaluate('//modelGenerated/name/text()', doc):
        # cut off $WORKSPACE, we need a relavite path
        reltiveDir = dirname.replace(os.getenv("WORKSPACE")+"/","")
        # in most cases, libraries locates at .../sh_lib in legacy
        if reltiveDir.startswith(os.getenv("NONSHIPMENT_ROOT")):
            reltiveDir += "/sh_lib"
        botmStream += "UCL".ljust(4)+" "+reltiveDir.ljust(67)+" "+("lib%s.so" % name.data).ljust(47)+" "+"y".center(7)+"\n"
        #if os.access(dirname+"/"+("lib%s.so" % name.data), os.F_OK):
            #print "OKAY: ",dirname+"/"+("lib%s.so" % name.data)
        #else:
            #print "ERROR ",dirname+"/"+("lib%s.so" % name.data)

    for name in xpath.Evaluate("//@href", doc):
        #print "href: ",name.value
        nestedXml = os.path.normpath(os.path.join(dirname, name.value))
        #print nestedXml
        parse_xml(nestedXml)

def fire():
    global botmStream
    realTargetPath = os.path.dirname(os.path.join(getPWD(),sys.argv[1]))
    botmName = os.path.basename(sys.argv[1]) # it can be *.botm.generated
    cdef = os.path.normpath(sys.argv[3])

    parse_xml(cdef)
    botmPath = os.path.join(realTargetPath, botmName)
    #print "Output :"+ botmPath
    f = open(botmPath,'w')
    f.write(botmStream)
    f.close()
    #os.system("cat "+botmPath)

###################################Do the job in the following####################################################################
botmStream = ""
botmStream +=('''# Builds TestBed for component test
#
# Developer maintained file, initial version is created by code generator
#
#    source path                                                         libname                                         active?
BOTM services/misc/componentTestSupport/additionalTypeRegistries/default bill-of-test-materials.botm                        y   
''')

fire()
