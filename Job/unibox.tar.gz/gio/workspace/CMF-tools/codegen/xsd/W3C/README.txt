This directory contains copies of the www.w3.org
standard dtd and xsd file to use for validating
our own files off-line.
