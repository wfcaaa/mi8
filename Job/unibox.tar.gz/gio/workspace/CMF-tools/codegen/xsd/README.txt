This directory contains xml schemas and dtds for the code generation tools.

XMLSchema.dtd and datatypes.dtd have been copied from
http://www.w3.org/2001/XMLSchema for the purpose of validating
schemas only.
