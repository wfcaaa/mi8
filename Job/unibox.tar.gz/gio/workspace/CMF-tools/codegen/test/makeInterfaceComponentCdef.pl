#!/usr/bin/perl -w
#
# Example output:
#<?xml version="1.0"?>
#<component category="default"
#           xmlns:xi="http://www.w3.org/2001/XInclude"
#           xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
#           xsi:noNamespaceSchemaLocation="componentDefinition.xsd"
#>
#  <modelGenerated>
#    <name>BigComponent</name>
#    <package>misc</package>
#    <owner>Charles Halliday</owner>
#    <date>01 Aug 2005</date>
#    <brief>Brief BigComponent</brief>
#    <detailed>All interfaces implemented in weakObjects</detailed>
#    <serviceImplementation>
#      <service>
#        <name>xoc.svc.misc.BigService</name>
#        <brief>Dummy MyService1</brief>
#        <detailed></detailed>
#      </service>
#      <class>BigService</class>
#    </serviceImplementation>
#    <weakObjectImplementation>
#      <package>misc</package>
#      <weakObject>
#        <name>ZSPropertyValueList</name>
#        <provides>xoc.svc.ZPropertyValueList</provides>
#        <brief>ZPropertyValueList implementation</brief>
#      </weakObject>
#      <class>ZSPropertyValueList</class>
#    </weakObjectImplementation>
#  ...
#  </modelGenerated>
#</component>

# Creates a component definition file with interfaces implemented
# using a weakObject


use strict;
use Getopt::Long;
use FileHandle;

my $componentName = "BigComponent";
my $helpOpt = 0;
my $interfaceName = "";
my $excludePattern = "";  # Exclude interfaces matching this pattern
&GetOptions("-name=s"   => \$componentName,
            "-if=s"     => \$interfaceName,
            "-exclude=s"=> \$excludePattern,
            "-help!"    => \$helpOpt); 

my @rdbFiles = @ARGV;


if ( $helpOpt) {
    &usage ;
    exit 1;
}

my %rdbInterfaceTypeClasses = ();
if ( $interfaceName ) {
    # Use specified interface
    $rdbInterfaceTypeClasses{$interfaceName} = "interface";
}
else {
    # Collect all interface names in rdbs
    &getInterfaceTypeClasses;
    if ( $excludePattern ) {
        foreach my $rdbIfKey ( sort keys %rdbInterfaceTypeClasses ) {
            $rdbIfKey =~ m/${excludePattern}/
                and delete $rdbInterfaceTypeClasses{$rdbIfKey};
        }
    }
}

# Output head
print STDOUT "<?xml version=\"1.0\"?>\n";
print STDOUT "<component category=\"default\"\n";
print STDOUT "           xmlns:xi=\"http://www.w3.org/2001/XInclude\"\n";
print STDOUT "           xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n";
print STDOUT "           xsi:noNamespaceSchemaLocation=\"componentDefinition.xsd\"\n";
print STDOUT ">\n";
print STDOUT "  <modelGenerated>\n";
print STDOUT "    <name>$componentName</name>\n";
print STDOUT "    <package>misc</package>\n";
print STDOUT "    <owner>Charles Halliday</owner>\n";
print STDOUT "    <date>01 Aug 2005</date>\n";
print STDOUT "    <brief>Brief $componentName</brief>\n";
print STDOUT "    <detailed>Service with interfaces implemented in weakObjects</detailed>\n";
print STDOUT "    <serviceImplementation>\n";
print STDOUT "      <service>\n";
print STDOUT "        <name>xoc.svc.misc.$componentName</name>\n";
print STDOUT "        <brief>Dummy $componentName</brief>\n";
print STDOUT "        <detailed></detailed>\n";
print STDOUT "      </service>\n";
print STDOUT "      <class>$componentName</class>\n";
print STDOUT "    </serviceImplementation>\n";

# Output weakObjects for interfaces
my @interfaceList = sort keys %rdbInterfaceTypeClasses;

my %weakObjectReuseCounts = (); # Protect against same short name
foreach my $interface (@interfaceList) {
    my $packageName = "misc";
    my $interfacePackage = $interface;
    $interfacePackage =~ s/^(.*)\.(.*)/$1/;
    my $shortName =  $interface;
    $shortName =~ s/^(.*)\.(.*)/$2/;
    my $weakObjectName = "ZS" . substr $shortName,1;
    my $classSuffix = "";
    if ( exists $weakObjectReuseCounts{$weakObjectName} ) {
        $classSuffix = $weakObjectReuseCounts{$weakObjectName};
        $weakObjectReuseCounts{$weakObjectName} += 1;
    }
    else {
        $weakObjectReuseCounts{$weakObjectName} = 1;
    }

    print STDOUT "    <weakObjectImplementation>\n";
    print STDOUT "      <package>$packageName</package>\n";
    print STDOUT "      <weakObject>\n";
    print STDOUT "        <name>$interfacePackage.$weakObjectName</name>\n";
    print STDOUT "        <provides>$interface</provides>\n";
    print STDOUT "        <brief>$shortName implementation</brief>\n";
    print STDOUT "      </weakObject>\n";
    print STDOUT "      <class>$weakObjectName$classSuffix</class>\n";
    print STDOUT "    </weakObjectImplementation>\n";
} # ! foreach interface

# Output tail
print STDOUT "  </modelGenerated>\n";
print STDOUT "</component>\n";



# reads the rdb files and collects the interface names
# into %rdbInterfaceTypeClasses
sub getInterfaceTypeClasses
{
    my $rdbKey = "/UCR";
    my $fileHandle = new FileHandle;
    
    # Try each rdb in turn
    foreach my $rdb ( @rdbFiles ) {
        my @rdbTypeKey = ();

        my $fileSpec = "regview $rdb $rdbKey 2>/dev/null |" ;
        open ($fileHandle, $fileSpec)
            or die "Unable to open \"$fileSpec\"";
        $_ = <$fileHandle>;
        if ( ! $_) {
            print STDERR "WARNING: no $rdbKey key in $rdb\n";
             close $fileHandle ;
            next;
        }
        my $typeClass = "";
        my $typeName  = "";
        for ( ; $_ ; $_ = <$fileHandle>) {
            # Pick up type class: for interfaces and type name: for a /UCR key entry
            if ( m/^\s+type class:/ ) {
                my $initialTypeClass = &extractStringAfterColon($_);
                $initialTypeClass =~ m/\binterface\b/
                    and $typeClass = $initialTypeClass;
            }
            elsif ( m/^\s+type name:/ ) {
                $typeName = &toDotPath(&extractQuotedValue($_));
                $typeClass and $rdbInterfaceTypeClasses{$typeName} = $typeClass;
                $typeClass = "";
                $typeName = ""; 
            }
        }
        close $fileHandle ;
    }
} # ! getInterfaceTypeClasses

# Returns string between "" in input line
sub extractQuotedValue
{
    my $quoted = $_[0];
    chomp $quoted;
    $quoted =~ s/.*\"(.*)\".*$/$1/ ;
    return $quoted;
}

# Returns (trimmed) string after ":" in input line
sub extractStringAfterColon
{
    my $sac = $_[0];
    chomp $sac;
    $sac =~ s/^.*:// ; # Remove upto colon
    $sac =~ s/^\s+//;  # trim
    $sac =~ s/\s+$//;

    return $sac;
}

# Converts '/' to '.' separated path 
sub toDotPath
{
    my $path = $_[0];
    $path =~ s%/%.%g ;
    return $path;
}

sub usage
{
    print STDERR "Usage:\n";
    print STDERR "$0 [-help] [-name componentname] [-if interfacename] [-exclude pattern] rdb...\n";
    print STDERR "  -name componentname is optional component name,\n";
    print STDERR "       default is \"BigComponent\"\n";
    print STDERR "  -if interfacename is optional interface name, if specified\n";
    print STDERR "       only this interface is implemented, otherwise all in rbds\n";
    print STDERR "  -exclude pattern exclude interfaces matching regex pattern\n";
    print STDERR "  rdb is UNO rdb containing interface types (tried in order)\n";
    print STDERR "Output goes to stdout\n";
    print STDERR "Outputs .cdef file with each interface implemented\n";
    print STDERR "  in a separate weakObject file\n";
    print STDERR "Typical usage:\n";
    print STDERR "$0 " . $ENV{"WORKSPACE"} . "/IDL/zenith.rdb\n";
}
