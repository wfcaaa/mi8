/** 
 ****************************************************************************
 *
 * An Output stream
 *
 * Copyright by Agilent Technologies, 2006
 *
 * @file    MyOutputStream.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

#include "com/sun/star/io/XPersist.hpp"
#include "com/sun/star/lang/IllegalArgumentException.hpp"


// Use the following editable section for #includes,
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----


namespace {
  OUString something;
}

// ---- END EDITABLE SECTION UTILS ----

using namespace ::com::sun::star::io;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::rtl;

namespace xoc_svc_misc {


  MyOutputStream::~MyOutputStream()
  {
    // ---- BEGIN EDITABLE SECTION ~MyOutputStream ----

    // ---- END EDITABLE SECTION ~MyOutputStream ----
  }

  // Interface com.sun.star.io.XOutputStream

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyOutputStream::writeBytes(
    const Sequence< sal_Int8 >& aData )
    throw (

      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION writeBytes ----

    // ---- END EDITABLE SECTION writeBytes ----
  }

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyOutputStream::flush()
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION flush ----

    // ---- END EDITABLE SECTION flush ----
  }


  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  MyOutputStream::MyOutputStream()
  {
  }

  // my memebers
  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

