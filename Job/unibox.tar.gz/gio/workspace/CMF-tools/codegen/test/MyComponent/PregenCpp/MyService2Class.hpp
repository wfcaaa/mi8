#ifndef _XOC_SVC_PCKG_MYSERVICE2CLASS_HPP_
#define _XOC_SVC_PCKG_MYSERVICE2CLASS_HPP_
/** 
 ****************************************************************************
 *
 * Brief MyService2
 *
 * Copyright by Verigy, 2006
 *
 * @file    MyService2Class.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2006
 *
 ****************************************************************************
 */
 *****************************************************************************/

// Saved in DOS format to check can handle Rose output


#include "MyComponentBase.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----


#include <something>

// ---- END EDITABLE SECTION INCLUDES ----

namespace xoc { namespace svc { namespace pckg {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----
  using namespace abc::xyz;
// ---- END EDITABLE SECTION USING ----

/*
 * Full description of xoc.svc.misc.MyService2
 */
  //##ModelId=4394429D01D7
  class MyService2Class : public ::xoc_svc_misc::MyService2ClassBase
  {

  public:kjhlkhlkjh;kjk


    //##ModelId=4394429D01DD
    MyService2Class( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    //##ModelId=4394429D01DF
    virtual ~MyService2Class();

    // Interface xoc.svc.reflector.ZEcho

    // Method of xoc.svc.reflector.ZEcho
    //##ModelId=4394429D01E1
    virtual ::rtl::OUString SAL_CALL echo( 
      const ::rtl::OUString& s )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Method of xoc.svc.reflector.ZEcho
    //##ModelId=4394429D0200
    virtual void SAL_CALL print( 
      const ::rtl::OUString& s )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Interface xoc.svc.reflector.ZBroadcaster

    // Method of xoc.svc.reflector.ZBroadcaster
    //##ModelId=4394429D0201
    virtual void SAL_CALL registerReceiver( 
      const ::com::sun::star::uno::Reference< ::xoc::svc::reflector::ZReceiver >& r )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Method of xoc.svc.reflector.ZBroadcaster
    //##ModelId=4394429D0202
    virtual void SAL_CALL unRegisterReceiver( 
      const ::com::sun::star::uno::Reference< ::xoc::svc::reflector::ZReceiver >& r )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Method of xoc.svc.reflector.ZBroadcaster
    //##ModelId=4394429D0203
    virtual void SAL_CALL broadcast( 
      const ::rtl::OUString& s )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Use the following editable section for additional class members
    // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    //##ModelId=4394429D0204
    sal_Int32 junk;
    // ---- END EDITABLE SECTION MEMBERS ----
  };

} } } // namespace close


#endif // ! _XOC_SVC_PCKG_MYSERVICE2CLASS_HPP_
