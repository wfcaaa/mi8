#ifndef _E9431900_6810_11DB_8323_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _E9431900_6810_11DB_8323_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Property value list
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    PropertyValueList.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include <cppuhelper/implbase1.hxx>
#include <com/sun/star/uno/RuntimeException.hpp>

#include <xoc/svc/ZPropertyValueList.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Enable following line to log weakObject reference counts
//#define DEBUG_REFCOUNT

namespace xoc_unoobj_pckg {
typedef ::cppu::WeakImplHelper1<
  ::xoc::svc::ZPropertyValueList
  > PropertyValueListImplHelper;

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Property value list
 */
class PropertyValueList :
    public PropertyValueListImplHelper
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    // Interface xoc.svc.ZPropertyValueList

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0284
    virtual void SAL_CALL
    addProperty(
      ::sal_Int32 propertyId,
      const ::com::sun::star::uno::Any& value )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0285
    virtual void SAL_CALL
    addPropertyArray(
      ::sal_Int32 propertyId,
      ::sal_Int32 size )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0212
    virtual void SAL_CALL
    addPropertyBool(
      ::sal_Int32 propertyId,
      ::sal_Bool boolVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0213
    virtual void SAL_CALL
    addPropertyBoolArray(
      ::sal_Int32 propertyId,
      ::sal_Int32 size )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0214
    virtual void SAL_CALL
    addPropertyFloat(
      ::sal_Int32 propertyId,
      float floatVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0215
    virtual void SAL_CALL
    addPropertyFloatArray(
      ::sal_Int32 propertyId,
      ::sal_Int32 size )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0216
    virtual void SAL_CALL
    addPropertyDouble(
      ::sal_Int32 propertyId,
      double doubleVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0217
    virtual void SAL_CALL
    addPropertyDoubleArray(
      ::sal_Int32 propertyId,
      ::sal_Int32 size )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0218
    virtual void SAL_CALL
    addPropertyInt(
      ::sal_Int32 propertyId,
      ::sal_Int32 intVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF0219
    virtual void SAL_CALL
    addPropertyIntArray(
      ::sal_Int32 propertyId,
      ::sal_Int32 size )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF021A
    virtual void SAL_CALL
    addPropertyString(
      ::sal_Int32 propertyId,
      const ::rtl::OUString& stringVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF022B
    virtual void SAL_CALL
    addPropertyStringArray(
      ::sal_Int32 propertyId,
      ::sal_Int32 size )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    //##ModelId=43834AFF022C
    virtual void SAL_CALL
    addPropertyHyper(
      ::sal_Int32 propertyId,
      ::sal_Int64 hyperVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    addPropertyHyperArray(
      ::sal_Int32 propertyId,
      ::sal_Int32 size )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    addPropertyInterface(
      ::sal_Int32 propertyId,
      const ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface >& interfaceVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    addPropertyInterfaceArray(
      ::sal_Int32 propertyId,
      ::sal_Int32 size )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::com::sun::star::uno::Any SAL_CALL
    getValue(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::com::sun::star::uno::Any SAL_CALL
    getValueAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Bool SAL_CALL
    getValueAsBool(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Bool SAL_CALL
    getValueAsBoolAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual float SAL_CALL
    getValueAsFloat(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual float SAL_CALL
    getValueAsFloatAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual double SAL_CALL
    getValueAsDouble(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual double SAL_CALL
    getValueAsDoubleAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Int32 SAL_CALL
    getValueAsInt(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Int32 SAL_CALL
    getValueAsIntAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::rtl::OUString SAL_CALL
    getValueAsString(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::rtl::OUString SAL_CALL
    getValueAsStringAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Int64 SAL_CALL
    getValueAsHyper(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Int64 SAL_CALL
    getValueAsHyperAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface > SAL_CALL
    getValueAsInterface(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface > SAL_CALL
    getValueAsInterfaceAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValue(
      ::sal_Int32 propertyId,
      const ::com::sun::star::uno::Any& value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index,
      const ::com::sun::star::uno::Any& value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsBool(
      ::sal_Int32 propertyId,
      ::sal_Bool value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsBoolAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index,
      ::sal_Bool value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsFloat(
      ::sal_Int32 propertyId,
      float value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsFloatAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index,
      float value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsDouble(
      ::sal_Int32 propertyId,
      double value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsDoubleAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index,
      double value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsInt(
      ::sal_Int32 propertyId,
      ::sal_Int32 value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsIntAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index,
      ::sal_Int32 value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsString(
      ::sal_Int32 propertyId,
      const ::rtl::OUString& value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsStringAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index,
      const ::rtl::OUString& value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsHyper(
      ::sal_Int32 propertyId,
      ::sal_Int64 value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsHyperAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index,
      ::sal_Int64 value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsInterface(
      ::sal_Int32 propertyId,
      const ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface >& value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setValueAsInterfaceAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index,
      const ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface >& value )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::com::sun::star::uno::Reference< ::xoc::svc::ZPropertyValueList > SAL_CALL
    clone()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    deleteProperty(
      ::sal_Int32 propertyId )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    deleteAllProperties()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setEmpty(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setEmptyAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Bool SAL_CALL
    getEmpty(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Bool SAL_CALL
    getEmptyAt(
      ::sal_Int32 propertyId,
      ::sal_Int32 index )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Bool SAL_CALL
    hasProperty(
      ::sal_Int32 propertyId )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    getType(
      ::sal_Int32 propertyId,
      ::sal_Bool& isArray,
      ::com::sun::star::uno::Type& propertyType )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Int32 SAL_CALL
    getArraySize(
      ::sal_Int32 propertyId )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    setReadOnly(
      ::sal_Bool readOnlyValue )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::sal_Bool SAL_CALL
    getReadOnly()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZPropertyValueList
    virtual ::com::sun::star::uno::Sequence< ::sal_Int32 > SAL_CALL
    getPropertyIds()
      throw ( ::com::sun::star::uno::RuntimeException );

    //##ModelId=43834AFF022C
    // Method of xoc.svc.ZPropertyValueList
    virtual void SAL_CALL
    update(
      const ::com::sun::star::uno::Reference< ::xoc::svc::ZPropertyValueList >& news )
      throw ( ::com::sun::star::uno::RuntimeException );

#ifdef DEBUG_REFCOUNT
    // XInterface overridden methods, for debugging only
    virtual void SAL_CALL acquire() throw ();
    virtual void SAL_CALL release() throw ();
#endif

    virtual ~PropertyValueList();

  // Constructors and additional class member declarations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

    PropertyValueList();

  private:
    // Copy constructor
    PropertyValueList(const PropertyValueList & r);

    // Asignment operator
    PropertyValueList&operator=(PropertyValueList & r);

  // ---- END EDITABLE SECTION MEMBERS ----
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
