/** 
 ****************************************************************************
 *
 * Brief MyService2
 *
 * Copyright by Verigy, 2006
 *
 * @file    MyService2Class.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2006
 *
 ****************************************************************************
 */


// Saved in DOS format to check can handle Rose output



// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Use the following editable section for #includes,
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

namespace {
  // My stuff for UTILS
}

// ---- END EDITABLE SECTION UTILS ----

using namespace ::com::sun::star::uno;
namespace xoc { namespace svc { namespace pckg {

  //##ModelId=4394429D01DD
  MyService2Class::MyService2Class(
    Reference< XComponentContext > const & xComponentContext)
    : MyService2ClassBase::MyService2ClassBase(xComponentContext)
  {
    // ---- BEGIN EDITABLE SECTION MyService2Class ----
    // My stuff for constructor
    // ---- END EDITABLE SECTION MyService2Class ----
  }



  //##ModelId=4394429D01DF
  MyService2Class::~MyService2Class()
  {
    // ---- BEGIN EDITABLE SECTION ~MyService2Class ----
    // My stuff for destructor

    // ---- END EDITABLE SECTION ~MyService2Class ----
  }
 kjlkjlkjlkj

  // Interface xoc.svc.reflector.ZEcho

  // Method of xoc.svc.reflector.ZEcho
  //##ModelId=4394429D01E1
  OUString SAL_CALL
  MyService2Class::echo(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION echo ----
    // my implementation for echo
    return OUString::createFromAscii("echo");
    // ---- END EDITABLE SECTION echo ----
  }
kjlkjlk

  // Method of xoc.svc.reflector.ZEcho
  //##ModelId=4394429D0200
  void SAL_CALL
  MyService2Class::print(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION print ----
    // my implementation for print
    // ---- END EDITABLE SECTION print ----
  }

  // Interface xoc.svc.reflector.ZBroadcaster

  // Method of xoc.svc.reflector.ZBroadcaster
  //##ModelId=4394429D0201
  void SAL_CALL
  MyService2Class::registerReceiver(
    const Reference< ZReceiver >& r )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION registerReceiver ----
    // my implementation for registerReceiver
    // ---- END EDITABLE SECTION registerReceiver ----
  }

  // Method of xoc.svc.reflector.ZBroadcaster
  //##ModelId=4394429D0202
  void SAL_CALL
  MyService2Class::unRegisterReceiver(
    const Reference< ZReceiver >& r )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION unRegisterReceiver ----
    // my implementation for unRegisterReceiver
    // ---- END EDITABLE SECTION unRegisterReceiver ----
  }

  // Method of xoc.svc.reflector.ZBroadcaster
  //##ModelId=4394429D0203
  void SAL_CALL
  MyService2Class::broadcast(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION broadcast ----
    // my implementation for broadcast
    // ---- END EDITABLE SECTION broadcast ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----
  // My memebers
  // ---- END EDITABLE SECTION MEMBERS ----

} } } // namespace close

