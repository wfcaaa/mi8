#ifndef _XOC_SVC_XOC_SVC_MISC_EXAMPLEENUM_HPP_
#define _XOC_SVC_XOC_SVC_MISC_EXAMPLEENUM_HPP_
/** 
 ****************************************************************************
 *
 * Example enum types in method parameters and return
 *
 * Copyright by Agilent Technologies, 2006
 *
 * @file    ExampleEnum.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

#include <cppuhelper/implbase2.hxx>
#include <com/sun/star/uno/RuntimeException.hpp>

#include "xoc/hw/ext/detect/ZControlBoardFactory.hpp"
#include "xoc/hw/cor/svc/exec/ZExecutorTaskControl.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <something>
// ---- END EDITABLE SECTION INCLUDES ----

namespace xoc_svc_misc {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----
  using namespace Junk;
// ---- END EDITABLE SECTION USING ----

/*
 * ZControlBoardRole and ZExecutorTaskState are enums.
 * 
 */
class ExampleEnum :
    public  ::cppu::WeakImplHelper2< ::xoc::hw::ext::detect::ZControlBoardFactory
           , ::xoc::hw::cor::svc::exec::ZExecutorTaskControl
             >
  {

  public:

    virtual ~ExampleEnum();

    // Interface xoc.hw.ext.detect.ZControlBoardFactory

    // Method of xoc.hw.ext.detect.ZControlBoardFactory
    virtual ::com::sun::star::uno::Reference< ::xoc::hw::cor::detection::ZSlotDetection > SAL_CALL createControlBoard( 
      ::sal_uInt32 startAddress, 
      ::sal_Int64 locationCode, ::xoc::hw::cor::detection::ZControlBoardRole roleOfControlBoard )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Method of xoc.hw.ext.detect.ZControlBoardFactory
    virtual ::com::sun::star::uno::Reference< ::xoc::hw::cor::detection::ZSlotDetection > SAL_CALL createPassiveControlBoard( 
      const ::com::sun::star::uno::Reference< ::xoc::hw::cor::detection::ZSlotDetection >& activeControlBoard )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Method of xoc.hw.ext.detect.ZControlBoardFactory
    virtual ::com::sun::star::uno::Reference< ::com::sun::star::beans::XPropertySetInfo > SAL_CALL getPropertySetInfo( 
       )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Method of xoc.hw.ext.detect.ZControlBoardFactory
    virtual void SAL_CALL setPropertyValue( 
      const ::rtl::OUString& aPropertyName, 
      const ::com::sun::star::uno::Any& aValue )
      throw (  ::com::sun::star::beans::UnknownPropertyException, ::com::sun::star::beans::PropertyVetoException, ::com::sun::star::lang::IllegalArgumentException, ::com::sun::star::lang::WrappedTargetException, ::com::sun::star::uno::RuntimeException);

    // Method of xoc.hw.ext.detect.ZControlBoardFactory
    virtual ::com::sun::star::uno::Any SAL_CALL getPropertyValue( 
      const ::rtl::OUString& PropertyName )
      throw (  ::com::sun::star::beans::UnknownPropertyException, 
      ::com::sun::star::lang::WrappedTargetException, ::com::sun::star::uno::RuntimeException);

    // Method of xoc.hw.ext.detect.ZControlBoardFactory
    virtual void SAL_CALL addPropertyChangeListener( 
      const ::rtl::OUString& aPropertyName, 
      const ::com::sun::star::uno::Reference< ::com::sun::star::beans::XPropertyChangeListener >& xListener )
      throw (  ::com::sun::star::beans::UnknownPropertyException, ::com::sun::star::lang::WrappedTargetException, ::com::sun::star::uno::RuntimeException);

    // Method of xoc.hw.ext.detect.ZControlBoardFactory
    virtual void SAL_CALL removePropertyChangeListener( 
      const ::rtl::OUString& aPropertyName, 
      const ::com::sun::star::uno::Reference< ::com::sun::star::beans::XPropertyChangeListener >& aListener )
      throw (  ::com::sun::star::beans::UnknownPropertyException, ::com::sun::star::lang::WrappedTargetException, ::com::sun::star::uno::RuntimeException);

    // Method of xoc.hw.ext.detect.ZControlBoardFactory
    virtual void SAL_CALL addVetoableChangeListener( 
      const ::rtl::OUString& PropertyName, 
      const ::com::sun::star::uno::Reference< ::com::sun::star::beans::XVetoableChangeListener >& aListener )
      throw (  ::com::sun::star::beans::UnknownPropertyException, ::com::sun::star::lang::WrappedTargetException, ::com::sun::star::uno::RuntimeException);

    // Method of xoc.hw.ext.detect.ZControlBoardFactory
    virtual void SAL_CALL removeVetoableChangeListener( 
      const ::rtl::OUString& PropertyName, 
      const ::com::sun::star::uno::Reference< ::com::sun::star::beans::XVetoableChangeListener >& aListener )
      throw (  ::com::sun::star::beans::UnknownPropertyException, ::com::sun::star::lang::WrappedTargetException, ::com::sun::star::uno::RuntimeException);

    // Interface xoc.hw.cor.svc.exec.ZExecutorTaskControl

    // Method of xoc.hw.cor.svc.exec.ZExecutorTaskControl
    virtual ::com::sun::star::uno::Reference< ::xoc::hw::cor::svc::exec::ZExecutorTask > SAL_CALL getTask( 
       )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Method of xoc.hw.cor.svc.exec.ZExecutorTaskControl
    virtual ::xoc::hw::cor::svc::exec::ZExecutorTaskState SAL_CALL getState( 
       )
      throw (  ::com::sun::star::uno::RuntimeException);

    // Use the following editable section for additional class members
    // ---- BEGIN EDITABLE SECTION MEMBERS ----

    ExampleEnum();

  private:
    sal_Int32 myint;
    // ---- END EDITABLE SECTION MEMBERS ----
  };

} // namespace close


#endif // ! _XOC_SVC_XOC_SVC_MISC_EXAMPLEENUM_HPP_
