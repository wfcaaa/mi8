#ifndef _XOC_SVC_XOC_SVC_MISC_MYOUTPUTSTREAM_HPP_
#define _XOC_SVC_XOC_SVC_MISC_MYOUTPUTSTREAM_HPP_
/** 
 ****************************************************************************
 *
 * An Output stream
 *
 * Copyright by Agilent Technologies, 2006
 *
 * @file    MyOutputStream.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */
#include <com/sun/star/uno/RuntimeException.hpp>

#include "com/sun/star/io/XOutputStream.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <something>
// ---- END EDITABLE SECTION INCLUDES ----

namespace xoc_svc_misc {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----
  using namespace a::b;
// ---- END EDITABLE SECTION USING ----

class MyOutputStream :
    public  ::cppu::WeakImplHelper1< ::com::sun::star::io::XOutputStream
             >
  {

  public:

    virtual ~MyOutputStream();

    // Interface com.sun.star.io.XOutputStream

    // Method of com.sun.star.io.XOutputStream
    virtual void SAL_CALL writeBytes( 
      const ::com::sun::star::uno::Sequence< ::sal_Int8 >& aData )
      throw (  ::com::sun::star::io::NotConnectedException, 
      ::com::sun::star::io::BufferSizeExceededException, ::com::sun::star::io::IOException, ::com::sun::star::uno::RuntimeException);

    // Method of com.sun.star.io.XOutputStream
    virtual void SAL_CALL flush( 
       )
      throw (  ::com::sun::star::io::NotConnectedException, 
      ::com::sun::star::io::BufferSizeExceededException, ::com::sun::star::io::IOException, ::com::sun::star::uno::RuntimeException);

    // Use the following editable section for additional class members
    // ---- BEGIN EDITABLE SECTION MEMBERS ----

    MyOutputStream();

  private:
    sal_Int32 iamaninteger;

    // ---- END EDITABLE SECTION MEMBERS ----
  };

} // namespace close


#endif // ! _XOC_SVC_XOC_SVC_MISC_MYOUTPUTSTREAM_HPP_
