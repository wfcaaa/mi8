/** 
 ****************************************************************************
 *
 * An Input and Output stream
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    MyInputOutputStream.java
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package xoc_svc_misc;

import com.sun.star.io.BufferSizeExceededException;
import com.sun.star.io.IOException;
import com.sun.star.io.NotConnectedException;
import com.sun.star.io.XInputStream;
import com.sun.star.io.XOutputStream;
import com.sun.star.lang.IllegalArgumentException;
import com.sun.star.test.performance.ComplexTypes;
import com.sun.star.test.performance.XPerformanceTest;
import com.sun.star.lib.uno.helper.WeakBase;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * An Input and Output stream
 *
 * Checks can have two weakObjects implementing same interface.
 * Checks IDL interfaces out and inout parameters.
 * 
 */

class MyInputOutputStream
  extends WeakBase
  implements
    XOutputStream,
    XInputStream,
    XPerformanceTest
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("xoc_svc_misc");

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  // Interface com.sun.star.io.XOutputStream

  // Method of com.sun.star.io.XOutputStream
  public void writeBytes(byte[] aData)
    throws
      NotConnectedException,
      BufferSizeExceededException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION writeBytes ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION writeBytes ----
  }

  // Method of com.sun.star.io.XOutputStream
  public void flush()
    throws
      NotConnectedException,
      BufferSizeExceededException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION flush ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION flush ----
  }

  // Method of com.sun.star.io.XOutputStream
  public void closeOutput()
    throws
      NotConnectedException,
      BufferSizeExceededException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION closeOutput ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION closeOutput ----
  }

  // Interface com.sun.star.io.XInputStream

  // Method of com.sun.star.io.XInputStream
  public int readBytes(byte[][] aData,
                       int nBytesToRead)
    throws
      NotConnectedException,
      BufferSizeExceededException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION readBytes ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION readBytes ----
  }

  // Method of com.sun.star.io.XInputStream
  public int readSomeBytes(byte[][] aData,
                           int nMaxBytesToRead)
    throws
      NotConnectedException,
      BufferSizeExceededException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION readSomeBytes ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION readSomeBytes ----
  }

  // Method of com.sun.star.io.XInputStream
  public void skipBytes(int nBytesToSkip)
    throws
      NotConnectedException,
      BufferSizeExceededException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION skipBytes ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION skipBytes ----
  }

  // Method of com.sun.star.io.XInputStream
  public int available()
    throws
      NotConnectedException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION available ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION available ----
  }

  // Method of com.sun.star.io.XInputStream
  public void closeInput()
    throws
      NotConnectedException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION closeInput ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION closeInput ----
  }

  // Interface com.sun.star.test.performance.XPerformanceTest

  // Get method for readwrite attribute Long_attr of com.sun.star.test.performance.XPerformanceTest
  public int getLong_attr()
  {
    // ---- BEGIN EDITABLE SECTION getLong_attr ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getLong_attr ----
  }

  // Set method for readwrite attribute Long_attr of com.sun.star.test.performance.XPerformanceTest
  public void setLong_attr(int _long_attr)
  {
    // ---- BEGIN EDITABLE SECTION setLong_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setLong_attr ----
  }

  // Get method for readwrite attribute Hyper_attr of com.sun.star.test.performance.XPerformanceTest
  public long getHyper_attr()
  {
    // ---- BEGIN EDITABLE SECTION getHyper_attr ----
    long returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getHyper_attr ----
  }

  // Set method for readwrite attribute Hyper_attr of com.sun.star.test.performance.XPerformanceTest
  public void setHyper_attr(long _hyper_attr)
  {
    // ---- BEGIN EDITABLE SECTION setHyper_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setHyper_attr ----
  }

  // Get method for readwrite attribute Float_attr of com.sun.star.test.performance.XPerformanceTest
  public float getFloat_attr()
  {
    // ---- BEGIN EDITABLE SECTION getFloat_attr ----
    float returnValue = (float)0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getFloat_attr ----
  }

  // Set method for readwrite attribute Float_attr of com.sun.star.test.performance.XPerformanceTest
  public void setFloat_attr(float _float_attr)
  {
    // ---- BEGIN EDITABLE SECTION setFloat_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setFloat_attr ----
  }

  // Get method for readwrite attribute Double_attr of com.sun.star.test.performance.XPerformanceTest
  public double getDouble_attr()
  {
    // ---- BEGIN EDITABLE SECTION getDouble_attr ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getDouble_attr ----
  }

  // Set method for readwrite attribute Double_attr of com.sun.star.test.performance.XPerformanceTest
  public void setDouble_attr(double _double_attr)
  {
    // ---- BEGIN EDITABLE SECTION setDouble_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setDouble_attr ----
  }

  // Get method for readwrite attribute String_attr of com.sun.star.test.performance.XPerformanceTest
  public String getString_attr()
  {
    // ---- BEGIN EDITABLE SECTION getString_attr ----
    String returnValue = "";
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getString_attr ----
  }

  // Set method for readwrite attribute String_attr of com.sun.star.test.performance.XPerformanceTest
  public void setString_attr(String _string_attr)
  {
    // ---- BEGIN EDITABLE SECTION setString_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setString_attr ----
  }

  // Get method for readwrite attribute Interface_attr of com.sun.star.test.performance.XPerformanceTest
  public Object getInterface_attr()
  {
    // ---- BEGIN EDITABLE SECTION getInterface_attr ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getInterface_attr ----
  }

  // Set method for readwrite attribute Interface_attr of com.sun.star.test.performance.XPerformanceTest
  public void setInterface_attr(Object _interface_attr)
  {
    // ---- BEGIN EDITABLE SECTION setInterface_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setInterface_attr ----
  }

  // Get method for readwrite attribute Any_attr of com.sun.star.test.performance.XPerformanceTest
  public Object getAny_attr()
  {
    // ---- BEGIN EDITABLE SECTION getAny_attr ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getAny_attr ----
  }

  // Set method for readwrite attribute Any_attr of com.sun.star.test.performance.XPerformanceTest
  public void setAny_attr(Object _any_attr)
  {
    // ---- BEGIN EDITABLE SECTION setAny_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setAny_attr ----
  }

  // Get method for readwrite attribute Sequence_attr of com.sun.star.test.performance.XPerformanceTest
  public Object[] getSequence_attr()
  {
    // ---- BEGIN EDITABLE SECTION getSequence_attr ----
    Object[] returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getSequence_attr ----
  }

  // Set method for readwrite attribute Sequence_attr of com.sun.star.test.performance.XPerformanceTest
  public void setSequence_attr(Object[] _sequence_attr)
  {
    // ---- BEGIN EDITABLE SECTION setSequence_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setSequence_attr ----
  }

  // Get method for readwrite attribute Struct_attr of com.sun.star.test.performance.XPerformanceTest
  public ComplexTypes getStruct_attr()
  {
    // ---- BEGIN EDITABLE SECTION getStruct_attr ----
    ComplexTypes returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getStruct_attr ----
  }

  // Set method for readwrite attribute Struct_attr of com.sun.star.test.performance.XPerformanceTest
  public void setStruct_attr(ComplexTypes _struct_attr)
  {
    // ---- BEGIN EDITABLE SECTION setStruct_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setStruct_attr ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void async()
  {
    // ---- BEGIN EDITABLE SECTION async ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION async ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void sync()
  {
    // ---- BEGIN EDITABLE SECTION sync ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION sync ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public ComplexTypes complex_in(ComplexTypes aVal)
  {
    // ---- BEGIN EDITABLE SECTION complex_in ----
    ComplexTypes returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION complex_in ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public ComplexTypes complex_inout(ComplexTypes[] aVal)
  {
    // ---- BEGIN EDITABLE SECTION complex_inout ----
    ComplexTypes returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION complex_inout ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void complex_oneway(ComplexTypes aVal)
  {
    // ---- BEGIN EDITABLE SECTION complex_oneway ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION complex_oneway ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void complex_noreturn(ComplexTypes aVal)
  {
    // ---- BEGIN EDITABLE SECTION complex_noreturn ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION complex_noreturn ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public XPerformanceTest createObject()
  {
    // ---- BEGIN EDITABLE SECTION createObject ----
    XPerformanceTest returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION createObject ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public int getLong()
  {
    // ---- BEGIN EDITABLE SECTION getLong ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getLong ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void setLong(int n)
  {
    // ---- BEGIN EDITABLE SECTION setLong ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setLong ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public long getHyper()
  {
    // ---- BEGIN EDITABLE SECTION getHyper ----
    long returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getHyper ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void setHyper(long n)
  {
    // ---- BEGIN EDITABLE SECTION setHyper ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setHyper ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public float getFloat()
  {
    // ---- BEGIN EDITABLE SECTION getFloat ----
    float returnValue = (float)0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getFloat ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void setFloat(float f)
  {
    // ---- BEGIN EDITABLE SECTION setFloat ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setFloat ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public double getDouble()
  {
    // ---- BEGIN EDITABLE SECTION getDouble ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getDouble ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void setDouble(double f)
  {
    // ---- BEGIN EDITABLE SECTION setDouble ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setDouble ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public String getString()
  {
    // ---- BEGIN EDITABLE SECTION getString ----
    String returnValue = "";
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getString ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void setString(String s)
  {
    // ---- BEGIN EDITABLE SECTION setString ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setString ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public Object getInterface()
  {
    // ---- BEGIN EDITABLE SECTION getInterface ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getInterface ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void setInterface(Object x)
  {
    // ---- BEGIN EDITABLE SECTION setInterface ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setInterface ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public Object getAny()
  {
    // ---- BEGIN EDITABLE SECTION getAny ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getAny ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void setAny(Object a)
  {
    // ---- BEGIN EDITABLE SECTION setAny ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setAny ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public Object[] getSequence()
  {
    // ---- BEGIN EDITABLE SECTION getSequence ----
    Object[] returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getSequence ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void setSequence(Object[] seq)
  {
    // ---- BEGIN EDITABLE SECTION setSequence ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setSequence ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public ComplexTypes getStruct()
  {
    // ---- BEGIN EDITABLE SECTION getStruct ----
    ComplexTypes returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getStruct ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void setStruct(ComplexTypes c)
  {
    // ---- BEGIN EDITABLE SECTION setStruct ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setStruct ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  public void raiseRuntimeException()
  {
    // ---- BEGIN EDITABLE SECTION raiseRuntimeException ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION raiseRuntimeException ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // Default constructor, may be replaced
  MyInputOutputStream()
  {
  }

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // ! MyInputOutputStream
