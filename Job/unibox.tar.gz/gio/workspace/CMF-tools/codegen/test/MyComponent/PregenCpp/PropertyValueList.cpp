/** 
 ****************************************************************************
 *
 * Property value list
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    PropertyValueList.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "PropertyValueList.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <iostream>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::exc;
using namespace ::xoc::svc;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::std;
namespace {
  using namespace ::xoc::unoobj::pckg;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_unoobj_pckg {

  // Interface xoc.svc.ZPropertyValueList

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0284
  void SAL_CALL
  PropertyValueList::addProperty(
    sal_Int32 propertyId,
    const Any& value )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addProperty ----
    XOC_ERROR("Method addProperty not implemented");  // @todo
    // ---- END EDITABLE SECTION addProperty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0285
  void SAL_CALL
  PropertyValueList::addPropertyArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyArray ----
    XOC_ERROR("Method addPropertyArray not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0286
  void SAL_CALL
  PropertyValueList::addPropertyBool(
    sal_Int32 propertyId,
    sal_Bool boolVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyBool ----
    XOC_ERROR("Method addPropertyBool not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyBool ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0287
  void SAL_CALL
  PropertyValueList::addPropertyBoolArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyBoolArray ----
    XOC_ERROR("Method addPropertyBoolArray not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyBoolArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0288
  void SAL_CALL
  PropertyValueList::addPropertyFloat(
    sal_Int32 propertyId,
    float floatVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyFloat ----
    XOC_ERROR("Method addPropertyFloat not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyFloat ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0289
  void SAL_CALL
  PropertyValueList::addPropertyFloatArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyFloatArray ----
    XOC_ERROR("Method addPropertyFloatArray not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyFloatArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF028A
  void SAL_CALL
  PropertyValueList::addPropertyDouble(
    sal_Int32 propertyId,
    double doubleVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyDouble ----
    XOC_ERROR("Method addPropertyDouble not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyDouble ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF028B
  void SAL_CALL
  PropertyValueList::addPropertyDoubleArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyDoubleArray ----
    XOC_ERROR("Method addPropertyDoubleArray not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyDoubleArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF028C
  void SAL_CALL
  PropertyValueList::addPropertyInt(
    sal_Int32 propertyId,
    sal_Int32 intVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyInt ----
    XOC_ERROR("Method addPropertyInt not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyInt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF028D
  void SAL_CALL
  PropertyValueList::addPropertyIntArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyIntArray ----
    XOC_ERROR("Method addPropertyIntArray not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyIntArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF028E
  void SAL_CALL
  PropertyValueList::addPropertyString(
    sal_Int32 propertyId,
    const OUString& stringVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyString ----
    XOC_ERROR("Method addPropertyString not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyString ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF028F
  void SAL_CALL
  PropertyValueList::addPropertyStringArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyStringArray ----
    XOC_ERROR("Method addPropertyStringArray not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyStringArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0301
  void SAL_CALL
  PropertyValueList::addPropertyHyper(
    sal_Int32 propertyId,
    sal_Int64 hyperVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyHyper ----
    XOC_ERROR("Method addPropertyHyper not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyHyper ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0302
  void SAL_CALL
  PropertyValueList::addPropertyHyperArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyHyperArray ----
    XOC_ERROR("Method addPropertyHyperArray not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyHyperArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0303
  void SAL_CALL
  PropertyValueList::addPropertyInterface(
    sal_Int32 propertyId,
    const Reference< XInterface >& interfaceVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyInterface ----
    XOC_ERROR("Method addPropertyInterface not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyInterface ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0304
  void SAL_CALL
  PropertyValueList::addPropertyInterfaceArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyInterfaceArray ----
    XOC_ERROR("Method addPropertyInterfaceArray not implemented");  // @todo
    // ---- END EDITABLE SECTION addPropertyInterfaceArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0305
  Any SAL_CALL
  PropertyValueList::getValue(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValue ----
    Any returnValue;
    XOC_ERROR("Method getValue not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValue ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0306
  Any SAL_CALL
  PropertyValueList::getValueAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAt ----
    Any returnValue;
    XOC_ERROR("Method getValueAt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0307
  sal_Bool SAL_CALL
  PropertyValueList::getValueAsBool(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsBool ----
    sal_Bool returnValue = sal_False;
    XOC_ERROR("Method getValueAsBool not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsBool ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0308
  sal_Bool SAL_CALL
  PropertyValueList::getValueAsBoolAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsBoolAt ----
    sal_Bool returnValue = sal_False;
    XOC_ERROR("Method getValueAsBoolAt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsBoolAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0309
  float SAL_CALL
  PropertyValueList::getValueAsFloat(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsFloat ----
    float returnValue = 0.0;
    XOC_ERROR("Method getValueAsFloat not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsFloat ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF030A
  float SAL_CALL
  PropertyValueList::getValueAsFloatAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsFloatAt ----
    float returnValue = 0.0;
    XOC_ERROR("Method getValueAsFloatAt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsFloatAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF030B
  double SAL_CALL
  PropertyValueList::getValueAsDouble(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsDouble ----
    double returnValue = 0.0;
    XOC_ERROR("Method getValueAsDouble not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsDouble ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF030C
  double SAL_CALL
  PropertyValueList::getValueAsDoubleAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsDoubleAt ----
    double returnValue = 0.0;
    XOC_ERROR("Method getValueAsDoubleAt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsDoubleAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF030D
  sal_Int32 SAL_CALL
  PropertyValueList::getValueAsInt(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsInt ----
    sal_Int32 returnValue = 0;
    XOC_ERROR("Method getValueAsInt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsInt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF030E
  sal_Int32 SAL_CALL
  PropertyValueList::getValueAsIntAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsIntAt ----
    sal_Int32 returnValue = 0;
    XOC_ERROR("Method getValueAsIntAt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsIntAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF030F
  OUString SAL_CALL
  PropertyValueList::getValueAsString(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsString ----
    OUString returnValue;
    XOC_ERROR("Method getValueAsString not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsString ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0310
  OUString SAL_CALL
  PropertyValueList::getValueAsStringAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsStringAt ----
    OUString returnValue;
    XOC_ERROR("Method getValueAsStringAt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsStringAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0311
  sal_Int64 SAL_CALL
  PropertyValueList::getValueAsHyper(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsHyper ----
    sal_Int64 returnValue = 0;
    XOC_ERROR("Method getValueAsHyper not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsHyper ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0312
  sal_Int64 SAL_CALL
  PropertyValueList::getValueAsHyperAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsHyperAt ----
    sal_Int64 returnValue = 0;
    XOC_ERROR("Method getValueAsHyperAt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsHyperAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0313
  Reference< XInterface > SAL_CALL
  PropertyValueList::getValueAsInterface(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsInterface ----
    Reference< XInterface > returnValue;
    XOC_ERROR("Method getValueAsInterface not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsInterface ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0314
  Reference< XInterface > SAL_CALL
  PropertyValueList::getValueAsInterfaceAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsInterfaceAt ----
    Reference< XInterface > returnValue;
    XOC_ERROR("Method getValueAsInterfaceAt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsInterfaceAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0315
  void SAL_CALL
  PropertyValueList::setValue(
    sal_Int32 propertyId,
    const Any& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValue ----
    XOC_ERROR("Method setValue not implemented");  // @todo
    // ---- END EDITABLE SECTION setValue ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0316
  void SAL_CALL
  PropertyValueList::setValueAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    const Any& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAt ----
    XOC_ERROR("Method setValueAt not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0317
  void SAL_CALL
  PropertyValueList::setValueAsBool(
    sal_Int32 propertyId,
    sal_Bool value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsBool ----
    XOC_ERROR("Method setValueAsBool not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsBool ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0318
  void SAL_CALL
  PropertyValueList::setValueAsBoolAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    sal_Bool value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsBoolAt ----
    XOC_ERROR("Method setValueAsBoolAt not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsBoolAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0319
  void SAL_CALL
  PropertyValueList::setValueAsFloat(
    sal_Int32 propertyId,
    float value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsFloat ----
    XOC_ERROR("Method setValueAsFloat not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsFloat ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF031A
  void SAL_CALL
  PropertyValueList::setValueAsFloatAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    float value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsFloatAt ----
    XOC_ERROR("Method setValueAsFloatAt not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsFloatAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF031B
  void SAL_CALL
  PropertyValueList::setValueAsDouble(
    sal_Int32 propertyId,
    double value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsDouble ----
    XOC_ERROR("Method setValueAsDouble not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsDouble ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF031C
  void SAL_CALL
  PropertyValueList::setValueAsDoubleAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    double value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsDoubleAt ----
    XOC_ERROR("Method setValueAsDoubleAt not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsDoubleAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF031D
  void SAL_CALL
  PropertyValueList::setValueAsInt(
    sal_Int32 propertyId,
    sal_Int32 value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsInt ----
    XOC_ERROR("Method setValueAsInt not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsInt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF031E
  void SAL_CALL
  PropertyValueList::setValueAsIntAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    sal_Int32 value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsIntAt ----
    XOC_ERROR("Method setValueAsIntAt not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsIntAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF031F
  void SAL_CALL
  PropertyValueList::setValueAsString(
    sal_Int32 propertyId,
    const OUString& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsString ----
    XOC_ERROR("Method setValueAsString not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsString ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0320
  void SAL_CALL
  PropertyValueList::setValueAsStringAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    const OUString& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsStringAt ----
    XOC_ERROR("Method setValueAsStringAt not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsStringAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0321
  void SAL_CALL
  PropertyValueList::setValueAsHyper(
    sal_Int32 propertyId,
    sal_Int64 value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsHyper ----
    XOC_ERROR("Method setValueAsHyper not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsHyper ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0322
  void SAL_CALL
  PropertyValueList::setValueAsHyperAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    sal_Int64 value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsHyperAt ----
    XOC_ERROR("Method setValueAsHyperAt not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsHyperAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0323
  void SAL_CALL
  PropertyValueList::setValueAsInterface(
    sal_Int32 propertyId,
    const Reference< XInterface >& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsInterface ----
    XOC_ERROR("Method setValueAsInterface not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsInterface ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0324
  void SAL_CALL
  PropertyValueList::setValueAsInterfaceAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    const Reference< XInterface >& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsInterfaceAt ----
    XOC_ERROR("Method setValueAsInterfaceAt not implemented");  // @todo
    // ---- END EDITABLE SECTION setValueAsInterfaceAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0325
  Reference< ZPropertyValueList > SAL_CALL
  PropertyValueList::clone()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION clone ----
    Reference< ZPropertyValueList > returnValue;
    XOC_ERROR("Method clone not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION clone ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0326
  void SAL_CALL
  PropertyValueList::deleteProperty(
    sal_Int32 propertyId )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION deleteProperty ----
    XOC_ERROR("Method deleteProperty not implemented");  // @todo
    // ---- END EDITABLE SECTION deleteProperty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0327
  void SAL_CALL
  PropertyValueList::deleteAllProperties()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION deleteAllProperties ----
    XOC_ERROR("Method deleteAllProperties not implemented");  // @todo
    // ---- END EDITABLE SECTION deleteAllProperties ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0328
  void SAL_CALL
  PropertyValueList::setEmpty(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setEmpty ----
    XOC_ERROR("Method setEmpty not implemented");  // @todo
    // ---- END EDITABLE SECTION setEmpty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0329
  void SAL_CALL
  PropertyValueList::setEmptyAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setEmptyAt ----
    XOC_ERROR("Method setEmptyAt not implemented");  // @todo
    // ---- END EDITABLE SECTION setEmptyAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF032A
  sal_Bool SAL_CALL
  PropertyValueList::getEmpty(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getEmpty ----
    sal_Bool returnValue = sal_False;
    XOC_ERROR("Method getEmpty not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getEmpty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF032B
  sal_Bool SAL_CALL
  PropertyValueList::getEmptyAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getEmptyAt ----
    sal_Bool returnValue = sal_False;
    XOC_ERROR("Method getEmptyAt not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getEmptyAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF032C
  sal_Bool SAL_CALL
  PropertyValueList::hasProperty(
    sal_Int32 propertyId )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION hasProperty ----
    sal_Bool returnValue = sal_False;
    XOC_ERROR("Method hasProperty not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION hasProperty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF032D
  void SAL_CALL
  PropertyValueList::getType(
    sal_Int32 propertyId,
    sal_Bool& isArray,
    Type& propertyType )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getType ----
    XOC_ERROR("Method getType not implemented");  // @todo
    // ---- END EDITABLE SECTION getType ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF032E
  sal_Int32 SAL_CALL
  PropertyValueList::getArraySize(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getArraySize ----
    sal_Int32 returnValue = 0;
    XOC_ERROR("Method getArraySize not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getArraySize ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF032F
  void SAL_CALL
  PropertyValueList::setReadOnly(
    sal_Bool readOnlyValue )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setReadOnly ----
    XOC_ERROR("Method setReadOnly not implemented");  // @todo
    // ---- END EDITABLE SECTION setReadOnly ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0330
  sal_Bool SAL_CALL
  PropertyValueList::getReadOnly()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getReadOnly ----
    sal_Bool returnValue = sal_False;
    XOC_ERROR("Method getReadOnly not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getReadOnly ----
  }

  // Method of xoc.svc.ZPropertyValueList
  //##ModelId=43834AFF0331
  Sequence< sal_Int32 > SAL_CALL
  PropertyValueList::getPropertyIds()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getPropertyIds ----
    Sequence< sal_Int32 > returnValue;
    XOC_ERROR("Method getPropertyIds not implemented");  // @todo
    return returnValue;
    // ---- END EDITABLE SECTION getPropertyIds ----
  }

  //##ModelId=43834AFF0331
  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::update(
    const Reference< ZPropertyValueList >& news )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION update ----
    XOC_ERROR("PropertyValueList::update not implemented");  // @todo
    // ---- END EDITABLE SECTION update ----
  }

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL PropertyValueList::acquire()
     throw ()
   {
     PropertyValueListImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL PropertyValueList::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     PropertyValueListImplHelper::release();
   }
#endif

  PropertyValueList::~PropertyValueList()
  {
    // ---- BEGIN EDITABLE SECTION ~PropertyValueList ----

    // ---- END EDITABLE SECTION ~PropertyValueList ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  PropertyValueList::PropertyValueList()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

