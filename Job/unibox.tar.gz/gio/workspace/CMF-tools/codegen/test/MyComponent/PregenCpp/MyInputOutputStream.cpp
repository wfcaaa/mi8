/** 
 ****************************************************************************
 *
 * An Input and Output stream
 *
 * Copyright by Agilent Technologies, 2006
 *
 * @file    MyInputOutputStream.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/




// Use the following editable section for #includes,
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----


namespace {
  // junk
}

// ---- END EDITABLE SECTION UTILS ----

using namespace ::com::sun::star::io;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::test::performance;
using namespace ::com::sun::star::uno;
using namespace ::rtl;

namespace xoc_svc_misc {

  /*
   * Checks can have two weakObjects implementing same interface.
   * Checks IDL interfaces out and inout parameters.
   * 
   */

  MyInputOutputStream::~MyInputOutputStream()
  {
    // ---- BEGIN EDITABLE SECTION ~MyInputOutputStream ----

    // ---- END EDITABLE SECTION ~MyInputOutputStream ----
  }

  // Interface com.sun.star.io.XOutputStream

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyInputOutputStream::writeBytes(
    const Sequence< sal_Int8 >& aData )
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION writeBytes ----
    // My version of writeBytes
    // ---- END EDITABLE SECTION writeBytes ----
  }

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyInputOutputStream::flush()
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION flush ----
    // My version of flush
    // ---- END EDITABLE SECTION flush ----
  }

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyInputOutputStream::closeOutput()
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION closeOutput ----
    // My version of closeOutput
    // ---- END EDITABLE SECTION closeOutput ----
  }

  // Interface com.sun.star.io.XInputStream

  // Method of com.sun.star.io.XInputStream
  sal_Int32 SAL_CALL
  MyInputOutputStream::readBytes(
    Sequence< sal_Int8 >& aData,
    sal_Int32 nBytesToRead )
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION readBytes ----
    sal_Int32 returnValue = 0;
    // My version of readBytes
    return returnValue;
    // ---- END EDITABLE SECTION readBytes ----
  }

  // Method of com.sun.star.io.XInputStream
  sal_Int32 SAL_CALL
  MyInputOutputStream::readSomeBytes(
    Sequence< sal_Int8 >& aData,
    sal_Int32 nMaxBytesToRead )
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION readSomeBytes ----
    sal_Int32 returnValue = 0;
    // My version of readSomeBytes
    return returnValue;
    // ---- END EDITABLE SECTION readSomeBytes ----
  }

  // Method of com.sun.star.io.XInputStream
  void SAL_CALL
  MyInputOutputStream::skipBytes(
    sal_Int32 nBytesToSkip )
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION skipBytes ----
    // My version of skipBytes
    // ---- END EDITABLE SECTION skipBytes ----
  }

  // Method of com.sun.star.io.XInputStream
  sal_Int32 SAL_CALL
  MyInputOutputStream::available()
    throw (
      NotConnectedException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION available ----
    sal_Int32 returnValue = 0;
    // My version of available
    return returnValue;
    // ---- END EDITABLE SECTION available ----
  }

  // Method of com.sun.star.io.XInputStream
  void SAL_CALL
  MyInputOutputStream::closeInput()
    throw (
      NotConnectedException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION closeInput ----
    // My version of closeInput
    // ---- END EDITABLE SECTION closeInput ----
  }

  // Interface com.sun.star.test.performance.XPerformanceTest

  // Get method for readwrite attribute Long_attr of com.sun.star.test.performance.XPerformanceTest
  sal_Int32 SAL_CALL
  MyInputOutputStream::getLong_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getLong_attr ----
    sal_Int32 returnValue = 0;
    // My version of getLong_attr
    return returnValue;
    // ---- END EDITABLE SECTION getLong_attr ----
  }

  // Set method for readwrite attribute Long_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setLong_attr(
    sal_Int32 _long_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setLong_attr ----
    // My version of setLong_attr
    // ---- END EDITABLE SECTION setLong_attr ----
  }

  // Get method for readwrite attribute Hyper_attr of com.sun.star.test.performance.XPerformanceTest
  sal_Int64 SAL_CALL
  MyInputOutputStream::getHyper_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getHyper_attr ----
    sal_Int64 returnValue = 0;
    // My version of getHyper_attr
    return returnValue;
    // ---- END EDITABLE SECTION getHyper_attr ----
  }

  // Set method for readwrite attribute Hyper_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setHyper_attr(
    sal_Int64 _hyper_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setHyper_attr ----
    // My version of setHyper_attr
    // ---- END EDITABLE SECTION setHyper_attr ----
  }

  // Get method for readwrite attribute Float_attr of com.sun.star.test.performance.XPerformanceTest
  float SAL_CALL
  MyInputOutputStream::getFloat_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getFloat_attr ----
    // My version of getFloat_attr
    return 0.0;
    // ---- END EDITABLE SECTION getFloat_attr ----
  }

  // Set method for readwrite attribute Float_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setFloat_attr(
    float _float_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setFloat_attr ----
    // My version of setFloat_attr
    // ---- END EDITABLE SECTION setFloat_attr ----
  }

  // Get method for readwrite attribute Double_attr of com.sun.star.test.performance.XPerformanceTest
  double SAL_CALL
  MyInputOutputStream::getDouble_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getDouble_attr ----
    double returnValue = 0.0;
    // My version of getDouble_attr
    return returnValue;
    // ---- END EDITABLE SECTION getDouble_attr ----
  }

  // Set method for readwrite attribute Double_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setDouble_attr(
    double _double_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setDouble_attr ----
    // My version of setDouble_attr
    // ---- END EDITABLE SECTION setDouble_attr ----
  }

  // Get method for readwrite attribute String_attr of com.sun.star.test.performance.XPerformanceTest
  OUString SAL_CALL
  MyInputOutputStream::getString_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getString_attr ----
    OUString returnValue;
    // My version of getString_attr
    return returnValue;
    // ---- END EDITABLE SECTION getString_attr ----
  }

  // Set method for readwrite attribute String_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setString_attr(
    const OUString& _string_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setString_attr ----
    // My version of setString_attr
    // ---- END EDITABLE SECTION setString_attr ----
  }

  // Get method for readwrite attribute Interface_attr of com.sun.star.test.performance.XPerformanceTest
  Reference< XInterface > SAL_CALL
  MyInputOutputStream::getInterface_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getInterface_attr ----
    Reference< XInterface > returnValue;
    // My version of getInterface_attr
    return returnValue;
    // ---- END EDITABLE SECTION getInterface_attr ----
  }

  // Set method for readwrite attribute Interface_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setInterface_attr(
    const Reference< XInterface >& _interface_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setInterface_attr ----
    // My version of setInterface_attr
    // ---- END EDITABLE SECTION setInterface_attr ----
  }

  // Get method for readwrite attribute Any_attr of com.sun.star.test.performance.XPerformanceTest
  Any SAL_CALL
  MyInputOutputStream::getAny_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getAny_attr ----
    Any returnValue;
    // My version of getAny_attr
    return returnValue;
    // ---- END EDITABLE SECTION getAny_attr ----
  }

  // Set method for readwrite attribute Any_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setAny_attr(
    const Any& _any_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setAny_attr ----
    // My version of setAny_attr
    // ---- END EDITABLE SECTION setAny_attr ----
  }

  // Get method for readwrite attribute Sequence_attr of com.sun.star.test.performance.XPerformanceTest
  Sequence< Reference< XInterface > > SAL_CALL
  MyInputOutputStream::getSequence_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getSequence_attr ----
    Sequence< Reference< XInterface > > returnValue;
    // My version of getSequence_attr
    return returnValue;
    // ---- END EDITABLE SECTION getSequence_attr ----
  }

  // Set method for readwrite attribute Sequence_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setSequence_attr(
    const Sequence< Reference< XInterface > >& _sequence_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setSequence_attr ----
    // My version of setSequence_attr
    // ---- END EDITABLE SECTION setSequence_attr ----
  }

  // Get method for readwrite attribute Struct_attr of com.sun.star.test.performance.XPerformanceTest
  ComplexTypes SAL_CALL
  MyInputOutputStream::getStruct_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getStruct_attr ----
    ComplexTypes returnValue;
    // My version of getStruct_attr
    return returnValue;
    // ---- END EDITABLE SECTION getStruct_attr ----
  }

  // Set method for readwrite attribute Struct_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setStruct_attr(
    const ComplexTypes& _struct_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setStruct_attr ----
    // My version of setStruct_attr
    // ---- END EDITABLE SECTION setStruct_attr ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::async()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION async ----
    // My version of async
    // ---- END EDITABLE SECTION async ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::sync()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION sync ----
    // My version of sync
    // ---- END EDITABLE SECTION sync ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  ComplexTypes SAL_CALL
  MyInputOutputStream::complex_in(
    const ComplexTypes& aVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION complex_in ----
    ComplexTypes returnValue;
    // My version of complex_in
    return returnValue;
    // ---- END EDITABLE SECTION complex_in ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  ComplexTypes SAL_CALL
  MyInputOutputStream::complex_inout(
    ComplexTypes& aVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION complex_inout ----
    ComplexTypes returnValue;
    // My version of complex_inout
    return returnValue;
    // ---- END EDITABLE SECTION complex_inout ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::complex_oneway(
    const ComplexTypes& aVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION complex_oneway ----
    // My version of complex_oneway
    // ---- END EDITABLE SECTION complex_oneway ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::complex_noreturn(
    const ComplexTypes& aVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION complex_noreturn ----
    // My version of complex_noreturn
    // ---- END EDITABLE SECTION complex_noreturn ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  Reference< XPerformanceTest > SAL_CALL
  MyInputOutputStream::createObject()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION createObject ----
    Reference< XPerformanceTest > returnValue;
    // My version of createObject
    return returnValue;
    // ---- END EDITABLE SECTION createObject ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  sal_Int32 SAL_CALL
  MyInputOutputStream::getLong()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getLong ----
    sal_Int32 returnValue = 0;
    // My version of getLong
    return returnValue;
    // ---- END EDITABLE SECTION getLong ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setLong(
    sal_Int32 n )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setLong ----
    // My version of setLong
    // ---- END EDITABLE SECTION setLong ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  sal_Int64 SAL_CALL
  MyInputOutputStream::getHyper()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getHyper ----
    sal_Int64 returnValue = 0;
    // My version of getHyper
    return returnValue;
    // ---- END EDITABLE SECTION getHyper ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setHyper(
    sal_Int64 n )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setHyper ----
    // My version of setHyper
    // ---- END EDITABLE SECTION setHyper ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  float SAL_CALL
  MyInputOutputStream::getFloat()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getFloat ----
    float returnValue = 0.0;
    // My version of getFloat
    return returnValue;
    // ---- END EDITABLE SECTION getFloat ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setFloat(
    float f )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setFloat ----
    // My version of setFloat
    // ---- END EDITABLE SECTION setFloat ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  double SAL_CALL
  MyInputOutputStream::getDouble()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getDouble ----
    double returnValue = 0.0;
    // My version of getDouble
    return returnValue;
    // ---- END EDITABLE SECTION getDouble ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setDouble(
    double f )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setDouble ----
    // My version of setDouble
    // ---- END EDITABLE SECTION setDouble ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  OUString SAL_CALL
  MyInputOutputStream::getString()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getString ----
    OUString returnValue;
    // My version of getString
    return returnValue;
    // ---- END EDITABLE SECTION getString ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setString(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setString ----
    // My version of setString
    // ---- END EDITABLE SECTION setString ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  Reference< XInterface > SAL_CALL
  MyInputOutputStream::getInterface()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getInterface ----
    Reference< XInterface > returnValue;
    // My version of getInterface
    return returnValue;
    // ---- END EDITABLE SECTION getInterface ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setInterface(
    const Reference< XInterface >& x )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setInterface ----
    // My version of setInterface
    // ---- END EDITABLE SECTION setInterface ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  Any SAL_CALL
  MyInputOutputStream::getAny()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getAny ----
    Any returnValue;
    // My version of getAny
    return returnValue;
    // ---- END EDITABLE SECTION getAny ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setAny(
    const Any& a )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setAny ----
    // My version of setAny
    // ---- END EDITABLE SECTION setAny ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  Sequence< Reference< XInterface > > SAL_CALL
  MyInputOutputStream::getSequence()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getSequence ----
    Sequence< Reference< XInterface > > returnValue;
    // My version of getSequence
    return returnValue;
    // ---- END EDITABLE SECTION getSequence ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setSequence(
    const Sequence< Reference< XInterface > >& seq )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setSequence ----
    // My version of setSequence
    // ---- END EDITABLE SECTION setSequence ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  ComplexTypes SAL_CALL
  MyInputOutputStream::getStruct()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getStruct ----
    ComplexTypes returnValue;
    // My version of getStruct
    return returnValue;
    // ---- END EDITABLE SECTION getStruct ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setStruct(
    const ComplexTypes& c )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setStruct ----
    // My version of setStruct
    // ---- END EDITABLE SECTION setStruct ----
  }

  // Removed raiseRuntimeException

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  MyInputOutputStream::MyInputOutputStream()
  {
  }

  // no members
  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

