// MyComponentBase replaced by generated version
