/** 
 ****************************************************************************
 *
 * Example enum types in method parameters and return
 *
 * Copyright by Agilent Technologies, 2006
 *
 * @file    ExampleEnum.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

#include "ExampleEnum.hpp"


// MISSING EDITABLE SECTION INCLUDES

// Use the following editable section for #includes,
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

namespace {
  // local shared variables
}

// ---- END EDITABLE SECTION UTILS ----

using namespace ::com::sun::star::beans;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::hw::cor::svc::exec;
using namespace ::xoc::hw::cor::detection;

namespace xoc_svc_misc {

  /*
   * ZControlBoardRole and ZExecutorTaskState are enums.
   * 
   */

  ExampleEnum::~ExampleEnum()
  {
    // ---- BEGIN EDITABLE SECTION ~ExampleEnum ----
    // My destructor code
    // ---- END EDITABLE SECTION ~ExampleEnum ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  void SAL_CALL
  ExampleEnum::setDuration(
    sal_Int32 duration,
    ZWaitingUnit unit )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setDuration ----
    // my implementation of setDuration
    // ---- END EDITABLE SECTION setDuration ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  double SAL_CALL
  ExampleEnum::getRemainingTime(
    ZWaitingUnit unit )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getRemainingTime ----
    double returnValue = 0.0;
    // my implementation of getRemainingTime
    return returnValue;
    // ---- END EDITABLE SECTION getRemainingTime ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  sal_Bool SAL_CALL
  ExampleEnum::hasElapsed()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION hasElapsed ----
    sal_Bool returnValue = sal_False;
    // My version of hasElapsed
    return returnValue;
    // ---- END EDITABLE SECTION hasElapsed ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  void SAL_CALL
  ExampleEnum::unite(
    const Reference< ZWaiting >& waitingObject )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION unite ----
    // My implementation of unite
    // ---- END EDITABLE SECTION unite ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  void SAL_CALL
  ExampleEnum::wait()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION wait ----
    // My implementation of wait
    // ---- END EDITABLE SECTION wait ----
  }

  // Interface xoc.hw.cor.svc.exec.ZExecutorTaskControl

  // Method of xoc.hw.cor.svc.exec.ZExecutorTaskControl
  Reference< ZExecutorTask > SAL_CALL
  ExampleEnum::getTask()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getTask ----
    Reference< ZExecutorTask > returnValue;
    // My version of getTask
    return returnValue;
    // ---- END EDITABLE SECTION getTask ----
  }

  // Method of xoc.hw.cor.svc.exec.ZExecutorTaskControl
  ZExecutorTaskState SAL_CALL
  ExampleEnum::getState()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getState ----
    ZExecutorTaskState returnValue = ZExecutorTaskState_READY;
    // My version of getState
    return returnValue;
    // ---- END EDITABLE SECTION getState ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  ExampleEnum::ExampleEnum()
  {
    // My constructor code
  }

  // local members
  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

