/** 
 ****************************************************************************
 *
 * Brief MyService1
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    MyService1Impl.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyService1Impl.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc::threads;
namespace {

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_misc {

  //##ModelId=43834AFF0284
  MyService1Impl::MyService1Impl(
    Reference< XComponentContext > const & xComponentContext)
    : MyService1ImplBase::MyService1ImplBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
    , mInitialized(sal_False)
  {
    // ---- BEGIN EDITABLE SECTION MyService1Impl ----

    // ---- END EDITABLE SECTION MyService1Impl ----
  }

  //##ModelId=43834AFF0286
  MyService1Impl::~MyService1Impl()
  {
    // ---- BEGIN EDITABLE SECTION ~MyService1Impl ----

    // ---- END EDITABLE SECTION ~MyService1Impl ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  //##ModelId=43834AFF0286
  void SAL_CALL
  MyService1Impl::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    Guard< Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      mInitialized = sal_True;
      XOC_ERROR("MyService1Impl::initialize not implemented");  // @todo
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

