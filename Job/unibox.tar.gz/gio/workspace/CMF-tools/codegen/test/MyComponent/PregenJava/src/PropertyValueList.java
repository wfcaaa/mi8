/** 
 ****************************************************************************
 *
 * Property value list
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    PropertyValueList.java
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package xoc_unoobj_pckg;

import com.sun.star.uno.Type;
import xoc.exc.ZNotAvailable_v2;
import xoc.svc.ZPropertyValueList;
import com.sun.star.lib.uno.helper.WeakBase;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * Property value list
 */

class PropertyValueList
  extends WeakBase
  implements ZPropertyValueList
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("xoc_unoobj_pckg");

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  // Interface xoc.svc.ZPropertyValueList

  // Method of xoc.svc.ZPropertyValueList
  public void addProperty(int propertyId,
                          Object value)
  {
    // ---- BEGIN EDITABLE SECTION addProperty ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addProperty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyArray(int propertyId,
                               int size)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyBool(int propertyId,
                              boolean boolVal)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyBool ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyBool ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyBoolArray(int propertyId,
                                   int size)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyBoolArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyBoolArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyFloat(int propertyId,
                               float floatVal)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyFloat ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyFloat ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyFloatArray(int propertyId,
                                    int size)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyFloatArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyFloatArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyDouble(int propertyId,
                                double doubleVal)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyDouble ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyDouble ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyDoubleArray(int propertyId,
                                     int size)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyDoubleArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyDoubleArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyInt(int propertyId,
                             int intVal)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyInt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyInt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyIntArray(int propertyId,
                                  int size)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyIntArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyIntArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyString(int propertyId,
                                String stringVal)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyString ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyString ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyStringArray(int propertyId,
                                     int size)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyStringArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyStringArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyHyper(int propertyId,
                               long hyperVal)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyHyper ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyHyper ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyHyperArray(int propertyId,
                                    int size)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyHyperArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyHyperArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyInterface(int propertyId,
                                   Object interfaceVal)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyInterface ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyInterface ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void addPropertyInterfaceArray(int propertyId,
                                        int size)
  {
    // ---- BEGIN EDITABLE SECTION addPropertyInterfaceArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyInterfaceArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public Object getValue(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValue ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValue ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public Object getValueAt(int propertyId,
                           int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAt ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public boolean getValueAsBool(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsBool ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsBool ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public boolean getValueAsBoolAt(int propertyId,
                                  int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsBoolAt ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsBoolAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public float getValueAsFloat(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsFloat ----
    float returnValue = (float)0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsFloat ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public float getValueAsFloatAt(int propertyId,
                                 int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsFloatAt ----
    float returnValue = (float)0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsFloatAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public double getValueAsDouble(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsDouble ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsDouble ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public double getValueAsDoubleAt(int propertyId,
                                   int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsDoubleAt ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsDoubleAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public int getValueAsInt(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsInt ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsInt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public int getValueAsIntAt(int propertyId,
                             int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsIntAt ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsIntAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public String getValueAsString(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsString ----
    String returnValue = "";
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsString ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public String getValueAsStringAt(int propertyId,
                                   int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsStringAt ----
    String returnValue = "";
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsStringAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public long getValueAsHyper(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsHyper ----
    long returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsHyper ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public long getValueAsHyperAt(int propertyId,
                                int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsHyperAt ----
    long returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsHyperAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public Object getValueAsInterface(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsInterface ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsInterface ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public Object getValueAsInterfaceAt(int propertyId,
                                      int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getValueAsInterfaceAt ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsInterfaceAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValue(int propertyId,
                       Object value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValue ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValue ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAt(int propertyId,
                         int index,
                         Object value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsBool(int propertyId,
                             boolean value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsBool ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsBool ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsBoolAt(int propertyId,
                               int index,
                               boolean value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsBoolAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsBoolAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsFloat(int propertyId,
                              float value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsFloat ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsFloat ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsFloatAt(int propertyId,
                                int index,
                                float value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsFloatAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsFloatAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsDouble(int propertyId,
                               double value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsDouble ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsDouble ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsDoubleAt(int propertyId,
                                 int index,
                                 double value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsDoubleAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsDoubleAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsInt(int propertyId,
                            int value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsInt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsInt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsIntAt(int propertyId,
                              int index,
                              int value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsIntAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsIntAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsString(int propertyId,
                               String value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsString ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsString ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsStringAt(int propertyId,
                                 int index,
                                 String value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsStringAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsStringAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsHyper(int propertyId,
                              long value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsHyper ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsHyper ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsHyperAt(int propertyId,
                                int index,
                                long value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsHyperAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsHyperAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsInterface(int propertyId,
                                  Object value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsInterface ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsInterface ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setValueAsInterfaceAt(int propertyId,
                                    int index,
                                    Object value)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setValueAsInterfaceAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsInterfaceAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public ZPropertyValueList clone()
  {
    // ---- BEGIN EDITABLE SECTION clone ----
    ZPropertyValueList returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION clone ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void deleteProperty(int propertyId)
  {
    // ---- BEGIN EDITABLE SECTION deleteProperty ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION deleteProperty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void deleteAllProperties()
  {
    // ---- BEGIN EDITABLE SECTION deleteAllProperties ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION deleteAllProperties ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setEmpty(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setEmpty ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setEmpty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setEmptyAt(int propertyId,
                         int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION setEmptyAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setEmptyAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public boolean getEmpty(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getEmpty ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getEmpty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public boolean getEmptyAt(int propertyId,
                            int index)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getEmptyAt ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getEmptyAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public boolean hasProperty(int propertyId)
  {
    // ---- BEGIN EDITABLE SECTION hasProperty ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION hasProperty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void getType(int propertyId,
                      boolean[] isArray,
                      Type[] propertyType)
  {
    // ---- BEGIN EDITABLE SECTION getType ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION getType ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public int getArraySize(int propertyId)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getArraySize ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getArraySize ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void setReadOnly(boolean readOnlyValue)
  {
    // ---- BEGIN EDITABLE SECTION setReadOnly ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setReadOnly ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public boolean getReadOnly()
  {
    // ---- BEGIN EDITABLE SECTION getReadOnly ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getReadOnly ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public int[] getPropertyIds()
  {
    // ---- BEGIN EDITABLE SECTION getPropertyIds ----
    int[] returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getPropertyIds ----
  }

  // Method of xoc.svc.ZPropertyValueList
  public void update(ZPropertyValueList news)
  {
    // ---- BEGIN EDITABLE SECTION update ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION update ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // Default constructor, may be replaced
  PropertyValueList()
  {
  }

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // ! PropertyValueList
