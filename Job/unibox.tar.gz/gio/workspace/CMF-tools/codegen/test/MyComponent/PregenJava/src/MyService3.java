/** 
 ****************************************************************************
 *
 * Brief MyService3
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    MyService3.java
 *
 * @author  Charles Halliday
 *
 * @date    16 Apr 2004
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package xoc_svc_pckg;

import com.sun.star.lang.XInitialization;
import com.sun.star.uno.Exception;
import com.sun.star.uno.XComponentContext;
import xoc.cot.ZDebug;
import xoc.cot.ZLogStream;
import xoc.svc.reflector.ZEcho;
import xoc.svc.reflector.ZReceiver;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * Brief MyService3
 *
 * Another service implementing ZEcho
 */

public class MyService3
  extends xoc_svc_pckg.MyService3Base
  implements
    XInitialization,
    ZEcho,
    ZDebug
  // ---- BEGIN EDITABLE SECTION IMPLEMENTS ----
  // ---- END EDITABLE SECTION IMPLEMENTS ----
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("xoc_svc_pckg");

  private boolean mInitialized = false;

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  public MyService3(XComponentContext xComponentContext)
  {
    super(xComponentContext);
    // ---- BEGIN EDITABLE SECTION MyService3 ----

    // ---- END EDITABLE SECTION MyService3 ----
  }

  // Interface xoc.svc.reflector.ZEcho

  // Method of xoc.svc.reflector.ZEcho
  public String echo(String s)
  {
    // ---- BEGIN EDITABLE SECTION echo ----
    String returnValue = "";
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION echo ----
  }

  // Method of xoc.svc.reflector.ZEcho
  public void print(String s)
  {
    // ---- BEGIN EDITABLE SECTION print ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION print ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // !  MyService3
