/** 
 ****************************************************************************
 *
 * An Output stream
 *
 * Copyright by Agilent Technologies, 2006
 *
 * @file    MyOutputStream.java
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package xoc_svc_misc;


import com.sun.star.lang.IllegalArgumentException;
import com.sun.star.lib.uno.helper.WeakBase;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * An Output stream
 */

class MyOutputStream
  extends WeakBase
  implements XOutputStream, Junk
{
  private Logger _logger =
    SystemLoggerHelper.getSystemLogger("xoc_svc_misc");

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- BEGIN EDITABLE SECTION MyOutputStream ----
  // Default constructor, may be replaced
  MyOutputStream()
  {
  }
  // ---- END EDITABLE SECTION MyOutputStream ----

  // Interface com.sun.star.io.XOutputStream

  // Method of com.sun.star.io.XOutputStream
  public void writeBytes(byte[] aData)
    throws
      NotConnectedException,
      BufferSizeExceededException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION writeBytes ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION writeBytes ----
  }

  // Method of com.sun.star.io.XOutputStream
  public void flush()
    throws
      NotConnectedException,
      BufferSizeExceededException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION flush ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION flush ----
  }

  // Method of com.sun.star.io.XOutputStream
  public void closeOutput()
    throws
      NotConnectedException,
      BufferSizeExceededException,
      IOException
  {
    // ---- BEGIN EDITABLE SECTION closeOutput ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION closeOutput ----
  }

  // Method of Junk
  public void setJunk()
  {
    // ---- BEGIN EDITABLE SECTION setJunk ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setJunk ----
  }


  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // Default constructor, may be replaced
  MyOutputStream()
  {
  }

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // ! MyOutputStream
