# 
#***************************************************************************
#
# Property value list
#
# Copyright by Verigy, 2005
#
# @file    PropertyValueList.rb
#
# @author  Charles Halliday
#
# @date    01 Aug 2005
#
#***************************************************************************
#

#
# This file is developer maintained.
# NOTE: You may edit this file between BEGIN EDITABLE SECTION and END
# EDITABLE SECTION. But don't edit it outside these comments, or your code
# _will_ be lost after a component regeneration.
#

# Use the following editable section for items required before the class
# definition
# ---- BEGIN EDITABLE SECTION HEADER ----

# ---- END EDITABLE SECTION HEADER ----


class PropertyValueList < xoc.svc.ZPropertyValueList

  # Interface xoc.svc.ZPropertyValueList

  # Method of xoc.svc.ZPropertyValueList
  def addProperty(propertyId, value)
    # ---- BEGIN EDITABLE SECTION addProperty ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addProperty ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyArray(propertyId, size)
    # ---- BEGIN EDITABLE SECTION addPropertyArray ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyArray ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyBool(propertyId, boolVal)
    # ---- BEGIN EDITABLE SECTION addPropertyBool ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyBool ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyBoolArray(propertyId, size)
    # ---- BEGIN EDITABLE SECTION addPropertyBoolArray ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyBoolArray ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyFloat(propertyId, floatVal)
    # ---- BEGIN EDITABLE SECTION addPropertyFloat ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyFloat ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyFloatArray(propertyId, size)
    # ---- BEGIN EDITABLE SECTION addPropertyFloatArray ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyFloatArray ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyDouble(propertyId, doubleVal)
    # ---- BEGIN EDITABLE SECTION addPropertyDouble ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyDouble ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyDoubleArray(propertyId, size)
    # ---- BEGIN EDITABLE SECTION addPropertyDoubleArray ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyDoubleArray ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyInt(propertyId, intVal)
    # ---- BEGIN EDITABLE SECTION addPropertyInt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyInt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyIntArray(propertyId, size)
    # ---- BEGIN EDITABLE SECTION addPropertyIntArray ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyIntArray ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyString(propertyId, stringVal)
    # ---- BEGIN EDITABLE SECTION addPropertyString ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyString ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyStringArray(propertyId, size)
    # ---- BEGIN EDITABLE SECTION addPropertyStringArray ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyStringArray ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyHyper(propertyId, hyperVal)
    # ---- BEGIN EDITABLE SECTION addPropertyHyper ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyHyper ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyHyperArray(propertyId, size)
    # ---- BEGIN EDITABLE SECTION addPropertyHyperArray ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyHyperArray ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyInterface(propertyId, interfaceVal)
    # ---- BEGIN EDITABLE SECTION addPropertyInterface ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyInterface ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def addPropertyInterfaceArray(propertyId, size)
    # ---- BEGIN EDITABLE SECTION addPropertyInterfaceArray ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION addPropertyInterfaceArray ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValue(propertyId)
    # ---- BEGIN EDITABLE SECTION getValue ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValue ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION getValueAt ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsBool(propertyId)
    # ---- BEGIN EDITABLE SECTION getValueAsBool ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsBool ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsBoolAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION getValueAsBoolAt ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsBoolAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsFloat(propertyId)
    # ---- BEGIN EDITABLE SECTION getValueAsFloat ----
    returnValue = 0.0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsFloat ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsFloatAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION getValueAsFloatAt ----
    returnValue = 0.0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsFloatAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsDouble(propertyId)
    # ---- BEGIN EDITABLE SECTION getValueAsDouble ----
    returnValue = 0.0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsDouble ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsDoubleAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION getValueAsDoubleAt ----
    returnValue = 0.0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsDoubleAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsInt(propertyId)
    # ---- BEGIN EDITABLE SECTION getValueAsInt ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsInt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsIntAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION getValueAsIntAt ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsIntAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsString(propertyId)
    # ---- BEGIN EDITABLE SECTION getValueAsString ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsString ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsStringAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION getValueAsStringAt ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsStringAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsHyper(propertyId)
    # ---- BEGIN EDITABLE SECTION getValueAsHyper ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsHyper ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsHyperAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION getValueAsHyperAt ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsHyperAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsInterface(propertyId)
    # ---- BEGIN EDITABLE SECTION getValueAsInterface ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsInterface ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getValueAsInterfaceAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION getValueAsInterfaceAt ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getValueAsInterfaceAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValue(propertyId, value)
    # ---- BEGIN EDITABLE SECTION setValue ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValue ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAt(propertyId, index, value)
    # ---- BEGIN EDITABLE SECTION setValueAt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsBool(propertyId, value)
    # ---- BEGIN EDITABLE SECTION setValueAsBool ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsBool ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsBoolAt(propertyId, index, value)
    # ---- BEGIN EDITABLE SECTION setValueAsBoolAt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsBoolAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsFloat(propertyId, value)
    # ---- BEGIN EDITABLE SECTION setValueAsFloat ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsFloat ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsFloatAt(propertyId, index, value)
    # ---- BEGIN EDITABLE SECTION setValueAsFloatAt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsFloatAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsDouble(propertyId, value)
    # ---- BEGIN EDITABLE SECTION setValueAsDouble ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsDouble ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsDoubleAt(propertyId, index, value)
    # ---- BEGIN EDITABLE SECTION setValueAsDoubleAt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsDoubleAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsInt(propertyId, value)
    # ---- BEGIN EDITABLE SECTION setValueAsInt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsInt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsIntAt(propertyId, index, value)
    # ---- BEGIN EDITABLE SECTION setValueAsIntAt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsIntAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsString(propertyId, value)
    # ---- BEGIN EDITABLE SECTION setValueAsString ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsString ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsStringAt(propertyId, index, value)
    # ---- BEGIN EDITABLE SECTION setValueAsStringAt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsStringAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsHyper(propertyId, value)
    # ---- BEGIN EDITABLE SECTION setValueAsHyper ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsHyper ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsHyperAt(propertyId, index, value)
    # ---- BEGIN EDITABLE SECTION setValueAsHyperAt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsHyperAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsInterface(propertyId, value)
    # ---- BEGIN EDITABLE SECTION setValueAsInterface ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsInterface ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setValueAsInterfaceAt(propertyId, index, value)
    # ---- BEGIN EDITABLE SECTION setValueAsInterfaceAt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setValueAsInterfaceAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def clone()
    # ---- BEGIN EDITABLE SECTION clone ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION clone ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def deleteProperty(propertyId)
    # ---- BEGIN EDITABLE SECTION deleteProperty ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION deleteProperty ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def deleteAllProperties()
    # ---- BEGIN EDITABLE SECTION deleteAllProperties ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION deleteAllProperties ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setEmpty(propertyId)
    # ---- BEGIN EDITABLE SECTION setEmpty ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setEmpty ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setEmptyAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION setEmptyAt ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setEmptyAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getEmpty(propertyId)
    # ---- BEGIN EDITABLE SECTION getEmpty ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getEmpty ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getEmptyAt(propertyId, index)
    # ---- BEGIN EDITABLE SECTION getEmptyAt ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getEmptyAt ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def hasProperty(propertyId)
    # ---- BEGIN EDITABLE SECTION hasProperty ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION hasProperty ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getType(propertyId, isArray, propertyType)
    # ---- BEGIN EDITABLE SECTION getType ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION getType ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getArraySize(propertyId)
    # ---- BEGIN EDITABLE SECTION getArraySize ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getArraySize ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def setReadOnly(readOnlyValue)
    # ---- BEGIN EDITABLE SECTION setReadOnly ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setReadOnly ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getReadOnly()
    # ---- BEGIN EDITABLE SECTION getReadOnly ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getReadOnly ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def getPropertyIds()
    # ---- BEGIN EDITABLE SECTION getPropertyIds ----
    returnValue = []
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getPropertyIds ----
  end

  # Method of xoc.svc.ZPropertyValueList
  def update(news)
    # ---- BEGIN EDITABLE SECTION update ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION update ----
  end

  # Use this section to define additional class members
  # ---- BEGIN EDITABLE SECTION MEMBERS ----

  # ruby constructor initialize method
  def initialize

  end

  # ---- END EDITABLE SECTION MEMBERS ----

end  # ! PropertyValueList

# Use the following editable section for items required after the class
# definition
# ---- BEGIN EDITABLE SECTION FOOTER ----

# ---- END EDITABLE SECTION FOOTER ----
