/** 
 ****************************************************************************
 *
 * Interface ZBarChild inherits from ZBar which inherits from ZFoo
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    InheritedInterface.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Apr 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "InheritedInterface.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::foobar;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::foobar;

}

// ---- END EDITABLE SECTION UTILS ----

namespace foobar {

  InheritedInterface::InheritedInterface(
    Reference< XComponentContext > const & xComponentContext)
    : InheritedInterfaceBase::InheritedInterfaceBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
    , mInitialized(sal_False)
  {
    // ---- BEGIN EDITABLE SECTION InheritedInterface ----

    // ---- END EDITABLE SECTION InheritedInterface ----
  }

  InheritedInterface::~InheritedInterface()
  {
    // ---- BEGIN EDITABLE SECTION ~InheritedInterface ----

    // ---- END EDITABLE SECTION ~InheritedInterface ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  InheritedInterface::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      mInitialized = sal_True;
      // @todo TODO_AUTO_GENERATED
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Interface foobar.ZBarChild

  // Method of foobar.ZBarChild
  sal_Int32 SAL_CALL
  InheritedInterface::doAnother(
    sal_Int32 param )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION doAnother ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION doAnother ----
  }

  // Method of foobar.ZBarChild
  sal_Int32 SAL_CALL
  InheritedInterface::doThat(
    sal_Int32 param )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION doThat ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION doThat ----
  }

  // Method of foobar.ZBarChild
  sal_Int32 SAL_CALL
  InheritedInterface::doThis(
    sal_Int32 param )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION doThis ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION doThis ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

