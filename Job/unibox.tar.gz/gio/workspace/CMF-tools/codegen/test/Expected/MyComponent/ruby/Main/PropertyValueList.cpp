// No longer required, no C bridge to Ruby weak object classes
// keep file to avoid evil-twin error if this is changed
