#ifndef _B324142A_844D_11DF_8426_0019BBEA6EFB_ // ---- INCLUDE PROTECTION ----
#define _B324142A_844D_11DF_8426_0019BBEA6EFB_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Brief ZSRunLevelControllerStub service
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    ZSMyRunLevelController.hpp
 *
 * @author  Kirstin Weber
 *
 * @date    30 June 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyRubyComponentBase.hpp"

#include <ruby.h>

#include <C_xoc_svc_session_ZSessionLifecycle_Stub.hpp>
#include <C_xoc_svc_session_ZRunLevelInformation_Stub.hpp>
#include <C_xoc_svc_session_ZRunLevelControl_Stub.hpp>

#include <xoc/svc/unoruby/Unoruby.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
// Enable the following if XInitialization::initialize is implemented in ruby
//#define ENABLE_RUBY_UNO_XINITIALIZATION_FOR_ZSMYRUNLEVELCONTROLLER
#ifdef ENABLE_RUBY_UNO_XINITIALIZATION_FOR_ZSMYRUNLEVELCONTROLLER
#include <C_com_sun_star_lang_XInitialization_Stub.hpp>
#endif

// ---- END EDITABLE SECTION INCLUDES ----

namespace xoc_svc_session {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Brief ZSRunLevelControllerStub service
 *
 * A Ruby service implementing a single interface
 */
class ZSMyRunLevelController : public ZSMyRunLevelControllerBase
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    ZSMyRunLevelController( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~ZSMyRunLevelController();

    // Interface xoc.svc.session.ZSessionLifecycle

    // Method of xoc.svc.session.ZSessionLifecycle
    virtual void SAL_CALL
    sbsInitialize()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.session.ZSessionLifecycle
    virtual void SAL_CALL
    sbsShutdown()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.session.ZRunLevelInformation

    // Method of xoc.svc.session.ZRunLevelInformation
    virtual ::rtl::OUString SAL_CALL
    getRunLevel()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.session.ZRunLevelInformation
    virtual ::rtl::OUString SAL_CALL
    registerForRunLevelChange(
      const ::com::sun::star::uno::Reference< ::xoc::svc::session::ZRunLevelListener >& client )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.session.ZRunLevelInformation
    virtual ::rtl::OUString SAL_CALL
    unregisterForRunLevelChange(
      const ::com::sun::star::uno::Reference< ::xoc::svc::session::ZRunLevelListener >& client )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.session.ZRunLevelInformation
    virtual ::sal_Bool SAL_CALL
    isRunLevelBelow(
      const ::rtl::OUString& runLevel )
      throw (
        ::xoc::exc::ZParameterException,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.session.ZRunLevelInformation
    virtual ::sal_Bool SAL_CALL
    isRunLevelAbove(
      const ::rtl::OUString& runLevel )
      throw (
        ::xoc::exc::ZParameterException,
        ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.session.ZRunLevelControl

    // Method of xoc.svc.session.ZRunLevelControl
    virtual void SAL_CALL
    enterRunLevel(
      const ::rtl::OUString& desiredLevel )
      throw (
        ::xoc::exc::ZParameterException,
        ::com::sun::star::uno::RuntimeException );

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    ZSMyRunLevelController(const ZSMyRunLevelController & r);

    // Assignment operator
    ZSMyRunLevelController&operator=(const ZSMyRunLevelController & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For interfacing to Ruby methods
    VALUE rubyClass;
    ::services_ruby_UnoRuby::C_xoc_svc_session_ZSessionLifecycleStub *pRubyStubZSessionLifecycle;
    ::services_ruby_UnoRuby::C_xoc_svc_session_ZRunLevelInformationStub *pRubyStubZRunLevelInformation;
    ::services_ruby_UnoRuby::C_xoc_svc_session_ZRunLevelControlStub *pRubyStubZRunLevelControl;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
