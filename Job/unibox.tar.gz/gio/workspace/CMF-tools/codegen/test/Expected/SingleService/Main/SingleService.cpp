/** 
 ****************************************************************************
 *
 * No additional interfaces
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    SingleService.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Apr 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "SingleService.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::svc_session_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace svc_session_misc {

  SingleService::SingleService(
    Reference< XComponentContext > const & xComponentContext)
    : SingleServiceBase::SingleServiceBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
    , mInitialized(sal_False)
  {
    // ---- BEGIN EDITABLE SECTION SingleService ----

    // ---- END EDITABLE SECTION SingleService ----
  }

  SingleService::~SingleService()
  {
    // ---- BEGIN EDITABLE SECTION ~SingleService ----

    // ---- END EDITABLE SECTION ~SingleService ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  SingleService::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      mInitialized = sal_True;
      // @todo TODO_AUTO_GENERATED
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

