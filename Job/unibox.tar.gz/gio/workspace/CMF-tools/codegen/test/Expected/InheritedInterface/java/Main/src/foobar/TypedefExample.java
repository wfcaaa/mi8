/** 
 ****************************************************************************
 *
 * Interface uses UNO types defined as typedefs 
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    TypedefExample.java
 *
 * @author  Charles Halliday
 *
 * @date    05 May 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package foobar;

import foobar.ZTypedefExample;
import com.sun.star.lib.uno.helper.WeakBase;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * Interface uses UNO types defined as typedefs
 */

class TypedefExample
  extends WeakBase
  implements ZTypedefExample
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("foobar");

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  // Interface foobar.ZTypedefExample

  // Method of foobar.ZTypedefExample
  public void setVersionId(int versionId)
  {
    // ---- BEGIN EDITABLE SECTION setVersionId ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setVersionId ----
  }

  // Method of foobar.ZTypedefExample
  public int getVersionId()
  {
    // ---- BEGIN EDITABLE SECTION getVersionId ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getVersionId ----
  }

  // Method of foobar.ZTypedefExample
  public void updateVersionId(int[] versionId)
  {
    // ---- BEGIN EDITABLE SECTION updateVersionId ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION updateVersionId ----
  }

  // Method of foobar.ZTypedefExample
  public int[] cloneVersionIdList(int[] versionIdArray)
  {
    // ---- BEGIN EDITABLE SECTION cloneVersionIdList ----
    int[] returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION cloneVersionIdList ----
  }

  // Method of foobar.ZTypedefExample
  public void setAnotherVersionId(int anotherVersionId)
  {
    // ---- BEGIN EDITABLE SECTION setAnotherVersionId ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setAnotherVersionId ----
  }

  // Method of foobar.ZTypedefExample
  public int getAnotherVersionId()
  {
    // ---- BEGIN EDITABLE SECTION getAnotherVersionId ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getAnotherVersionId ----
  }

  // Method of foobar.ZTypedefExample
  public void updateAnotherVersionId(int[] anotherVersionId)
  {
    // ---- BEGIN EDITABLE SECTION updateAnotherVersionId ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION updateAnotherVersionId ----
  }

  // Method of foobar.ZTypedefExample
  public int[] cloneAnotherVersionIdList(int[] anotherVersionIdArray)
  {
    // ---- BEGIN EDITABLE SECTION cloneAnotherVersionIdList ----
    int[] returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION cloneAnotherVersionIdList ----
  }

  // Method of foobar.ZTypedefExample
  public double mapValue(double value)
  {
    // ---- BEGIN EDITABLE SECTION mapValue ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION mapValue ----
  }

  // Method of foobar.ZTypedefExample
  public double[] cloneValueSequence(double[] valueSequence)
  {
    // ---- BEGIN EDITABLE SECTION cloneValueSequence ----
    double[] returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION cloneValueSequence ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // Default constructor, may be replaced
  TypedefExample()
  {
  }

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // ! TypedefExample
