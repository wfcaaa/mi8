# Builds MultipleInheritedInterface C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['MultipleInheritedInterface']
}
# **** CODE GENERATOR CHECKSUM a65ba067d6d9cef30581f65a4f95b8ee
