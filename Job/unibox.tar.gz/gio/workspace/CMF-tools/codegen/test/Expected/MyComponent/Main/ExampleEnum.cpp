/** 
 ****************************************************************************
 *
 * Example enum types in method parameters and return
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    ExampleEnum.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "ExampleEnum.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::exc;
using namespace ::xoc::svc::pref;
using namespace ::xoc::svc::waiting;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_misc {

  // Interface xoc.svc.waiting.ZWaiting

  // Method of xoc.svc.waiting.ZWaiting
  void SAL_CALL
  ExampleEnum::setDuration(
    sal_Int32 duration,
    ZWaitingUnit unit )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setDuration ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setDuration ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  double SAL_CALL
  ExampleEnum::getRemainingTime(
    ZWaitingUnit unit )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getRemainingTime ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getRemainingTime ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  sal_Bool SAL_CALL
  ExampleEnum::hasElapsed()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION hasElapsed ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION hasElapsed ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  void SAL_CALL
  ExampleEnum::unite(
    const Reference< ZWaiting >& waitingObject )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION unite ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION unite ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  void SAL_CALL
  ExampleEnum::wait()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION wait ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION wait ----
  }

  // Interface xoc.svc.pref.ZPreferences

  // Method of xoc.svc.pref.ZPreferences
  OUString SAL_CALL
  ExampleEnum::name()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION name ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION name ----
  }

  // Method of xoc.svc.pref.ZPreferences
  PrefMethodStatus SAL_CALL
  ExampleEnum::getKey(
    const OUString& keyPath,
    OUString& keyValue )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getKey ----
    PrefMethodStatus returnValue = PrefMethodStatus_SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getKey ----
  }

  // Method of xoc.svc.pref.ZPreferences
  PrefMethodStatus SAL_CALL
  ExampleEnum::putKey(
    const OUString& keyPath,
    const OUString& keyValue )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION putKey ----
    PrefMethodStatus returnValue = PrefMethodStatus_SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION putKey ----
  }

  // Method of xoc.svc.pref.ZPreferences
  PrefMethodStatus SAL_CALL
  ExampleEnum::removeKey(
    const OUString& keyPath )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION removeKey ----
    PrefMethodStatus returnValue = PrefMethodStatus_SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION removeKey ----
  }

  // Method of xoc.svc.pref.ZPreferences
  Sequence< OUString > SAL_CALL
  ExampleEnum::keys()
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION keys ----
    Sequence< OUString > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION keys ----
  }

  // Method of xoc.svc.pref.ZPreferences
  Sequence< OUString > SAL_CALL
  ExampleEnum::children()
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION children ----
    Sequence< OUString > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION children ----
  }

  // Method of xoc.svc.pref.ZPreferences
  PrefMethodStatus SAL_CALL
  ExampleEnum::addNode(
    const OUString& nodePath )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addNode ----
    PrefMethodStatus returnValue = PrefMethodStatus_SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION addNode ----
  }

  // Method of xoc.svc.pref.ZPreferences
  Reference< ZPreferences > SAL_CALL
  ExampleEnum::getNode(
    const OUString& nodePath )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getNode ----
    Reference< ZPreferences > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getNode ----
  }

  // Method of xoc.svc.pref.ZPreferences
  PrefMethodStatus SAL_CALL
  ExampleEnum::removeNode(
    const OUString& nodePath )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION removeNode ----
    PrefMethodStatus returnValue = PrefMethodStatus_SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION removeNode ----
  }

  // Method of xoc.svc.pref.ZPreferences
  sal_Bool SAL_CALL
  ExampleEnum::nodeExists(
    const OUString& nodePath )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION nodeExists ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION nodeExists ----
  }

  // Method of xoc.svc.pref.ZPreferences
  Reference< ZPreferences > SAL_CALL
  ExampleEnum::getParentNode()
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getParentNode ----
    Reference< ZPreferences > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getParentNode ----
  }

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL ExampleEnum::acquire()
     throw ()
   {
     ExampleEnumImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL ExampleEnum::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     ExampleEnumImplHelper::release();
   }
#endif

  ExampleEnum::~ExampleEnum()
  {
    // ---- BEGIN EDITABLE SECTION ~ExampleEnum ----

    // ---- END EDITABLE SECTION ~ExampleEnum ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  ExampleEnum::ExampleEnum()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

