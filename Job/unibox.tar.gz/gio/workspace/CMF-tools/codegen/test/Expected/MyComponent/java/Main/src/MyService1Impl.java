/** 
 ****************************************************************************
 *
 * Brief MyService1
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    MyService1Impl.java
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package xoc_svc_misc;

import com.sun.star.lang.XInitialization;
import com.sun.star.uno.Exception;
import com.sun.star.uno.XComponentContext;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * Brief MyService1
 *
 * Full description of xoc.svc.misc.MyService1,
 * no interfaces
 */

public class MyService1Impl
  extends xoc_svc_misc.MyService1ImplBase
  implements XInitialization
  // ---- BEGIN EDITABLE SECTION IMPLEMENTS ----
  // ---- END EDITABLE SECTION IMPLEMENTS ----
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("xoc_svc_misc");

  private boolean mInitialized = false;

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  public MyService1Impl(XComponentContext xComponentContext)
  {
    super(xComponentContext);
    // ---- BEGIN EDITABLE SECTION MyService1Impl ----

    // ---- END EDITABLE SECTION MyService1Impl ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  public void initialize(Object[] aArguments)
    throws Exception
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    synchronized (this) {
      if ( ! mInitialized ) {
        mInitialized = true;
        // @todo TODO_AUTO_GENERATED
      }
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // !  MyService1Impl
