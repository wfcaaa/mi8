#ifndef _DD0F3E40_9117_11DB_8D15_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _DD0F3E40_9117_11DB_8D15_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Explicit XServiceInfo overriding standard implementation
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    ZSXServiceInfoService.hpp
 *
 * @author  Charles Halliday
 *
 * @date    21 Dec 2006
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "HelperTestBase.hpp"
#include <xoc/threads/Synchronization.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

namespace svc_session_misc {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Explicit XServiceInfo overriding standard implementation
 *
 * Also explicit com.sun.star.lang.XInitialization
 * 
 */
class ZSXServiceInfoService : public ZSXServiceInfoServiceBase
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    ZSXServiceInfoService( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~ZSXServiceInfoService();

    // Interface com.sun.star.lang.XServiceInfo

    // Method of com.sun.star.lang.XServiceInfo
    virtual ::rtl::OUString SAL_CALL
    getImplementationName()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.lang.XServiceInfo
    virtual ::sal_Bool SAL_CALL
    supportsService(
      const ::rtl::OUString& ServiceName )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.lang.XServiceInfo
    virtual ::com::sun::star::uno::Sequence< ::rtl::OUString > SAL_CALL
    getSupportedServiceNames()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.ZValue

    // Method of xoc.svc.ZValue
    virtual ::sal_Int32 SAL_CALL
    getType()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface com.sun.star.lang.XInitialization

    // Method of com.sun.star.lang.XInitialization
    virtual void SAL_CALL
    initialize(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Any >& aArguments )
      throw (
        ::com::sun::star::uno::Exception,
        ::com::sun::star::uno::RuntimeException );

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    ZSXServiceInfoService(const ZSXServiceInfoService & r);

    // Assignment operator
    ZSXServiceInfoService&operator=(const ZSXServiceInfoService & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For com.sun.star.lang.XInitialization
    ::xoc::threads::Mutex mInitializedMutex;
    ::sal_Bool mInitialized;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
