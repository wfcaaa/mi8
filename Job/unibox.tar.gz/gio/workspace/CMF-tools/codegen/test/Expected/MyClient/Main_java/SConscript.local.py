# Builds MyClient Java Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['java_component_utility'] ,
'NAME' : ['MyClient']
}
# **** CODE GENERATOR CHECKSUM 66d05f65103f6a867dd759397e71ba6d
