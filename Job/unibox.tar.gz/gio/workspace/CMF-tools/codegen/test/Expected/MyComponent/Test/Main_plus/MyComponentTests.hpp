#ifndef _58755056_8871_11E0_AE64_00101819DE86_ // ---- INCLUDE PROTECTION ----
#define _58755056_8871_11E0_AE64_00101819DE86_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Component Tests for MyComponent.
 *
 * Copyright by Verigy Germany GmbH, 2011
 *
 * @file    MyComponentTests.hpp
 *
 * @author  Charles Halliday
 *
 * @date    27 May 2011
 *
 ****************************************************************************
 */

/*
 * This file is developer maintained.
 * The initial version file is generated automatically by a set of style
 * sheets, but requires manual changes for implementation specifics.
 * Warning, regenerating the file will require manual merging.
 */

#define ZENITH_COMPONENT_TEST_SUITES

#include <xoc/zutils.hpp>
#include <cxxtest_zenith/cxxtest_zenith.h>
#include <com/sun/star/lang/XComponent.hpp>
#include <com/sun/star/lang/XMain.hpp>
#include <xoc/svc/session/ZRunLevelControl.hpp>
#include <xoc/cot/ZDebug.hpp>
#include <xoc/svc/logstreamfactory/ZLogStreamFactory.hpp>

#include <com/sun/star/io/XInputStream.hpp>
#include <com/sun/star/io/XOutputStream.hpp>
#include <com/sun/star/lang/XInitialization.hpp>
#include <com/sun/star/test/performance/XPerformanceTest.hpp>
#include <xoc/svc/ZPropertyValueList.hpp>
#include <xoc/svc/pref/ZPreferences.hpp>
#include <xoc/svc/reflector/ZBroadcaster.hpp>
#include <xoc/svc/reflector/ZEcho.hpp>
#include <xoc/svc/waiting/ZWaiting.hpp>

using namespace ::com::sun::star::uno;
using namespace ::com::sun::star::lang;
using namespace ::rtl;
using namespace ::xoc;
using namespace ::xoc::cot;
using namespace ::xoc::svc::session;


// If your tests require the launcher to be active (eg. because your components 
// are session base services), set USE_LAUNCHER to 1.
// You also need to adapt your Test/TestBed/Makefile.local. For instructions see 
// http://socweb01.verigy.net/radix/bin/view/UNO_Components/ComponentTest#Enabling_the_Launcher

#define USE_LAUNCHER 0

// the world fixture; its scope is the entire test.

class WorldFixture : public CxxTest::GlobalFixture
{
public:
    bool setUpWorld() { // this is called once before all tests

#if USE_LAUNCHER
      Reference<XMain> main;
      TS_ASSERT_THROWS_NOTHING(
      main = XOC_GET_SERVICE(XMain, "xoc.svc.session.ZSLauncher");
      );
      TS_ASSERT( main.is() );
      if ( main.is() ) {
        Sequence<OUString> Args;    // you might want to add some stuff here...
        int launcher_exit_code = 1; // in case run throws up we want an error
        TS_ASSERT_THROWS_NOTHING(
          launcher_exit_code = main->run(Args);
        );
        TS_ASSERT( launcher_exit_code == 0 );

        const Reference <ZRunLevelControl> runLevelController =
          XOC_GET_IMPLEMENTER(ZRunLevelControl);
        runLevelController->enterRunLevel(toOu("AteServerReady"));

        return (launcher_exit_code == 0);
      } else {
        return false;
      }
#else
      return true;
#endif
    }

    bool tearDownWorld() { // this is called once after all tests
#if USE_LAUNCHER
      Reference<XComponent> launcher =
        XOC_GET_SERVICE(XComponent, "xoc.svc.session.ZSLauncher");

      launcher->dispose();
#endif
      return true;
    }

    bool setUp() {  // this is called before every test in every test suite
      // Make so TS_ASSERT and related functions abort the test on fail.
      CxxTest::setAbortTestOnFail(true);
      return true;
    }

    bool tearDown() { return true; } // this is called after every test in every test suite
};

// the following is needed to activate the world fixture - do not touch.
static WorldFixture* thewfp = 0;
void newWorldFixture()    { thewfp = new WorldFixture; }
void deleteWorldFixture() { delete thewfp; }


// test suite qualifiers: <name>_Q<codes>Q
// <name> is any name desired.
// <codes> is a string made up from the characters u,r,p,s,o,h
// u: run the test in the pseudo-level USER
// r: run the test suite for integration into release
// p: run the test suite for integration into project
// s: run the test suite for integration into sub-project
// o: run in offline mode
// h: run in on-line (hardware) mode
// example: TestMath_QrphQ - run this test suite for integration
// into release and project but only in on-line mode.
// if no qualifier is given the test suite is always run



/**
  * Default test case to ensure that a component under test loads and
  * service under test may be accessed.
  * Acquires the XInterface interface and checks the reference is non-zero
  */

class ElementaryTests : public CxxTest::TestSuite {
public:

// per suite pre calls
static ElementaryTests* createSuite()
{
  ElementaryTests *theSuite = new ElementaryTests;
  // any per-suit ramp-up code should go here
  return theSuite;
}

// per suite post calls
static void destroySuite(ElementaryTests* theSuite)
{
  // any per-suit tear-down code should go here
  delete theSuite;
}

// Any class method named "test*" of a testsuite class is a
// automatical executed testmethod.
void testInstantiation(void)
{
  // the first line in every test*(void) method should be a 'call' to
  // the macro Z_ENTER_TEST().
  Z_ENTER_TEST()

  // ADD USER CODE IN THE FOLLOWING BLOCK:
  {
    // get a reference to the component under test
    Reference<XInterface> testServiceRef =
      XOC_GET_SERVICE(XInterface, "xoc.svc.misc.MyService1");

    // assert that the reference is non-null
    TS_ASSERT(testServiceRef.is());

  }

  // were you enter you shall exit
  Z_EXIT_TEST()
}

// This test will never be executed; name doesn't start with "test"
void ztestDummyTest(void)
{
  Z_ENTER_TEST()
  {
    // user code
  }
  Z_EXIT_TEST()
}
};


#endif  // ---- INCLUDE PROTECTION ----
// **** CODE GENERATOR CHECKSUM a998fb9a175d8f74da4321704a7e4586
