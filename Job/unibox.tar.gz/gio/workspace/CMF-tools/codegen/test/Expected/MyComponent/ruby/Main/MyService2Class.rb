# 
#***************************************************************************
#
# Brief MyService2
#
# Copyright by Verigy, 2006
#
# @file    MyService2Class.rb
#
# @author  Charles Halliday
#
# @date    01 Aug 2005
#
#***************************************************************************
#

#
# This file is developer maintained.
# NOTE: You may edit this file between BEGIN EDITABLE SECTION and END
# EDITABLE SECTION. But don't edit it outside these comments, or your code
# _will_ be lost after a component regeneration.
#

# Use the following editable section for items required before the class
# definition
# ---- BEGIN EDITABLE SECTION HEADER ----

# ---- END EDITABLE SECTION HEADER ----

#
# Full description of xoc.svc.misc.MyService2

class MyService2Class

  # ruby constructor initialize method
  def initialize
    # ---- BEGIN EDITABLE SECTION initialize ----

    # ---- END EDITABLE SECTION initialize ----
  end

  # Interface com.sun.star.lang.XInitialization

  # Method of com.sun.star.lang.XInitialization
  # initialize method name mapped to unoInitialize
  def unoInitialize(aArguments)
    # ---- BEGIN EDITABLE SECTION unoInitialize ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION unoInitialize ----
  end

  # Interface xoc.svc.reflector.ZEcho

  # Method of xoc.svc.reflector.ZEcho
  def echo(s)
    # ---- BEGIN EDITABLE SECTION echo ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION echo ----
  end

  # Method of xoc.svc.reflector.ZEcho
  def print(s)
    # ---- BEGIN EDITABLE SECTION print ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION print ----
  end

  # Interface xoc.svc.reflector.ZBroadcaster

  # Method of xoc.svc.reflector.ZBroadcaster
  def registerReceiver(r)
    # ---- BEGIN EDITABLE SECTION registerReceiver ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION registerReceiver ----
  end

  # Method of xoc.svc.reflector.ZBroadcaster
  def unRegisterReceiver(r)
    # ---- BEGIN EDITABLE SECTION unRegisterReceiver ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION unRegisterReceiver ----
  end

  # Method of xoc.svc.reflector.ZBroadcaster
  def broadcast(s)
    # ---- BEGIN EDITABLE SECTION broadcast ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION broadcast ----
  end

  # Use this section to define additional class members
  # ---- BEGIN EDITABLE SECTION MEMBERS ----

  # ---- END EDITABLE SECTION MEMBERS ----

end  # ! MyService2Class

# Use the following editable section for items required after the class
# definition
# ---- BEGIN EDITABLE SECTION FOOTER ----

# ---- END EDITABLE SECTION FOOTER ----
