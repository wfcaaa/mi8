#ifndef _2C773610_2F8B_11DC_9E71_00306EB267AB_ // ---- INCLUDE PROTECTION ----
#define _2C773610_2F8B_11DC_9E71_00306EB267AB_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Service with overlapping interfaces
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    ExtendedInterface.hpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Jul 2007
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "InheritedInterfaceBase.hpp"
#include <xoc/threads/Synchronization.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

namespace foobar {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Service with overlapping interfaces
 *
 * Methods defined in both interfaces should only be
 * created once in the implementation class.
 */
class ExtendedInterface : public ExtendedInterfaceBase
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    ExtendedInterface( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~ExtendedInterface();

    // Interface com.sun.star.lang.XInitialization

    // Method of com.sun.star.lang.XInitialization
    virtual void SAL_CALL
    initialize(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Any >& aArguments )
      throw (
        ::com::sun::star::uno::Exception,
        ::com::sun::star::uno::RuntimeException );

    // Interface foobar.ZBar

    // Method of foobar.ZBar
    virtual ::sal_Int32 SAL_CALL
    doThat(
      ::sal_Int32 param )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZBar
    virtual ::sal_Int32 SAL_CALL
    doThis(
      ::sal_Int32 param )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface foobar.ZBarExtended

    // Method of foobar.ZBarExtended
    // doThat already implemented for interface foobar.ZBar

    // Method of foobar.ZBarExtended
    virtual void SAL_CALL
    doExtension()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZBarExtended
    // doThis already implemented for interface foobar.ZBar

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    ExtendedInterface(const ExtendedInterface & r);

    // Assignment operator
    ExtendedInterface&operator=(const ExtendedInterface & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For com.sun.star.lang.XInitialization
    ::xoc::threads::Mutex mInitializedMutex;
    ::sal_Bool mInitialized;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
