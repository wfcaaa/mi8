#ifndef _8735AE3A_30DF_11DF_8426_0019BBEA6EFB_ // ---- INCLUDE PROTECTION ----
#define _8735AE3A_30DF_11DF_8426_0019BBEA6EFB_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * 
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    ZSUsingMultipleInterfaces.hpp
 *
 * @author  Kirstin Weberr
 *
 * @date    16 Mar 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MultipleInheritedInterfaceBase.hpp"

#include <xoc/hw/cor/description/ZHwSpecifierAnalyzer.hpp>
#include <xoc/hw/cor/pogocabling/ZPogoCabling.hpp>
#include <foobar/ZBar.hpp>
#include <foobar/ZFoo.hpp>
#include <xoc/threads/Synchronization.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

namespace foobar_MultipleInheritedInterface {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * 
 */
class ZSUsingMultipleInterfaces : public ::foobar::ZSUsingMultipleInterfacesBase
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    ZSUsingMultipleInterfaces( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~ZSUsingMultipleInterfaces();

    // Interface com.sun.star.lang.XInitialization

    // Method of com.sun.star.lang.XInitialization
    virtual void SAL_CALL
    initialize(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Any >& aArguments )
      throw (
        ::com::sun::star::uno::Exception,
        ::com::sun::star::uno::RuntimeException );

    // Interface foobar.ZTestChild

    // Method of foobar.ZTestChild
    virtual void SAL_CALL
    function3(
      const ::com::sun::star::uno::Reference< ::foobar::ZFoo >& foo )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTestChild
    virtual void SAL_CALL
    function1(
      const ::com::sun::star::uno::Reference< ::foobar::ZBar >& bar )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTestChild
    virtual void SAL_CALL
    function4(
      const ::com::sun::star::uno::Reference< ::foobar::ZBar >& bar )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTestChild
    virtual void SAL_CALL
    function2(
      const ::xoc::hw::cor::pogocabling::ZPogoCabling& pogoCabling,
      const ::xoc::hw::cor::description::ZHwSpecifierType& hwSpecifierType )
      throw ( ::com::sun::star::uno::RuntimeException );

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    ZSUsingMultipleInterfaces(const ZSUsingMultipleInterfaces & r);

    // Assignment operator
    ZSUsingMultipleInterfaces&operator=(const ZSUsingMultipleInterfaces & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For com.sun.star.lang.XInitialization
    ::xoc::threads::Mutex mInitializedMutex;
    ::sal_Bool mInitialized;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
