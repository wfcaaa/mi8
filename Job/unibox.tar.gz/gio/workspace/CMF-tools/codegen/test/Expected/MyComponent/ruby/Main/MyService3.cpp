/** 
 ****************************************************************************
 *
 * Brief MyService3
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    MyService3.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyService3.hpp"
#include <xoc/svc/misc/LocationResolver.hpp>
#include <SystemLogger.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

#include <xoc/svc/session/SessionServiceManager.hpp>
// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::cot;
using namespace ::xoc::svc::reflector;
using namespace ::services_ruby_UnoRuby;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_pckg;

  const rtl::OUString serviceName =
  toOu("xoc.svc.misc.MyService3");

  const rtl::OUString configDataPath =
  toOu("ccd:")+ serviceName;
  const rtl::OUString rubyServiceImplementationPathTail =
  toOu("/MyService3.rb");

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_pckg {

  MyService3::MyService3(
    Reference< XComponentContext > const & xComponentContext)
    : MyService3Base::MyService3Base(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
  {
    // ---- BEGIN EDITABLE SECTION MyService3 ----

    initForServices();

    rtl::OUString absConfigDataPath =
      ::xoc::svc::misc::LocationResolver::instance()->
      getAbsPath(configDataPath);

    rtl::OUString initScript =
      absConfigDataPath + rubyServiceImplementationPathTail;

    callRubyScript(initScript);

    rubyClass = rubyEval(toOu("MyService3.new"));

#ifdef ENABLE_RUBY_UNO_XINITIALIZATION_FOR_MYSERVICE3
    pRubyStubXInitialization =
      new C_com_sun_star_lang_XInitializationStub(rubyClass);
#endif
    pRubyStubZEcho =
      new C_xoc_svc_reflector_ZEchoStub(rubyClass);
    pRubyStubZDebug =
      new C_xoc_cot_ZDebugStub(rubyClass);

    // ---- END EDITABLE SECTION MyService3 ----
  }

  MyService3::~MyService3()
  {
    // ---- BEGIN EDITABLE SECTION ~MyService3 ----

    // ---- END EDITABLE SECTION ~MyService3 ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  MyService3::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      mInitialized = sal_True;
#ifdef ENABLE_RUBY_UNO_XINITIALIZATION_FOR_MYSERVICE3
      pRubyStubXInitialization->unoInitialize(aArguments);
#endif
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Interface xoc.svc.reflector.ZEcho

  // Method of xoc.svc.reflector.ZEcho
  OUString SAL_CALL
  MyService3::echo(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION echo ----
    return pRubyStubZEcho->echo(s);
    // ---- END EDITABLE SECTION echo ----
  }

  // Method of xoc.svc.reflector.ZEcho
  void SAL_CALL
  MyService3::print(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION print ----
    pRubyStubZEcho->print(s);
    // ---- END EDITABLE SECTION print ----
  }

  // Interface xoc.cot.ZDebug

  // Method of xoc.cot.ZDebug
  void SAL_CALL
  MyService3::dump(
    const Reference< ZLogStream >& log )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION dump ----
    pRubyStubZDebug->dump(log);
    // ---- END EDITABLE SECTION dump ----
  }

  // Method of xoc.cot.ZDebug
  sal_Bool SAL_CALL
  MyService3::isValid()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION isValid ----
    return pRubyStubZDebug->isValid();
    // ---- END EDITABLE SECTION isValid ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

