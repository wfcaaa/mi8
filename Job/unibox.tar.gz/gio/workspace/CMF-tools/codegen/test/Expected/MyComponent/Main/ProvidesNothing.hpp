#ifndef _EB10826A_ECF3_11DF_A894_D8D38581BDAC_ // ---- INCLUDE PROTECTION ----
#define _EB10826A_ECF3_11DF_A894_D8D38581BDAC_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * An weak object that does not implement any interface.
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    ProvidesNothing.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include <cppuhelper/implbase_ex.hxx>
#include <com/sun/star/uno/RuntimeException.hpp>

#include <com/sun/star/lang/IllegalArgumentException.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Enable following line to log weakObject reference counts
//#define DEBUG_REFCOUNT

namespace xoc_svc_misc {
typedef ::cppu::OWeakObject ProvidesNothingImplHelper;

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * An weak object that does not implement any interface.
 */
class ProvidesNothing :
    public ProvidesNothingImplHelper
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

#ifdef DEBUG_REFCOUNT
    // XInterface overridden methods, for debugging only
    virtual void SAL_CALL acquire() throw ();
    virtual void SAL_CALL release() throw ();
#endif

    virtual ~ProvidesNothing();

  // Constructors and additional class member declarations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

    ProvidesNothing();

  private:
    // Copy constructor
    ProvidesNothing(const ProvidesNothing & r);

    // Assignment operator
    ProvidesNothing&operator=(const ProvidesNothing & r);

  // ---- END EDITABLE SECTION MEMBERS ----
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
