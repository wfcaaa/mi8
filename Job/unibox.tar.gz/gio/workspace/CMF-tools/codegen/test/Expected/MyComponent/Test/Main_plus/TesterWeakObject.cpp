/** 
 ****************************************************************************
 *
 * Additional (arbitrary) weakObject used by unit tester
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    TesterWeakObject.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Apr 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "TesterWeakObject.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::svc::xml;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_misc {

  // Interface xoc.svc.xml.ZSAXAttributes

  // Method of xoc.svc.xml.ZSAXAttributes
  sal_Int32 SAL_CALL
  TesterWeakObject::getLength()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getLength ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getLength ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  OUString SAL_CALL
  TesterWeakObject::getLocalName(
    sal_Int32 index )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getLocalName ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getLocalName ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  OUString SAL_CALL
  TesterWeakObject::getURI(
    sal_Int32 index )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getURI ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getURI ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  OUString SAL_CALL
  TesterWeakObject::getQName(
    sal_Int32 index )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getQName ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getQName ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  OUString SAL_CALL
  TesterWeakObject::getType(
    sal_Int32 index )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getType ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getType ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  OUString SAL_CALL
  TesterWeakObject::getTypeByUri(
    const OUString& uri,
    const OUString& localPart )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getTypeByUri ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getTypeByUri ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  OUString SAL_CALL
  TesterWeakObject::getTypeByQname(
    const OUString& qName )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getTypeByQname ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getTypeByQname ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  OUString SAL_CALL
  TesterWeakObject::getValue(
    sal_Int32 index )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValue ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValue ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  OUString SAL_CALL
  TesterWeakObject::getValueByUri(
    const OUString& uri,
    const OUString& localPart )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueByUri ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueByUri ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  OUString SAL_CALL
  TesterWeakObject::getValueByQname(
    const OUString& qName )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueByQname ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueByQname ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  sal_Int32 SAL_CALL
  TesterWeakObject::getIndexByUri(
    const OUString& uri,
    const OUString& localPart )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getIndexByUri ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getIndexByUri ----
  }

  // Method of xoc.svc.xml.ZSAXAttributes
  sal_Int32 SAL_CALL
  TesterWeakObject::getIndexByQname(
    const OUString& qName )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getIndexByQname ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getIndexByQname ----
  }

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL TesterWeakObject::acquire()
     throw ()
   {
     TesterWeakObjectImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL TesterWeakObject::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     TesterWeakObjectImplHelper::release();
   }
#endif

  TesterWeakObject::~TesterWeakObject()
  {
    // ---- BEGIN EDITABLE SECTION ~TesterWeakObject ----

    // ---- END EDITABLE SECTION ~TesterWeakObject ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  TesterWeakObject::TesterWeakObject()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

