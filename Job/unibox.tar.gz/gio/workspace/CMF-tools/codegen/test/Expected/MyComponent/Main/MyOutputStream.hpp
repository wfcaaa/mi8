#ifndef _1E739E08_65DA_11DB_8981_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _1E739E08_65DA_11DB_8981_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * An Output stream
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    MyOutputStream.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include <cppuhelper/implbase1.hxx>
#include <com/sun/star/uno/RuntimeException.hpp>

#include <com/sun/star/io/XOutputStream.hpp>

#include <com/sun/star/io/XPersist.hpp>
#include <com/sun/star/lang/IllegalArgumentException.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Enable following line to log weakObject reference counts
//#define DEBUG_REFCOUNT

namespace xoc_svc_misc {
typedef ::cppu::WeakImplHelper1<
  ::com::sun::star::io::XOutputStream
  > MyOutputStreamImplHelper;

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * An Output stream
 */
class MyOutputStream :
    public MyOutputStreamImplHelper
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    // Interface com.sun.star.io.XOutputStream

    // Method of com.sun.star.io.XOutputStream
    virtual void SAL_CALL
    writeBytes(
      const ::com::sun::star::uno::Sequence< ::sal_Int8 >& aData )
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::BufferSizeExceededException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.io.XOutputStream
    virtual void SAL_CALL
    flush()
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::BufferSizeExceededException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.io.XOutputStream
    virtual void SAL_CALL
    closeOutput()
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::BufferSizeExceededException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

#ifdef DEBUG_REFCOUNT
    // XInterface overridden methods, for debugging only
    virtual void SAL_CALL acquire() throw ();
    virtual void SAL_CALL release() throw ();
#endif

    virtual ~MyOutputStream();

  // Constructors and additional class member declarations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

    MyOutputStream();

  private:
    // Copy constructor
    MyOutputStream(const MyOutputStream & r);

    // Assignment operator
    MyOutputStream&operator=(const MyOutputStream & r);

  // ---- END EDITABLE SECTION MEMBERS ----
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
