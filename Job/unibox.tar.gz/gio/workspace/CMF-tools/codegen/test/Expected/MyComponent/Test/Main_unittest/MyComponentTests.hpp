/** 
 ****************************************************************************
 *
 * Unit Tests for component MyComponent.
 *
 * Copyright by Agilent Technologies, 2006
 *
 * @file    MyComponentTests.hpp
 *
 * @author  Charles Halliday
 *
 * @date    28 Apr 2006
 *
 ****************************************************************************
 */

/*
 * This file is developer maintained.
 * The initial version file is generated automatically by a set of style
 * sheets, but requires manual changes for implementation specifics.
 * Warning, regenerating the file will require manual merging.
 */
#include <xoc/cot/ZDebug.hpp>
#include <xoc/svc/logstreamfactory/ZLogStreamFactory.hpp>

#include <com/sun/star/io/XInputStream.hpp>
#include <com/sun/star/io/XOutputStream.hpp>
#include <com/sun/star/lang/XInitialization.hpp>
#include <com/sun/star/test/performance/XPerformanceTest.hpp>
#include <xoc/svc/ZPropertyValueList.hpp>
#include <xoc/svc/pref/ZPreferences.hpp>
#include <xoc/svc/reflector/ZBroadcaster.hpp>
#include <xoc/svc/reflector/ZEcho.hpp>
#include <xoc/svc/waiting/ZWaiting.hpp>

namespace xoc_svc_misc {
namespace MyComponentTests {

using namespace ::com::sun::star::uno ;
using namespace ::com::sun::star::lang ;
using namespace ::xoc;
using namespace ::xoc::cot;

  //------------------------ Tests ------------------------------------
  /**
    * Default test case to ensure that a component under test loads and
    * service under test may be accessed.
    * Acquires the XInterface interface and checks the reference is non-zero
    *
    * @param serviceName  name of service being tested
    * @param serviceRef   UNO reference of service being tested
    *
    * @return TestResult  results of test
    */ 
  ZSMyComponentUnitTester::TestResult 
  checkServiceLoads(const sal_Char *serviceName,
                    const Reference<XInterface>& serviceRef)
  {
    ZSMyComponentUnitTester::TestResult retVal;

    retVal = ZSMyComponentUnitTester::PASSED;

    XOC_UTF_ASSERT(serviceRef.is());

    return retVal;
  }

  // Test Table
  const ZSMyComponentUnitTester::TestEntry testTable[] = 
    {
      {&checkServiceLoads, 0,
       ZSMyComponentUnitTester::OFFLINE, 
       ZSMyComponentUnitTester::ALL_LEVELS,
       "( 0)checkServiceLoads"},
      // @todo TODO_AUTO_GENERATED Add one entry for each test case function call
      {NULL,-1,0,0,NULL}
    };

}
} // namespace close

// **** CODE GENERATOR CHECKSUM 17ead1bc187cd38d2f220ede8ae0f0fa
