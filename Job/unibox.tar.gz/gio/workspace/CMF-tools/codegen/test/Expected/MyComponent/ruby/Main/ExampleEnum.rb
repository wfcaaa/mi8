# 
#***************************************************************************
#
# Example enum types in method parameters and return
#
# Copyright by Verigy, 2006
#
# @file    ExampleEnum.rb
#
# @author  Charles Halliday
#
# @date    01 Aug 2005
#
#***************************************************************************
#

#
# This file is developer maintained.
# NOTE: You may edit this file between BEGIN EDITABLE SECTION and END
# EDITABLE SECTION. But don't edit it outside these comments, or your code
# _will_ be lost after a component regeneration.
#

# Use the following editable section for items required before the class
# definition
# ---- BEGIN EDITABLE SECTION HEADER ----

# ---- END EDITABLE SECTION HEADER ----

#
# ZWaiting and ZPreferences use enums.
# 

class ExampleEnum < xoc.svc.waiting.ZWaiting

  # Interface xoc.svc.waiting.ZWaiting

  # Method of xoc.svc.waiting.ZWaiting
  def setDuration(duration, unit)
    # ---- BEGIN EDITABLE SECTION setDuration ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setDuration ----
  end

  # Method of xoc.svc.waiting.ZWaiting
  def getRemainingTime(unit)
    # ---- BEGIN EDITABLE SECTION getRemainingTime ----
    returnValue = 0.0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getRemainingTime ----
  end

  # Method of xoc.svc.waiting.ZWaiting
  def hasElapsed()
    # ---- BEGIN EDITABLE SECTION hasElapsed ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION hasElapsed ----
  end

  # Method of xoc.svc.waiting.ZWaiting
  def unite(waitingObject)
    # ---- BEGIN EDITABLE SECTION unite ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION unite ----
  end

  # Method of xoc.svc.waiting.ZWaiting
  def wait()
    # ---- BEGIN EDITABLE SECTION wait ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION wait ----
  end

  # Interface xoc.svc.pref.ZPreferences

  # Method of xoc.svc.pref.ZPreferences
  def name()
    # ---- BEGIN EDITABLE SECTION name ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION name ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def getKey(keyPath, keyValue)
    # ---- BEGIN EDITABLE SECTION getKey ----
    returnValue = E_3_SUCCESS
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getKey ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def putKey(keyPath, keyValue)
    # ---- BEGIN EDITABLE SECTION putKey ----
    returnValue = E_3_SUCCESS
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION putKey ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def removeKey(keyPath)
    # ---- BEGIN EDITABLE SECTION removeKey ----
    returnValue = E_3_SUCCESS
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION removeKey ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def keys()
    # ---- BEGIN EDITABLE SECTION keys ----
    returnValue = []
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION keys ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def children()
    # ---- BEGIN EDITABLE SECTION children ----
    returnValue = []
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION children ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def addNode(nodePath)
    # ---- BEGIN EDITABLE SECTION addNode ----
    returnValue = E_3_SUCCESS
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION addNode ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def getNode(nodePath)
    # ---- BEGIN EDITABLE SECTION getNode ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getNode ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def removeNode(nodePath)
    # ---- BEGIN EDITABLE SECTION removeNode ----
    returnValue = E_3_SUCCESS
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION removeNode ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def nodeExists(nodePath)
    # ---- BEGIN EDITABLE SECTION nodeExists ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION nodeExists ----
  end

  # Method of xoc.svc.pref.ZPreferences
  def getParentNode()
    # ---- BEGIN EDITABLE SECTION getParentNode ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getParentNode ----
  end

  # Use this section to define additional class members
  # ---- BEGIN EDITABLE SECTION MEMBERS ----

  # ruby constructor initialize method
  def initialize

  end

  # ---- END EDITABLE SECTION MEMBERS ----

end  # ! ExampleEnum

# Use the following editable section for items required after the class
# definition
# ---- BEGIN EDITABLE SECTION FOOTER ----

# ---- END EDITABLE SECTION FOOTER ----
