/** 
 ****************************************************************************
 *
 * Interface uses UNO types defined as typedefs 
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    TypedefExample.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Apr 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "TypedefExample.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::uno;
using namespace ::foobar;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::foobar;

}

// ---- END EDITABLE SECTION UTILS ----

namespace foobar {

  // Interface foobar.ZTypedefExample

  // Method of foobar.ZTypedefExample
  void SAL_CALL
  TypedefExample::setVersionId(
    sal_Int32 versionId )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setVersionId ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setVersionId ----
  }

  // Method of foobar.ZTypedefExample
  sal_Int32 SAL_CALL
  TypedefExample::getVersionId()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getVersionId ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getVersionId ----
  }

  // Method of foobar.ZTypedefExample
  void SAL_CALL
  TypedefExample::updateVersionId(
    sal_Int32& versionId )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION updateVersionId ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION updateVersionId ----
  }

  // Method of foobar.ZTypedefExample
  Sequence< sal_Int32 > SAL_CALL
  TypedefExample::cloneVersionIdList(
    const Sequence< sal_Int32 >& versionIdArray )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION cloneVersionIdList ----
    Sequence< sal_Int32 > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION cloneVersionIdList ----
  }

  // Method of foobar.ZTypedefExample
  void SAL_CALL
  TypedefExample::setAnotherVersionId(
    sal_Int32 anotherVersionId )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setAnotherVersionId ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setAnotherVersionId ----
  }

  // Method of foobar.ZTypedefExample
  sal_Int32 SAL_CALL
  TypedefExample::getAnotherVersionId()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getAnotherVersionId ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getAnotherVersionId ----
  }

  // Method of foobar.ZTypedefExample
  void SAL_CALL
  TypedefExample::updateAnotherVersionId(
    sal_Int32& anotherVersionId )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION updateAnotherVersionId ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION updateAnotherVersionId ----
  }

  // Method of foobar.ZTypedefExample
  Sequence< sal_Int32 > SAL_CALL
  TypedefExample::cloneAnotherVersionIdList(
    const Sequence< sal_Int32 >& anotherVersionIdArray )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION cloneAnotherVersionIdList ----
    Sequence< sal_Int32 > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION cloneAnotherVersionIdList ----
  }

  // Method of foobar.ZTypedefExample
  double SAL_CALL
  TypedefExample::mapValue(
    double value )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION mapValue ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION mapValue ----
  }

  // Method of foobar.ZTypedefExample
  Sequence< double > SAL_CALL
  TypedefExample::cloneValueSequence(
    const Sequence< double >& valueSequence )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION cloneValueSequence ----
    Sequence< double > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION cloneValueSequence ----
  }

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL TypedefExample::acquire()
     throw ()
   {
     TypedefExampleImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL TypedefExample::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     TypedefExampleImplHelper::release();
   }
#endif

  TypedefExample::~TypedefExample()
  {
    // ---- BEGIN EDITABLE SECTION ~TypedefExample ----

    // ---- END EDITABLE SECTION ~TypedefExample ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  TypedefExample::TypedefExample()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

