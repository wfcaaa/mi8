/** 
 ****************************************************************************
 *
 * Brief MyService2
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    MyService2Class.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyService2Class.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

#include <xoc/svc/session/SessionServiceManager.hpp>
// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::svc::reflector;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_pckg;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_pckg {

  MyService2Class::MyService2Class(
    Reference< XComponentContext > const & xComponentContext)
    : MyService2ClassBase::MyService2ClassBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
    , mInitialized(sal_False)
  {
    // ---- BEGIN EDITABLE SECTION MyService2Class ----

    // ---- END EDITABLE SECTION MyService2Class ----
  }

  MyService2Class::~MyService2Class()
  {
    // ---- BEGIN EDITABLE SECTION ~MyService2Class ----

    // ---- END EDITABLE SECTION ~MyService2Class ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  MyService2Class::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      // @todo TODO_AUTO_GENERATED remove if lifecycle is controlled by another singleton
      ::xoc::svc::session::SessionServiceManager::instance().
          registerForShutdown(this);
      mInitialized = sal_True;
      // @todo TODO_AUTO_GENERATED
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Interface xoc.svc.reflector.ZEcho

  // Method of xoc.svc.reflector.ZEcho
  OUString SAL_CALL
  MyService2Class::echo(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION echo ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION echo ----
  }

  // Method of xoc.svc.reflector.ZEcho
  void SAL_CALL
  MyService2Class::print(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION print ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION print ----
  }

  // Interface xoc.svc.reflector.ZBroadcaster

  // Method of xoc.svc.reflector.ZBroadcaster
  void SAL_CALL
  MyService2Class::registerReceiver(
    const Reference< ZReceiver >& r )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION registerReceiver ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION registerReceiver ----
  }

  // Method of xoc.svc.reflector.ZBroadcaster
  void SAL_CALL
  MyService2Class::unRegisterReceiver(
    const Reference< ZReceiver >& r )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION unRegisterReceiver ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION unRegisterReceiver ----
  }

  // Method of xoc.svc.reflector.ZBroadcaster
  void SAL_CALL
  MyService2Class::broadcast(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION broadcast ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION broadcast ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

