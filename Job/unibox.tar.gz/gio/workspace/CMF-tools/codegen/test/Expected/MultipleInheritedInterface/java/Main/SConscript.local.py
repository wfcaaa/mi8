# Builds MultipleInheritedInterface Java Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['java_component_package'] ,
'NAME' : ['MultipleInheritedInterface']
}
# **** CODE GENERATOR CHECKSUM 6d99e9b933cca16b96e2b1ab143adcde
