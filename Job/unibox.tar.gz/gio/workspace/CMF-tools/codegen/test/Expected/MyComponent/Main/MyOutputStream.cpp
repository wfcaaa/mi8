/** 
 ****************************************************************************
 *
 * An Output stream
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    MyOutputStream.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyOutputStream.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::io;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::rtl;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_misc {

  // Interface com.sun.star.io.XOutputStream

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyOutputStream::writeBytes(
    const Sequence< sal_Int8 >& aData )
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION writeBytes ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION writeBytes ----
  }

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyOutputStream::flush()
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION flush ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION flush ----
  }

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyOutputStream::closeOutput()
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION closeOutput ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION closeOutput ----
  }

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL MyOutputStream::acquire()
     throw ()
   {
     MyOutputStreamImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL MyOutputStream::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     MyOutputStreamImplHelper::release();
   }
#endif

  MyOutputStream::~MyOutputStream()
  {
    // ---- BEGIN EDITABLE SECTION ~MyOutputStream ----

    // ---- END EDITABLE SECTION ~MyOutputStream ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  MyOutputStream::MyOutputStream()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

