#ifndef _BED99718_9117_11DB_876C_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _BED99718_9117_11DB_876C_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Explicit XComponent implementaion
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    ZSXComponentService.hpp
 *
 * @author  Charles Halliday
 *
 * @date    21 Dec 2006
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "HelperTestBase.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

namespace svc_session_misc {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Explicit XComponent implementaion
 *
 * Also implements XWeak overriding helper class and
 * XMain overriding standard base class implementation.
 * Is singleton, so overrides helper class dispose() to
 * clear own reference to self.
 * Also explicit ZSessionLifecycle (no XInitialization)
 * 
 */
class ZSXComponentService : public ZSXComponentServiceBase
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    ZSXComponentService( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~ZSXComponentService();

    // Interface com.sun.star.lang.XComponent

    // Method of com.sun.star.lang.XComponent
    virtual void SAL_CALL
    dispose()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.lang.XComponent
    virtual void SAL_CALL
    addEventListener(
      const ::com::sun::star::uno::Reference< ::com::sun::star::lang::XEventListener >& xListener )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.lang.XComponent
    virtual void SAL_CALL
    removeEventListener(
      const ::com::sun::star::uno::Reference< ::com::sun::star::lang::XEventListener >& aListener )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface com.sun.star.uno.XWeak

    // Method of com.sun.star.uno.XWeak
    virtual ::com::sun::star::uno::Reference< ::com::sun::star::uno::XAdapter > SAL_CALL
    queryAdapter()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.ZIDService

    // Method of xoc.svc.ZIDService
    virtual ::sal_Int32 SAL_CALL
    getId(
      const ::rtl::OUString& idString )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.ZIDService
    virtual ::rtl::OUString SAL_CALL
    getString(
      ::sal_Int32 id )
      throw (
        ::xoc::exc::ZParameterException,
        ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.reflector.ZEcho

    // Method of xoc.svc.reflector.ZEcho
    virtual ::rtl::OUString SAL_CALL
    echo(
      const ::rtl::OUString& s )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.reflector.ZEcho
    virtual void SAL_CALL
    print(
      const ::rtl::OUString& s )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.session.ZSessionLifecycle

    // Method of xoc.svc.session.ZSessionLifecycle
    virtual void SAL_CALL
    sbsInitialize()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.session.ZSessionLifecycle
    virtual void SAL_CALL
    sbsShutdown()
      throw ( ::com::sun::star::uno::RuntimeException );

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    ZSXComponentService(const ZSXComponentService & r);

    // Assignment operator
    ZSXComponentService&operator=(const ZSXComponentService & r);

  // ---- END EDITABLE SECTION MEMBERS ----
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
