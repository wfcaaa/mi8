/** 
 ****************************************************************************
 *
 * Property value list
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    PropertyValueList.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "PropertyValueList.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::exc;
using namespace ::xoc::svc;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_unoobj_pckg;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_unoobj_pckg {

  // Interface xoc.svc.ZPropertyValueList

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addProperty(
    sal_Int32 propertyId,
    const Any& value )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addProperty ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addProperty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyBool(
    sal_Int32 propertyId,
    sal_Bool boolVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyBool ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyBool ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyBoolArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyBoolArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyBoolArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyFloat(
    sal_Int32 propertyId,
    float floatVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyFloat ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyFloat ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyFloatArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyFloatArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyFloatArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyDouble(
    sal_Int32 propertyId,
    double doubleVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyDouble ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyDouble ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyDoubleArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyDoubleArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyDoubleArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyInt(
    sal_Int32 propertyId,
    sal_Int32 intVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyInt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyInt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyIntArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyIntArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyIntArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyString(
    sal_Int32 propertyId,
    const OUString& stringVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyString ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyString ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyStringArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyStringArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyStringArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyHyper(
    sal_Int32 propertyId,
    sal_Int64 hyperVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyHyper ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyHyper ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyHyperArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyHyperArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyHyperArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyInterface(
    sal_Int32 propertyId,
    const Reference< XInterface >& interfaceVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyInterface ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyInterface ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::addPropertyInterfaceArray(
    sal_Int32 propertyId,
    sal_Int32 size )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addPropertyInterfaceArray ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION addPropertyInterfaceArray ----
  }

  // Method of xoc.svc.ZPropertyValueList
  Any SAL_CALL
  PropertyValueList::getValue(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValue ----
    Any returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValue ----
  }

  // Method of xoc.svc.ZPropertyValueList
  Any SAL_CALL
  PropertyValueList::getValueAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAt ----
    Any returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Bool SAL_CALL
  PropertyValueList::getValueAsBool(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsBool ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsBool ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Bool SAL_CALL
  PropertyValueList::getValueAsBoolAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsBoolAt ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsBoolAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  float SAL_CALL
  PropertyValueList::getValueAsFloat(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsFloat ----
    float returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsFloat ----
  }

  // Method of xoc.svc.ZPropertyValueList
  float SAL_CALL
  PropertyValueList::getValueAsFloatAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsFloatAt ----
    float returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsFloatAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  double SAL_CALL
  PropertyValueList::getValueAsDouble(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsDouble ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsDouble ----
  }

  // Method of xoc.svc.ZPropertyValueList
  double SAL_CALL
  PropertyValueList::getValueAsDoubleAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsDoubleAt ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsDoubleAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Int32 SAL_CALL
  PropertyValueList::getValueAsInt(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsInt ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsInt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Int32 SAL_CALL
  PropertyValueList::getValueAsIntAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsIntAt ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsIntAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  OUString SAL_CALL
  PropertyValueList::getValueAsString(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsString ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsString ----
  }

  // Method of xoc.svc.ZPropertyValueList
  OUString SAL_CALL
  PropertyValueList::getValueAsStringAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsStringAt ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsStringAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Int64 SAL_CALL
  PropertyValueList::getValueAsHyper(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsHyper ----
    sal_Int64 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsHyper ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Int64 SAL_CALL
  PropertyValueList::getValueAsHyperAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsHyperAt ----
    sal_Int64 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsHyperAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  Reference< XInterface > SAL_CALL
  PropertyValueList::getValueAsInterface(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsInterface ----
    Reference< XInterface > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsInterface ----
  }

  // Method of xoc.svc.ZPropertyValueList
  Reference< XInterface > SAL_CALL
  PropertyValueList::getValueAsInterfaceAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getValueAsInterfaceAt ----
    Reference< XInterface > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getValueAsInterfaceAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValue(
    sal_Int32 propertyId,
    const Any& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValue ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValue ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    const Any& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsBool(
    sal_Int32 propertyId,
    sal_Bool value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsBool ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsBool ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsBoolAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    sal_Bool value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsBoolAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsBoolAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsFloat(
    sal_Int32 propertyId,
    float value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsFloat ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsFloat ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsFloatAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    float value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsFloatAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsFloatAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsDouble(
    sal_Int32 propertyId,
    double value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsDouble ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsDouble ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsDoubleAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    double value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsDoubleAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsDoubleAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsInt(
    sal_Int32 propertyId,
    sal_Int32 value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsInt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsInt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsIntAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    sal_Int32 value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsIntAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsIntAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsString(
    sal_Int32 propertyId,
    const OUString& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsString ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsString ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsStringAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    const OUString& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsStringAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsStringAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsHyper(
    sal_Int32 propertyId,
    sal_Int64 value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsHyper ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsHyper ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsHyperAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    sal_Int64 value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsHyperAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsHyperAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsInterface(
    sal_Int32 propertyId,
    const Reference< XInterface >& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsInterface ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsInterface ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setValueAsInterfaceAt(
    sal_Int32 propertyId,
    sal_Int32 index,
    const Reference< XInterface >& value )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setValueAsInterfaceAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setValueAsInterfaceAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  Reference< ZPropertyValueList > SAL_CALL
  PropertyValueList::clone()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION clone ----
    Reference< ZPropertyValueList > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION clone ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::deleteProperty(
    sal_Int32 propertyId )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION deleteProperty ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION deleteProperty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::deleteAllProperties()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION deleteAllProperties ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION deleteAllProperties ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setEmpty(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setEmpty ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setEmpty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setEmptyAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setEmptyAt ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setEmptyAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Bool SAL_CALL
  PropertyValueList::getEmpty(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getEmpty ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getEmpty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Bool SAL_CALL
  PropertyValueList::getEmptyAt(
    sal_Int32 propertyId,
    sal_Int32 index )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getEmptyAt ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getEmptyAt ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Bool SAL_CALL
  PropertyValueList::hasProperty(
    sal_Int32 propertyId )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION hasProperty ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION hasProperty ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::getType(
    sal_Int32 propertyId,
    sal_Bool& isArray,
    Type& propertyType )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getType ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION getType ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Int32 SAL_CALL
  PropertyValueList::getArraySize(
    sal_Int32 propertyId )
    throw (
      ZNotAvailable_v2,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getArraySize ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getArraySize ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::setReadOnly(
    sal_Bool readOnlyValue )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setReadOnly ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setReadOnly ----
  }

  // Method of xoc.svc.ZPropertyValueList
  sal_Bool SAL_CALL
  PropertyValueList::getReadOnly()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getReadOnly ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getReadOnly ----
  }

  // Method of xoc.svc.ZPropertyValueList
  Sequence< sal_Int32 > SAL_CALL
  PropertyValueList::getPropertyIds()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getPropertyIds ----
    Sequence< sal_Int32 > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getPropertyIds ----
  }

  // Method of xoc.svc.ZPropertyValueList
  void SAL_CALL
  PropertyValueList::update(
    const Reference< ZPropertyValueList >& news )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION update ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION update ----
  }

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL PropertyValueList::acquire()
     throw ()
   {
     PropertyValueListImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL PropertyValueList::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     PropertyValueListImplHelper::release();
   }
#endif

  PropertyValueList::~PropertyValueList()
  {
    // ---- BEGIN EDITABLE SECTION ~PropertyValueList ----

    // ---- END EDITABLE SECTION ~PropertyValueList ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  PropertyValueList::PropertyValueList()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

