/** 
 ****************************************************************************
 *
 * Interface uses sequence of sequence 
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    SequenceOfSequenceExample.java
 *
 * @author  Charles Halliday
 *
 * @date    19 Jul 2007
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package foobar;

import foobar.ZSequenceOfSequence;
import com.sun.star.lib.uno.helper.WeakBase;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * Interface uses sequence of sequence
 */

class SequenceOfSequenceExample
  extends WeakBase
  implements ZSequenceOfSequence
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("foobar");

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  // Interface foobar.ZSequenceOfSequence

  // Method of foobar.ZSequenceOfSequence
  public byte[][] getSequenceOfSequence()
  {
    // ---- BEGIN EDITABLE SECTION getSequenceOfSequence ----
    byte[][] returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getSequenceOfSequence ----
  }

  // Method of foobar.ZSequenceOfSequence
  public void setSequenceOfSequence(String[][] arg)
  {
    // ---- BEGIN EDITABLE SECTION setSequenceOfSequence ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setSequenceOfSequence ----
  }

  // Method of foobar.ZSequenceOfSequence
  public void updateSequenceOfSequence(Object[][][] arg)
  {
    // ---- BEGIN EDITABLE SECTION updateSequenceOfSequence ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION updateSequenceOfSequence ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // Default constructor, may be replaced
  SequenceOfSequenceExample()
  {
  }

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // ! SequenceOfSequenceExample
