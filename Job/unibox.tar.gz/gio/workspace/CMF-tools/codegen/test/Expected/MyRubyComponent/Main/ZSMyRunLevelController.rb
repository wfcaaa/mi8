# 
#***************************************************************************
#
# Brief ZSRunLevelControllerStub service
#
# Copyright by Verigy, 2010
#
# @file    ZSMyRunLevelController.rb
#
# @author  Kirstin Weber
#
# @date    30 June 2010
#
#***************************************************************************
#

#
# This file is developer maintained.
# NOTE: You may edit this file between BEGIN EDITABLE SECTION and END
# EDITABLE SECTION. But don't edit it outside these comments, or your code
# _will_ be lost after a component regeneration.
#

# Use the following editable section for items required before the class
# definition
# ---- BEGIN EDITABLE SECTION HEADER ----

# ---- END EDITABLE SECTION HEADER ----

#
# A Ruby service implementing a single interface

class ZSMyRunLevelController

  # ruby constructor initialize method
  def initialize
    # ---- BEGIN EDITABLE SECTION initialize ----

    # ---- END EDITABLE SECTION initialize ----
  end

  # Interface xoc.svc.session.ZSessionLifecycle

  # Method of xoc.svc.session.ZSessionLifecycle
  def sbsInitialize()
    # ---- BEGIN EDITABLE SECTION sbsInitialize ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION sbsInitialize ----
  end

  # Method of xoc.svc.session.ZSessionLifecycle
  def sbsShutdown()
    # ---- BEGIN EDITABLE SECTION sbsShutdown ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION sbsShutdown ----
  end

  # Interface xoc.svc.session.ZRunLevelInformation

  # Method of xoc.svc.session.ZRunLevelInformation
  def getRunLevel()
    # ---- BEGIN EDITABLE SECTION getRunLevel ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getRunLevel ----
  end

  # Method of xoc.svc.session.ZRunLevelInformation
  def registerForRunLevelChange(client)
    # ---- BEGIN EDITABLE SECTION registerForRunLevelChange ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION registerForRunLevelChange ----
  end

  # Method of xoc.svc.session.ZRunLevelInformation
  def unregisterForRunLevelChange(client)
    # ---- BEGIN EDITABLE SECTION unregisterForRunLevelChange ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION unregisterForRunLevelChange ----
  end

  # Method of xoc.svc.session.ZRunLevelInformation
  def isRunLevelBelow(runLevel)
    # ---- BEGIN EDITABLE SECTION isRunLevelBelow ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION isRunLevelBelow ----
  end

  # Method of xoc.svc.session.ZRunLevelInformation
  def isRunLevelAbove(runLevel)
    # ---- BEGIN EDITABLE SECTION isRunLevelAbove ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION isRunLevelAbove ----
  end

  # Interface xoc.svc.session.ZRunLevelControl

  # Method of xoc.svc.session.ZRunLevelControl
  def enterRunLevel(desiredLevel)
    # ---- BEGIN EDITABLE SECTION enterRunLevel ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION enterRunLevel ----
  end

  # Use this section to define additional class members
  # ---- BEGIN EDITABLE SECTION MEMBERS ----

  # ---- END EDITABLE SECTION MEMBERS ----

end  # ! ZSMyRunLevelController

# Use the following editable section for items required after the class
# definition
# ---- BEGIN EDITABLE SECTION FOOTER ----

# ---- END EDITABLE SECTION FOOTER ----
