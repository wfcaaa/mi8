/** 
 ****************************************************************************
 *
 * WeakObject explicitly overriding helper XComponent
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    OXComponentObject.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Apr 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "OXComponentObject.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::container;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::svc_session_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace svc_session_misc {

  // Interface com.sun.star.container.XEnumeration

  // Method of com.sun.star.container.XEnumeration
  sal_Bool SAL_CALL
  OXComponentObject::hasMoreElements()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION hasMoreElements ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION hasMoreElements ----
  }

  // Method of com.sun.star.container.XEnumeration
  Any SAL_CALL
  OXComponentObject::nextElement()
    throw (
      NoSuchElementException,
      WrappedTargetException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION nextElement ----
    Any returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION nextElement ----
  }

  // Interface com.sun.star.lang.XComponent

  // Method of com.sun.star.lang.XComponent
  void SAL_CALL
  OXComponentObject::dispose()
    throw ( RuntimeException )
  {
#ifdef DEBUG_REFCOUNT
    static int disposeRecurseCount = 0;
    XOC_DEBUG(__FUNCTION__
              << " pid=" << getpid()
              << " instance=0x" << std::hex << (void *)this << std::dec
              << " disposeRecurseCount=" << disposeRecurseCount
              << " m_refCount->" << m_refCount << " on entry");
    ++disposeRecurseCount;
#endif
    // ---- BEGIN EDITABLE SECTION dispose ----
    // WARNING: removing the base class method call may break the component
    OXComponentObjectImplHelper::dispose();
    // ---- END EDITABLE SECTION dispose ----
#ifdef DEBUG_REFCOUNT
    --disposeRecurseCount;
#endif
  }

  // Method of com.sun.star.lang.XComponent
  void SAL_CALL
  OXComponentObject::addEventListener(
    const Reference< XEventListener >& xListener )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addEventListener ----
    // WARNING: removing the base class method call may break the component
    OXComponentObjectImplHelper::addEventListener(xListener);
    // ---- END EDITABLE SECTION addEventListener ----
  }

  // Method of com.sun.star.lang.XComponent
  void SAL_CALL
  OXComponentObject::removeEventListener(
    const Reference< XEventListener >& aListener )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION removeEventListener ----
    // WARNING: removing the base class method call may break the component
    OXComponentObjectImplHelper::removeEventListener(aListener);
    // ---- END EDITABLE SECTION removeEventListener ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  OXComponentObject::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      mInitialized = sal_True;
      // @todo TODO_AUTO_GENERATED
    }
    // ---- END EDITABLE SECTION initialize ----
  }

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL OXComponentObject::acquire()
     throw ()
   {
     OXComponentObjectImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL OXComponentObject::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     OXComponentObjectImplHelper::release();
   }
#endif

  OXComponentObject::~OXComponentObject()
  {
    // ---- BEGIN EDITABLE SECTION ~OXComponentObject ----

    // ---- END EDITABLE SECTION ~OXComponentObject ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  OXComponentObject::OXComponentObject()
    : OXComponentObjectImplHelper(m_aBaseMutex)
    , mInitialized(sal_False)
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

