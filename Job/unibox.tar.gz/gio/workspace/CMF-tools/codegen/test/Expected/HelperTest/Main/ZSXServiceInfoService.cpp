/** 
 ****************************************************************************
 *
 * Explicit XServiceInfo overriding standard implementation
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    ZSXServiceInfoService.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Apr 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "ZSXServiceInfoService.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::svc;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::svc_session_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace svc_session_misc {

  ZSXServiceInfoService::ZSXServiceInfoService(
    Reference< XComponentContext > const & xComponentContext)
    : ZSXServiceInfoServiceBase::ZSXServiceInfoServiceBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
    , mInitialized(sal_False)
  {
    // ---- BEGIN EDITABLE SECTION ZSXServiceInfoService ----

    // ---- END EDITABLE SECTION ZSXServiceInfoService ----
  }

  ZSXServiceInfoService::~ZSXServiceInfoService()
  {
    // ---- BEGIN EDITABLE SECTION ~ZSXServiceInfoService ----

    // ---- END EDITABLE SECTION ~ZSXServiceInfoService ----
  }

  // Interface com.sun.star.lang.XServiceInfo

  // Method of com.sun.star.lang.XServiceInfo
  OUString SAL_CALL
  ZSXServiceInfoService::getImplementationName()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getImplementationName ----
    OUString returnValue;
    // WARNING: removing the base class method call may break the component
    returnValue =
      ZSXServiceInfoServiceBase::getImplementationName();
    return returnValue;
    // ---- END EDITABLE SECTION getImplementationName ----
  }

  // Method of com.sun.star.lang.XServiceInfo
  sal_Bool SAL_CALL
  ZSXServiceInfoService::supportsService(
    const OUString& ServiceName )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION supportsService ----
    sal_Bool returnValue = sal_False;
    // WARNING: removing the base class method call may break the component
    returnValue =
      ZSXServiceInfoServiceBase::supportsService(ServiceName);
    return returnValue;
    // ---- END EDITABLE SECTION supportsService ----
  }

  // Method of com.sun.star.lang.XServiceInfo
  Sequence< OUString > SAL_CALL
  ZSXServiceInfoService::getSupportedServiceNames()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getSupportedServiceNames ----
    Sequence< OUString > returnValue;
    // WARNING: removing the base class method call may break the component
    returnValue =
      ZSXServiceInfoServiceBase::getSupportedServiceNames();
    return returnValue;
    // ---- END EDITABLE SECTION getSupportedServiceNames ----
  }

  // Interface xoc.svc.ZValue

  // Method of xoc.svc.ZValue
  sal_Int32 SAL_CALL
  ZSXServiceInfoService::getType()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getType ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getType ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  ZSXServiceInfoService::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      mInitialized = sal_True;
      // @todo TODO_AUTO_GENERATED
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

