/** 
 ****************************************************************************
 *
 * An Input and Output stream
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    MyInputOutputStream.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyInputOutputStream.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::io;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::test::performance;
using namespace ::com::sun::star::uno;
using namespace ::rtl;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_misc {

  // Interface com.sun.star.io.XOutputStream

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyInputOutputStream::writeBytes(
    const Sequence< sal_Int8 >& aData )
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION writeBytes ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION writeBytes ----
  }

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyInputOutputStream::flush()
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION flush ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION flush ----
  }

  // Method of com.sun.star.io.XOutputStream
  void SAL_CALL
  MyInputOutputStream::closeOutput()
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION closeOutput ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION closeOutput ----
  }

  // Interface com.sun.star.io.XInputStream

  // Method of com.sun.star.io.XInputStream
  sal_Int32 SAL_CALL
  MyInputOutputStream::readBytes(
    Sequence< sal_Int8 >& aData,
    sal_Int32 nBytesToRead )
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION readBytes ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION readBytes ----
  }

  // Method of com.sun.star.io.XInputStream
  sal_Int32 SAL_CALL
  MyInputOutputStream::readSomeBytes(
    Sequence< sal_Int8 >& aData,
    sal_Int32 nMaxBytesToRead )
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION readSomeBytes ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION readSomeBytes ----
  }

  // Method of com.sun.star.io.XInputStream
  void SAL_CALL
  MyInputOutputStream::skipBytes(
    sal_Int32 nBytesToSkip )
    throw (
      NotConnectedException,
      BufferSizeExceededException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION skipBytes ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION skipBytes ----
  }

  // Method of com.sun.star.io.XInputStream
  sal_Int32 SAL_CALL
  MyInputOutputStream::available()
    throw (
      NotConnectedException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION available ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION available ----
  }

  // Method of com.sun.star.io.XInputStream
  void SAL_CALL
  MyInputOutputStream::closeInput()
    throw (
      NotConnectedException,
      IOException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION closeInput ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION closeInput ----
  }

  // Interface com.sun.star.test.performance.XPerformanceTest

  // Get method for readwrite attribute Long_attr of com.sun.star.test.performance.XPerformanceTest
  sal_Int32 SAL_CALL
  MyInputOutputStream::getLong_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getLong_attr ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getLong_attr ----
  }

  // Set method for readwrite attribute Long_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setLong_attr(
    sal_Int32 _long_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setLong_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setLong_attr ----
  }

  // Get method for readwrite attribute Hyper_attr of com.sun.star.test.performance.XPerformanceTest
  sal_Int64 SAL_CALL
  MyInputOutputStream::getHyper_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getHyper_attr ----
    sal_Int64 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getHyper_attr ----
  }

  // Set method for readwrite attribute Hyper_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setHyper_attr(
    sal_Int64 _hyper_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setHyper_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setHyper_attr ----
  }

  // Get method for readwrite attribute Float_attr of com.sun.star.test.performance.XPerformanceTest
  float SAL_CALL
  MyInputOutputStream::getFloat_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getFloat_attr ----
    float returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getFloat_attr ----
  }

  // Set method for readwrite attribute Float_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setFloat_attr(
    float _float_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setFloat_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setFloat_attr ----
  }

  // Get method for readwrite attribute Double_attr of com.sun.star.test.performance.XPerformanceTest
  double SAL_CALL
  MyInputOutputStream::getDouble_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getDouble_attr ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getDouble_attr ----
  }

  // Set method for readwrite attribute Double_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setDouble_attr(
    double _double_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setDouble_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setDouble_attr ----
  }

  // Get method for readwrite attribute String_attr of com.sun.star.test.performance.XPerformanceTest
  OUString SAL_CALL
  MyInputOutputStream::getString_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getString_attr ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getString_attr ----
  }

  // Set method for readwrite attribute String_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setString_attr(
    const OUString& _string_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setString_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setString_attr ----
  }

  // Get method for readwrite attribute Interface_attr of com.sun.star.test.performance.XPerformanceTest
  Reference< XInterface > SAL_CALL
  MyInputOutputStream::getInterface_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getInterface_attr ----
    Reference< XInterface > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getInterface_attr ----
  }

  // Set method for readwrite attribute Interface_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setInterface_attr(
    const Reference< XInterface >& _interface_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setInterface_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setInterface_attr ----
  }

  // Get method for readwrite attribute Any_attr of com.sun.star.test.performance.XPerformanceTest
  Any SAL_CALL
  MyInputOutputStream::getAny_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getAny_attr ----
    Any returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getAny_attr ----
  }

  // Set method for readwrite attribute Any_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setAny_attr(
    const Any& _any_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setAny_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setAny_attr ----
  }

  // Get method for readwrite attribute Sequence_attr of com.sun.star.test.performance.XPerformanceTest
  Sequence< Reference< XInterface > > SAL_CALL
  MyInputOutputStream::getSequence_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getSequence_attr ----
    Sequence< Reference< XInterface > > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getSequence_attr ----
  }

  // Set method for readwrite attribute Sequence_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setSequence_attr(
    const Sequence< Reference< XInterface > >& _sequence_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setSequence_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setSequence_attr ----
  }

  // Get method for readwrite attribute Struct_attr of com.sun.star.test.performance.XPerformanceTest
  ComplexTypes SAL_CALL
  MyInputOutputStream::getStruct_attr()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getStruct_attr ----
    ComplexTypes returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getStruct_attr ----
  }

  // Set method for readwrite attribute Struct_attr of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setStruct_attr(
    const ComplexTypes& _struct_attr )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setStruct_attr ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setStruct_attr ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::async()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION async ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION async ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::sync()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION sync ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION sync ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  ComplexTypes SAL_CALL
  MyInputOutputStream::complex_in(
    const ComplexTypes& aVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION complex_in ----
    ComplexTypes returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION complex_in ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  ComplexTypes SAL_CALL
  MyInputOutputStream::complex_inout(
    ComplexTypes& aVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION complex_inout ----
    ComplexTypes returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION complex_inout ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::complex_oneway(
    const ComplexTypes& aVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION complex_oneway ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION complex_oneway ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::complex_noreturn(
    const ComplexTypes& aVal )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION complex_noreturn ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION complex_noreturn ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  Reference< XPerformanceTest > SAL_CALL
  MyInputOutputStream::createObject()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION createObject ----
    Reference< XPerformanceTest > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION createObject ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  sal_Int32 SAL_CALL
  MyInputOutputStream::getLong()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getLong ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getLong ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setLong(
    sal_Int32 n )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setLong ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setLong ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  sal_Int64 SAL_CALL
  MyInputOutputStream::getHyper()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getHyper ----
    sal_Int64 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getHyper ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setHyper(
    sal_Int64 n )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setHyper ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setHyper ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  float SAL_CALL
  MyInputOutputStream::getFloat()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getFloat ----
    float returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getFloat ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setFloat(
    float f )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setFloat ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setFloat ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  double SAL_CALL
  MyInputOutputStream::getDouble()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getDouble ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getDouble ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setDouble(
    double f )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setDouble ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setDouble ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  OUString SAL_CALL
  MyInputOutputStream::getString()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getString ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getString ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setString(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setString ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setString ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  Reference< XInterface > SAL_CALL
  MyInputOutputStream::getInterface()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getInterface ----
    Reference< XInterface > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getInterface ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setInterface(
    const Reference< XInterface >& x )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setInterface ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setInterface ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  Any SAL_CALL
  MyInputOutputStream::getAny()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getAny ----
    Any returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getAny ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setAny(
    const Any& a )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setAny ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setAny ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  Sequence< Reference< XInterface > > SAL_CALL
  MyInputOutputStream::getSequence()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getSequence ----
    Sequence< Reference< XInterface > > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getSequence ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setSequence(
    const Sequence< Reference< XInterface > >& seq )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setSequence ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setSequence ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  ComplexTypes SAL_CALL
  MyInputOutputStream::getStruct()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getStruct ----
    ComplexTypes returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getStruct ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::setStruct(
    const ComplexTypes& c )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setStruct ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setStruct ----
  }

  // Method of com.sun.star.test.performance.XPerformanceTest
  void SAL_CALL
  MyInputOutputStream::raiseRuntimeException()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION raiseRuntimeException ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION raiseRuntimeException ----
  }

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL MyInputOutputStream::acquire()
     throw ()
   {
     MyInputOutputStreamImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL MyInputOutputStream::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     MyInputOutputStreamImplHelper::release();
   }
#endif

  MyInputOutputStream::~MyInputOutputStream()
  {
    // ---- BEGIN EDITABLE SECTION ~MyInputOutputStream ----

    // ---- END EDITABLE SECTION ~MyInputOutputStream ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  MyInputOutputStream::MyInputOutputStream()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

