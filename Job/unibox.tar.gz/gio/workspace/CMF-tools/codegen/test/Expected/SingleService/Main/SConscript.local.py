# Builds SingleService C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['SingleService']
}
# **** CODE GENERATOR CHECKSUM 44e44bbdb432b3dbf74a898ae12ec956
