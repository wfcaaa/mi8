/** 
 ****************************************************************************
 *
 * Interface uses sequence of sequence 
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    SequenceOfSequenceExample.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Apr 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "SequenceOfSequenceExample.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::uno;
using namespace ::foobar;
using namespace ::rtl;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::foobar;

}

// ---- END EDITABLE SECTION UTILS ----

namespace foobar {

  // Interface foobar.ZSequenceOfSequence

  // Method of foobar.ZSequenceOfSequence
  Sequence< Sequence< sal_Int8 > > SAL_CALL
  SequenceOfSequenceExample::getSequenceOfSequence()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getSequenceOfSequence ----
    Sequence< Sequence< sal_Int8 > > returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getSequenceOfSequence ----
  }

  // Method of foobar.ZSequenceOfSequence
  void SAL_CALL
  SequenceOfSequenceExample::setSequenceOfSequence(
    const Sequence< Sequence< OUString > >& arg )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setSequenceOfSequence ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setSequenceOfSequence ----
  }

  // Method of foobar.ZSequenceOfSequence
  void SAL_CALL
  SequenceOfSequenceExample::updateSequenceOfSequence(
    Sequence< Sequence< Reference< XInterface > > >& arg )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION updateSequenceOfSequence ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION updateSequenceOfSequence ----
  }

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL SequenceOfSequenceExample::acquire()
     throw ()
   {
     SequenceOfSequenceExampleImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL SequenceOfSequenceExample::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     SequenceOfSequenceExampleImplHelper::release();
   }
#endif

  SequenceOfSequenceExample::~SequenceOfSequenceExample()
  {
    // ---- BEGIN EDITABLE SECTION ~SequenceOfSequenceExample ----

    // ---- END EDITABLE SECTION ~SequenceOfSequenceExample ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  SequenceOfSequenceExample::SequenceOfSequenceExample()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

