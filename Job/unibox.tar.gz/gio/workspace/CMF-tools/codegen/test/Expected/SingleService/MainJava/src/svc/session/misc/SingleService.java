/** 
 ****************************************************************************
 *
 * No additional interfaces
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    SingleService.java
 *
 * @author  Charles Halliday
 *
 * @date    22 Aug 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package svc.session.misc;

import com.sun.star.lang.XInitialization;
import com.sun.star.uno.Exception;
import com.sun.star.uno.XComponentContext;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * No additional interfaces
 */

public class SingleService
  extends svc.session.misc.SingleServiceBase
  implements XInitialization
  // ---- BEGIN EDITABLE SECTION IMPLEMENTS ----
  // ---- END EDITABLE SECTION IMPLEMENTS ----
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("svc_session_misc");

  private boolean mInitialized = false;

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  public SingleService(XComponentContext xComponentContext)
  {
    super(xComponentContext);
    // ---- BEGIN EDITABLE SECTION SingleService ----

    // ---- END EDITABLE SECTION SingleService ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  public void initialize(Object[] aArguments)
    throws Exception
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    synchronized (this) {
      if ( ! mInitialized ) {
        mInitialized = true;
        // @todo TODO_AUTO_GENERATED
      }
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // !  SingleService
