/** 
 ****************************************************************************
 *
 * Additional (arbitrary) service used by unit tester
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    TesterService.cpp
 *
 * @author  Charles Halliday
 *
 * @date    15 Dec 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "TesterService.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::io;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::exc;
using namespace ::xoc::svc::xml;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_misc {

  TesterService::TesterService(
    Reference< XComponentContext > const & xComponentContext)
    : TesterServiceBase::TesterServiceBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
    , mInitialized(sal_False)
  {
    // ---- BEGIN EDITABLE SECTION TesterService ----

    // ---- END EDITABLE SECTION TesterService ----
  }

  TesterService::~TesterService()
  {
    // ---- BEGIN EDITABLE SECTION ~TesterService ----

    // ---- END EDITABLE SECTION ~TesterService ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  TesterService::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      mInitialized = sal_True;
      // @todo TODO_AUTO_GENERATED
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Interface xoc.svc.xml.ZXMLReader

  // Method of xoc.svc.xml.ZXMLReader
  void SAL_CALL
  TesterService::parseFile(
    const OUString& filePath )
    throw (
      ZRecoverable,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION parseFile ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION parseFile ----
  }

  // Method of xoc.svc.xml.ZXMLReader
  void SAL_CALL
  TesterService::parseString(
    const OUString& xmlString )
    throw (
      ZRecoverable,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION parseString ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION parseString ----
  }

  // Method of xoc.svc.xml.ZXMLReader
  void SAL_CALL
  TesterService::parseStream(
    const Reference< XInputStream >& inputStream )
    throw (
      ZRecoverable,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION parseStream ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION parseStream ----
  }

  // Method of xoc.svc.xml.ZXMLReader
  void SAL_CALL
  TesterService::setEntityResolver(
    const Reference< ZSAXEntityResolver >& resolver )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setEntityResolver ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setEntityResolver ----
  }

  // Method of xoc.svc.xml.ZXMLReader
  void SAL_CALL
  TesterService::setContentHandler(
    const Reference< ZSAXContentHandler >& handler )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setContentHandler ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setContentHandler ----
  }

  // Method of xoc.svc.xml.ZXMLReader
  void SAL_CALL
  TesterService::setErrorHandler(
    const Reference< ZSAXErrorHandler >& handler )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setErrorHandler ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setErrorHandler ----
  }

  // Method of xoc.svc.xml.ZXMLReader
  void SAL_CALL
  TesterService::setExitOnFirstFatalError(
    sal_Bool exitOnFirstFatalError )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION setExitOnFirstFatalError ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setExitOnFirstFatalError ----
  }

  // Method of xoc.svc.xml.ZXMLReader
  sal_Bool SAL_CALL
  TesterService::getExitOnFirstFatalError()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getExitOnFirstFatalError ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getExitOnFirstFatalError ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

