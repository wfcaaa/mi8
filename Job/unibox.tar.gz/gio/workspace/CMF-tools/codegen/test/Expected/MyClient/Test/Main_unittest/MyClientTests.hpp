/** 
 ****************************************************************************
 *
 * Unit Tests for component MyClient.
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    MyClientTests.hpp
 *
 * @author  Charles Halliday
 *
 * @date    15 Dec 2010
 *
 ****************************************************************************
 */

/*
 * This file is developer maintained.
 * The initial version file is generated automatically by a set of style
 * sheets, but requires manual changes for implementation specifics.
 * Warning, regenerating the file will require manual merging.
 */
#include <xoc/cot/ZDebug.hpp>
#include <xoc/svc/logstreamfactory/ZLogStreamFactory.hpp>

#include <com/sun/star/io/XOutputStream.hpp>

namespace xoc_svc_misc {
namespace MyClientTests {

using namespace ::com::sun::star::uno ;
using namespace ::com::sun::star::lang ;
using namespace ::xoc;
using namespace ::xoc::cot;

  //------------------------ Tests ------------------------------------
  /**
    * Default test case to ensure that a component under test loads and
    * service under test may be accessed.
    * Acquires the XInterface interface and checks the reference is non-zero
    *
    * @param serviceName  name of service being tested
    * @param serviceRef   UNO reference of service being tested
    *
    * @return TestResult  results of test
    */ 
  ZSMyClientUnitTester::TestResult 
  checkServiceLoads(const sal_Char *serviceName,
                    const Reference<XInterface>& serviceRef)
  {
    ZSMyClientUnitTester::TestResult retVal;

    retVal = ZSMyClientUnitTester::PASSED;

    XOC_UTF_ASSERT(serviceRef.is());

    return retVal;
  }

  // Test Table
  const ZSMyClientUnitTester::TestEntry testTable[] = 
    {
      {&checkServiceLoads, 0,
       ZSMyClientUnitTester::OFFLINE, 
       ZSMyClientUnitTester::ALL_LEVELS,
       "( 0)checkServiceLoads"},
      // @todo TODO_AUTO_GENERATED Add one entry for each test case function call
      {NULL,-1,0,0,NULL}
    };

}
} // namespace close

// **** CODE GENERATOR CHECKSUM 05a571784aaf4cccefca26de32b58ee3
