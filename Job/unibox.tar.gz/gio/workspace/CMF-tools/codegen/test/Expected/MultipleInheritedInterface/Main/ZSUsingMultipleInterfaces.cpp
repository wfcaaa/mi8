/** 
 ****************************************************************************
 *
 * 
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    ZSUsingMultipleInterfaces.cpp
 *
 * @author  Kirstin Weberr
 *
 * @date    16 Mar 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "ZSUsingMultipleInterfaces.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

#include <xoc/svc/session/SessionServiceManager.hpp>
// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::foobar;
using namespace ::xoc::hw::cor::description;
using namespace ::xoc::hw::cor::pogocabling;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::foobar_MultipleInheritedInterface;

}

// ---- END EDITABLE SECTION UTILS ----

namespace foobar_MultipleInheritedInterface {

  ZSUsingMultipleInterfaces::ZSUsingMultipleInterfaces(
    Reference< XComponentContext > const & xComponentContext)
    : ZSUsingMultipleInterfacesBase::ZSUsingMultipleInterfacesBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
    , mInitialized(sal_False)
  {
    // ---- BEGIN EDITABLE SECTION ZSUsingMultipleInterfaces ----

    // ---- END EDITABLE SECTION ZSUsingMultipleInterfaces ----
  }

  ZSUsingMultipleInterfaces::~ZSUsingMultipleInterfaces()
  {
    // ---- BEGIN EDITABLE SECTION ~ZSUsingMultipleInterfaces ----

    // ---- END EDITABLE SECTION ~ZSUsingMultipleInterfaces ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  ZSUsingMultipleInterfaces::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      // @todo TODO_AUTO_GENERATED remove if lifecycle is controlled by another singleton
      ::xoc::svc::session::SessionServiceManager::instance().
          registerForShutdown(this);
      mInitialized = sal_True;
      // @todo TODO_AUTO_GENERATED
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Interface foobar.ZTestChild

  // Method of foobar.ZTestChild
  void SAL_CALL
  ZSUsingMultipleInterfaces::function3(
    const Reference< ZFoo >& foo )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION function3 ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION function3 ----
  }

  // Method of foobar.ZTestChild
  void SAL_CALL
  ZSUsingMultipleInterfaces::function1(
    const Reference< ZBar >& bar )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION function1 ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION function1 ----
  }

  // Method of foobar.ZTestChild
  void SAL_CALL
  ZSUsingMultipleInterfaces::function4(
    const Reference< ZBar >& bar )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION function4 ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION function4 ----
  }

  // Method of foobar.ZTestChild
  void SAL_CALL
  ZSUsingMultipleInterfaces::function2(
    const ZPogoCabling& pogoCabling,
    const ZHwSpecifierType& hwSpecifierType )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION function2 ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION function2 ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

