/** 
 ****************************************************************************
 *
 * Brief MyService1
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    MyService1Impl.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyService1Impl.hpp"
#include <xoc/svc/misc/LocationResolver.hpp>
#include <SystemLogger.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::services_ruby_UnoRuby;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_misc;

  const rtl::OUString serviceName =
  toOu("xoc.svc.misc.MyService1");

  const rtl::OUString configDataPath =
  toOu("ccd:")+ serviceName;
  const rtl::OUString rubyServiceImplementationPathTail =
  toOu("/MyService1Impl.rb");

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_misc {

  MyService1Impl::MyService1Impl(
    Reference< XComponentContext > const & xComponentContext)
    : MyService1ImplBase::MyService1ImplBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
  {
    // ---- BEGIN EDITABLE SECTION MyService1Impl ----

    initForServices();

    rtl::OUString absConfigDataPath =
      ::xoc::svc::misc::LocationResolver::instance()->
      getAbsPath(configDataPath);

    rtl::OUString initScript =
      absConfigDataPath + rubyServiceImplementationPathTail;

    callRubyScript(initScript);

    rubyClass = rubyEval(toOu("MyService1Impl.new"));

#ifdef ENABLE_RUBY_UNO_XINITIALIZATION_FOR_MYSERVICE1IMPL
    pRubyStubXInitialization =
      new C_com_sun_star_lang_XInitializationStub(rubyClass);
#endif

    // ---- END EDITABLE SECTION MyService1Impl ----
  }

  MyService1Impl::~MyService1Impl()
  {
    // ---- BEGIN EDITABLE SECTION ~MyService1Impl ----

    // ---- END EDITABLE SECTION ~MyService1Impl ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  MyService1Impl::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      mInitialized = sal_True;
#ifdef ENABLE_RUBY_UNO_XINITIALIZATION_FOR_MYSERVICE1IMPL
      pRubyStubXInitialization->unoInitialize(aArguments);
#endif
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

