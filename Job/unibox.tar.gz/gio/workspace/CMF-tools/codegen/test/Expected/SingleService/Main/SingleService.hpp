#ifndef _B48BB54A_6843_11DB_8446_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _B48BB54A_6843_11DB_8446_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * No additional interfaces
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    SingleService.hpp
 *
 * @author  Charles Halliday
 *
 * @date    30 Oct 2006
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "SingleServiceBase.hpp"
#include <xoc/threads/Synchronization.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

namespace svc_session_misc {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * No additional interfaces
 */
class SingleService : public SingleServiceBase
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    SingleService( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~SingleService();

    // Interface com.sun.star.lang.XInitialization

    // Method of com.sun.star.lang.XInitialization
    virtual void SAL_CALL
    initialize(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Any >& aArguments )
      throw (
        ::com::sun::star::uno::Exception,
        ::com::sun::star::uno::RuntimeException );

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    SingleService(const SingleService & r);

    // Assignment operator
    SingleService&operator=(const SingleService & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For com.sun.star.lang.XInitialization
    ::xoc::threads::Mutex mInitializedMutex;
    ::sal_Bool mInitialized;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
