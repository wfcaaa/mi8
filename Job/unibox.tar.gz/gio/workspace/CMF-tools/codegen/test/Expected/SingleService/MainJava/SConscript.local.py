# Builds SingleService Java Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['java_component_package'] ,
'NAME' : ['SingleService']
}
# **** CODE GENERATOR CHECKSUM c048bc4cd00c690d29847753c1b4a8f3
