# 
#***************************************************************************
#
# An Input and Output stream
#
# Copyright by Verigy, 2006
#
# @file    MyInputOutputStream.rb
#
# @author  Charles Halliday
#
# @date    01 Aug 2005
#
#***************************************************************************
#

#
# This file is developer maintained.
# NOTE: You may edit this file between BEGIN EDITABLE SECTION and END
# EDITABLE SECTION. But don't edit it outside these comments, or your code
# _will_ be lost after a component regeneration.
#

# Use the following editable section for items required before the class
# definition
# ---- BEGIN EDITABLE SECTION HEADER ----

# ---- END EDITABLE SECTION HEADER ----

#
# Checks can have two weakObjects implementing same interface.
# Checks IDL interfaces out and inout parameters.
# 

class MyInputOutputStream < com.sun.star.io.XOutputStream

  # Interface com.sun.star.io.XOutputStream

  # Method of com.sun.star.io.XOutputStream
  def writeBytes(aData)
    # ---- BEGIN EDITABLE SECTION writeBytes ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION writeBytes ----
  end

  # Method of com.sun.star.io.XOutputStream
  def flush()
    # ---- BEGIN EDITABLE SECTION flush ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION flush ----
  end

  # Method of com.sun.star.io.XOutputStream
  def closeOutput()
    # ---- BEGIN EDITABLE SECTION closeOutput ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION closeOutput ----
  end

  # Interface com.sun.star.io.XInputStream

  # Method of com.sun.star.io.XInputStream
  def readBytes(aData, nBytesToRead)
    # ---- BEGIN EDITABLE SECTION readBytes ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION readBytes ----
  end

  # Method of com.sun.star.io.XInputStream
  def readSomeBytes(aData, nMaxBytesToRead)
    # ---- BEGIN EDITABLE SECTION readSomeBytes ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION readSomeBytes ----
  end

  # Method of com.sun.star.io.XInputStream
  def skipBytes(nBytesToSkip)
    # ---- BEGIN EDITABLE SECTION skipBytes ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION skipBytes ----
  end

  # Method of com.sun.star.io.XInputStream
  def available()
    # ---- BEGIN EDITABLE SECTION available ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION available ----
  end

  # Method of com.sun.star.io.XInputStream
  def closeInput()
    # ---- BEGIN EDITABLE SECTION closeInput ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION closeInput ----
  end

  # Interface com.sun.star.test.performance.XPerformanceTest

  # Get method for readwrite attribute Long_attr of com.sun.star.test.performance.XPerformanceTest
  def getLong_attr()
    # ---- BEGIN EDITABLE SECTION getLong_attr ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getLong_attr ----
  end

  # Set method for readwrite attribute Long_attr of com.sun.star.test.performance.XPerformanceTest
  def setLong_attr(_long_attr)
    # ---- BEGIN EDITABLE SECTION setLong_attr ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setLong_attr ----
  end

  # Get method for readwrite attribute Hyper_attr of com.sun.star.test.performance.XPerformanceTest
  def getHyper_attr()
    # ---- BEGIN EDITABLE SECTION getHyper_attr ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getHyper_attr ----
  end

  # Set method for readwrite attribute Hyper_attr of com.sun.star.test.performance.XPerformanceTest
  def setHyper_attr(_hyper_attr)
    # ---- BEGIN EDITABLE SECTION setHyper_attr ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setHyper_attr ----
  end

  # Get method for readwrite attribute Float_attr of com.sun.star.test.performance.XPerformanceTest
  def getFloat_attr()
    # ---- BEGIN EDITABLE SECTION getFloat_attr ----
    returnValue = 0.0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getFloat_attr ----
  end

  # Set method for readwrite attribute Float_attr of com.sun.star.test.performance.XPerformanceTest
  def setFloat_attr(_float_attr)
    # ---- BEGIN EDITABLE SECTION setFloat_attr ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setFloat_attr ----
  end

  # Get method for readwrite attribute Double_attr of com.sun.star.test.performance.XPerformanceTest
  def getDouble_attr()
    # ---- BEGIN EDITABLE SECTION getDouble_attr ----
    returnValue = 0.0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getDouble_attr ----
  end

  # Set method for readwrite attribute Double_attr of com.sun.star.test.performance.XPerformanceTest
  def setDouble_attr(_double_attr)
    # ---- BEGIN EDITABLE SECTION setDouble_attr ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setDouble_attr ----
  end

  # Get method for readwrite attribute String_attr of com.sun.star.test.performance.XPerformanceTest
  def getString_attr()
    # ---- BEGIN EDITABLE SECTION getString_attr ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getString_attr ----
  end

  # Set method for readwrite attribute String_attr of com.sun.star.test.performance.XPerformanceTest
  def setString_attr(_string_attr)
    # ---- BEGIN EDITABLE SECTION setString_attr ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setString_attr ----
  end

  # Get method for readwrite attribute Interface_attr of com.sun.star.test.performance.XPerformanceTest
  def getInterface_attr()
    # ---- BEGIN EDITABLE SECTION getInterface_attr ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getInterface_attr ----
  end

  # Set method for readwrite attribute Interface_attr of com.sun.star.test.performance.XPerformanceTest
  def setInterface_attr(_interface_attr)
    # ---- BEGIN EDITABLE SECTION setInterface_attr ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setInterface_attr ----
  end

  # Get method for readwrite attribute Any_attr of com.sun.star.test.performance.XPerformanceTest
  def getAny_attr()
    # ---- BEGIN EDITABLE SECTION getAny_attr ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getAny_attr ----
  end

  # Set method for readwrite attribute Any_attr of com.sun.star.test.performance.XPerformanceTest
  def setAny_attr(_any_attr)
    # ---- BEGIN EDITABLE SECTION setAny_attr ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setAny_attr ----
  end

  # Get method for readwrite attribute Sequence_attr of com.sun.star.test.performance.XPerformanceTest
  def getSequence_attr()
    # ---- BEGIN EDITABLE SECTION getSequence_attr ----
    returnValue = []
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getSequence_attr ----
  end

  # Set method for readwrite attribute Sequence_attr of com.sun.star.test.performance.XPerformanceTest
  def setSequence_attr(_sequence_attr)
    # ---- BEGIN EDITABLE SECTION setSequence_attr ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setSequence_attr ----
  end

  # Get method for readwrite attribute Struct_attr of com.sun.star.test.performance.XPerformanceTest
  def getStruct_attr()
    # ---- BEGIN EDITABLE SECTION getStruct_attr ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getStruct_attr ----
  end

  # Set method for readwrite attribute Struct_attr of com.sun.star.test.performance.XPerformanceTest
  def setStruct_attr(_struct_attr)
    # ---- BEGIN EDITABLE SECTION setStruct_attr ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setStruct_attr ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def async()
    # ---- BEGIN EDITABLE SECTION async ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION async ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def sync()
    # ---- BEGIN EDITABLE SECTION sync ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION sync ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def complex_in(aVal)
    # ---- BEGIN EDITABLE SECTION complex_in ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION complex_in ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def complex_inout(aVal)
    # ---- BEGIN EDITABLE SECTION complex_inout ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION complex_inout ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def complex_oneway(aVal)
    # ---- BEGIN EDITABLE SECTION complex_oneway ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION complex_oneway ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def complex_noreturn(aVal)
    # ---- BEGIN EDITABLE SECTION complex_noreturn ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION complex_noreturn ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def createObject()
    # ---- BEGIN EDITABLE SECTION createObject ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION createObject ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def getLong()
    # ---- BEGIN EDITABLE SECTION getLong ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getLong ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def setLong(n)
    # ---- BEGIN EDITABLE SECTION setLong ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setLong ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def getHyper()
    # ---- BEGIN EDITABLE SECTION getHyper ----
    returnValue = 0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getHyper ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def setHyper(n)
    # ---- BEGIN EDITABLE SECTION setHyper ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setHyper ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def getFloat()
    # ---- BEGIN EDITABLE SECTION getFloat ----
    returnValue = 0.0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getFloat ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def setFloat(f)
    # ---- BEGIN EDITABLE SECTION setFloat ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setFloat ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def getDouble()
    # ---- BEGIN EDITABLE SECTION getDouble ----
    returnValue = 0.0
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getDouble ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def setDouble(f)
    # ---- BEGIN EDITABLE SECTION setDouble ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setDouble ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def getString()
    # ---- BEGIN EDITABLE SECTION getString ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getString ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def setString(s)
    # ---- BEGIN EDITABLE SECTION setString ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setString ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def getInterface()
    # ---- BEGIN EDITABLE SECTION getInterface ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getInterface ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def setInterface(x)
    # ---- BEGIN EDITABLE SECTION setInterface ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setInterface ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def getAny()
    # ---- BEGIN EDITABLE SECTION getAny ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getAny ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def setAny(a)
    # ---- BEGIN EDITABLE SECTION setAny ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setAny ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def getSequence()
    # ---- BEGIN EDITABLE SECTION getSequence ----
    returnValue = []
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getSequence ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def setSequence(seq)
    # ---- BEGIN EDITABLE SECTION setSequence ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setSequence ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def getStruct()
    # ---- BEGIN EDITABLE SECTION getStruct ----
    returnValue = nil
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getStruct ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def setStruct(c)
    # ---- BEGIN EDITABLE SECTION setStruct ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION setStruct ----
  end

  # Method of com.sun.star.test.performance.XPerformanceTest
  def raiseRuntimeException()
    # ---- BEGIN EDITABLE SECTION raiseRuntimeException ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION raiseRuntimeException ----
  end

  # Use this section to define additional class members
  # ---- BEGIN EDITABLE SECTION MEMBERS ----

  # ruby constructor initialize method
  def initialize

  end

  # ---- END EDITABLE SECTION MEMBERS ----

end  # ! MyInputOutputStream

# Use the following editable section for items required after the class
# definition
# ---- BEGIN EDITABLE SECTION FOOTER ----

# ---- END EDITABLE SECTION FOOTER ----
