# Builds InheritedInterface C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['InheritedInterface']
}
# **** CODE GENERATOR CHECKSUM 883f904de03974beac0292552a0412b5
