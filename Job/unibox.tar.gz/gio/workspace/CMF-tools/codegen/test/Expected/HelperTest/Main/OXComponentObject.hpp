#ifndef _ECCE72CE_9117_11DB_85D4_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _ECCE72CE_9117_11DB_85D4_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * WeakObject explicitly overriding helper XComponent
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    OXComponentObject.hpp
 *
 * @author  Charles Halliday
 *
 * @date    21 Dec 2006
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include <cppuhelper/compbase2.hxx>
#include <xoc/svc/session/BaseMutex.hpp>
#include <com/sun/star/uno/RuntimeException.hpp>

#include <com/sun/star/container/XEnumeration.hpp>
#include <com/sun/star/lang/XComponent.hpp>
#include <com/sun/star/lang/XInitialization.hpp>
#include <xoc/threads/Synchronization.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Enable following line to log weakObject reference counts
//#define DEBUG_REFCOUNT

namespace svc_session_misc {
typedef ::cppu::WeakComponentImplHelper2<
  ::com::sun::star::container::XEnumeration
  , ::com::sun::star::lang::XInitialization
  > OXComponentObjectImplHelper;

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * WeakObject explicitly overriding helper XComponent
 *
 * Also explicit com.sun.star.lang.XInitialization
 * 
 */
class OXComponentObject :
    public ::xoc::svc::session::BaseMutex,
    public OXComponentObjectImplHelper
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    // Interface com.sun.star.container.XEnumeration

    // Method of com.sun.star.container.XEnumeration
    virtual ::sal_Bool SAL_CALL
    hasMoreElements()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.container.XEnumeration
    virtual ::com::sun::star::uno::Any SAL_CALL
    nextElement()
      throw (
        ::com::sun::star::container::NoSuchElementException,
        ::com::sun::star::lang::WrappedTargetException,
        ::com::sun::star::uno::RuntimeException );

    // Interface com.sun.star.lang.XComponent

    // Method of com.sun.star.lang.XComponent
    virtual void SAL_CALL
    dispose()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.lang.XComponent
    virtual void SAL_CALL
    addEventListener(
      const ::com::sun::star::uno::Reference< ::com::sun::star::lang::XEventListener >& xListener )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.lang.XComponent
    virtual void SAL_CALL
    removeEventListener(
      const ::com::sun::star::uno::Reference< ::com::sun::star::lang::XEventListener >& aListener )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface com.sun.star.lang.XInitialization

    // Method of com.sun.star.lang.XInitialization
    virtual void SAL_CALL
    initialize(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Any >& aArguments )
      throw (
        ::com::sun::star::uno::Exception,
        ::com::sun::star::uno::RuntimeException );

#ifdef DEBUG_REFCOUNT
    // XInterface overridden methods, for debugging only
    virtual void SAL_CALL acquire() throw ();
    virtual void SAL_CALL release() throw ();
#endif

    virtual ~OXComponentObject();

  // Constructors and additional class member declarations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

    OXComponentObject();

  private:
    // Copy constructor
    OXComponentObject(const OXComponentObject & r);

    // Assignment operator
    OXComponentObject&operator=(const OXComponentObject & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For com.sun.star.lang.XInitialization
    ::xoc::threads::Mutex mInitializedMutex;
    ::sal_Bool mInitialized;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
