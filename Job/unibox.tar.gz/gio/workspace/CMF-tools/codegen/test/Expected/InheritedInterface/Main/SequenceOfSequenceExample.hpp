#ifndef _15B45158_3605_11DC_956F_00306EB267AB_ // ---- INCLUDE PROTECTION ----
#define _15B45158_3605_11DC_956F_00306EB267AB_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Interface uses sequence of sequence 
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    SequenceOfSequenceExample.hpp
 *
 * @author  Charles Halliday
 *
 * @date    19 Jul 2007
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include <cppuhelper/implbase1.hxx>
#include <com/sun/star/uno/RuntimeException.hpp>

#include <foobar/ZSequenceOfSequence.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Enable following line to log weakObject reference counts
//#define DEBUG_REFCOUNT

namespace foobar {
typedef ::cppu::WeakImplHelper1<
  ::foobar::ZSequenceOfSequence
  > SequenceOfSequenceExampleImplHelper;

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Interface uses sequence of sequence
 */
class SequenceOfSequenceExample :
    public SequenceOfSequenceExampleImplHelper
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    // Interface foobar.ZSequenceOfSequence

    // Method of foobar.ZSequenceOfSequence
    virtual ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Sequence< ::sal_Int8 > > SAL_CALL
    getSequenceOfSequence()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZSequenceOfSequence
    virtual void SAL_CALL
    setSequenceOfSequence(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Sequence< ::rtl::OUString > >& arg )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZSequenceOfSequence
    virtual void SAL_CALL
    updateSequenceOfSequence(
      ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface > > >& arg )
      throw ( ::com::sun::star::uno::RuntimeException );

#ifdef DEBUG_REFCOUNT
    // XInterface overridden methods, for debugging only
    virtual void SAL_CALL acquire() throw ();
    virtual void SAL_CALL release() throw ();
#endif

    virtual ~SequenceOfSequenceExample();

  // Constructors and additional class member declarations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

    SequenceOfSequenceExample();

  private:
    // Copy constructor
    SequenceOfSequenceExample(const SequenceOfSequenceExample & r);

    // Assignment operator
    SequenceOfSequenceExample&operator=(const SequenceOfSequenceExample & r);

  // ---- END EDITABLE SECTION MEMBERS ----
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
