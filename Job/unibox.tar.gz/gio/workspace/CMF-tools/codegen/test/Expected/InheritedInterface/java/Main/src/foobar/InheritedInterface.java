/** 
 ****************************************************************************
 *
 * Interface ZBarChild inherits from ZBar which inherits from ZFoo
 *
 * Copyright by Verigy Germany GmbH, 2005
 *
 * @file    InheritedInterface.java
 *
 * @author  Charles Halliday
 *
 * @date    05 May 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package foobar;

import com.sun.star.lang.XInitialization;
import com.sun.star.uno.Exception;
import com.sun.star.uno.XComponentContext;
import foobar.ZBar;
import foobar.ZBarChild;
import foobar.ZFoo;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * Interface ZBarChild inherits from ZBar which inherits from ZFoo
 */

public class InheritedInterface
  extends foobar.InheritedInterfaceBase
  implements
    XInitialization,
    ZBarChild
  // ---- BEGIN EDITABLE SECTION IMPLEMENTS ----
  // ---- END EDITABLE SECTION IMPLEMENTS ----
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("foobar");

  private boolean mInitialized = false;

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  public InheritedInterface(XComponentContext xComponentContext)
  {
    super(xComponentContext);
    // ---- BEGIN EDITABLE SECTION InheritedInterface ----

    // ---- END EDITABLE SECTION InheritedInterface ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  public void initialize(Object[] aArguments)
    throws Exception
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    synchronized (this) {
      if ( ! mInitialized ) {
        mInitialized = true;
        // @todo TODO_AUTO_GENERATED
      }
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Interface foobar.ZBarChild

  // Method of foobar.ZBarChild
  public int doAnother(int param)
  {
    // ---- BEGIN EDITABLE SECTION doAnother ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION doAnother ----
  }

  // Method of foobar.ZBarChild
  public int doThat(int param)
  {
    // ---- BEGIN EDITABLE SECTION doThat ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION doThat ----
  }

  // Method of foobar.ZBarChild
  public int doThis(int param)
  {
    // ---- BEGIN EDITABLE SECTION doThis ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION doThis ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // !  InheritedInterface
