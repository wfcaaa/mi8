#ifndef _35579F4E_6836_11DB_9CC3_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _35579F4E_6836_11DB_9CC3_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Brief MyService2
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    MyService2Class.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyComponentBase.hpp"

#include <xoc/svc/reflector/ZReceiver.hpp>
#include <xoc/threads/Synchronization.hpp>

#include <ruby.h>

#include <C_xoc_svc_reflector_ZEcho_Stub.hpp>
#include <C_xoc_svc_reflector_ZBroadcaster_Stub.hpp>

#include <xoc/svc/unoruby/Unoruby.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
// Enable the following if XInitialization::initialize is implemented in ruby
//#define ENABLE_RUBY_UNO_XINITIALIZATION_FOR_MYSERVICE2CLASS
#ifdef ENABLE_RUBY_UNO_XINITIALIZATION_FOR_MYSERVICE2CLASS
#include <C_com_sun_star_lang_XInitialization_Stub.hpp>
#endif

// ---- END EDITABLE SECTION INCLUDES ----

namespace xoc_svc_pckg {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Brief MyService2
 *
 * Full description of xoc.svc.misc.MyService2
 */
class MyService2Class : public ::xoc_svc_misc::MyService2ClassBase
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    MyService2Class( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~MyService2Class();

    // Interface com.sun.star.lang.XInitialization

    // Method of com.sun.star.lang.XInitialization
    virtual void SAL_CALL
    initialize(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Any >& aArguments )
      throw (
        ::com::sun::star::uno::Exception,
        ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.reflector.ZEcho

    // Method of xoc.svc.reflector.ZEcho
    virtual ::rtl::OUString SAL_CALL
    echo(
      const ::rtl::OUString& s )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.reflector.ZEcho
    virtual void SAL_CALL
    print(
      const ::rtl::OUString& s )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.reflector.ZBroadcaster

    // Method of xoc.svc.reflector.ZBroadcaster
    virtual void SAL_CALL
    registerReceiver(
      const ::com::sun::star::uno::Reference< ::xoc::svc::reflector::ZReceiver >& r )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.reflector.ZBroadcaster
    virtual void SAL_CALL
    unRegisterReceiver(
      const ::com::sun::star::uno::Reference< ::xoc::svc::reflector::ZReceiver >& r )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.reflector.ZBroadcaster
    virtual void SAL_CALL
    broadcast(
      const ::rtl::OUString& s )
      throw ( ::com::sun::star::uno::RuntimeException );

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    MyService2Class(const MyService2Class & r);

    // Assignment operator
    MyService2Class&operator=(const MyService2Class & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For com.sun.star.lang.XInitialization
    ::xoc::threads::Mutex mInitializedMutex;
    ::sal_Bool mInitialized;

    // For interfacing to Ruby methods
    VALUE rubyClass;
#ifdef ENABLE_RUBY_UNO_XINITIALIZATION_FOR_MYSERVICE2CLASS
    ::services_ruby_UnoRuby::C_com_sun_star_lang_XInitializationStub *pRubyStubXInitialization;
#endif
    ::services_ruby_UnoRuby::C_xoc_svc_reflector_ZEchoStub *pRubyStubZEcho;
    ::services_ruby_UnoRuby::C_xoc_svc_reflector_ZBroadcasterStub *pRubyStubZBroadcaster;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
