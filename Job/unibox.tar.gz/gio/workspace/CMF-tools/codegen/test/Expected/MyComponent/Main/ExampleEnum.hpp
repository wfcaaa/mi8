#ifndef _3DAE65F0_65DA_11DB_898B_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _3DAE65F0_65DA_11DB_898B_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Example enum types in method parameters and return
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    ExampleEnum.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include <cppuhelper/implbase2.hxx>
#include <com/sun/star/uno/RuntimeException.hpp>

#include <xoc/svc/waiting/ZWaiting.hpp>
#include <xoc/svc/pref/ZPreferences.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Enable following line to log weakObject reference counts
//#define DEBUG_REFCOUNT

namespace xoc_svc_misc {
typedef ::cppu::WeakImplHelper2<
  ::xoc::svc::waiting::ZWaiting
  , ::xoc::svc::pref::ZPreferences
  > ExampleEnumImplHelper;

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Example enum types in method parameters and return
 *
 * ZWaiting and ZPreferences use enums.
 * 
 */
class ExampleEnum :
    public ExampleEnumImplHelper
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    // Interface xoc.svc.waiting.ZWaiting

    // Method of xoc.svc.waiting.ZWaiting
    virtual void SAL_CALL
    setDuration(
      ::sal_Int32 duration,
      ::xoc::svc::waiting::ZWaitingUnit unit )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.waiting.ZWaiting
    virtual double SAL_CALL
    getRemainingTime(
      ::xoc::svc::waiting::ZWaitingUnit unit )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.waiting.ZWaiting
    virtual ::sal_Bool SAL_CALL
    hasElapsed()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.waiting.ZWaiting
    virtual void SAL_CALL
    unite(
      const ::com::sun::star::uno::Reference< ::xoc::svc::waiting::ZWaiting >& waitingObject )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.waiting.ZWaiting
    virtual void SAL_CALL
    wait()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.pref.ZPreferences

    // Method of xoc.svc.pref.ZPreferences
    virtual ::rtl::OUString SAL_CALL
    name()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::xoc::svc::pref::PrefMethodStatus SAL_CALL
    getKey(
      const ::rtl::OUString& keyPath,
      ::rtl::OUString& keyValue )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::xoc::svc::pref::PrefMethodStatus SAL_CALL
    putKey(
      const ::rtl::OUString& keyPath,
      const ::rtl::OUString& keyValue )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::xoc::svc::pref::PrefMethodStatus SAL_CALL
    removeKey(
      const ::rtl::OUString& keyPath )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::com::sun::star::uno::Sequence< ::rtl::OUString > SAL_CALL
    keys()
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::com::sun::star::uno::Sequence< ::rtl::OUString > SAL_CALL
    children()
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::xoc::svc::pref::PrefMethodStatus SAL_CALL
    addNode(
      const ::rtl::OUString& nodePath )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::com::sun::star::uno::Reference< ::xoc::svc::pref::ZPreferences > SAL_CALL
    getNode(
      const ::rtl::OUString& nodePath )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::xoc::svc::pref::PrefMethodStatus SAL_CALL
    removeNode(
      const ::rtl::OUString& nodePath )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::sal_Bool SAL_CALL
    nodeExists(
      const ::rtl::OUString& nodePath )
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.pref.ZPreferences
    virtual ::com::sun::star::uno::Reference< ::xoc::svc::pref::ZPreferences > SAL_CALL
    getParentNode()
      throw (
        ::xoc::exc::ZNotAvailable_v2,
        ::com::sun::star::uno::RuntimeException );

#ifdef DEBUG_REFCOUNT
    // XInterface overridden methods, for debugging only
    virtual void SAL_CALL acquire() throw ();
    virtual void SAL_CALL release() throw ();
#endif

    virtual ~ExampleEnum();

  // Constructors and additional class member declarations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

    ExampleEnum();

  private:
    // Copy constructor
    ExampleEnum(const ExampleEnum & r);

    // Assignment operator
    ExampleEnum&operator=(const ExampleEnum & r);

  // ---- END EDITABLE SECTION MEMBERS ----
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
