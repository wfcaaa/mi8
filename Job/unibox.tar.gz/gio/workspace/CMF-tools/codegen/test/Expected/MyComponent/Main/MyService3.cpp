/** 
 ****************************************************************************
 *
 * Brief MyService3
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    MyService3.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyService3.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

#include <xoc/svc/session/SessionServiceManager.hpp>
// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::cot;
using namespace ::xoc::svc::reflector;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_pckg;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_pckg {

  MyService3::MyService3(
    Reference< XComponentContext > const & xComponentContext)
    : MyService3Base::MyService3Base(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
    , mInitialized(sal_False)
  {
    // ---- BEGIN EDITABLE SECTION MyService3 ----

    // ---- END EDITABLE SECTION MyService3 ----
  }

  MyService3::~MyService3()
  {
    // ---- BEGIN EDITABLE SECTION ~MyService3 ----

    // ---- END EDITABLE SECTION ~MyService3 ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  void SAL_CALL
  MyService3::initialize(
    const Sequence< Any >& aArguments )
    throw (
      Exception,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    ::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);
    if ( mInitialized == sal_False ) {
      // @todo TODO_AUTO_GENERATED remove if lifecycle is controlled by another singleton
      ::xoc::svc::session::SessionServiceManager::instance().
          registerForShutdown(this);
      mInitialized = sal_True;
      // @todo TODO_AUTO_GENERATED
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Interface xoc.svc.reflector.ZEcho

  // Method of xoc.svc.reflector.ZEcho
  OUString SAL_CALL
  MyService3::echo(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION echo ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION echo ----
  }

  // Method of xoc.svc.reflector.ZEcho
  void SAL_CALL
  MyService3::print(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION print ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION print ----
  }

  // Interface xoc.cot.ZDebug

  // Method of xoc.cot.ZDebug
  void SAL_CALL
  MyService3::dump(
    const Reference< ZLogStream >& log )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION dump ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION dump ----
  }

  // Method of xoc.cot.ZDebug
  sal_Bool SAL_CALL
  MyService3::isValid()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION isValid ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION isValid ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

