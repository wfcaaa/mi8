/** 
 ****************************************************************************
 *
 * Brief ZSRunLevelControllerStub service
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    ZSMyRunLevelController.cpp
 *
 * @author  Kirstin Weber
 *
 * @date    30 June 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "ZSMyRunLevelController.hpp"
#include <xoc/svc/misc/LocationResolver.hpp>
#include <SystemLogger.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::exc;
using namespace ::xoc::svc::session;
using namespace ::services_ruby_UnoRuby;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_session;

  const rtl::OUString serviceName =
  toOu("xoc.svc.session.ZSMyRunLevelController");

  const rtl::OUString configDataPath =
  toOu("ccd:")+ serviceName;
  const rtl::OUString rubyServiceImplementationPathTail =
  toOu("/ZSMyRunLevelController.rb");

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_session {

  ZSMyRunLevelController::ZSMyRunLevelController(
    Reference< XComponentContext > const & xComponentContext)
    : ZSMyRunLevelControllerBase::ZSMyRunLevelControllerBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
  {
    // ---- BEGIN EDITABLE SECTION ZSMyRunLevelController ----

    initForServices();

    rtl::OUString absConfigDataPath =
      ::xoc::svc::misc::LocationResolver::instance()->
      getAbsPath(configDataPath);

    rtl::OUString initScript =
      absConfigDataPath + rubyServiceImplementationPathTail;

    callRubyScript(initScript);

    rubyClass = rubyEval(toOu("ZSMyRunLevelController.new"));

    pRubyStubZSessionLifecycle =
      new C_xoc_svc_session_ZSessionLifecycleStub(rubyClass);
    pRubyStubZRunLevelInformation =
      new C_xoc_svc_session_ZRunLevelInformationStub(rubyClass);
    pRubyStubZRunLevelControl =
      new C_xoc_svc_session_ZRunLevelControlStub(rubyClass);

    // ---- END EDITABLE SECTION ZSMyRunLevelController ----
  }

  ZSMyRunLevelController::~ZSMyRunLevelController()
  {
    // ---- BEGIN EDITABLE SECTION ~ZSMyRunLevelController ----

    // ---- END EDITABLE SECTION ~ZSMyRunLevelController ----
  }

  // Interface xoc.svc.session.ZSessionLifecycle

  // Method of xoc.svc.session.ZSessionLifecycle
  void SAL_CALL
  ZSMyRunLevelController::sbsInitialize()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION sbsInitialize ----
    pRubyStubZSessionLifecycle->sbsInitialize();
    // ---- END EDITABLE SECTION sbsInitialize ----
  }

  // Method of xoc.svc.session.ZSessionLifecycle
  void SAL_CALL
  ZSMyRunLevelController::sbsShutdown()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION sbsShutdown ----
    pRubyStubZSessionLifecycle->sbsShutdown();
    // ---- END EDITABLE SECTION sbsShutdown ----
  }

  // Interface xoc.svc.session.ZRunLevelInformation

  // Method of xoc.svc.session.ZRunLevelInformation
  OUString SAL_CALL
  ZSMyRunLevelController::getRunLevel()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getRunLevel ----
    return pRubyStubZRunLevelInformation->getRunLevel();
    // ---- END EDITABLE SECTION getRunLevel ----
  }

  // Method of xoc.svc.session.ZRunLevelInformation
  OUString SAL_CALL
  ZSMyRunLevelController::registerForRunLevelChange(
    const Reference< ZRunLevelListener >& client )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION registerForRunLevelChange ----
    return pRubyStubZRunLevelInformation->registerForRunLevelChange(client);
    // ---- END EDITABLE SECTION registerForRunLevelChange ----
  }

  // Method of xoc.svc.session.ZRunLevelInformation
  OUString SAL_CALL
  ZSMyRunLevelController::unregisterForRunLevelChange(
    const Reference< ZRunLevelListener >& client )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION unregisterForRunLevelChange ----
    return pRubyStubZRunLevelInformation->unregisterForRunLevelChange(client);
    // ---- END EDITABLE SECTION unregisterForRunLevelChange ----
  }

  // Method of xoc.svc.session.ZRunLevelInformation
  sal_Bool SAL_CALL
  ZSMyRunLevelController::isRunLevelBelow(
    const OUString& runLevel )
    throw (
      ZParameterException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION isRunLevelBelow ----
    return pRubyStubZRunLevelInformation->isRunLevelBelow(runLevel);
    // ---- END EDITABLE SECTION isRunLevelBelow ----
  }

  // Method of xoc.svc.session.ZRunLevelInformation
  sal_Bool SAL_CALL
  ZSMyRunLevelController::isRunLevelAbove(
    const OUString& runLevel )
    throw (
      ZParameterException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION isRunLevelAbove ----
    return pRubyStubZRunLevelInformation->isRunLevelAbove(runLevel);
    // ---- END EDITABLE SECTION isRunLevelAbove ----
  }

  // Interface xoc.svc.session.ZRunLevelControl

  // Method of xoc.svc.session.ZRunLevelControl
  void SAL_CALL
  ZSMyRunLevelController::enterRunLevel(
    const OUString& desiredLevel )
    throw (
      ZParameterException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION enterRunLevel ----
    pRubyStubZRunLevelControl->enterRunLevel(desiredLevel);
    // ---- END EDITABLE SECTION enterRunLevel ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

