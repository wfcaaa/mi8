/** 
 ****************************************************************************
 *
 * WeakObject explicitly overriding helper XInterface
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    OXInterfaceObject.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Apr 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "OXInterfaceObject.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::container;
using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::svc_session_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace svc_session_misc {

  // Interface com.sun.star.uno.XInterface

  // Method of com.sun.star.uno.XInterface
  Any SAL_CALL
  OXInterfaceObject::queryInterface(
    const Type& aType )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION queryInterface ----
    Any returnValue;
    // WARNING: removing the base class method call may break the component
    returnValue =
      OXInterfaceObjectImplHelper::queryInterface(aType);
    return returnValue;
    // ---- END EDITABLE SECTION queryInterface ----
  }

  // Method of com.sun.star.uno.XInterface
  void SAL_CALL
  OXInterfaceObject::acquire()
    throw (  )
  {
    // ---- BEGIN EDITABLE SECTION acquire ----
    // WARNING: removing the base class method call may break the component
    OXInterfaceObjectImplHelper::acquire();
    // ---- END EDITABLE SECTION acquire ----
#ifdef DEBUG_REFCOUNT
    XOC_DEBUG(__FUNCTION__
              << " pid=" << getpid()
              << " instance=0x" << std::hex << (void *)this << std::dec
              << " m_refCount->" << m_refCount << " on exit");
#endif
  }

  // Method of com.sun.star.uno.XInterface
  void SAL_CALL
  OXInterfaceObject::release()
    throw (  )
  {
#ifdef DEBUG_REFCOUNT
    // Need to log before calling release() otherwise
    // when ref count goes to 0, destructor is called before log
    XOC_DEBUG(__FUNCTION__
              << " pid=" << getpid()
              << " instance=0x" << std::hex << (void *)this << std::dec
              << " m_refCount->" << m_refCount - 1 << " on exit");
#endif
    // ---- BEGIN EDITABLE SECTION release ----
    // WARNING: removing the base class method call may break the component
    OXInterfaceObjectImplHelper::release();
    // ---- END EDITABLE SECTION release ----
  }

  // Interface com.sun.star.lang.XTypeProvider

  // Method of com.sun.star.lang.XTypeProvider
  Sequence< Type > SAL_CALL
  OXInterfaceObject::getTypes()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getTypes ----
    Sequence< Type > returnValue;
    // WARNING: removing the base class method call may break the component
    returnValue =
      OXInterfaceObjectImplHelper::getTypes();
    return returnValue;
    // ---- END EDITABLE SECTION getTypes ----
  }

  // Method of com.sun.star.lang.XTypeProvider
  Sequence< sal_Int8 > SAL_CALL
  OXInterfaceObject::getImplementationId()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getImplementationId ----
    Sequence< sal_Int8 > returnValue;
    // WARNING: removing the base class method call may break the component
    returnValue =
      OXInterfaceObjectImplHelper::getImplementationId();
    return returnValue;
    // ---- END EDITABLE SECTION getImplementationId ----
  }

  // Interface com.sun.star.container.XEnumeration

  // Method of com.sun.star.container.XEnumeration
  sal_Bool SAL_CALL
  OXInterfaceObject::hasMoreElements()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION hasMoreElements ----
    sal_Bool returnValue = sal_False;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION hasMoreElements ----
  }

  // Method of com.sun.star.container.XEnumeration
  Any SAL_CALL
  OXInterfaceObject::nextElement()
    throw (
      NoSuchElementException,
      WrappedTargetException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION nextElement ----
    Any returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION nextElement ----
  }

  OXInterfaceObject::~OXInterfaceObject()
  {
    // ---- BEGIN EDITABLE SECTION ~OXInterfaceObject ----

    // ---- END EDITABLE SECTION ~OXInterfaceObject ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  OXInterfaceObject::OXInterfaceObject()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

