#ifndef _10FBA992_6836_11DB_9CA3_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _10FBA992_6836_11DB_9CA3_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Interface ZBarChild inherits from ZBar which inherits from ZFoo
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    InheritedInterface.hpp
 *
 * @author  Charles Halliday
 *
 * @date    30 Oct 2006
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "InheritedInterfaceBase.hpp"
#include <xoc/threads/Synchronization.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

namespace foobar {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Interface ZBarChild inherits from ZBar which inherits from ZFoo
 */
class InheritedInterface : public InheritedInterfaceBase
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    InheritedInterface( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~InheritedInterface();

    // Interface com.sun.star.lang.XInitialization

    // Method of com.sun.star.lang.XInitialization
    virtual void SAL_CALL
    initialize(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Any >& aArguments )
      throw (
        ::com::sun::star::uno::Exception,
        ::com::sun::star::uno::RuntimeException );

    // Interface foobar.ZBarChild

    // Method of foobar.ZBarChild
    virtual ::sal_Int32 SAL_CALL
    doAnother(
      ::sal_Int32 param )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZBarChild
    virtual ::sal_Int32 SAL_CALL
    doThat(
      ::sal_Int32 param )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZBarChild
    virtual ::sal_Int32 SAL_CALL
    doThis(
      ::sal_Int32 param )
      throw ( ::com::sun::star::uno::RuntimeException );

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    InheritedInterface(const InheritedInterface & r);

    // Assignment operator
    InheritedInterface&operator=(const InheritedInterface & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For com.sun.star.lang.XInitialization
    ::xoc::threads::Mutex mInitializedMutex;
    ::sal_Bool mInitialized;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
