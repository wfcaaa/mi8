# 
#***************************************************************************
#
# An Output stream
#
# Copyright by Verigy, 2007
#
# @file    MyOutputStream.rb
#
# @author  Charles Halliday
#
# @date    01 Aug 2005
#
#***************************************************************************
#

#
# This file is developer maintained.
# NOTE: You may edit this file between BEGIN EDITABLE SECTION and END
# EDITABLE SECTION. But don't edit it outside these comments, or your code
# _will_ be lost after a component regeneration.
#

# Use the following editable section for items required before the class
# definition
# ---- BEGIN EDITABLE SECTION HEADER ----

# ---- END EDITABLE SECTION HEADER ----


class MyOutputStream < com.sun.star.io.XOutputStream

  # Interface com.sun.star.io.XOutputStream

  # Method of com.sun.star.io.XOutputStream
  def writeBytes(aData)
    # ---- BEGIN EDITABLE SECTION writeBytes ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION writeBytes ----
  end

  # Method of com.sun.star.io.XOutputStream
  def flush()
    # ---- BEGIN EDITABLE SECTION flush ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION flush ----
  end

  # Method of com.sun.star.io.XOutputStream
  def closeOutput()
    # ---- BEGIN EDITABLE SECTION closeOutput ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION closeOutput ----
  end

  # Use this section to define additional class members
  # ---- BEGIN EDITABLE SECTION MEMBERS ----

  # ruby constructor initialize method
  def initialize

  end

  # ---- END EDITABLE SECTION MEMBERS ----

end  # ! MyOutputStream

# Use the following editable section for items required after the class
# definition
# ---- BEGIN EDITABLE SECTION FOOTER ----

# ---- END EDITABLE SECTION FOOTER ----
