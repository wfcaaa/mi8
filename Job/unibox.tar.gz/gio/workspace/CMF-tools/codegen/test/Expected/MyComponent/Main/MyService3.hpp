#ifndef _08D32CA8_65DA_11DB_8013_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _08D32CA8_65DA_11DB_8013_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Brief MyService3
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    MyService3.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyComponentBase.hpp"

#include <xoc/svc/reflector/ZReceiver.hpp>
#include <xoc/threads/Synchronization.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

namespace xoc_svc_pckg {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Brief MyService3
 *
 * Another service implementing ZEcho
 */
class MyService3 : public ::xoc_svc_misc::MyService3Base
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    MyService3( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~MyService3();

    // Interface com.sun.star.lang.XInitialization

    // Method of com.sun.star.lang.XInitialization
    virtual void SAL_CALL
    initialize(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Any >& aArguments )
      throw (
        ::com::sun::star::uno::Exception,
        ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.reflector.ZEcho

    // Method of xoc.svc.reflector.ZEcho
    virtual ::rtl::OUString SAL_CALL
    echo(
      const ::rtl::OUString& s )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.reflector.ZEcho
    virtual void SAL_CALL
    print(
      const ::rtl::OUString& s )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Interface xoc.cot.ZDebug

    // Method of xoc.cot.ZDebug
    virtual void SAL_CALL
    dump(
      const ::com::sun::star::uno::Reference< ::xoc::cot::ZLogStream >& log )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.cot.ZDebug
    virtual ::sal_Bool SAL_CALL
    isValid()
      throw ( ::com::sun::star::uno::RuntimeException );

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    MyService3(const MyService3 & r);

    // Assignment operator
    MyService3&operator=(const MyService3 & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For com.sun.star.lang.XInitialization
    ::xoc::threads::Mutex mInitializedMutex;
    ::sal_Bool mInitialized;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
