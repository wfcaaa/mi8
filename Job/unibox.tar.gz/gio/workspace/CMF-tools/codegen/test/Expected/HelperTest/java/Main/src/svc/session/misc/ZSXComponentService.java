/** 
 ****************************************************************************
 *
 * Explicit XComponent implementaion
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    ZSXComponentService.java
 *
 * @author  Charles Halliday
 *
 * @date    01 Feb 2007
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package svc.session.misc;

import com.sun.star.lang.XComponent;
import com.sun.star.lang.XEventListener;
import com.sun.star.uno.XAdapter;
import com.sun.star.uno.XComponentContext;
import com.sun.star.uno.XWeak;
import xoc.exc.ZParameterException;
import xoc.svc.ZIDService;
import xoc.svc.reflector.ZEcho;
import xoc.svc.session.ZSessionLifecycle;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * Explicit XComponent implementaion
 *
 * Also implements XWeak overriding helper class and
 * XMain overriding standard base class implementation.
 * Is singleton, so overrides helper class dispose() to
 * clear own reference to self.
 * Also explicit ZSessionLifecycle (no XInitialization)
 * 
 */

public class ZSXComponentService
  extends svc.session.misc.ZSXComponentServiceBase
  implements
    ZIDService,
    ZEcho,
    ZSessionLifecycle
  // ---- BEGIN EDITABLE SECTION IMPLEMENTS ----
  // ---- END EDITABLE SECTION IMPLEMENTS ----
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("svc_session_misc");

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  public ZSXComponentService(XComponentContext xComponentContext)
  {
    super(xComponentContext);
    // ---- BEGIN EDITABLE SECTION ZSXComponentService ----

    // ---- END EDITABLE SECTION ZSXComponentService ----
  }

  // Interface com.sun.star.lang.XComponent

  // Method of com.sun.star.lang.XComponent
  public void dispose()
  {
    // ---- BEGIN EDITABLE SECTION dispose ----
    // WARNING: removing the base class method call may break the component
    super.dispose();
    // ---- END EDITABLE SECTION dispose ----
  }

  // Method of com.sun.star.lang.XComponent
  public void addEventListener(XEventListener xListener)
  {
    // ---- BEGIN EDITABLE SECTION addEventListener ----
    // WARNING: removing the base class method call may break the component
    super.addEventListener(xListener);
    // ---- END EDITABLE SECTION addEventListener ----
  }

  // Method of com.sun.star.lang.XComponent
  public void removeEventListener(XEventListener aListener)
  {
    // ---- BEGIN EDITABLE SECTION removeEventListener ----
    // WARNING: removing the base class method call may break the component
    super.removeEventListener(aListener);
    // ---- END EDITABLE SECTION removeEventListener ----
  }

  // Interface com.sun.star.uno.XWeak

  // Method of com.sun.star.uno.XWeak
  public XAdapter queryAdapter()
  {
    // ---- BEGIN EDITABLE SECTION queryAdapter ----
    // WARNING: removing the base class method call may break the component
    return super.queryAdapter();
    // ---- END EDITABLE SECTION queryAdapter ----
  }

  // Interface xoc.svc.ZIDService

  // Method of xoc.svc.ZIDService
  public int getId(String idString)
  {
    // ---- BEGIN EDITABLE SECTION getId ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getId ----
  }

  // Method of xoc.svc.ZIDService
  public String getString(int id)
    throws ZParameterException
  {
    // ---- BEGIN EDITABLE SECTION getString ----
    String returnValue = "";
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getString ----
  }

  // Interface xoc.svc.reflector.ZEcho

  // Method of xoc.svc.reflector.ZEcho
  public String echo(String s)
  {
    // ---- BEGIN EDITABLE SECTION echo ----
    String returnValue = "";
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION echo ----
  }

  // Method of xoc.svc.reflector.ZEcho
  public void print(String s)
  {
    // ---- BEGIN EDITABLE SECTION print ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION print ----
  }

  // Interface xoc.svc.session.ZSessionLifecycle

  // Method of xoc.svc.session.ZSessionLifecycle
  public void sbsInitialize()
  {
    // ---- BEGIN EDITABLE SECTION sbsInitialize ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION sbsInitialize ----
  }

  // Method of xoc.svc.session.ZSessionLifecycle
  public void sbsShutdown()
  {
    // ---- BEGIN EDITABLE SECTION sbsShutdown ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION sbsShutdown ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // !  ZSXComponentService
