/** 
 ****************************************************************************
 *
 * WeakObject explicitly overriding helper XComponent
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    OXComponentObject.java
 *
 * @author  Charles Halliday
 *
 * @date    01 Feb 2007
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package svc.session.misc;

import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XEnumeration;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XComponent;
import com.sun.star.lang.XEventListener;
import com.sun.star.lang.XInitialization;
import com.sun.star.uno.Exception;
import com.sun.star.lib.uno.helper.ComponentBase;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * WeakObject explicitly overriding helper XComponent
 *
 * Also explicit com.sun.star.lang.XInitialization
 * 
 */

class OXComponentObject
  extends ComponentBase
  implements
    XEnumeration,
    XInitialization
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("svc_session_misc");

  private boolean mInitialized = false;

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  // Interface com.sun.star.container.XEnumeration

  // Method of com.sun.star.container.XEnumeration
  public boolean hasMoreElements()
  {
    // ---- BEGIN EDITABLE SECTION hasMoreElements ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION hasMoreElements ----
  }

  // Method of com.sun.star.container.XEnumeration
  public Object nextElement()
    throws
      NoSuchElementException,
      WrappedTargetException
  {
    // ---- BEGIN EDITABLE SECTION nextElement ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION nextElement ----
  }

  // Interface com.sun.star.lang.XComponent

  // Method of com.sun.star.lang.XComponent
  public void dispose()
  {
    // ---- BEGIN EDITABLE SECTION dispose ----
    // WARNING: removing the base class method call may break the component
    super.dispose();
    // ---- END EDITABLE SECTION dispose ----
  }

  // Method of com.sun.star.lang.XComponent
  public void addEventListener(XEventListener xListener)
  {
    // ---- BEGIN EDITABLE SECTION addEventListener ----
    // WARNING: removing the base class method call may break the component
    super.addEventListener(xListener);
    // ---- END EDITABLE SECTION addEventListener ----
  }

  // Method of com.sun.star.lang.XComponent
  public void removeEventListener(XEventListener aListener)
  {
    // ---- BEGIN EDITABLE SECTION removeEventListener ----
    // WARNING: removing the base class method call may break the component
    super.removeEventListener(aListener);
    // ---- END EDITABLE SECTION removeEventListener ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  public void initialize(Object[] aArguments)
    throws Exception
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    synchronized (this) {
      if ( ! mInitialized ) {
        mInitialized = true;
        // @todo TODO_AUTO_GENERATED
      }
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // Default constructor, may be replaced
  OXComponentObject()
  {
  }

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // ! OXComponentObject
