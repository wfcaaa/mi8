/** 
 ****************************************************************************
 *
 * Explicit XServiceInfo overriding standard implementation
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    ZSXServiceInfoService.java
 *
 * @author  Charles Halliday
 *
 * @date    01 Feb 2007
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package svc.session.misc;

import com.sun.star.lang.XInitialization;
import com.sun.star.lang.XServiceInfo;
import com.sun.star.uno.Exception;
import com.sun.star.uno.XComponentContext;
import xoc.svc.ZValue;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * Explicit XServiceInfo overriding standard implementation
 *
 * Also explicit com.sun.star.lang.XInitialization
 * 
 */

public class ZSXServiceInfoService
  extends svc.session.misc.ZSXServiceInfoServiceBase
  implements
    ZValue,
    XInitialization
  // ---- BEGIN EDITABLE SECTION IMPLEMENTS ----
  // ---- END EDITABLE SECTION IMPLEMENTS ----
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("svc_session_misc");

  private boolean mInitialized = false;

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  public ZSXServiceInfoService(XComponentContext xComponentContext)
  {
    super(xComponentContext);
    // ---- BEGIN EDITABLE SECTION ZSXServiceInfoService ----

    // ---- END EDITABLE SECTION ZSXServiceInfoService ----
  }

  // Interface com.sun.star.lang.XServiceInfo

  // Method of com.sun.star.lang.XServiceInfo
  public String getImplementationName()
  {
    // ---- BEGIN EDITABLE SECTION getImplementationName ----
    // WARNING: removing the base class method call may break the component
    return super.getImplementationName();
    // ---- END EDITABLE SECTION getImplementationName ----
  }

  // Method of com.sun.star.lang.XServiceInfo
  public boolean supportsService(String ServiceName)
  {
    // ---- BEGIN EDITABLE SECTION supportsService ----
    // WARNING: removing the base class method call may break the component
    return super.supportsService(ServiceName);
    // ---- END EDITABLE SECTION supportsService ----
  }

  // Method of com.sun.star.lang.XServiceInfo
  public String[] getSupportedServiceNames()
  {
    // ---- BEGIN EDITABLE SECTION getSupportedServiceNames ----
    // WARNING: removing the base class method call may break the component
    return super.getSupportedServiceNames();
    // ---- END EDITABLE SECTION getSupportedServiceNames ----
  }

  // Interface xoc.svc.ZValue

  // Method of xoc.svc.ZValue
  public int getType()
  {
    // ---- BEGIN EDITABLE SECTION getType ----
    int returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getType ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  public void initialize(Object[] aArguments)
    throws Exception
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    synchronized (this) {
      if ( ! mInitialized ) {
        mInitialized = true;
        // @todo TODO_AUTO_GENERATED
      }
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // !  ZSXServiceInfoService
