# Builds MyComponentUnitTester C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'],
'NAME' : ['MyComponentUnitTester'],
'CXXTEST_FILE' : ['MyComponentTests.hpp']
}

# **** CODE GENERATOR CHECKSUM 53e62f156dc3299c6271828979c431e7
