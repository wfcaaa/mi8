/** 
 ****************************************************************************
 *
 * Example enum types in method parameters and return
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    ExampleEnum.java
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package xoc_svc_misc;

import xoc.exc.ZNotAvailable_v2;
import xoc.svc.pref.PrefMethodStatus;
import xoc.svc.pref.ZPreferences;
import xoc.svc.waiting.ZWaiting;
import xoc.svc.waiting.ZWaitingUnit;
import com.sun.star.lib.uno.helper.WeakBase;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * Example enum types in method parameters and return
 *
 * ZWaiting and ZPreferences use enums.
 * 
 */

class ExampleEnum
  extends WeakBase
  implements
    ZWaiting,
    ZPreferences
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("xoc_svc_misc");

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  // Interface xoc.svc.waiting.ZWaiting

  // Method of xoc.svc.waiting.ZWaiting
  public void setDuration(int duration,
                          ZWaitingUnit unit)
  {
    // ---- BEGIN EDITABLE SECTION setDuration ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION setDuration ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  public double getRemainingTime(ZWaitingUnit unit)
  {
    // ---- BEGIN EDITABLE SECTION getRemainingTime ----
    double returnValue = 0.0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getRemainingTime ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  public boolean hasElapsed()
  {
    // ---- BEGIN EDITABLE SECTION hasElapsed ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION hasElapsed ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  public void unite(ZWaiting waitingObject)
  {
    // ---- BEGIN EDITABLE SECTION unite ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION unite ----
  }

  // Method of xoc.svc.waiting.ZWaiting
  public void wait()
  {
    // ---- BEGIN EDITABLE SECTION wait ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION wait ----
  }

  // Interface xoc.svc.pref.ZPreferences

  // Method of xoc.svc.pref.ZPreferences
  public String name()
  {
    // ---- BEGIN EDITABLE SECTION name ----
    String returnValue = "";
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION name ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public PrefMethodStatus getKey(String keyPath,
                                 String[] keyValue)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getKey ----
    PrefMethodStatus returnValue = PrefMethodStatus.SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getKey ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public PrefMethodStatus putKey(String keyPath,
                                 String keyValue)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION putKey ----
    PrefMethodStatus returnValue = PrefMethodStatus.SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION putKey ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public PrefMethodStatus removeKey(String keyPath)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION removeKey ----
    PrefMethodStatus returnValue = PrefMethodStatus.SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION removeKey ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public String[] keys()
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION keys ----
    String[] returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION keys ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public String[] children()
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION children ----
    String[] returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION children ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public PrefMethodStatus addNode(String nodePath)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION addNode ----
    PrefMethodStatus returnValue = PrefMethodStatus.SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION addNode ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public ZPreferences getNode(String nodePath)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getNode ----
    ZPreferences returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getNode ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public PrefMethodStatus removeNode(String nodePath)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION removeNode ----
    PrefMethodStatus returnValue = PrefMethodStatus.SUCCESS;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION removeNode ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public boolean nodeExists(String nodePath)
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION nodeExists ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION nodeExists ----
  }

  // Method of xoc.svc.pref.ZPreferences
  public ZPreferences getParentNode()
    throws ZNotAvailable_v2
  {
    // ---- BEGIN EDITABLE SECTION getParentNode ----
    ZPreferences returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getParentNode ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // Default constructor, may be replaced
  ExampleEnum()
  {
  }

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // ! ExampleEnum
