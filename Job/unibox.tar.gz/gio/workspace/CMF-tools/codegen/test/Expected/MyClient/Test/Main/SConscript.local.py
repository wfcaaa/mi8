# Builds MyClientUnitTester C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'],
'NAME' : ['MyClientUnitTester'],
'INCLUDE_PATH_LOCAL' : ['../../Main',
                        '../../src'],
'REQUIRED_LIBS' : ['../../libMyClient.so'],
'LDFLAGS_LOCAL' : ['-lMyClient'],
'CXXTEST_FILE' : ['MyClientTests.hpp']
}

# **** CODE GENERATOR CHECKSUM 0dcc0bd10909f3c427506487e6a95646
