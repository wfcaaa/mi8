# 
#***************************************************************************
#
# Brief MyService3
#
# Copyright by Verigy, 2006
#
# @file    MyService3.rb
#
# @author  Charles Halliday
#
# @date    01 Aug 2005
#
#***************************************************************************
#

#
# This file is developer maintained.
# NOTE: You may edit this file between BEGIN EDITABLE SECTION and END
# EDITABLE SECTION. But don't edit it outside these comments, or your code
# _will_ be lost after a component regeneration.
#

# Use the following editable section for items required before the class
# definition
# ---- BEGIN EDITABLE SECTION HEADER ----

# ---- END EDITABLE SECTION HEADER ----

#
# Another service implementing ZEcho

class MyService3

  # ruby constructor initialize method
  def initialize
    # ---- BEGIN EDITABLE SECTION initialize ----

    # ---- END EDITABLE SECTION initialize ----
  end

  # Interface com.sun.star.lang.XInitialization

  # Method of com.sun.star.lang.XInitialization
  # initialize method name mapped to unoInitialize
  def unoInitialize(aArguments)
    # ---- BEGIN EDITABLE SECTION unoInitialize ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION unoInitialize ----
  end

  # Interface xoc.svc.reflector.ZEcho

  # Method of xoc.svc.reflector.ZEcho
  def echo(s)
    # ---- BEGIN EDITABLE SECTION echo ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION echo ----
  end

  # Method of xoc.svc.reflector.ZEcho
  def print(s)
    # ---- BEGIN EDITABLE SECTION print ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION print ----
  end

  # Interface xoc.cot.ZDebug

  # Method of xoc.cot.ZDebug
  def dump(log)
    # ---- BEGIN EDITABLE SECTION dump ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION dump ----
  end

  # Method of xoc.cot.ZDebug
  def isValid()
    # ---- BEGIN EDITABLE SECTION isValid ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION isValid ----
  end

  # Use this section to define additional class members
  # ---- BEGIN EDITABLE SECTION MEMBERS ----

  # ---- END EDITABLE SECTION MEMBERS ----

end  # ! MyService3

# Use the following editable section for items required after the class
# definition
# ---- BEGIN EDITABLE SECTION FOOTER ----

# ---- END EDITABLE SECTION FOOTER ----
