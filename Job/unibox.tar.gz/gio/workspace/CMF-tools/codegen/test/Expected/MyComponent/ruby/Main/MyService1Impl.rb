# 
#***************************************************************************
#
# Brief MyService1
#
# Copyright by Verigy, 2007
#
# @file    MyService1Impl.rb
#
# @author  Charles Halliday
#
# @date    01 Aug 2005
#
#***************************************************************************
#

#
# This file is developer maintained.
# NOTE: You may edit this file between BEGIN EDITABLE SECTION and END
# EDITABLE SECTION. But don't edit it outside these comments, or your code
# _will_ be lost after a component regeneration.
#

# Use the following editable section for items required before the class
# definition
# ---- BEGIN EDITABLE SECTION HEADER ----

# ---- END EDITABLE SECTION HEADER ----

#
# Full description of xoc.svc.misc.MyService1,
# no interfaces

class MyService1Impl

  # ruby constructor initialize method
  def initialize
    # ---- BEGIN EDITABLE SECTION initialize ----

    # ---- END EDITABLE SECTION initialize ----
  end

  # Interface com.sun.star.lang.XInitialization

  # Method of com.sun.star.lang.XInitialization
  # initialize method name mapped to unoInitialize
  def unoInitialize(aArguments)
    # ---- BEGIN EDITABLE SECTION unoInitialize ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION unoInitialize ----
  end

  # Use this section to define additional class members
  # ---- BEGIN EDITABLE SECTION MEMBERS ----

  # ---- END EDITABLE SECTION MEMBERS ----

end  # ! MyService1Impl

# Use the following editable section for items required after the class
# definition
# ---- BEGIN EDITABLE SECTION FOOTER ----

# ---- END EDITABLE SECTION FOOTER ----
