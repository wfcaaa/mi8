#ifndef _2923FEE2_65DA_11DB_9086_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _2923FEE2_65DA_11DB_9086_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * An Input and Output stream
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    MyInputOutputStream.hpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include <cppuhelper/implbase3.hxx>
#include <com/sun/star/uno/RuntimeException.hpp>

#include <com/sun/star/io/XOutputStream.hpp>
#include <com/sun/star/io/XInputStream.hpp>
#include <com/sun/star/test/performance/XPerformanceTest.hpp>

#include <com/sun/star/lang/IllegalArgumentException.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Enable following line to log weakObject reference counts
//#define DEBUG_REFCOUNT

namespace xoc_svc_misc {
typedef ::cppu::WeakImplHelper3<
  ::com::sun::star::io::XOutputStream
  , ::com::sun::star::io::XInputStream
  , ::com::sun::star::test::performance::XPerformanceTest
  > MyInputOutputStreamImplHelper;

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * An Input and Output stream
 *
 * Checks can have two weakObjects implementing same interface.
 * Checks IDL interfaces out and inout parameters.
 * 
 */
class MyInputOutputStream :
    public MyInputOutputStreamImplHelper
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    // Interface com.sun.star.io.XOutputStream

    // Method of com.sun.star.io.XOutputStream
    virtual void SAL_CALL
    writeBytes(
      const ::com::sun::star::uno::Sequence< ::sal_Int8 >& aData )
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::BufferSizeExceededException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.io.XOutputStream
    virtual void SAL_CALL
    flush()
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::BufferSizeExceededException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.io.XOutputStream
    virtual void SAL_CALL
    closeOutput()
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::BufferSizeExceededException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Interface com.sun.star.io.XInputStream

    // Method of com.sun.star.io.XInputStream
    virtual ::sal_Int32 SAL_CALL
    readBytes(
      ::com::sun::star::uno::Sequence< ::sal_Int8 >& aData,
      ::sal_Int32 nBytesToRead )
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::BufferSizeExceededException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.io.XInputStream
    virtual ::sal_Int32 SAL_CALL
    readSomeBytes(
      ::com::sun::star::uno::Sequence< ::sal_Int8 >& aData,
      ::sal_Int32 nMaxBytesToRead )
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::BufferSizeExceededException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.io.XInputStream
    virtual void SAL_CALL
    skipBytes(
      ::sal_Int32 nBytesToSkip )
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::BufferSizeExceededException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.io.XInputStream
    virtual ::sal_Int32 SAL_CALL
    available()
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.io.XInputStream
    virtual void SAL_CALL
    closeInput()
      throw (
        ::com::sun::star::io::NotConnectedException,
        ::com::sun::star::io::IOException,
        ::com::sun::star::uno::RuntimeException );

    // Interface com.sun.star.test.performance.XPerformanceTest

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::sal_Int32 SAL_CALL
    getLong_attr()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setLong_attr(
      ::sal_Int32 _long_attr )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::sal_Int64 SAL_CALL
    getHyper_attr()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setHyper_attr(
      ::sal_Int64 _hyper_attr )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual float SAL_CALL
    getFloat_attr()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setFloat_attr(
      float _float_attr )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual double SAL_CALL
    getDouble_attr()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setDouble_attr(
      double _double_attr )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::rtl::OUString SAL_CALL
    getString_attr()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setString_attr(
      const ::rtl::OUString& _string_attr )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface > SAL_CALL
    getInterface_attr()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setInterface_attr(
      const ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface >& _interface_attr )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::uno::Any SAL_CALL
    getAny_attr()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setAny_attr(
      const ::com::sun::star::uno::Any& _any_attr )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface > > SAL_CALL
    getSequence_attr()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setSequence_attr(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface > >& _sequence_attr )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::test::performance::ComplexTypes SAL_CALL
    getStruct_attr()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setStruct_attr(
      const ::com::sun::star::test::performance::ComplexTypes& _struct_attr )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    async()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    sync()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::test::performance::ComplexTypes SAL_CALL
    complex_in(
      const ::com::sun::star::test::performance::ComplexTypes& aVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::test::performance::ComplexTypes SAL_CALL
    complex_inout(
      ::com::sun::star::test::performance::ComplexTypes& aVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    complex_oneway(
      const ::com::sun::star::test::performance::ComplexTypes& aVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    complex_noreturn(
      const ::com::sun::star::test::performance::ComplexTypes& aVal )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::uno::Reference< ::com::sun::star::test::performance::XPerformanceTest > SAL_CALL
    createObject()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::sal_Int32 SAL_CALL
    getLong()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setLong(
      ::sal_Int32 n )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::sal_Int64 SAL_CALL
    getHyper()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setHyper(
      ::sal_Int64 n )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual float SAL_CALL
    getFloat()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setFloat(
      float f )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual double SAL_CALL
    getDouble()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setDouble(
      double f )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::rtl::OUString SAL_CALL
    getString()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setString(
      const ::rtl::OUString& s )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface > SAL_CALL
    getInterface()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setInterface(
      const ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface >& x )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::uno::Any SAL_CALL
    getAny()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setAny(
      const ::com::sun::star::uno::Any& a )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface > > SAL_CALL
    getSequence()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setSequence(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Reference< ::com::sun::star::uno::XInterface > >& seq )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual ::com::sun::star::test::performance::ComplexTypes SAL_CALL
    getStruct()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    setStruct(
      const ::com::sun::star::test::performance::ComplexTypes& c )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of com.sun.star.test.performance.XPerformanceTest
    virtual void SAL_CALL
    raiseRuntimeException()
      throw ( ::com::sun::star::uno::RuntimeException );

#ifdef DEBUG_REFCOUNT
    // XInterface overridden methods, for debugging only
    virtual void SAL_CALL acquire() throw ();
    virtual void SAL_CALL release() throw ();
#endif

    virtual ~MyInputOutputStream();

  // Constructors and additional class member declarations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

    MyInputOutputStream();

  private:
    // Copy constructor
    MyInputOutputStream(const MyInputOutputStream & r);

    // Assignment operator
    MyInputOutputStream&operator=(const MyInputOutputStream & r);

  // ---- END EDITABLE SECTION MEMBERS ----
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
