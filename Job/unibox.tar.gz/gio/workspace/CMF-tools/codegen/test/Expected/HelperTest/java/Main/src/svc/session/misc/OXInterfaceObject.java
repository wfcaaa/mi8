/** 
 ****************************************************************************
 *
 * WeakObject explicitly overriding helper XInterface
 *
 * Copyright by Verigy Germany GmbH, 2007
 *
 * @file    OXInterfaceObject.java
 *
 * @author  Charles Halliday
 *
 * @date    06 Feb 2007
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package svc.session.misc;

import com.sun.star.container.NoSuchElementException;
import com.sun.star.container.XEnumeration;
import com.sun.star.lang.WrappedTargetException;
import com.sun.star.lang.XTypeProvider;
import com.sun.star.uno.Type;
import com.sun.star.lib.uno.helper.WeakBase;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * WeakObject explicitly overriding helper XInterface
 *
 * Do not do this at home folks!
 * Also overrides helper XTypeProvider implementaion.
 * 
 */

class OXInterfaceObject
  extends WeakBase
  implements XEnumeration
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("svc_session_misc");

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  // Interface com.sun.star.uno.XInterface

  // Interface com.sun.star.lang.XTypeProvider

  // Method of com.sun.star.lang.XTypeProvider
  public Type[] getTypes()
  {
    // ---- BEGIN EDITABLE SECTION getTypes ----
    // WARNING: removing the base class method call may break the component
    return super.getTypes();
    // ---- END EDITABLE SECTION getTypes ----
  }

  // Method of com.sun.star.lang.XTypeProvider
  public byte[] getImplementationId()
  {
    // ---- BEGIN EDITABLE SECTION getImplementationId ----
    // WARNING: removing the base class method call may break the component
    return super.getImplementationId();
    // ---- END EDITABLE SECTION getImplementationId ----
  }

  // Interface com.sun.star.container.XEnumeration

  // Method of com.sun.star.container.XEnumeration
  public boolean hasMoreElements()
  {
    // ---- BEGIN EDITABLE SECTION hasMoreElements ----
    boolean returnValue = false;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION hasMoreElements ----
  }

  // Method of com.sun.star.container.XEnumeration
  public Object nextElement()
    throws
      NoSuchElementException,
      WrappedTargetException
  {
    // ---- BEGIN EDITABLE SECTION nextElement ----
    Object returnValue = null;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION nextElement ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // Default constructor, may be replaced
  OXInterfaceObject()
  {
  }

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // ! OXInterfaceObject
