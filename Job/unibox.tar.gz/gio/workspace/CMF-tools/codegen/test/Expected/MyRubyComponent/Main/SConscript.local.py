# Builds MyRubyComponent C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['MyRubyComponent']
}

# Use the following make variables to localize the build:
#   flags to pass to the compiler
#CXXFLAGS_LOCAL     +=
#   list of locations to find headers to include when compiling 
# Ruby bridge UNO interface headers
INCLUDE_PATH_LOCAL += -I$(WORKSPACE)/services/ruby/UnoRuby/Main \
                      -I$(RUBY_INCLUDE_DIR)

#   flags to pass to the linker
#   Ruby libraries
LDFLAGS_LOCAL      += $(LDFLAGS_RUBY) -lzruby -lservices_ruby_UnoRuby
# **** CODE GENERATOR CHECKSUM 8012943b4ca1faeda2c0bac4f81f23a4
