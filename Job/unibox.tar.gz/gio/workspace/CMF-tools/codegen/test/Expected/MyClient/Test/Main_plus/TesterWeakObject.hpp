#ifndef _E6A8DC4E_0856_11E0_A894_D8D38581BDAC_ // ---- INCLUDE PROTECTION ----
#define _E6A8DC4E_0856_11E0_A894_D8D38581BDAC_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Additional (arbitrary) weakObject used by unit tester
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    TesterWeakObject.hpp
 *
 * @author  Charles Halliday
 *
 * @date    15 Dec 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include <cppuhelper/implbase1.hxx>
#include <com/sun/star/uno/RuntimeException.hpp>

#include <xoc/svc/xml/ZSAXAttributes.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Enable following line to log weakObject reference counts
//#define DEBUG_REFCOUNT

namespace xoc_svc_misc {
typedef ::cppu::WeakImplHelper1<
  ::xoc::svc::xml::ZSAXAttributes
  > TesterWeakObjectImplHelper;

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Additional (arbitrary) weakObject used by unit tester
 */
class TesterWeakObject :
    public TesterWeakObjectImplHelper
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    // Interface xoc.svc.xml.ZSAXAttributes

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::sal_Int32 SAL_CALL
    getLength()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::rtl::OUString SAL_CALL
    getLocalName(
      ::sal_Int32 index )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::rtl::OUString SAL_CALL
    getURI(
      ::sal_Int32 index )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::rtl::OUString SAL_CALL
    getQName(
      ::sal_Int32 index )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::rtl::OUString SAL_CALL
    getType(
      ::sal_Int32 index )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::rtl::OUString SAL_CALL
    getTypeByUri(
      const ::rtl::OUString& uri,
      const ::rtl::OUString& localPart )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::rtl::OUString SAL_CALL
    getTypeByQname(
      const ::rtl::OUString& qName )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::rtl::OUString SAL_CALL
    getValue(
      ::sal_Int32 index )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::rtl::OUString SAL_CALL
    getValueByUri(
      const ::rtl::OUString& uri,
      const ::rtl::OUString& localPart )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::rtl::OUString SAL_CALL
    getValueByQname(
      const ::rtl::OUString& qName )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::sal_Int32 SAL_CALL
    getIndexByUri(
      const ::rtl::OUString& uri,
      const ::rtl::OUString& localPart )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZSAXAttributes
    virtual ::sal_Int32 SAL_CALL
    getIndexByQname(
      const ::rtl::OUString& qName )
      throw ( ::com::sun::star::uno::RuntimeException );

#ifdef DEBUG_REFCOUNT
    // XInterface overridden methods, for debugging only
    virtual void SAL_CALL acquire() throw ();
    virtual void SAL_CALL release() throw ();
#endif

    virtual ~TesterWeakObject();

  // Constructors and additional class member declarations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

    TesterWeakObject();

  private:
    // Copy constructor
    TesterWeakObject(const TesterWeakObject & r);

    // Assignment operator
    TesterWeakObject&operator=(const TesterWeakObject & r);

  // ---- END EDITABLE SECTION MEMBERS ----
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
