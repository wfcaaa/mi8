# Builds HelperTest C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['HelperTest']
}
# **** CODE GENERATOR CHECKSUM 80860a8fc6d6d6e549b68a3997313790
