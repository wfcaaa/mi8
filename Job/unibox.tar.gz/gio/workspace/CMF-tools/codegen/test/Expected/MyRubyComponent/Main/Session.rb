# 
#***************************************************************************
#
# ZSession example weakObject
#
# Copyright by Verigy, 2010
#
# @file    Session.rb
#
# @author  Kirstin Weber
#
# @date    30 June 2010
#
#***************************************************************************
#

#
# This file is developer maintained.
# NOTE: You may edit this file between BEGIN EDITABLE SECTION and END
# EDITABLE SECTION. But don't edit it outside these comments, or your code
# _will_ be lost after a component regeneration.
#

# Use the following editable section for items required before the class
# definition
# ---- BEGIN EDITABLE SECTION HEADER ----

# ---- END EDITABLE SECTION HEADER ----

#
# A Ruby weakObject implementing a single interface

class Session < xoc.svc.session.ZSession

  # Interface xoc.svc.session.ZSession

  # Method of xoc.svc.session.ZSession
  def getSessionId()
    # ---- BEGIN EDITABLE SECTION getSessionId ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getSessionId ----
  end

  # Method of xoc.svc.session.ZSession
  def getVersion()
    # ---- BEGIN EDITABLE SECTION getVersion ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getVersion ----
  end

  # Method of xoc.svc.session.ZSession
  def getServiceURL(servicename)
    # ---- BEGIN EDITABLE SECTION getServiceURL ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getServiceURL ----
  end

  # Method of xoc.svc.session.ZSession
  def addProcess(processId, port, pid, callback)
    # ---- BEGIN EDITABLE SECTION addProcess ----
    returnValue = []
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION addProcess ----
  end

  # Method of xoc.svc.session.ZSession
  def removeProcess(processId, pid)
    # ---- BEGIN EDITABLE SECTION removeProcess ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION removeProcess ----
  end

  # Method of xoc.svc.session.ZSession
  def registerForShutdown(xComponent, level)
    # ---- BEGIN EDITABLE SECTION registerForShutdown ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION registerForShutdown ----
  end

  # Method of xoc.svc.session.ZSession
  def shutdown()
    # ---- BEGIN EDITABLE SECTION shutdown ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION shutdown ----
  end

  # Method of xoc.svc.session.ZSession
  def getDescription()
    # ---- BEGIN EDITABLE SECTION getDescription ----
    returnValue = ""
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION getDescription ----
  end

  # Method of xoc.svc.session.ZSession
  def unregisterForShutdown(xComponent)
    # ---- BEGIN EDITABLE SECTION unregisterForShutdown ----
    returnValue = false
    # // @todo TODO_AUTO_GENERATED
    return returnValue
    # ---- END EDITABLE SECTION unregisterForShutdown ----
  end

  # Method of xoc.svc.session.ZSession
  def validateProcesses()
    # ---- BEGIN EDITABLE SECTION validateProcesses ----
    # // @todo TODO_AUTO_GENERATED
    # ---- END EDITABLE SECTION validateProcesses ----
  end

  # Use this section to define additional class members
  # ---- BEGIN EDITABLE SECTION MEMBERS ----

  # ruby constructor initialize method
  def initialize

  end

  # ---- END EDITABLE SECTION MEMBERS ----

end  # ! Session

# Use the following editable section for items required after the class
# definition
# ---- BEGIN EDITABLE SECTION FOOTER ----

# ---- END EDITABLE SECTION FOOTER ----
