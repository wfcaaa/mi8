#ifndef _E689ACF2_0856_11E0_A894_D8D38581BDAC_ // ---- INCLUDE PROTECTION ----
#define _E689ACF2_0856_11E0_A894_D8D38581BDAC_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Additional (arbitrary) service used by unit tester
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    TesterService.hpp
 *
 * @author  Charles Halliday
 *
 * @date    15 Dec 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "MyClientUnitTesterBase.hpp"
#include <xoc/threads/Synchronization.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

namespace xoc_svc_misc {

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Additional (arbitrary) service used by unit tester
 */
class TesterService : public TesterServiceBase
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    TesterService( ::com::sun::star::uno::Reference< ::com::sun::star::uno::XComponentContext > const & xComponentContext);

    virtual ~TesterService();

    // Interface com.sun.star.lang.XInitialization

    // Method of com.sun.star.lang.XInitialization
    virtual void SAL_CALL
    initialize(
      const ::com::sun::star::uno::Sequence< ::com::sun::star::uno::Any >& aArguments )
      throw (
        ::com::sun::star::uno::Exception,
        ::com::sun::star::uno::RuntimeException );

    // Interface xoc.svc.xml.ZXMLReader

    // Method of xoc.svc.xml.ZXMLReader
    virtual void SAL_CALL
    parseFile(
      const ::rtl::OUString& filePath )
      throw (
        ::xoc::exc::ZRecoverable,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZXMLReader
    virtual void SAL_CALL
    parseString(
      const ::rtl::OUString& xmlString )
      throw (
        ::xoc::exc::ZRecoverable,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZXMLReader
    virtual void SAL_CALL
    parseStream(
      const ::com::sun::star::uno::Reference< ::com::sun::star::io::XInputStream >& inputStream )
      throw (
        ::xoc::exc::ZRecoverable,
        ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZXMLReader
    virtual void SAL_CALL
    setEntityResolver(
      const ::com::sun::star::uno::Reference< ::xoc::svc::xml::ZSAXEntityResolver >& resolver )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZXMLReader
    virtual void SAL_CALL
    setContentHandler(
      const ::com::sun::star::uno::Reference< ::xoc::svc::xml::ZSAXContentHandler >& handler )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZXMLReader
    virtual void SAL_CALL
    setErrorHandler(
      const ::com::sun::star::uno::Reference< ::xoc::svc::xml::ZSAXErrorHandler >& handler )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZXMLReader
    virtual void SAL_CALL
    setExitOnFirstFatalError(
      ::sal_Bool exitOnFirstFatalError )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of xoc.svc.xml.ZXMLReader
    virtual ::sal_Bool SAL_CALL
    getExitOnFirstFatalError()
      throw ( ::com::sun::star::uno::RuntimeException );

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  private:
    // Copy constructor
    TesterService(const TesterService & r);

    // Assignment operator
    TesterService&operator=(const TesterService & r);

  // ---- END EDITABLE SECTION MEMBERS ----

    // For com.sun.star.lang.XInitialization
    ::xoc::threads::Mutex mInitializedMutex;
    ::sal_Bool mInitialized;
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
