/** 
 ****************************************************************************
 *
 * An weak object that does not implement any interface.
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    ProvidesNothing.cpp
 *
 * @author  Charles Halliday
 *
 * @date    01 Aug 2005
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "ProvidesNothing.hpp"

#ifdef DEBUG_REFCOUNT
#include <unistd.h>
#endif

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::xoc_svc_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace xoc_svc_misc {

#ifdef DEBUG_REFCOUNT
   // XInterface method override, for debugging only
   void SAL_CALL ProvidesNothing::acquire()
     throw ()
   {
     ProvidesNothingImplHelper::acquire();
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount << " on exit");
   }

   void SAL_CALL ProvidesNothing::release()
     throw ()
   {
     // Need to log before calling release() otherwise
     // when ref count goes to 0, destructor is called before log
     XOC_DEBUG(__FUNCTION__
               << " pid=" << getpid()
               << " instance=0x" << std::hex << (void *)this << std::dec
               << " m_refCount->" << m_refCount - 1 << " on exit");
     ProvidesNothingImplHelper::release();
   }
#endif

  ProvidesNothing::~ProvidesNothing()
  {
    // ---- BEGIN EDITABLE SECTION ~ProvidesNothing ----

    // ---- END EDITABLE SECTION ~ProvidesNothing ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  ProvidesNothing::ProvidesNothing()
  {
  }


  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

