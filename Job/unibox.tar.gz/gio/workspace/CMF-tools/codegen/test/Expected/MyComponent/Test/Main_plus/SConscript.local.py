# Builds MyComponentUnitTester C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['MyComponentUnitTester'],
'CXXTEST_FILE' : ['hw_cor_HwIgnoreTests.hpp']
}

# **** CODE GENERATOR CHECKSUM 3fc60fcc5b6b5aa46453357c8997acc3
