/** 
 ****************************************************************************
 *
 * Explicit XComponent implementaion
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    ZSXComponentService.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Apr 2008
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include "ZSXComponentService.hpp"

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----
#include <xoc/zutils.hpp>

// ---- END EDITABLE SECTION INCLUDES ----

using namespace ::com::sun::star::lang;
using namespace ::com::sun::star::uno;
using namespace ::rtl;
using namespace ::xoc::exc;
using namespace ::xoc::svc;
using namespace ::xoc::svc::reflector;
using namespace ::xoc::svc::session;

// Use the following editable section for
// shared variables in anonymous namespace,
// additional using namespace statements
// ---- BEGIN EDITABLE SECTION UTILS ----

using namespace ::xoc;
namespace {
  using namespace ::svc_session_misc;

}

// ---- END EDITABLE SECTION UTILS ----

namespace svc_session_misc {

  ZSXComponentService::ZSXComponentService(
    Reference< XComponentContext > const & xComponentContext)
    : ZSXComponentServiceBase::ZSXComponentServiceBase(xComponentContext)
    // ---- BEGIN EDITABLE SECTION INITIALIZERS ----
    // ---- END EDITABLE SECTION INITIALIZERS ----
  {
    // ---- BEGIN EDITABLE SECTION ZSXComponentService ----

    // ---- END EDITABLE SECTION ZSXComponentService ----
  }

  ZSXComponentService::~ZSXComponentService()
  {
    // ---- BEGIN EDITABLE SECTION ~ZSXComponentService ----

    // ---- END EDITABLE SECTION ~ZSXComponentService ----
  }

  // Interface com.sun.star.lang.XComponent

  // Method of com.sun.star.lang.XComponent
  void SAL_CALL
  ZSXComponentService::dispose()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION dispose ----
    // WARNING: removing the base class method call may break the component
    ZSXComponentServiceBase::dispose();
    // ---- END EDITABLE SECTION dispose ----
  }

  // Method of com.sun.star.lang.XComponent
  void SAL_CALL
  ZSXComponentService::addEventListener(
    const Reference< XEventListener >& xListener )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION addEventListener ----
    // WARNING: removing the base class method call may break the component
    ZSXComponentServiceBase::addEventListener(xListener);
    // ---- END EDITABLE SECTION addEventListener ----
  }

  // Method of com.sun.star.lang.XComponent
  void SAL_CALL
  ZSXComponentService::removeEventListener(
    const Reference< XEventListener >& aListener )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION removeEventListener ----
    // WARNING: removing the base class method call may break the component
    ZSXComponentServiceBase::removeEventListener(aListener);
    // ---- END EDITABLE SECTION removeEventListener ----
  }

  // Interface com.sun.star.uno.XWeak

  // Method of com.sun.star.uno.XWeak
  Reference< XAdapter > SAL_CALL
  ZSXComponentService::queryAdapter()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION queryAdapter ----
    Reference< XAdapter > returnValue;
    // WARNING: removing the base class method call may break the component
    returnValue =
      ZSXComponentServiceBase::queryAdapter();
    return returnValue;
    // ---- END EDITABLE SECTION queryAdapter ----
  }

  // Interface xoc.svc.ZIDService

  // Method of xoc.svc.ZIDService
  sal_Int32 SAL_CALL
  ZSXComponentService::getId(
    const OUString& idString )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getId ----
    sal_Int32 returnValue = 0;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getId ----
  }

  // Method of xoc.svc.ZIDService
  OUString SAL_CALL
  ZSXComponentService::getString(
    sal_Int32 id )
    throw (
      ZParameterException,
      RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION getString ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION getString ----
  }

  // Interface xoc.svc.reflector.ZEcho

  // Method of xoc.svc.reflector.ZEcho
  OUString SAL_CALL
  ZSXComponentService::echo(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION echo ----
    OUString returnValue;
    // @todo TODO_AUTO_GENERATED
    return returnValue;
    // ---- END EDITABLE SECTION echo ----
  }

  // Method of xoc.svc.reflector.ZEcho
  void SAL_CALL
  ZSXComponentService::print(
    const OUString& s )
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION print ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION print ----
  }

  // Interface xoc.svc.session.ZSessionLifecycle

  // Method of xoc.svc.session.ZSessionLifecycle
  void SAL_CALL
  ZSXComponentService::sbsInitialize()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION sbsInitialize ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION sbsInitialize ----
  }

  // Method of xoc.svc.session.ZSessionLifecycle
  void SAL_CALL
  ZSXComponentService::sbsShutdown()
    throw ( RuntimeException )
  {
    // ---- BEGIN EDITABLE SECTION sbsShutdown ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION sbsShutdown ----
  }

  // Additional class member implementations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

  // ---- END EDITABLE SECTION MEMBERS ----

} // namespace close

