# Builds MyComponent C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['MyComponent']
}
# **** CODE GENERATOR CHECKSUM 138e45b5dfc29eef8b93a4f498fc2a51
