#ifndef _14D703F4_6836_11DB_9218_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
#define _14D703F4_6836_11DB_9218_000F203BFBA8_ // ---- INCLUDE PROTECTION ----
/** 
 ****************************************************************************
 *
 * Interface uses UNO types defined as typedefs 
 *
 * Copyright by Verigy Germany GmbH, 2006
 *
 * @file    TypedefExample.hpp
 *
 * @author  Charles Halliday
 *
 * @date    30 Oct 2006
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

#include <cppuhelper/implbase1.hxx>
#include <com/sun/star/uno/RuntimeException.hpp>

#include <foobar/ZTypedefExample.hpp>

// Use the following editable section for #includes etc.
// ---- BEGIN EDITABLE SECTION INCLUDES ----

// ---- END EDITABLE SECTION INCLUDES ----

// Enable following line to log weakObject reference counts
//#define DEBUG_REFCOUNT

namespace foobar {
typedef ::cppu::WeakImplHelper1<
  ::foobar::ZTypedefExample
  > TypedefExampleImplHelper;

// Use the following editable section for
// using directives to keep type names short
// ---- BEGIN EDITABLE SECTION USING ----

// ---- END EDITABLE SECTION USING ----

/**
 * Interface uses UNO types defined as typedefs
 */
class TypedefExample :
    public TypedefExampleImplHelper
  // ---- BEGIN EDITABLE SECTION EXTENDS ----
  // ---- END EDITABLE SECTION EXTENDS ----
  {

  public:

    // Interface foobar.ZTypedefExample

    // Method of foobar.ZTypedefExample
    virtual void SAL_CALL
    setVersionId(
      ::sal_Int32 versionId )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTypedefExample
    virtual ::sal_Int32 SAL_CALL
    getVersionId()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTypedefExample
    virtual void SAL_CALL
    updateVersionId(
      ::sal_Int32& versionId )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTypedefExample
    virtual ::com::sun::star::uno::Sequence< ::sal_Int32 > SAL_CALL
    cloneVersionIdList(
      const ::com::sun::star::uno::Sequence< ::sal_Int32 >& versionIdArray )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTypedefExample
    virtual void SAL_CALL
    setAnotherVersionId(
      ::sal_Int32 anotherVersionId )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTypedefExample
    virtual ::sal_Int32 SAL_CALL
    getAnotherVersionId()
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTypedefExample
    virtual void SAL_CALL
    updateAnotherVersionId(
      ::sal_Int32& anotherVersionId )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTypedefExample
    virtual ::com::sun::star::uno::Sequence< ::sal_Int32 > SAL_CALL
    cloneAnotherVersionIdList(
      const ::com::sun::star::uno::Sequence< ::sal_Int32 >& anotherVersionIdArray )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTypedefExample
    virtual double SAL_CALL
    mapValue(
      double value )
      throw ( ::com::sun::star::uno::RuntimeException );

    // Method of foobar.ZTypedefExample
    virtual ::com::sun::star::uno::Sequence< double > SAL_CALL
    cloneValueSequence(
      const ::com::sun::star::uno::Sequence< double >& valueSequence )
      throw ( ::com::sun::star::uno::RuntimeException );

#ifdef DEBUG_REFCOUNT
    // XInterface overridden methods, for debugging only
    virtual void SAL_CALL acquire() throw ();
    virtual void SAL_CALL release() throw ();
#endif

    virtual ~TypedefExample();

  // Constructors and additional class member declarations
  // ---- BEGIN EDITABLE SECTION MEMBERS ----

    TypedefExample();

  private:
    // Copy constructor
    TypedefExample(const TypedefExample & r);

    // Assignment operator
    TypedefExample&operator=(const TypedefExample & r);

  // ---- END EDITABLE SECTION MEMBERS ----
  };

// Use the following editable section for
// class dependent declarations, templates etc.
// ---- BEGIN EDITABLE SECTION ADDITIONS ----

// ---- END EDITABLE SECTION ADDITIONS ----

} // namespace close


#endif  // ---- INCLUDE PROTECTION ----
