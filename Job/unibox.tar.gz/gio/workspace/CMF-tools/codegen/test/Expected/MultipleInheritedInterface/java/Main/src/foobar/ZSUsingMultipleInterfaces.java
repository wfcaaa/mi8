/** 
 ****************************************************************************
 *
 * 
 *
 * Copyright by Verigy Germany GmbH, 2010
 *
 * @file    ZSUsingMultipleInterfaces.java
 *
 * @author  Kirstin Weberr
 *
 * @date    17 Mar 2010
 *
 ****************************************************************************
 */

/*****************************************************************************
 * This file is developer maintained.                                        *
 * NOTE: You may edit this file between BEGIN EDITABLE SECTION and END       *
 * EDITABLE SECTION. But don't edit it outside these comments, or your code  *
 * _will_ be lost after an component regeneration.                           *
 *****************************************************************************/

package foobar.MultipleInheritedInterface;

import com.sun.star.lang.XInitialization;
import com.sun.star.uno.Exception;
import com.sun.star.uno.XComponentContext;
import foobar.ZBar;
import foobar.ZFoo;
import foobar.ZTestChild;
import foobar.ZTestSuper1;
import foobar.ZTestSuper2;
import foobar.ZTestSuperSuper1;
import xoc.hw.cor.description.ZHwSpecifierAnalyzer;
import xoc.hw.cor.description.ZHwSpecifierType;
import xoc.hw.cor.pogocabling.ZPogoCabling;
import org.apache.log4j.Logger;
import xoc.svc.misc.SystemLoggerHelper;

// Use the following editable section for
// local import statements and type definitions
// ---- BEGIN EDITABLE SECTION IMPORTS_TYPES ----

// ---- END EDITABLE SECTION IMPORTS_TYPES ----

/**
 * 
 */

public class ZSUsingMultipleInterfaces
  extends foobar.MultipleInheritedInterface.ZSUsingMultipleInterfacesBase
  implements
    XInitialization,
    ZTestChild
  // ---- BEGIN EDITABLE SECTION IMPLEMENTS ----
  // ---- END EDITABLE SECTION IMPLEMENTS ----
{
  private Logger logger =
    SystemLoggerHelper.getSystemLogger("foobar_MultipleInheritedInterface");

  private boolean mInitialized = false;

  // Use the following editable section for
  // implementation class fields and initializers
  // ---- BEGIN EDITABLE SECTION FIELDS_INITIALIZERS ----

  // ---- END EDITABLE SECTION FIELDS_INITIALIZERS ----

  public ZSUsingMultipleInterfaces(XComponentContext xComponentContext)
  {
    super(xComponentContext);
    // ---- BEGIN EDITABLE SECTION ZSUsingMultipleInterfaces ----

    // ---- END EDITABLE SECTION ZSUsingMultipleInterfaces ----
  }

  // Interface com.sun.star.lang.XInitialization

  // Method of com.sun.star.lang.XInitialization
  public void initialize(Object[] aArguments)
    throws Exception
  {
    // ---- BEGIN EDITABLE SECTION initialize ----
    synchronized (this) {
      if ( ! mInitialized ) {
        mInitialized = true;
        // @todo TODO_AUTO_GENERATED
      }
    }
    // ---- END EDITABLE SECTION initialize ----
  }

  // Interface foobar.ZTestChild

  // Method of foobar.ZTestChild
  public void function3(ZFoo foo)
  {
    // ---- BEGIN EDITABLE SECTION function3 ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION function3 ----
  }

  // Method of foobar.ZTestChild
  public void function1(ZBar bar)
  {
    // ---- BEGIN EDITABLE SECTION function1 ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION function1 ----
  }

  // Method of foobar.ZTestChild
  public void function4(ZBar bar)
  {
    // ---- BEGIN EDITABLE SECTION function4 ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION function4 ----
  }

  // Method of foobar.ZTestChild
  public void function2(ZPogoCabling pogoCabling,
                        ZHwSpecifierType hwSpecifierType)
  {
    // ---- BEGIN EDITABLE SECTION function2 ----
    // @todo TODO_AUTO_GENERATED
    // ---- END EDITABLE SECTION function2 ----
  }

  // Use the following editable section for
  // implementation class methods and internal class definitions
  // ---- BEGIN EDITABLE SECTION METHODS_CLASSES ----

  // ---- END EDITABLE SECTION METHODS_CLASSES ----

} // !  ZSUsingMultipleInterfaces
