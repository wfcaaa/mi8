# Builds MyClient C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['utility_library'] ,
'NAME' : ['MyClient']
}
# **** CODE GENERATOR CHECKSUM a59c2b499179e673731b0190fc6d1df4
