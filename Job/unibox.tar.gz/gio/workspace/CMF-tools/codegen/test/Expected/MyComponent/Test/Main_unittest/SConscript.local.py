# Builds MyComponentUnitTester C++ Implementation
# 
# Developer maintained file, initial version is created by component generator
#
{
'PROJECT_TYPE' : ['cpp_component'] ,
'NAME' : ['MyComponentUnitTester']
}
# **** CODE GENERATOR CHECKSUM 8626fba3225622b7fd1b8ac5418e239e
