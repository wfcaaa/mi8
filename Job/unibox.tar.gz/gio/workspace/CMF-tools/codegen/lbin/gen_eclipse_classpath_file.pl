#!/usr/bin/perl -w

# Create .project file for eclipse
# NOT USED, FILE KEPT IN CASE NEEDED IN FUTURE

package main;

use strict;
use Getopt::Long;
use FileHandle;
use File::Basename;
use File::Path;

sub usage
{
    print STDERR "Usage:\n";
    print STDERR "$0 [-help] -out target_file_path -file filename definition_file\n";
    print STDERR "   -out target_file_path is file to generate\n";
    print STDERR "   -file filename name of file to be generated (not used)\n";
    print STDERR "   definition_file is xml file containing component definition\n";
}

my $classpathFileSkeleton =
'<?xml version="1.0" encoding="UTF-8"?>
<classpath>
	<classpathentry kind="src" path="src"/>
	<classpathentry kind="con" path="org.eclipse.jdt.launching.JRE_CONTAINER"/>
	<classpathentry kind="lib" path="classes"/>
	<classpathentry kind="lib" path="/usr/share/java/log4j.jar"/>
	<classpathentry kind="lib" path="/vobs/zenith/workspace/services/session/SessionServiceManagerJava/SessionServiceManager.jar"/>
	<classpathentry kind="lib" path="/vobs/zenith/workspace/services/misc/SystemLoggerHelperJava/SystemLoggerHelper.jar"/>
	<classpathentry kind="lib" path="XOC_UNO_JAVA_DIR/java_uno.jar"/>
	<classpathentry kind="lib" path="XOC_UNO_JAVA_DIR/juh.jar"/>
	<classpathentry kind="lib" path="XOC_UNO_JAVA_DIR/jurt.jar"/>
	<classpathentry kind="lib" path="XOC_UNO_JAVA_DIR/ridl.jar"/>
	<classpathentry kind="lib" path="XOC_UNO_JAVA_DIR/unoloader.jar"/>
	<classpathentry kind="output" path="classes"/>
</classpath>
';
my $helpOpt = 0;
my $cdefFile = "";
my $outOpt   = "";
my $fileOpt  = "";
my $projectNameOpt = "";
&GetOptions("help|h!"  => \$helpOpt,
            "out=s"  => \$outOpt,
            "file=s" => \$fileOpt )
  or die; 

if ( $helpOpt) {
    &usage ;
    exit 1;
}

if ( @ARGV > 0 ) {
  $cdefFile = shift @ARGV;
}

if (length $outOpt == 0 ) {
  print STDERR "Missing mandatory -out option\n";
  exit 1;
}
if (length $fileOpt == 0 ) {
  print STDERR "Missing mandatory -file option\n";
  exit 1;
}

my $classpathFile = $classpathFileSkeleton;
my $urePath = ${ENV}{"XOC_UNO_JAVA_DIR"};
if ( $urePath ) {
  $classpathFile =~ s/XOC_UNO_JAVA_DIR/$urePath/g;
}
else {
  print STDERR "WARNING: XOC_UNO_RE_DIR not defined, you must modify XOC_UNO_JAVA_DIR in "
    . $fileOpt . " manually\n";
}
my $fh = new FileHandle "$outOpt", "w";
if (defined $fh) {
  print $fh $classpathFile;
  $fh->close();
}
else {
  die "$0: Cannot open file for writing: $outOpt\n";
}

