#!/usr/bin/perl -w
#

# Generates all the merge files dependent on UNO registries
# for Java component code generation:
#  Java import statements for dependent interfaces
#  Java service and weakObject method implementations for .java
#
# This script is dependent on the path for merge files in the
# output from the xslt generated code.
#


package main;

use strict;
use Getopt::Long;
use FileHandle;
use File::Basename;
use File::Path;

use lib &dirname($0). "/perlm";
use XML::LibXML;

use RegviewParser;
use RegviewTypesDb;
use RegviewUtils;

use Codegen::Utils;
use Codegen::JavaUtils;
use Codegen::JavaMethods;
use Cdef;

my @javaServiceBaseInterfaces =
  ( "com.sun.star.lang.XComponent",
    "com.sun.star.lang.XServiceInfo",
    "com.sun.star.lang.XTypeProvider",
    "com.sun.star.uno.XWeak",
    "com.sun.star.uno.XInterface",
    );
my @javaWeakObjectBaseInterfaces =
  ( "com.sun.star.lang.XComponent",
    "com.sun.star.lang.XTypeProvider",
    "com.sun.star.uno.XWeak",
    "com.sun.star.uno.XInterface",
    );

my $optHelp       = 0;
my $optDebug      = 0; # DEBUG printout
my $optShortNames = 1;
my $optOutdir     = "";
my $optVerbose    = 0;
my @optImplNames  = ();
my @optRdbFiles   = ();
my $cdefFile      = "";

&getCommandLineOptions;

&verbosePrintln ("Generating rdb dependent files");
# Collect general information on all types in rdbs.
my $rdbTypeDefDb = RegviewTypesDb->new(@optRdbFiles);
$rdbTypeDefDb->addAllTypes;
my $javaUtils     = Codegen::JavaUtils->new($rdbTypeDefDb);
# Load component definition file
my $cdef         = Cdef->new($cdefFile);

my @serviceNames = ();
my @weakObjects  = ();
if (@optImplNames) {
  foreach my  $optImplName (@optImplNames) {
    if ( $cdef->isService($optImplName) ) {
      push @serviceNames, $optImplName;
    }
    else {
      push @weakObjects, $optImplName;
    }
  }
}
else {
  @serviceNames = $cdef->getServiceNames();
  @weakObjects  = $cdef->getWeakObjectNames();
}

# Output imports and method stubs merge files
my %seenMethodsHash = ();
foreach my $name ( @serviceNames ) {
  &verbosePrintln("... for service $name");

  &checkImplementation($name);  # Ensure have consistent data
  &outputImportMergeFile($name);

  %seenMethodsHash = ();
  &outputInterfaceMethodStubs($name,\%seenMethodsHash);

}

foreach my $name ( @weakObjects ) {
  &verbosePrintln("... for weakObject $name");

  &checkImplementation($name);  # Ensure have consistent data
  &outputImportMergeFile($name);
  %seenMethodsHash = ();
  &outputInterfaceMethodStubs($name,\%seenMethodsHash);
}


### Methods

# Output namespace .import merge file for single service or weakObject
#
# arg1 service or weakObject name
sub outputImportMergeFile
{
  my $name = shift;

  my $className = $cdef->getImplementationClassName($name);
  my $baseClassName = $cdef->getBaseClassName($name);
  my $fileDir  = $optOutdir;
  mkpath([$fileDir]);

  my $importFilePath = $fileDir . "/" . $className . ".import";
  debugPrintln("Creating $name imports in $importFilePath");

  my $importStatements = &getImportStatements($name );
  my $fh = new FileHandle "$importFilePath", "w";
  if (defined $fh) {
    print $fh $importStatements;
    $fh->close();
  }
  else {
    die "$0: Cannot open file for writing: $importFilePath\n";
  }

} # ! outputImportMergeFile

# Output interface method stubs for a single interface
# arg 1 interface name
# arg 2 optional reference to hash containing seen methods and their first interface
sub outputInterfaceMethodStubs
{
  my $name = shift;
  my $seenMethodsRef = 0;
  $seenMethodsRef = shift if @_;

  my $className     = $cdef->getImplementationClassName($name);
  my $baseClassName = $cdef->getBaseClassName($name);
  my $category      = $cdef->getImplementationCategory($name);

  # Prepare generator
  my $javaMethods
    = Codegen::JavaMethods->new($rdbTypeDefDb,
                                $className,$baseClassName);
  $javaMethods->setCategory($category);
  $javaMethods->setIsService($cdef->isService($name));
  $javaMethods->setIndent("  ");
  $javaMethods->setSeenMethodsHashRef($seenMethodsRef);
  $javaMethods->setUseShortNames($optShortNames);

  my $fileDir  = $optOutdir;

  my @provides = $cdef->getProvidesForName($name);
  &debugPrintln("$name provides");
  &debugPrintln(@provides);
  foreach my $ifName ( @provides ) {
    my $interface;
    &debugPrintln("Creating $name interface $ifName method stubs");
    
    my $stubCode = $javaMethods->getMethodImplementations($ifName);
    
    my $stubFilePath  = $fileDir . "/" . &toSlashPath($ifName) . ".stubs";
    mkpath([dirname($stubFilePath)]);

    &debugPrintln("stubFilePath=$stubFilePath");

    my $fh = new FileHandle "$stubFilePath", "w";
    if (defined $fh) {
      print $fh $stubCode;
      $fh->close();
    }
    else {
      die "$0: Cannot open file for writing: $stubFilePath\n";
    }
  }

} # ! outputInterfaceMethodStubs

## Local functions

# Returns string containing Java import statements for service or weakObject
# arg1 service or weakObject name
sub getImportStatements
{
  my $name     = shift;

  my $importStatements = "";

  my $className = $cdef->getImplementationClassName($name);

  my @provides = $cdef->getProvidesForName($name);
  my @uses     = $cdef->getUsesForName($name);

  my @allUnoTypes        = ( @provides, @uses );

  my %dependentTypesHash = ();
  foreach my $unoType ( @allUnoTypes ) {
    &addDependentTypesForInterface($unoType, \%dependentTypesHash);
  }

  &debugPrintln("$className dependentTypesHash=");
  &debugPrintln(sort keys %dependentTypesHash);

  my %importsHash =  (); # Collects imports from types
  # Service needs XComponentContext for constructor
  $cdef->isService($name)
    and $importsHash{"com.sun.star.uno.XComponentContext"} = 1;

  foreach my $key (sort keys %dependentTypesHash) {
    my $unoTypeName =
      $rdbTypeDefDb->getResolvedTypeName(&removeArraysFromType($key));
    my $javaType   = &unoToJavaType($unoTypeName);

    # Exclude primitives and java.lang. members
    if ($javaType =~ m/\./ 
        && $javaType !~ m/^java\.lang\.[^.]+$/ ) {
      $importsHash{$javaType} = 1;
    }

    # Exclude own class name
    delete $importsHash{$className} if exists $importsHash{$className};
  }

  foreach my $import ( sort keys %importsHash ) {
    $importStatements .= "import ${import};" . "\n";
  }

  %dependentTypesHash = ();
  %importsHash = ();
  return $importStatements;
} # getImportStatements

# add all dependent types for an interface including its ancestors
# to a hash
# arg1 UNO type name
# arg 2 reference to hash containing the types
sub addDependentTypesForInterface
{
  my $unoTypeName = shift;
  my $hashRef     = shift;
  my @typeName = $unoTypeName;
  
  while (@typeName > 0) {
    my @dependentTypesList =
      $rdbTypeDefDb->getDependentTypes($typeName[0]);
    foreach my $dependentTypeName (@dependentTypesList) {
      $hashRef->{$dependentTypeName} = 1;
    }
    if ( $rdbTypeDefDb->isTypeAnInterface($typeName[0]) ) {
      my @parent = $rdbTypeDefDb->getParentTypeNames($typeName[0]);
      shift @typeName; # remove already handled interface
      unshift @typeName, @parent; # add parents because they must be handled, too      
    }
    else {
      shift @typeName; # remove already handled interface
    }
  }
} # ! addDependentTypesForInterface

# Check implementation for valid interfaces etc.
# arg 1 service or weakObject name
# Dies if fails validation
sub checkImplementation
{
  my $name = shift;
  my @interfaces = ();
  if ( $cdef->isService($name) ) {
    @interfaces = (@javaServiceBaseInterfaces,
                   $cdef->getProvidesForName($name));
  }
  else {
    @interfaces = (@javaWeakObjectBaseInterfaces,
                   $cdef->getProvidesForName($name));
  }

  my $errorMessage =
    $rdbTypeDefDb->checkInterfacesForImplementation(@interfaces);

  $errorMessage and die "ERROR: $name: $errorMessage\n";

} # checkImplementation

# Prints args on separate line, if $optVerbose is set
sub verbosePrintln
{
  if ( $optVerbose ) {
    foreach my $line ( @_ ) {
      print STDOUT "$line\n";
    }
  }
} # verbosePrintln

# Prints args on separate line, if $optDebug is set
sub debugPrintln
{
  if ( $optDebug ) {
    foreach my $line ( @_ ) {
      print STDOUT "DEBUG: $line\n";
    }
  }
} # debugPrintln


# Checks options etc
# exits with non-zero value if any error
sub getCommandLineOptions
{
  my $optFullnames=0;

  &GetOptions("-outdir=s"  => \$optOutdir,
              "-verbose"   => \$optVerbose,
              "-rdb=s"     => \@optRdbFiles,
              "-impl=s"    => \@optImplNames,
              "-fullnames" => \$optFullnames,
              "-help!"     => \$optHelp)
    or die ;

  if ( @ARGV > 0 ) {
    $cdefFile = shift @ARGV;
  }
  else {
    print STDERR "Missing cdef file\n";
    &usage ;
    exit 1;
  }
  if ( @optRdbFiles == 0 ) {
    print STDERR "Missing rdb file(s)\n";
    &usage ;
    exit 1;
  }
  if ( $optHelp) {
    &usage ;
    exit 1;
  }

  $optFullnames
    and $optShortNames = 0;
  if ( ! $optOutdir ) {
    print STDERR "Missing -outdir option\n";
    &usage ;
    exit 1;
  }

  if ( ! $cdefFile ) {
    print STDERR "Missing cdef file\n";
    &usage ;
    exit 1;
  }

} # ! getCommandLineOptions

sub usage
{
  print STDERR "Usage:\n";
  print STDERR "$0 [-help] [-verbose] [-impl name]... -outdir outdir -rdb rdbfile... cdefFile \n";
  print STDERR "  -outdir outdir output directory for generated files\n";
  print STDERR "  -impl name service or weakObject, restricts output to given name\n";
  print STDERR "  -rdb rdbfile\n";
  print STDERR "  cdefFile component definition file\n";
  print STDERR "  rdbfile is UNO rdb containing interface types (tried in order)\n";
  print STDERR "  -verbose prints information on progress\n";
  print STDERR "Typical usage:\n";
  print STDERR "$0 -outdir Main/tmp_codegen -rdb \$WORKSPACE/IDL/zenith.rdb MyComponent.cdef\n";
}
