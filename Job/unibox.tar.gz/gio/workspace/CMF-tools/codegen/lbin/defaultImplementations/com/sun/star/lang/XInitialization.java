/**
 ****************************************************************************
 *
 * Default implementation of interface com.sun.star.lang.XInitialization
 *
 * Code between EDITABLE sections for a method will be
 * placed in the generated file.
 * Other methods will have the default implementaion
 *
 * __CLASS_NAME__ will be replaced by the actual implementation class name
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    XInitialization.java
 *
 * @author  Charles Halliday
 *
 * @date    11 Sep 2008
 *
 ****************************************************************************
 */

    // ---- BEGIN EDITABLE SECTION initialize ----
    synchronized (this) {
      if ( ! mInitialized ) {
        mInitialized = true;
        // @todo TODO_AUTO_GENERATED
      }
    }
    // ---- END EDITABLE SECTION initialize ----
