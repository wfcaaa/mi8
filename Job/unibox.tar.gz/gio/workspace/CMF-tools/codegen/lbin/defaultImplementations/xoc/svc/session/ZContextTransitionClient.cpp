/**
 ****************************************************************************
 *
 * Default implementation of interface xoc.svc.session.ZContextTransitionClient
 *
 * Code between EDITABLE sections for a method will be
 * placed in the generated file.
 * Other methods will have the default implementaion
 *
 * __CLASS_NAME__ will be replaced by the actual implementation class name
 *
 * Copyright by Verigy Germany GmbH, 2008
 *
 * @file    ZContextTransitionClient.cpp
 *
 * @author  Charles Halliday
 *
 * @date    11 Sep 2008
 *
 ****************************************************************************
 */

    // ---- BEGIN EDITABLE SECTION getPrecedenceSpecification ----
    // @todo TODO_AUTO_GENERATED Default implementation returns own service name
    Sequence< OUString > seqServiceName =
      getSupportedServiceNames();
    XOC_ASSERT(seqServiceName.getLength() == 1);

    return seqServiceName[0];
    // ---- END EDITABLE SECTION getPrecedenceSpecification ----
