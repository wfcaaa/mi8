#!/usr/bin/perl

# Tool to merge existing editable sections with a template file
# See usage()

use strict;
use Getopt::Long;

if ( $ARGV[0] eq '-h' ) {
  &usage;
  exit 0;
}

if ( @ARGV != 2 ) {
  &usage();
  die("You have to provide exactly two filenames, not ".@ARGV.", stopped");
}

my $editableSectionsFile = $ARGV[0]; # File with EDITABLE SECTIONS to merge
my $templateFile = $ARGV[1];         # Template file with new fixed content

my %editableContent; # $editableContent{key} contains the editable content for section with key
my %foundInESFile;   # $foundInESFile{key} set if key in editableSectionsFile
my %foundInTemplate; # $foundInTemplate{key} set if key in templateFile

&collect;
&merge;


sub usage
{
  print STDERR "Usage:\n" .
      "$0 [-h] editableSectionsFile templateFile\n" .
      "where:\n" .
      "  -h displays this usage\n" .
      "  editableSectionsFile file containing editable sections to be\n" .
      "    merged into the template code\n" .
      "  templateFile file with main code required and default editable sections\n" .
      "Merges editable sections in editableSectionsFile with templateFile and\n" .
      "  outputs the result to stdout\n" .
      "Editable sections are marked with line pairs of the following form,\n" .
      "  set in comments appropriate to the implementation language,\n" .
      "   ---- BEGIN EDITABLE SECTION <key> ----\n" .
      "   ---- END EDITABLE SECTION <key> ----\n" .
      "editableSectionsFile may be in DOS format (from rose round trip)\n" .
      "Don't call this by hand. It is used by the code generation scripts\n" ;
}

sub warning
{
  print STDERR "Warning: @_\n";
}

sub collect
{
  my $beginKey= "";
  my $inEditableSection = 0;

  my $fileSpec = "cat $editableSectionsFile | dos2unix |";
  open(EDITABLE_SECS,"$fileSpec")
      or die "$editableSectionsFile: $!";
  while(<EDITABLE_SECS>) {
    if ( m/ ---- BEGIN EDITABLE SECTION (.*) ----( *$| )/ ) {
      $inEditableSection and
        die "\"BEGIN EDITABLE SECTION $1\" found in open \"BEGIN EDITABLE SECTION $beginKey\" at line $. in $editableSectionsFile.\n";
      $beginKey = $1;
      defined $foundInESFile{$beginKey} and
        die "Duplicate EDITABLE SECTION $beginKey found at line $. in $editableSectionsFile.\n";
      $foundInESFile{$beginKey} = 1;
      $inEditableSection = 1;
      next;
    }
    elsif ( m/ ---- END EDITABLE SECTION (.*) ----( *$| )/ ) {
      my $endKey = $1;
      $inEditableSection or
        die "Got \"END EDITABLE SECTION $endKey\"outside EDITABLE SECTION at line $. in $editableSectionsFile\n";
      $endKey eq $beginKey or
        die "Mismatching \"BEGIN EDITABLE SECTION BEGIN $beginKey\", and \"END EDITABLE SECTION $endKey\" at line $. in $editableSectionsFile\n";
      $inEditableSection = 0;
      $beginKey = "";
      next;
    }
    else {
      if ( $inEditableSection ) {
        $editableContent{$beginKey} .= $_;
      }
    }
  }
  close(EDITABLE_SECS);
  $inEditableSection and
    die "\"BEGIN EDITABLE SECTION $beginKey\" still open at end of file in $editableSectionsFile\n";
  %foundInESFile or
    die "No EDITABLE SECTION found in $editableSectionsFile.\n";
} # ! collect

sub merge
{
  my $key = "";

  open(TEMPLATE,"<$templateFile")
    || die "Couldn't open file $templateFile: $!\n";
  while(<TEMPLATE>) {
    if ( m/ ---- BEGIN EDITABLE SECTION (.*) ----( *$| )/ ) {
      $key = $1;
      defined $foundInTemplate{$key} and
          die "Another EDITABLE SECTION $1 found at line $. in $templateFile.\n";
      $foundInTemplate{$key} = 1;
      print;
      if ( defined $foundInESFile{$key} ) {
        print $editableContent{$key};
      }
      next;
    }
    elsif ( m/ ---- END EDITABLE SECTION (.*) ----( *$| )/ ) {
      if ( ! $key ) {
        print STDERR ;
        die "Found END for key $key without BEGIN at line $. in $templateFile.\n";
      }
      $key = "";
      print;
      next;
    }
    else {
      if ( ! $key
           || ! $foundInESFile{$key} ) {
        print;
      }
    }
  }
  close(TEMPLATE);
  
  # check if something was found in the Editable sections file,
  # but is missing in template file
  my $key;
  foreach $key ( keys %foundInESFile ) {
    if ( ! defined $foundInTemplate{$key} ) {
      warning("EDITABLE SECTION $key found in your code, but is removed now. You might have lost some source code.");
    }
  }
} # ! merge
