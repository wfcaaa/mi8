#!/usr/bin/perl -w

# Create .project file for eclipse
# NOT USED, FILE KEPT IN CASE NEEDED IN FUTURE

package main;

use strict;
use Getopt::Long;
use FileHandle;
use File::Basename;
use File::Path;

use lib &dirname($0). "/perlm";
use Cdef;

sub usage
{
    print STDERR "Usage:\n";
    print STDERR "$0 [-help] -out target_file_path -file filename definition_file\n";
    print STDERR "   -out target_file_path is file to generate\n";
    print STDERR "   -file filename name of file to be generated\n";
    print STDERR "   definition_file is xml file containing component definition\n";
}

my $projectFileSkeleton =
"<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<projectDescription>
  <name>__NAME__</name>
  <comment></comment>
  <projects>
  </projects>
  <buildSpec>
    <buildCommand>
      <name>org.eclipse.jdt.core.javabuilder</name>
      <arguments>
      </arguments>
    </buildCommand>
  </buildSpec>
  <natures>
    <nature>org.eclipse.jdt.core.javanature</nature>
  </natures>
</projectDescription>
";
my $helpOpt = 0;
my $cdefFile = "";
my $outOpt   = "";
my $fileOpt  = "";
my $projectNameOpt = "";
&GetOptions("help|h!" => \$helpOpt,
            "out=s"   => \$outOpt,
            "file=s"  => \$fileOpt )
  or die; 

if ( $helpOpt) {
    &usage ;
    exit 1;
}

if ( @ARGV > 0 ) {
  $cdefFile = shift @ARGV;
}
else {
  print STDERR "Missing cdef file\n";
  &usage ;
  exit 1;
}

my $cdef         = Cdef->new($cdefFile);

if (length $outOpt == 0 ) {
  print STDERR "Missing mandatory -out option\n";
  exit 1;
}

my $projectName = $cdef->getComponentName();
my $projectFile = $projectFileSkeleton;
$projectFile =~ s/__NAME__/$projectName/g;

my $fh = new FileHandle "$outOpt", "w";
if (defined $fh) {
  print $fh $projectFile;
  $fh->close();
}
else {
  die "$0: Cannot open file for writing: $outOpt\n";
}

