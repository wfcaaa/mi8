#!/usr/bin/perl -w
#

# Generates all the merge files dependent on UNO registries
# for C++ component code generation:
#  C++ service and weakObject methods declarations for .hpp
#  using namespace statements for .cpp
#  C++ service and weakObject methods implementations for .cpp
# For ruby category:
#  C++-Ruby bridge for service implementations for .cpp
#  Ruby service implementations for .rb
#
# This script is dependent on the path for merge files in the
# output from the xslt generated code.
#


package main;

use strict;
use Getopt::Long;
use FileHandle;
use File::Basename;
use File::Path;

use lib &dirname($0). "/perlm";
use XML::LibXML;

use RegviewParser;
use RegviewTypesDb;
use RegviewUtils;

use Codegen::Utils;
use Codegen::CppUtils;
use Codegen::CppMethods;
use Codegen::RubyMethods;
use Cdef;

my @cppServiceBaseInterfaces =
  ( "com.sun.star.lang.XComponent",
    "com.sun.star.lang.XServiceInfo",
    "com.sun.star.lang.XTypeProvider",
    "com.sun.star.uno.XWeak",
    "com.sun.star.uno.XInterface",
    );
my @cppWeakObjectBaseInterfaces =
  ( "com.sun.star.lang.XComponent",
    "com.sun.star.lang.XTypeProvider",
    "com.sun.star.uno.XWeak",
    "com.sun.star.uno.XInterface",
    );

my $optHelp       = 0;
my $optDebug      = 0;
my $optShortNames = 1;
my $optOutdir     = "";
my $optVerbose    = 0;
my @optImplNames  = ();
my @optRdbFiles   = ();
my $cdefFile      = "";

&getCommandLineOptions;

&verbosePrintln ("Generating rdb dependent files");
# Collect general information on all types in rdbs.
my $rdbTypeDefDb = RegviewTypesDb->new(@optRdbFiles);
$rdbTypeDefDb->addAllTypes;
my $cppUtils     = Codegen::CppUtils->new($rdbTypeDefDb);
# Load component definition file
my $cdef         = Cdef->new($cdefFile);

my @serviceNames = ();
my @weakObjects  = ();
if (@optImplNames) {
  foreach my  $optImplName (@optImplNames) {
    if ( $cdef->isService($optImplName) ) {
      push @serviceNames, $optImplName;
    }
    else {
      push @weakObjects, $optImplName;
    }
  }
}
else {
  @serviceNames = $cdef->getServiceNames();
  @weakObjects  = $cdef->getWeakObjectNames();
}

# Output namespace, method declarations and method stubs merge files
my %seenMethodsHash = ();
my %seenMethodDeclsHash = ();
my %seenRubyMethodsHash = ();
foreach my $name ( @serviceNames ) {
  &verbosePrintln("... for service $name");

  &checkImplementation($name);  # Ensure have consistent data

  &outputNamespaceMergeFile($name);

  %seenMethodsHash = ();
  &outputInterfaceMethodStubs($name,\%seenMethodsHash);

  %seenMethodDeclsHash = ();
  &outputInterfaceMethodDeclarations($name,\%seenMethodDeclsHash);

  my $category = $cdef->getImplementationCategory($name);
  if ( $category eq "ruby" ) {
    %seenRubyMethodsHash = ();
    &outputRubyInterfaceMethodStubs($name,\%seenRubyMethodsHash);
  }
}

foreach my $name ( @weakObjects ) {
  &verbosePrintln("... for weakObject $name");

  &checkImplementation($name);  # Ensure have consistent data

  my $category = $cdef->getImplementationCategory($name);
  if ( $category eq "ruby" ) {
    %seenRubyMethodsHash = ();
    &outputRubyInterfaceMethodStubs($name,\%seenRubyMethodsHash);
  }
  else {
    &outputNamespaceMergeFile($name);
    %seenMethodsHash = ();
    &outputInterfaceMethodStubs($name,\%seenMethodsHash);

    %seenMethodDeclsHash = ();
    &outputInterfaceMethodDeclarations($name,\%seenMethodDeclsHash);
  }
}


### Methods

# Output namespace .using merge file for single service or weakObject
#
# arg1 service or weakObject name
sub outputNamespaceMergeFile
{
  my $name = shift;

  my $className = $cdef->getImplementationClassName($name);
  my $baseClassName = $cdef->getBaseClassName($name);
  my $fileDir  = $optOutdir . "/" . $className;
  mkpath([$fileDir]);

  my $usingFilePath = $fileDir . "/" . $className . ".using";
  debugPrintln("Creating $name using namespace in $usingFilePath");

  &outputNamespaceStatements($usingFilePath, $name );

} # ! outputNamespaceMergeFile

# Output interface method stubs for a single interface
# arg 1 interface name
# arg 2 optional reference to hash containing seen methods and their first interface
sub outputInterfaceMethodStubs
{
  my $name = shift;
  my $seenMethodsRef = 0;
  $seenMethodsRef = shift if @_;

  my $className     = $cdef->getImplementationClassName($name);
  my $baseClassName = $cdef->getBaseClassName($name);
  my $category      = $cdef->getImplementationCategory($name);

  # Prepare generator
  my $cppMethods
    = Codegen::CppMethods->new($rdbTypeDefDb,
                                       $className,$baseClassName,$name,$cdef);
  $cppMethods->setCategory($category);
  $cppMethods->setIsService($cdef->isService($name));
  $cppMethods->setIndent("  ");
  $cppMethods->setSeenMethodsHashRef($seenMethodsRef);
  $cppMethods->setUseShortNames($optShortNames);

  my $fileDir  = $optOutdir . "/" . $className;
  mkpath([$fileDir]);

  my @provides = $cdef->getProvidesForName($name);
  &debugPrintln("$name provides");
  &debugPrintln(@provides);
  foreach my $ifName ( @provides ) {
    my $interface;
    &debugPrintln("Creating $name interface $ifName method stubs");
    
    my $stubCode = $cppMethods->getMethodImplementations($ifName);
    
    my $stubFilePath  = $fileDir . "/" . &toSlashPath($ifName) . ".stubs";
    
    mkpath([dirname($stubFilePath)]);

    &debugPrintln("stubFilePath=$stubFilePath");

#    print $stubCode; # \@TODO properly
    my $fh = new FileHandle "$stubFilePath", "w";
    if (defined $fh) {
      print $fh $stubCode;
      $fh->close();
    }
    else {
      die "$0: Cannot open file for writing: $stubFilePath\n";
    }
  }

} # ! outputInterfaceMethodStubs

# Output interface method declarations for a single interface
# arg 1 interface name
# arg 2 optional reference to hash containing seen methods and their first interface
sub outputInterfaceMethodDeclarations
{
  my $name            = shift;
  my $seenMethodsRef = 0;
  $seenMethodsRef = shift if @_;

  my $className     = $cdef->getImplementationClassName($name);
  my $category      = $cdef->getImplementationCategory($name);

  # Prepare generator
  my $cppMethods = Codegen::CppMethods->new($rdbTypeDefDb);
  $cppMethods->setCategory($category);
  $cppMethods->setIsService($cdef->isService($name));
  $cppMethods->setIndent("    ");
  $cppMethods->setSeenMethodsHashRef($seenMethodsRef);
  $cppMethods->setUseShortNames(0);

  my $fileDir  = $optOutdir . "/" . $className;
  mkpath([$fileDir]);

  my @provides = $cdef->getProvidesForName($name);
  &debugPrintln("$name provides");
  &debugPrintln(@provides);
  foreach my $ifName ( @provides ) {
    my $interface;
    &debugPrintln("Creating $name interface $ifName method declarations");
    
    my $declCode = $cppMethods->getMethodDeclarations($ifName,
                                                      1);
    
    my $declFilePath  = $fileDir . "/" . &toSlashPath($ifName) . ".decls";
    
    mkpath([dirname($declFilePath)]);

    &debugPrintln("declFilePath=$declFilePath");

#    print $declCode; # \@TODO properly
    my $fh = new FileHandle "$declFilePath", "w";
    if (defined $fh) {
      print $fh $declCode;
      $fh->close();
    }
    else {
      die "$0: Cannot open file for writing: $declFilePath\n";
    }
  }

} # ! outputInterfaceMethodDeclarations

# Output interface method stubs for a single interface
# arg 1 interface name
# arg 2 optional reference to hash containing seen methods and their first interface
sub outputRubyInterfaceMethodStubs
{
  my $name = shift;
  my $seenMethodsRef = 0;
  $seenMethodsRef = shift if @_;

  my $className     = $cdef->getImplementationClassName($name);
  my $baseClassName = $cdef->getBaseClassName($name);
  my $category      = $cdef->getImplementationCategory($name);

  # Prepare generator
  my $cppMethods
    = Codegen::RubyMethods->new($rdbTypeDefDb,
                               $className,$baseClassName);
  $cppMethods->setCategory($category);
  $cppMethods->setIsService($cdef->isService($name));
  $cppMethods->setIndent("  ");
  $cppMethods->setSeenMethodsHashRef($seenMethodsRef);
  $cppMethods->setUseShortNames($optShortNames);

  my $fileDir  = $optOutdir . "/" . $className;
  mkpath([$fileDir]);

  my @provides = $cdef->getProvidesForName($name);
  &debugPrintln("$name provides");
  &debugPrintln(@provides);
  foreach my $ifName ( @provides ) {
    my $interface;
    &debugPrintln("Creating $name interface $ifName method stubs");
    
    my $stubCode = $cppMethods->getMethodImplementations($ifName);
    
    my $stubFilePath  = $fileDir . "/" . &toSlashPath($ifName) . ".rubystubs";
    
    mkpath([dirname($stubFilePath)]);

    &debugPrintln("stubFilePath=$stubFilePath");

#    print $stubCode; # \@TODO properly
    my $fh = new FileHandle "$stubFilePath", "w";
    if (defined $fh) {
      print $fh $stubCode;
      $fh->close();
    }
    else {
      die "$0: Cannot open file for writing: $stubFilePath\n";
    }
  }

} # ! outputRubyInterfaceMethodStubs

## Local functions

# Output "using namespace" statements for service or weakObject
# arg1 filePath for output ($localClassBasedDir/${className}.using)
# arg2 service or weakObject name
sub outputNamespaceStatements
{
  my $filePath = shift;
  my $name     = shift;

  my $className = $cdef->getImplementationClassName($name);

  # baseTypes, types that are always present, but not in provides/uses
  my @baseTypes = ("com.sun.star.uno.RuntimeException");

  my @provides = $cdef->getProvidesForName($name);
  my @uses     = $cdef->getUsesForName($name);

  my @allUnoTypes        = ( @baseTypes, @provides, @uses );
  my @excludedNamespaces = ( &getCppNamespace($className) );

  my %namespacesHash =  (); # Collects namespaces from types
  foreach my $givenTypeName ( @allUnoTypes ) {
    map
    { $namespacesHash{$_} = 1 }
    $cppUtils->getDependentCppNamespacesForUno($givenTypeName);
  }

  foreach my $exclude (@excludedNamespaces) {
    delete $namespacesHash{$exclude} if exists $namespacesHash{$exclude};
  }

  my @namespaceStatements =
    map { "using namespace " . $_ . ";\n" } sort keys %namespacesHash;

  ## DEBUG
  debugPrintln("Namespaces for $name to $filePath");
  my $fh = new FileHandle "$filePath", "w";
  if (defined $fh) {
    print $fh (@namespaceStatements);
    $fh->close();
  }
  else {
    print STDERR "$0: Cannot open file for writing: $filePath\n";
  }

} # outputNamespaceStatements

# Check implementation for valid interfaces etc.
# arg 1 service or weakObject name
# Dies if fails validation
sub checkImplementation
{
  my $name = shift;
  my @interfaces = ();
  if ( $cdef->isService($name) ) {
    @interfaces = (@cppServiceBaseInterfaces,
                   $cdef->getProvidesForName($name));
  }
  else {
    @interfaces = (@cppWeakObjectBaseInterfaces,
                   $cdef->getProvidesForName($name));
  }

  my $errorMessage =
    $rdbTypeDefDb->checkInterfacesForImplementation(@interfaces);

  $errorMessage and die "ERROR: $name: $errorMessage\n";

} # checkImplementation

# Prints args on separate line, if $optVerbose is set
sub verbosePrintln
{
  if ( $optVerbose ) {
    foreach my $line ( @_ ) {
      print STDOUT "$line\n";
    }
  }
} # verbosePrintln

# Prints args on separate line, if $optDebug is set
sub debugPrintln
{
  if ( $optDebug ) {
    foreach my $line ( @_ ) {
      print STDOUT "DEBUG: $line\n";
    }
  }
} # debugPrintln


# Checks options etc
# exits with non-zero value if any error
sub getCommandLineOptions
{
  my $optFullnames=0;

  &GetOptions("-outdir=s"  => \$optOutdir,
              "-verbose"   => \$optVerbose,
              "-rdb=s"     => \@optRdbFiles,
              "-impl=s"    => \@optImplNames,
              "-fullnames" => \$optFullnames,
              "-help!"     => \$optHelp)
    or die ;

  if ( @ARGV > 0 ) {
    $cdefFile = shift @ARGV;
  }
  else {
    print STDERR "Missing cdef file\n";
    &usage ;
    exit 1;
  }
  if ( @optRdbFiles == 0 ) {
    print STDERR "Missing rdb file(s)\n";
    &usage ;
    exit 1;
  }
  if ( $optHelp) {
    &usage ;
    exit 1;
  }

  $optFullnames
    and $optShortNames = 0;
  if ( ! $optOutdir ) {
    print STDERR "Missing -outdir option\n";
    &usage ;
    exit 1;
  }

  if ( ! $cdefFile ) {
    print STDERR "Missing cdef file\n";
    &usage ;
    exit 1;
  }

} # ! getCommandLineOptions

sub usage
{
  print STDERR "Usage:\n";
  print STDERR "$0 [-help] [-verbose] [-impl name]... -outdir outdir -rdb rdbfile... cdefFile \n";
  print STDERR "  -outdir outdir outout directory for generated files\n";
  print STDERR "  -impl name service or weakObject, restricts output to given name\n";
  print STDERR "  -rdb rdbfile\n";
  print STDERR "  cdefFile component definition file\n";
  print STDERR "  rdbfile is UNO rdb containing interface types (tried in order)\n";
  print STDERR "  -verbose prints information on progress\n";
  print STDERR "Typical usage:\n";
  print STDERR "$0 -outdir Main/tmp_codegen -rdb \$WORKSPACE/IDL/zenith.rdb MyComponent.cdef\n";
}
