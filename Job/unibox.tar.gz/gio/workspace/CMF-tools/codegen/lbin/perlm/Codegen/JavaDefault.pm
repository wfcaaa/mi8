# Perl package to generate Java method cade for default category
#

package Codegen::JavaDefault;


use strict;
use lib "..";
use RegviewTypesDb;
use Codegen::Utils;
use Codegen::JavaUtils;

sub new
{
  my $class     = shift;
  my $typeDefDb = shift;  # RegviewTypesDb reference
  my $interface = shift;  # UNO interface name
  my $className = "";     # C++ class name (short)
  @_ and $className = shift;

  return bless {
    
    TYPE_DEF_DB    => $typeDefDb,
    USE_SHORT_NAMES => 1,
    INTERFACE_NAME => $interface,
    INTERFACE_REF  => $typeDefDb->getTypeDefinition($interface ),
    CLASS_NAME     => $className,
    INDENT         => "  ",
    CATEGORY       => "default",
    }, $class ;

}

# Return implementation code for method of category default
#
# arg1 reference to RegviewMethodDef
# arg2 indent string at method code level
sub getMethodCode
{
  my $self             = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;

  my $methodName = $methodDefRef->{NAME};

  my $code = "";
  $code .= $methodCodeIndent . &getBeginEditableSection($methodName);

  my $defaultImplementationCode =
    _getDefaultCode($self->{INTERFACE_NAME}, $methodName, $self->{CLASS_NAME});
  $code .= $defaultImplementationCode;
  if ( ! $defaultImplementationCode )  {
    $code .= $self->_getNotImplementedCode($methodDefRef,
                                           $methodCodeIndent);
  }
  $code .= $methodCodeIndent . &getEndEditableSection($methodName);
  return $code;
} # ! getMethodCode



# get code for com.sun.star.lang.XInitialization.initialize method
# arg1 indent string
sub _getNotImplementedCode
{
  my $self             = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;

  my $methodName = $methodDefRef->{NAME};
  my $className  = $self->{CLASS_NAME};

  my $javaUtils = new Codegen::JavaUtils($self->{TYPE_DEF_DB},
                                         $self->{USE_SHORT_NAMES});
  my $code = "";

  my $logNotImplemented =
    "// \@todo TODO_AUTO_GENERATED";

  my $returnTypeName = $self->{TYPE_DEF_DB}->
    getResolvedTypeName($methodDefRef->{RETURN_TYPE_NAME});
  my $javaReturnType = $javaUtils->getJavaReturnType($returnTypeName);

  if ( $returnTypeName !~ m/^void$/  ) {
    $code .= $methodCodeIndent
      . $javaReturnType . " returnValue"
      . $javaUtils->getJavaInitCode($returnTypeName)
      . ";\n" ;
    $code .= $methodCodeIndent . $logNotImplemented ."\n" ;
    $code .= $methodCodeIndent . "return returnValue;\n" ;
  }
  else {
    $code .= $methodCodeIndent . $logNotImplemented ."\n" ;
  }

  return $code;
} # ! _getNotImplementedCode

# Return implementation code from default interface implementation file, if any
#
# arg1 interfaceName
# arg2 method name
# arg3 class name
sub _getDefaultCode
{
  my $interfaceName    = shift;
  my $methodName       = shift;
  my $class            = shift;

  my $workspace = $ENV{"WORKSPACE"};
  my $interfacePath =  $interfaceName;
  $interfacePath =~ tr%.%/%;
  my $implFileName = $workspace .
    "/CMF-tools/codegen/lbin/defaultImplementations/" .
     $interfacePath . ".java";

  my $code = getEditableSectionContent($implFileName,$methodName);
  $code =~ s/__CLASS_NAME__/$class/g;
  return $code;
} # ! getDefaultCode

# End of package, needed for module load
1;
