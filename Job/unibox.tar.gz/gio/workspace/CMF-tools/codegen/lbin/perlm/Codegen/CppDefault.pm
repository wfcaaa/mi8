# Perl package with utility methods etc.
# supporting C++ code generation from uno types

#

package Codegen::CppDefault;

use strict;
use lib "..";
use RegviewTypesDb;
use Codegen::Utils;
use Codegen::CppUtils;

sub new
{
  my $class     = shift;
  my $typeDefDb = shift;  # RegviewTypesDb reference
  my $interface = shift;  # UNO interface name
  my $cppMethod = shift;
  my $className = "";     # C++ class name (short)
  @_ and $className = shift;

  return bless {
    
    TYPE_DEF_DB    => $typeDefDb,
    LONG_NAMES     => 0,     # Set to 1 to output names with namespace
    INTERFACE_NAME => $interface,
    INTERFACE_REF  => $typeDefDb->getTypeDefinition($interface ),
    CLASS_NAME     => $className,
    INDENT         => "  ",
    CATEGORY       => "default",
    CPP_METHODS    => $cppMethod,
    }, $class ;
}

# Return implementation code for method of category default
#
# arg1 reference to RegviewMethodDef
# arg2 indent string at method code level
sub getMethodCode
{
  my $self             = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;

  my $methodName = $methodDefRef->{NAME};

  my $code = "";
  $code .= $methodCodeIndent . &getBeginEditableSection($methodName);

  my $defaultImplementationCode =
    $self->_getDefaultCode($self->{INTERFACE_NAME}, $methodName, $self->{CLASS_NAME});
  $code .= $defaultImplementationCode;
  if ( ! $defaultImplementationCode )  {
    $code .= $self->_getNotImplementedCode($methodDefRef,
                                           $methodCodeIndent);
  }
  $code .= $methodCodeIndent . &getEndEditableSection($methodName);
  return $code;
} # ! getMethodCode



# get code for com.sun.star.lang.XInitialization.initialize method
# arg1 indent string
sub _getNotImplementedCode
{
  my $self             = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;

  my $cppUtils   = new Codegen::CppUtils($self->{TYPE_DEF_DB});
  my $methodName = $methodDefRef->{NAME};
  my $className  = $self->{CLASS_NAME};

  my $code = "";

  $code .= 
    $cppUtils->getCppReturnValueDecl($methodDefRef->{RETURN_TYPE_NAME},
                                     $methodCodeIndent);
    $code .= $methodCodeIndent .
      "// \@todo TODO_AUTO_GENERATED\n";
  $code .= 
    $cppUtils->getCppReturnStatement($methodDefRef->{RETURN_TYPE_NAME},
                                     $methodCodeIndent);
  return $code;
} # ! _getNotImplementedCode

# Return implementation code from default interface implementation file, if any
# arg1 interfaceName
# arg2 method name
# arg3 class name
sub _getDefaultCode
{
  my $self             = shift;
  my $interfaceName    = shift;
  my $methodName       = shift;
  my $class            = shift;

  my $workspace = $ENV{"WORKSPACE"};
  my $interfacePath =  $interfaceName;
  $interfacePath =~ tr%.%/%;
  my $implFileName="";
  
  if( $self->{CPP_METHODS}->needsRegistration eq "true")
  {
    $implFileName = $workspace .
     "/CMF-tools/codegen/lbin/defaultImplementations/" .
     $interfacePath . "_RegisterForShutdown.cpp";
  }  
   
  if(($implFileName eq "") || (! (-e $implFileName)))
  {  
    # $implFileName is either empty because previous condition is false
    # or file does not exist => take standard file
  
    $implFileName = $workspace .
     "/CMF-tools/codegen/lbin/defaultImplementations/" .
     $interfacePath . ".cpp";
  }

  my $code = getEditableSectionContent($implFileName,$methodName);
  $code =~ s/__CLASS_NAME__/$class/g;
  return $code;
} # ! getDefaultCode


# End of package, needed for module load
1;
