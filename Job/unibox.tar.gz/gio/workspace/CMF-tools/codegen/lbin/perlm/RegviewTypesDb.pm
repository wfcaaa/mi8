# Perl package with utility methods useful when processing
# regview output.

package RegviewDumper;
use strict;

sub asPlainHash
{
    my $hashRef = shift;
    return "ERROR: This is not a HASH ref !" if (ref($hashRef) ne "HASH");
    my %plainHash;
    foreach my $key (sort keys %{$hashRef} ) {
      if (   (! ref($hashRef->{$key}))            ## no reference at all
          || ref($hashRef->{$key}) eq "SCALAR")   ## reference to a scalar
      { 
        $plainHash{$key} = $hashRef->{$key};
      }
      elsif ( ref($hashRef->{$key}) eq "HASH" )
      {
        $plainHash{$key} = RegviewDumper::asPlainHash($hashRef->{$key});
      }
      elsif ( ref($hashRef->{$key}) eq "ARRAY" )
      {
        $plainHash{$key} = RegviewDumper::asPlainArray($hashRef->{$key});
      }
      else
      {
        ## This must be a referenced object,
        ## it should know how to extract itself.
        ## Beware of recursion!
        ##   -> modify reference to object RegviewTypeDef
        ##      into a simple key
        if (ref($hashRef->{$key}) eq "RegviewTypeDef")
        {
          $plainHash{$key} = $hashRef->{$key}->getTypeName();
        }
        else
        {
          $plainHash{$key} = $hashRef->{$key}->asPlainData();
        }
      }
    }
    return \%plainHash;
}

sub asPlainArray
{
    my $arrayRef = shift;
    return "This is not an ARRAY ref!" if (ref($arrayRef) ne "ARRAY");
    my @plainArray;
    foreach my $element (@{$arrayRef} ) {
      if (   (! ref($element))            ## no reference at all
          || ref($element) eq "SCALAR")   ## reference to a scalar
      { 
        push @plainArray, $element;
      }
      elsif ( ref($element) eq "HASH" )
      {
        push @plainArray, RegviewDumper::asPlainHash($element);
      }
      elsif ( ref($element) eq "ARRAY" )
      {
        push @plainArray, RegviewDumper::asPlainArray($element);
      }
      else
      {
        ## This must be a referenced object,
        ## it should know how to extract itself.
        ## Beware of recursion!
        ##   -> modify reference to object RegviewTypeDef
        ##      into a simple key
        if (ref($element) eq "RegviewTypeDef")
        {
          push @plainArray, $element->getTypeName();
        }
        else
        {
          push @plainArray, $element->asPlainData();
        }
      }
    }
    return \@plainArray;
}


# Hold data related to a single field
package RegviewFieldDef;

use strict;
use RegviewUtils;

# No additional args
sub new
{
    my ($class)         = shift;

    return bless {
        DOCUMENTATION => "",
        FILE_NAME     => "",
        FLAGS         => "",
        NAME          => "",
        TYPE_NAME     => "",
        VALUE         => ""
    }, $class;

}

# Return name: value of field
sub getName
{
    my $self   = shift;
    return $self->{NAME};
}

# Return true if field is readwrite attribute
sub isReadwrite
{
    my $self   = shift;
    return ($self->{FLAGS} =~ m/readwrite/);
}

# Sets the field data to that of nearest specified field to
# current position of parser
# arg 1 parser
# arg 2 field number to extract
sub setFieldFromParser
{
    my $self   = shift;
    my $parser = shift;
    my $fieldNum = shift;

    $parser->findNext("/field " . $fieldNum)
        or die "Missing /field $fieldNum:";
    $parser->findNext("/documentation")
        or die "Missing /documentation: for /field $fieldNum:";
    $self->{DOCUMENTATION} = $parser->getUnquotedValue;

    $parser->findNext("/file name")
        or die "Missing /file name: for /field $fieldNum:";
    $self->{FILE_NAME} = $parser->getUnquotedValue;

    $parser->findNext("/flags")
        or die "Missing /flags: for /field $fieldNum:";
    $self->{FLAGS} = $parser->getCurrentValue;

    $parser->findNext("/name")
        or die "Missing /name: for /field $fieldNum:";
    $self->{NAME} = $parser->getUnquotedValue;

    $parser->findNext("/type name")
        or die "Missing /type name: for /field $fieldNum:";
    $self->{TYPE_NAME} = &toDotPath($parser->getUnquotedValue);

    $parser->findNext("/value")
        or die "Missing /value: for /field $fieldNum:";
    $self->{VALUE} = $parser->getCurrentValue;

} # ! setFieldFromParser


# Dumps field
# optional arg 1 is indent level
sub dump
{
    my $self = shift;
    my $indent = "";
    my $indentLevel = 0;
    if ( @_ ) {
        $indentLevel = shift;
        for ( my $i = 0; $i < $indentLevel; $i++) {
            $indent .= " ";
        } 
    }

    print STDERR $indent . "DOCUMENTATION=" . $self->{DOCUMENTATION} . "\n";
    print STDERR $indent . "FILE_NAME=" . $self->{FILE_NAME} . "\n";
    print STDERR $indent . "FLAGS=" . $self->{FLAGS} . "\n";
    print STDERR $indent . "NAME=" . $self->{NAME} . "\n";
    print STDERR $indent . "TYPE_NAME=" . $self->{TYPE_NAME} . "\n";
    print STDERR $indent . "VALUE=" . $self->{VALUE} . "\n";
}

sub asPlainData
{
    my $self = shift;
    my %plainHash;
    foreach my $key (sort keys %{$self} ) {
      if (   (! ref($self->{$key}))            ## no reference at all
          || ref($self->{$key}) eq "SCALAR")   ## reference to a scalar
      { 
        $plainHash{$key} = $self->{$key};
      }
      elsif ( ref($self->{$key}) eq "HASH" )
      {
        $plainHash{$key} = RegviewDumper::asPlainHash($self->{$key});
      }
      elsif ( ref($self->{$key}) eq "ARRAY" )
      {
        $plainHash{$key} = RegviewDumper::asPlainArray($self->{$key});
      }
      else
      {
        ## This must be a referenced object,
        ## it should know how to extract itself.
        ## Beware of recursion!
        ##   -> modify reference to object RegviewTypeDef
        ##      into a simple key
        if (ref($self->{$key}) eq "RegviewTypeDef")
        {
          $plainHash{$key} = $self->{$key}->getTypeName();
        }
        else
        {
          $plainHash{$key} = $self->{$key}->asPlainData();
        }
      }
    }
    return \%plainHash;
}

# Hold data related to a single method
package RegviewMethodDef;

use strict;
use RegviewUtils;

# No additional args
sub new
{
    my ($class)         = shift;
    my $parentTypeRef = 0;
    if ( @_ ) {
      $parentTypeRef = shift;
    }

    return bless {
        DOCUMENTATION    => "",
        FLAGS            => "",
        NAME             => "",
        RETURN_TYPE_NAME => "", # Return type ParamTypeDefinition ref
        PARAMETERS       => [], # Array of refs to ParamTypeDefinition
        EXCEPTION_NAMES  => [], # Array of Exception names
        PARENT_TYPE      => $parentTypeRef,   # Reference to parent type
    }, $class;
}

# dump definition
sub dump
{
    my $self = shift;
    my $indent = "";
    my $indentLevel = 0;
    if ( @_ ) {
        $indentLevel = shift;
        for ( my $i = 0; $i < $indentLevel; $i++) {
            $indent .= " ";
        } 
    }

    print STDERR $indent . "DOCUMENTATION=" . $self->{DOCUMENTATION} . "\n";
    print STDERR $indent . "FLAGS=" . $self->{FLAGS} . "\n";
    print STDERR $indent . "NAME=" . $self->{NAME} . "\n";
    print STDERR $indent . "RETURN_TYPE_NAME=" . $self->{RETURN_TYPE_NAME} . "\n";

    print STDERR $indent . "PARAMETERS count=" . @{$self->{PARAMETERS}} . "\n";
    my $parametersRef = $self->{PARAMETERS};
    for ( my $i = 0; $i < @{$parametersRef} ; $i++ ) {
        print STDERR $indent . " parameter $i:\n";
        $parametersRef->[$i]->dump( $indentLevel + 2 );  
    }

    print STDERR $indent . "EXCEPTION_NAMES count="
        . @{$self->{EXCEPTION_NAMES}} . "\n";
    my $exceptionsArray = $self->{EXCEPTION_NAMES};
    for ( my $i = 0; $i < @{$exceptionsArray} ; $i++ ) {
        print STDERR $indent . " exception $i: ". $exceptionsArray->[$i] ."\n";
    }


} # ! dump

sub asPlainData
{
    my $self = shift;
    my %plainHash;
    foreach my $key (sort keys %{$self} ) {
      if (   (! ref($self->{$key}))            ## no reference at all
          || ref($self->{$key}) eq "SCALAR")   ## reference to a scalar
      { 
        $plainHash{$key} = $self->{$key};
      }
      elsif ( ref($self->{$key}) eq "HASH" )
      {
        $plainHash{$key} = RegviewDumper::asPlainHash($self->{$key});
      }
      elsif ( ref($self->{$key}) eq "ARRAY" )
      {
        $plainHash{$key} = RegviewDumper::asPlainArray($self->{$key});
      }
      else
      {
        ## This must be a referenced object,
        ## it should know how to extract itself.
        ## Beware of recursion!
        ##   -> modify reference to object RegviewTypeDef
        ##      into a simple key
        if (ref($self->{$key}) eq "RegviewTypeDef")
        {
          $plainHash{$key} = $self->{$key}->getTypeName();
        }
        else
        {
          $plainHash{$key} = $self->{$key}->asPlainData();
        }
      }
    }
    return \%plainHash;
}

# Sets the method data to that of nearest specified method to
# current position of parser
# arg 1 parser
# arg 2 method number to extract
sub setMethodFromParser
{
    my $self   = shift;
    my $parser = shift;
    my $methodNum = shift;


    $parser->findNext("/method " . $methodNum)
        or die "Missing /method $methodNum:";
    $parser->findNext("/documentation")
        or die "Missing /documentation: for /method $methodNum:";
    $self->{DOCUMENTATION} = $parser->getUnquotedValue;

    $parser->findNext("/flags")
        or die "Missing /flags: for /method $methodNum:";
    $self->{FLAGS} = $parser->getCurrentValue;

    $parser->findNext("/name")
        or die "Missing /name: for /method $methodNum:";
    $self->{NAME} = $parser->getUnquotedValue;

    $parser->findNext("/return type name")
        or die "Missing /return type name: for /method $methodNum:";
    $self->{RETURN_TYPE_NAME} = &toDotPath($parser->getUnquotedValue);

    $parser->findNext("/parameter count")
        or die "Missing \"parameter count\": for /method $methodNum:";
    my $paramCount = int $parser->getCurrentValue;
    for ( my $paramNum = 0; $paramNum < $paramCount; $paramNum++ ) {
        my $parameterTypeDefRef = RegviewParameterTypeDef->new;
        $parameterTypeDefRef->setParameterTypeDefinitionFromParser($parser,
                                                                   $paramNum);
        $self->{PARAMETERS}[ $paramNum ] = $parameterTypeDefRef;
    }

    $parser->findNext("/exception count")
        or die "Missing \"exception count\": for /method $methodNum:";
    my $exceptionCount = int $parser->getCurrentValue;
    for ( my $exceptionNum = 0; $exceptionNum < $exceptionCount; $exceptionNum++ ) {
        $parser->findNext("/exception type name $exceptionNum")
        or die "Missing /exception type name $exceptionNum: for /method $methodNum:";
        $self->{EXCEPTION_NAMES}[$exceptionNum] =
            &toDotPath($parser->getUnquotedValue);

    }

} # ! setMethodFromParser

# Sets the method data get<attribute> method for given field
# current position of parser
# arg RegviewFieldDef
sub setGetMethodFromFieldDef
{
    my $self = shift;
    my $fieldDefRef = shift;

    $self->{NAME} = "get" . $fieldDefRef->getName;

    $self->{RETURN_TYPE_NAME} = $fieldDefRef->{TYPE_NAME};
}

# Sets the method data set<attribute> method for given field
# current position of parser
# arg RegviewFieldDef
sub setSetMethodFromFieldDef
{
    my $self = shift;
    my $fieldDefRef = shift;

    $self->{NAME} = "set" . $fieldDefRef->getName;
    $self->{RETURN_TYPE_NAME} = "void";

    my $argParameterTypeDefRef = RegviewParameterTypeDef->new;
    my $argName ="_" . lcfirst $fieldDefRef->getName;
    $argParameterTypeDefRef->{ARG_NAME}  = $argName;
    $argParameterTypeDefRef->{FLAGS}     = "in";
    $argParameterTypeDefRef->{TYPE_NAME} = $fieldDefRef->{TYPE_NAME};
    $self->{PARAMETERS}[0] = $argParameterTypeDefRef;
}

# get UNO signature for method
#
sub getUnoSignature
{
    my $self = shift;

    my $signature = "";
    $signature .= $self->{RETURN_TYPE_NAME} .
      " " . $self->{NAME} .
      "(";
    for (my $i = 0; $i < @{$self->{PARAMETERS}} ; $i++ ) {
      my $parameterTypeRef = $self->{PARAMETERS}[$i];
      $i and $signature .= ",";
      $signature .= $parameterTypeRef->{FLAGS};
      $parameterTypeRef->{FLAGS} and $signature .= " ";
      $signature .= $parameterTypeRef->{TYPE_NAME};
    }
    $signature .= ")";

    return $signature;
} # getUnoSignature

package RegviewTypeDef;

use strict;
use RegviewUtils;
use RegviewParser;

# No additional args
sub new
{
    my ($class)         = shift;
    my $typeName      = "";
    my $typeClass     = "";    
    if ( @_ ) {
        $typeName   = shift;
    }
    if ( @_ ) {
        $typeClass  = shift;
    }    

    return bless{
        TYPE_CLASS        => $typeClass,
        TYPE_NAME         => $typeName,
        SUPER_TYPE_NAMES  => [],
        FIELDS            => [],
        METHODS           => [],
        REFERENCES        => []
    }, $class;
}

# Get type name of type
# returns regview "type name:" entry, "" if bad type def
sub getTypeName
{
    my $self  = shift;
    return $self->{TYPE_NAME};
}

# Returns true if this type's type class is an enum
#
sub isEnum
{
    my $self  = shift;
    return $self->{TYPE_CLASS} =~ m/\benum\b/;
}

# Returns true if this type's type class is an interface
#
sub isInterface
{
    my $self  = shift;
    return $self->{TYPE_CLASS} =~ m/\binterface\b/;
}

# Returns true if this type's type class is typedef
#
sub isTypedef
{
    my $self  = shift;
    return $self->{TYPE_CLASS} =~ m/\btypedef\b/;
}

# Return parent type names
# returns parent names or nothing
sub getParentTypeNames
{
    my $self  = shift;    
    my @parents;
    
    # iterate all parents and keep only those that are not a terminal type
    foreach my $parentTypeName (@{$self->{SUPER_TYPE_NAME}}){
       if(!(exists $RegviewTypesDb::terminalTypes{$parentTypeName})){
            push @parents, $parentTypeName;  # append $parentTypeName to @parents
       }     
    }    
 
    return @parents;

} # ! getParentTypeNames

# get field name
# arg 1 is field number
# returns field name, "" is none
sub getFieldName
{
    my $self  = shift;
    my $fieldNum = shift;
    my $fieldName = "";

    my $fieldsArrayRef = $self->{FIELDS};
    if ( @{$fieldsArrayRef} > $fieldNum ) {
        $fieldName = $fieldsArrayRef->[$fieldNum]->getName;
    }
    return $fieldName;
} # ! getFieldName

# Add dependent types to hash
# includes own type, those used in methods
# excludes super type and its dependent types
# arg 1 is reference to hash containing tyope names
sub addTypesToHash
{
    my $self   = shift;
    my $hashRef = shift;

    $hashRef->{$self->{TYPE_NAME}} = 1;

    my $fieldsRef = $self->{FIELDS};
    for ( my $i = 0; $i < @{$fieldsRef} ; $i++ ) {
        $fieldsRef->[$i]{TYPE_NAME} and
            $hashRef->{$fieldsRef->[$i]{TYPE_NAME}} = 1;
    }

    my $methodsRef = $self->{METHODS};
    foreach my $methodRef (@$methodsRef) {
        $methodRef->{RETURN_TYPE_NAME} and
            $hashRef->{$methodRef->{RETURN_TYPE_NAME}} = 1;
        foreach my $parameterRef (@{$methodRef->{PARAMETERS}}) {
            $parameterRef->{TYPE_NAME} and
                $hashRef->{$parameterRef->{TYPE_NAME}} = 1;
        }
        my $exceptionsArray = $methodRef->{EXCEPTION_NAMES};
        for my $exceptionName ( @$exceptionsArray ) {
            $hashRef->{$exceptionName} = 1;
        }
    }
} # ! addTypesToHash

# Set type definition from parser positioned at "/type class:" key
# arg 1 is parser
sub setTypeDefinitionFromParser
{
    my $self  = shift;
    my $parser = shift;

    $parser->matchCurrentKey("/type class")
        or die "Not at /type class: line";

    $self->{TYPE_CLASS} = $parser->getCurrentValue;
    $parser->findNext("/type name")
        or die "Missing \"type name:\" for \"/type class\"" ;
    $self->{TYPE_NAME} = &toDotPath($parser->getUnquotedValue);

    my $superTypeName = "";
    $parser->findNext("/super type count")
        or die  "Missing \"super type count:\" for $self->{TYPE_NAME}";
    my $superTypeCount = int $parser->getCurrentValue;
    
    if ( $superTypeCount > 0 ) {        
        for (my $superTypeNum = 0; $superTypeNum < $superTypeCount ; $superTypeNum++ ) {
            $parser->findNext("/super type name $superTypeNum")
            or die "Missing \"super type name $superTypeNum\" for $self->{TYPE_NAME}";            
            
            $superTypeName = &toDotPath($parser->getUnquotedValue);             
            $self->{SUPER_TYPE_NAME}[ $superTypeNum ] = $superTypeName;            
        }            
    }        

    $parser->findNext("/field count")
        or die "Missing \"field count\" for $self->{TYPE_NAME}";
    my $fieldsRef = $self->{FIELDS};
    my $fieldCount = int $parser->getCurrentValue;
    for (my $fieldNum = 0; $fieldNum < $fieldCount ; $fieldNum++ ) {
        my $fieldDefRef = RegviewFieldDef->new;
        $fieldDefRef->setFieldFromParser($parser, $fieldNum);
        $fieldsRef->[ $fieldNum ] = $fieldDefRef;
    }

    $parser->findNext("/method count")
        or die "Missing \"method count\" for $self->{TYPE_NAME}";
    my $methodsRef = $self->{METHODS};
    my $methodCount = int $parser->getCurrentValue;
    for (my $methodNum = 0; $methodNum < $methodCount ; $methodNum++ ) {
        my $methodDefRef = RegviewMethodDef->new($self);
        $methodDefRef->setMethodFromParser($parser, $methodNum);
        $methodsRef->[ $methodNum ] = $methodDefRef;
    }

} # ! setTypeDefinitionFromParser

# dump type type definition
sub dump
{
    my $self = shift;
    my $indent = "";
    my $indentLevel = 0;
    if ( @_ ) {
        $indentLevel = shift;
        for ( my $i = 0; $i < $indentLevel; $i++) {
            $indent .= " ";
        } 
    }

    print STDERR $indent . "TYPE_CLASS=" . $self->{TYPE_CLASS} . "\n";
    print STDERR $indent . "TYPE_NAME=" . $self->{TYPE_NAME} . "\n";
    
    print STDERR $indent . "SUPER_TYPE_NAMES count=" . @{$self->{SUPER_TYPE_NAMES}} . "\n";
    my $superTypeNamesRef = $self->{SUPER_TYPE_NAMES};
    for ( my $i = 0; $i < @{$superTypeNamesRef} ; $i++ ) {
        print STDERR $indent . " super type name $i:\n";
        $superTypeNamesRef->[$i]->dump( $indentLevel + 2 );  
    }    
    
    print STDERR $indent . "FIELDS count=" . @{$self->{FIELDS}} . "\n";
    my $fieldsRef = $self->{FIELDS};
    for ( my $i = 0; $i < @{$fieldsRef} ; $i++ ) {
        print STDERR $indent . " field $i:\n";
        $fieldsRef->[$i]->dump( $indentLevel + 2 );  
    }
 
    print STDERR $indent . "METHODS count=" . @{$self->{METHODS}} . "\n";
    my $methodsRef = $self->{METHODS};
    for ( my $i = 0; $i < @{$methodsRef} ; $i++ ) {
        print STDERR $indent . " method $i:\n";
        $methodsRef->[$i]->dump( $indentLevel + 2 );  
    }

    print STDERR $indent . "REFERENCES count=" . @{$self->{REFERENCES}} . " (NOT IMPLEMENTED)\n";

} # ! dump

sub asPlainData
{
    my $self = shift;
    my %plainHash;
    foreach my $key (sort keys %{$self} ) {
      if (   (! ref($self->{$key}))            ## no reference at all
          || ref($self->{$key}) eq "SCALAR")   ## reference to a scalar
      { 
        $plainHash{$key} = $self->{$key};
      }
      elsif ( ref($self->{$key}) eq "HASH" )
      {
        $plainHash{$key} = RegviewDumper::asPlainHash($self->{$key});
      }
      elsif ( ref($self->{$key}) eq "ARRAY" )
      {
        $plainHash{$key} = RegviewDumper::asPlainArray($self->{$key});
      }
      else
      {
        ## This must be a referenced object,
        ## it should know how to extract itself.
        ## Beware of recursion!
        ##   -> modify reference to object RegviewTypeDef
        ##      into a simple key
        if (ref($self->{$key}) eq "RegviewTypeDef")
        {
          $plainHash{$key} = $self->{$key}->getTypeName();
        }
        else
        {
          $plainHash{$key} = $self->{$key}->asPlainData();
        }
      }
    }
    return \%plainHash;
}

# Holds information for a single method parameter
package RegviewParameterTypeDef;

use strict;
use RegviewUtils;
use RegviewParser;

sub new
{
    my ($class) = shift;
    my ($typeName) = shift;

    return bless{
        FLAGS     => "",  # flags for method arg
        ARG_NAME  => "",  # Name used for method arg
        TYPE_NAME => "",  # full type name (dotted)
    }, $class;
}

# Return true if parameter is "in"
sub isInParam
{
    my $self  = shift;
    my $in = ($self->{FLAGS} =~ m/\bin\b/) ;

    return $in;
}

# Return true if parameter is "out" or "inout"
sub isOutOrInoutParam
{
    my $self  = shift;
    my $outOrInout = ( $self->{FLAGS} =~ m/\b(in)?out\b/ );

    return $outOrInout;
}

# Set parameter type definition from parser positioned before "/parameter <n>:" key
# arg 1 is parser
# arg 2 parameter number to extract
sub setParameterTypeDefinitionFromParser
{
    my $self  = shift;
    my $parser = shift;
    my $parameterNum = shift;

    $parser->findNext("/parameter " . $parameterNum)
        or die "Missing /parameter $parameterNum:";

    $parser->findNext("/flags")
        or die "Missing \"flags:\" for \"/parameter $parameterNum\"" ;
    $self->{FLAGS} = $parser->getCurrentValue;

    $parser->findNext("/name")
        or die "Missing \"name:\" for \"/parameter $parameterNum\"" ;
    $self->{ARG_NAME} = $parser->getUnquotedValue;

    $parser->findNext("/type name")
        or die "Missing \"type name:\" for \"/parameter $parameterNum\"" ;
    $self->{TYPE_NAME} = &toDotPath($parser->getUnquotedValue);

} # ! setParameterTypeDefinitionFromParser

# dump parameter type type definition
sub dump
{
    my $self = shift;
    my $indent = "";
    my $indentLevel = 0;
    if ( @_ ) {
        $indentLevel = shift;
        for ( my $i = 0; $i < $indentLevel; $i++) {
            $indent .= " ";
        } 
    }

    print STDERR $indent . "FLAGS=" . $self->{FLAGS}. "\n";
    print STDERR $indent . "ARG_NAME=" . $self->{ARG_NAME} . "\n";
    print STDERR $indent . "TYPE_NAME=" . $self->{TYPE_NAME} . "\n";

} # ! dump

sub asPlainData
{
    my $self = shift;
    my %plainHash;
    foreach my $key (sort keys %{$self} ) {
      if (   (! ref($self->{$key}))            ## no reference at all
          || ref($self->{$key}) eq "SCALAR")   ## reference to a scalar
      { 
        $plainHash{$key} = $self->{$key};
      }
      elsif ( ref($self->{$key}) eq "HASH" )
      {
        $plainHash{$key} = RegviewDumper::asPlainHash($self->{$key});
      }
      elsif ( ref($self->{$key}) eq "ARRAY" )
      {
        $plainHash{$key} = RegviewDumper::asPlainArray($self->{$key});
      }
      else
      {
        ## This must be a referenced object,
        ## it should know how to extract itself.
        ## Beware of recursion!
        ##   -> modify reference to object RegviewTypeDef
        ##      into a simple key
        if (ref($self->{$key}) eq "RegviewTypeDef")
        {
          $plainHash{$key} = $self->{$key}->getTypeName();
        }
        else
        {
          $plainHash{$key} = $self->{$key}->asPlainData();
        }
      }
    }
    return \%plainHash;
}


# Contains the hash table with all types
# and access methods
package RegviewTypesDb;

use strict;
#use lib &dirname($0). "/perlm";
use RegviewUtils;
use RegviewParser;

# List of types that stop ancestor searches
%RegviewTypesDb::terminalTypes =
  ( "com.sun.star.uno.XInterface" => "");

%RegviewTypesDb::unoBaseTypes =
    ("void"           => 1,
     "short"          => 1,
     "long"           => 1,
     "hyper"          => 1,
     "unsigned short" => 1,
     "unsigned long"  => 1,
     "unsigned hyper" => 1,
     "float"          => 1,
     "double"         => 1,
     "char"           => 1,
     "byte"           => 1,
     "boolean"        => 1,
     "string"         => 1,
     "any"            => 1,
     "type"           => 1,
     );

# arg 1... rdb file list
sub new
{
    my ($class) = shift;
    @_ or die "RegviewTypesDb->new: Missing rdb file(s)";
    my @rdbs = @_;

    return bless{
        TYPES_HASH    => {},  # hash of RegviewTypeDef
        RDB_FILES_REF => \@rdbs,
        
    }, $class;
}

# Returns true if type is a UNO base type
# arg1 uno type name
sub isUnoBaseType
{
    my $self = shift;
    my $unoTypeName = shift;

    return exists $RegviewTypesDb::unoBaseTypes{$unoTypeName};
}

# Returns true if type is defined and is an interface
# arg 1 uno type name (dotted path)
sub isTypeAnEnum
{
    my $self = shift;
    my $unoTypeName = shift;
    my $isInterface = 0;
    if ( exists $self->{TYPES_HASH}{$unoTypeName} ) {
        my $typeDefRef =  $self->{TYPES_HASH}{$unoTypeName};
        $isInterface = $typeDefRef->isEnum;
    }
    return $isInterface;

} # ! isTypeAnEnum

# Returns true if type is defined and is an interface
# arg 1 type name
sub isTypeAnInterface
{
    my $self = shift;
    my $unoTypeName = shift;
    my $isInterface = 0;
    if ( exists $self->{TYPES_HASH}{$unoTypeName} ) {
        my $typeDefRef =  $self->{TYPES_HASH}{$unoTypeName};
        $isInterface = $typeDefRef->isInterface;
    }
    return $isInterface;

} # ! isTypeAnInterface

# Returns true if type is defined and is an interface
# arg 1 UNO type name
sub isTypeATypedef
{
    my $self = shift;
    my $unoTypeName = shift;
    my $isTypedef = 0;
    if ( exists $self->{TYPES_HASH}{$unoTypeName} ) {
        my $typeDefRef =  $self->{TYPES_HASH}{$unoTypeName};
        $isTypedef = $typeDefRef->isTypedef;
    }
    return $isTypedef;

} # ! isTypeATypedef

# return parent type names
# arg 1 UNO type name
# returns names or "" if none
sub getParentTypeNames
{
    my $self = shift;
    my $unoTypeName = shift;    

    my @parentTypeNames;
    if ( exists $self->{TYPES_HASH}{$unoTypeName} ) {
        my $typeDefRef =  $self->{TYPES_HASH}{$unoTypeName};
        @parentTypeNames = $typeDefRef->getParentTypeNames;
    }

    return @parentTypeNames;
} # ! getParentTypeNames

# Returns name of specified field for a type
# arg 1 uno type name
# arg 2 optional field number, default first (0)
# returns name or '" if none
sub getTypeFieldName
{
    my $self = shift;
    my $unoTypeName = shift;
    my $fieldNum = 0;
    if ( @_ ) {
        $fieldNum = shift;
    }

    my $name = "";
    if ( exists $self->{TYPES_HASH}{$unoTypeName} ) {
        my $typeDefRef =  $self->{TYPES_HASH}{$unoTypeName};
        $name = $typeDefRef->getFieldName($fieldNum);
    }

    return $name;
} # ! getTypeFieldName

# Returns list of all dependent types for given type name
# arg 1 uno type name
sub getDependentTypes
{
    my $self = shift;
    my $unoTypeName = shift;
    my %typeNameHash = ($unoTypeName => 1);

    my $typeDefRef = $self->getTypeDefinition($unoTypeName);
    $typeDefRef
        and $typeDefRef->addTypesToHash(\%typeNameHash);

    return (sort keys %typeNameHash);
}

# Sets all types from the specified RDB into database
# No args
sub addAllTypes
{
    my $self = shift;
    my @rdbs  = @{$self->{RDB_FILES_REF}};

    my $parser = RegviewParser->new("/UCR", @rdbs);
    my $typeClass = "";
    my $typeName  = "";

    while ( $parser->findNext("/type class")) {
        my $typeDefRef = RegviewTypeDef->new;
        $typeDefRef->setTypeDefinitionFromParser($parser);
        my $dbHashRef = $self->{TYPES_HASH};
        if ( $typeDefRef->getTypeName ) {
            $dbHashRef->{$typeDefRef->getTypeName } = $typeDefRef;
        }
    }
    
    $parser->closeRdb;

} # ! addAllTypes

# Get a single type definition
# arg 1 type name (dotted)
# returns reference to RegviewTypeDef
sub getTypeDefinition
{
    my $self = shift;
    my $typeName = shift;
    my $typeDefRef = 0;

    if ( exists $self->{TYPES_HASH}{$typeName} ) {
        $typeDefRef = $self->{TYPES_HASH}{$typeName};
    }

    return $typeDefRef;
}

# Get short type name by removing or separated path
# arg 1 type name (dotted)
# returns type basename
sub getShortTypeName
{
    my $self      = shift;
    my $typeName  = shift;

    my $shortName = "";

    $typeName =~ m/.*\.(.+)/
      and $shortName = $1;
    return $shortName;
}

# Returns type resolved through any typedefs to ultimate type
# Note: sequences are resolved internally in rdb, so only
#  need to handle the simple case.
# arg 1 is UNO type name
sub getResolvedTypeName
{
    my $self = shift;
    my $unoTypeName = shift;    
    my $resolvedName = $unoTypeName;
    my @parentTypeName;
    
    while ( $resolvedName && $self->isTypeATypedef($resolvedName) ) {
        @parentTypeName= $self->getParentTypeNames($resolvedName);  
        
        if(@parentTypeName == 1){
        	$resolvedName = $parentTypeName[0];
        }else{
            die "Multiple inheritence is not allowed for a typedef: $unoTypeName";
        }          
    }
    
    return $resolvedName;
}

# Checks list of interfaces are valid for an implementation
# 1. all interfaces are present in database
# 2. interfaces do not have mismatching duplicate methods
# args is UNO
# returns error message relating to first error found, "" if OK
sub checkInterfacesForImplementation
{
  my $self = shift;
  my $errorMessage = "";
  my %seenMethodSignatures = ();
  my %seenMethodInterfaces = ();
  my $nextInterface = shift;
  while ( $nextInterface ) {
    # Check for missing interface
    if ( ! $self->isTypeAnInterface($nextInterface) ) {
      $errorMessage = "Interface $nextInterface is not defined in rdb";
      last;
    }

    # Check interface does not conflict with previous methods
    my $interfaceTypeDefRef = $self->getTypeDefinition( $nextInterface );
    # Attributes
    my $fieldDefRefs = $interfaceTypeDefRef->{FIELDS};
    for (my  $aa = 0; $aa < @$fieldDefRefs; $aa++ ) {
      my $fieldDefRef = $fieldDefRefs->[$aa];
      my $methodDefRef =  RegviewMethodDef->new;
      $methodDefRef->setGetMethodFromFieldDef($fieldDefRef);
      my $methodName =  $methodDefRef->{NAME};
      my $signature   = $methodDefRef->getUnoSignature;
      if ( exists $seenMethodSignatures{$methodName} ) {
        if ( $signature ne $seenMethodSignatures{$methodName} ) {
          $errorMessage = "$fieldDefRef->{NAME} attribute" .
            " in interface $nextInterface" .
            " conflicts with definition in" .
            " $seenMethodInterfaces{$methodName}";
          last;
        }
      } 
      else {
        # Method not seen already, record first use
        $seenMethodSignatures{$methodName} = $signature;
        $seenMethodInterfaces{$methodName} = $nextInterface;
      }
    }
    # Normal methods
    for (my  $mm = 0; $mm < @{$interfaceTypeDefRef->{METHODS}}; $mm++ ) {
      my $methodDefRef = $interfaceTypeDefRef->{METHODS}[$mm];
      my $methodName   = $methodDefRef->{NAME};
      my $signature    = $methodDefRef->getUnoSignature;

      if ( exists $seenMethodSignatures{$methodName} ) {
        if ( $signature ne $seenMethodSignatures{$methodName} ) {
          $errorMessage = "$methodName method" .
            " in interface $nextInterface" .
            " conflicts with definition in" .
            " $seenMethodInterfaces{$methodName}";
          last;
        }
      } 
      else {
        # Method not seen already, record first use
        $seenMethodSignatures{$methodName} = $signature;
        $seenMethodInterfaces{$methodName} = $nextInterface;
      }
    }

    $nextInterface = shift;
  }

  return $errorMessage;
} # ! checkInterfacesForImplementation

# Dump whole database
#
sub dump
{
    my $self = shift;

    print STDERR "RegviewTypesDb=\n";
    foreach my $unoTypeName (sort keys %{$self->{TYPES_HASH}} ) {
        my $typedef = $self->getTypeDefinition($unoTypeName);
        $typedef->dump(2);
    }
    print STDERR "  rdb files:\n";
    foreach my $rdb ( @{$self->{RDB_FILES_REF}} ) {
        print STDERR "    $rdb\n";
    }
}

sub asPlainData
{
    my $self = shift;
    my %plainHash;
    foreach my $key (sort keys %{$self->{"TYPES_HASH"}} ) {
      if (   (! ref($self->{"TYPES_HASH"}->{$key}))            ## no reference at all
          || ref($self->{"TYPES_HASH"}->{$key}) eq "SCALAR")   ## reference to a scalar
      { 
        $plainHash{$key} = $self->{"TYPES_HASH"}->{$key};
      }
      elsif ( ref($self->{"TYPES_HASH"}->{$key}) eq "HASH" )
      {
        $plainHash{$key} = RegviewDumper::asPlainHash($self->{"TYPES_HASH"}->{$key});
      }
      elsif ( ref($self->{"TYPES_HASH"}->{$key}) eq "ARRAY" )
      {
        $plainHash{$key} = RegviewDumper::asPlainArray($self->{"TYPES_HASH"}->{$key});
      }
      else
      {
        ## This must be a referenced object,
        ## it should know how to extract itself.
        $plainHash{$key} = $self->{"TYPES_HASH"}->{$key}->asPlainData();
      }
    }
    return \%plainHash;
}


# Needed for module load
1;

