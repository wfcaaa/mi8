# Perl package for generating method implementations for
# methods that are delegated to the base class method.
#
# For weakObjects, conditional code for debugging reference counts
# is added (for a service this is don in the base class)
#

package Codegen::CppBaseDelegate;


#use strict;
use lib "..";
use RegviewTypesDb;
use Codegen::Utils;
use Codegen::CppUtils;

require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw( isImplementedInBase );


# Interfaces implemented in service base class
%Codegen::CppBaseDelegate::serviceBaseInterfaces =
  ( "com.sun.star.lang.XComponent" => "",
    "com.sun.star.lang.XServiceInfo" => "",
    "com.sun.star.lang.XTypeProvider" => "",
    "com.sun.star.uno.XWeak"      => "",
    "com.sun.star.uno.XInterface" => "",
    );

# Interfaces implemented in weakObject base class
%Codegen::CppBaseDelegate::weakObjectBaseInterfaces =
  ( "com.sun.star.lang.XComponent" => "",
    "com.sun.star.lang.XTypeProvider" => "",
    "com.sun.star.uno.XWeak"      => "",
    "com.sun.star.uno.XInterface" => "",
    );

@Codegen::CppBaseDelegate::acquirePostRefcountCode =
  ( "#ifdef DEBUG_REFCOUNT",
     "XOC_DEBUG(__FUNCTION__",
     "          << \" pid=\" << getpid()",
     "          << \" instance=0x\" << std::hex << (void *)this << std::dec",
     "          << \" m_refCount->\" << m_refCount << \" on exit\");",
    "#endif"
    );

@Codegen::CppBaseDelegate::releasePreRefcountCode =
  ( "#ifdef DEBUG_REFCOUNT",
    "// Need to log before calling release() otherwise",
    "// when ref count goes to 0, destructor is called before log",
    "XOC_DEBUG(__FUNCTION__",
    "          << \" pid=\" << getpid()",
    "          << \" instance=0x\" << std::hex << (void *)this << std::dec",
    "          << \" m_refCount->\" << m_refCount - 1 << \" on exit\");",
    "#endif"
    );

@Codegen::CppBaseDelegate::disposePreRefcountCode =
  ( "#ifdef DEBUG_REFCOUNT",
    "static int disposeRecurseCount = 0;",
    "XOC_DEBUG(__FUNCTION__",
    "          << \" pid=\" << getpid()",
    "          << \" instance=0x\" << std::hex << (void *)this << std::dec",
    "          << \" disposeRecurseCount=\" << disposeRecurseCount",
    "          << \" m_refCount->\" << m_refCount << \" on entry\");",
    "++disposeRecurseCount;",
    "#endif"
    );
@Codegen::CppBaseDelegate::disposePostRefcountCode =
  ( "#ifdef DEBUG_REFCOUNT",
    "--disposeRecurseCount;",
    "#endif");

%Codegen::CppBaseDelegate::preEditableSectionRefcountCode =
  ( "com.sun.star.lang.XComponent.dispose"
    => \@Codegen::CppBaseDelegate::disposePreRefcountCode,
    "com.sun.star.uno.XInterface.release"
    => \@Codegen::CppBaseDelegate::releasePreRefcountCode
    );

%Codegen::CppBaseDelegate::postEditableSectionRefcountCode =
  ( "com.sun.star.lang.XComponent.dispose"
    => \@Codegen::CppBaseDelegate::disposePostRefcountCode,
    "com.sun.star.uno.XInterface.acquire"
    => \@Codegen::CppBaseDelegate::acquirePostRefcountCode
    );

sub new
{
  my $class     = shift;
  my $typeDefDb = shift;  # RegviewTypesDb reference
  my $interface = shift;  # UNO interface name
  my $className = shift;     # C++ class name (short)
  my $baseClassName = shift; # C++ base class name (short)

  return bless {
    
    TYPE_DEF_DB    => $typeDefDb,
    LONG_NAMES     => 0,     # Set to 1 to output names with namespace
    INTERFACE_NAME => $interface,
    INTERFACE_REF  => $typeDefDb->getTypeDefinition($interface ),
    CLASS_NAME     => $className,
    BASE_CLASS_NAME => $baseClassName,
    IS_SERVICE     => 0,
    INDENT         => "  ",
    CATEGORY       => "default",
    }, $class ;
}

# Static methods

# Returns true if interface is implemented in base class
#
# arg1 interface name
# arg2 true if testing for a service, else a weakObject
sub isImplementedInBase
{
  my $interfaceName = shift;
  my $isService     = shift;

  if ( $isService ) {
    return
      exists $Codegen::CppBaseDelegate::serviceBaseInterfaces{$interfaceName};
  }
  else {
    return
      exists $Codegen::CppBaseDelegate::weakObjectBaseInterfaces{$interfaceName};
  }

} # ! isImplementedInBase


# Object methods

# returns a string containing the implementation code to
# delegate a method call to the base class method.
# arg1 reference to RegviewMethodDef for the method to generate
# arg2 indent string
sub getMethodCode
{
  my $self             = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;
  my $code = "";

  my $methodName = $methodDefRef->{NAME};

  my $cppUtils  = new Codegen::CppUtils($self->{TYPE_DEF_DB});
  my $className = $self->{CLASS_NAME};

  $code .= $self->_getPreEditableCode($methodCodeIndent,
                                      $self->{INTERFACE_NAME},
                                      $methodName);

  $code .= $methodCodeIndent . &getBeginEditableSection($methodName);

  $code .=  $self->_getEditableCode($methodCodeIndent, $methodDefRef);

  $code .= $methodCodeIndent . &getEndEditableSection($methodName);

  $code .= $self->_getPostEditableCode($methodCodeIndent,
                                       $self->{INTERFACE_NAME},
                                       $methodName);
  return $code;
} # ! getMethodCode

# Returns the editable code for the delegated call.
# $1 indent string
# $2 methodDefRef method definition
sub _getEditableCode
{
  my $self = shift;
  my $methodCodeIndent = shift;
  my $methodDefRef     = shift;
  my $methodImpl = "";
  
  my $cppUtils  = new Codegen::CppUtils($self->{TYPE_DEF_DB});

  # Default code, return value declared inside editable section
  $methodImpl .= 
    $cppUtils->getCppReturnValueDecl($methodDefRef->{RETURN_TYPE_NAME},
                                     $methodCodeIndent);

  my $cppReturnType =
    $cppUtils->getCppReturnType($methodDefRef->{RETURN_TYPE_NAME});

  $methodImpl .= $methodCodeIndent
    . "// WARNING:"
    . " removing the base class method call may break the component\n";
  my $methodCallIndent = $methodCodeIndent;
  if ( $cppReturnType !~ m/^void$/  ) {
    $methodImpl .= $methodCodeIndent . "returnValue =\n";
    $methodCallIndent .= "  ";
  }
  $methodImpl .= $methodCallIndent .
    $self->{BASE_CLASS_NAME} .
    "::" . $cppUtils->getCppMethodCall($methodDefRef) .
    ";\n";

  $methodImpl .= 
    $cppUtils->getCppReturnStatement($methodDefRef->{RETURN_TYPE_NAME},
                                     $methodCodeIndent);

  return $methodImpl;
} # ! _getEditableCode


# Returns code required before BEGIN EDITABLE SECTION
# arg1 indent
# arg2 interfacename
# arg3 method
# returns string that is the code
sub _getPreEditableCode
{
  my $self       = shift;
  my $indent     = shift;
  my $interface  = shift;
  my $methodName = shift;

  my $methodNameKey = $interface . "." . $methodName;
  my $methodCodeHashRef =
    \%Codegen::CppBaseDelegate::preEditableSectionRefcountCode;

  my $codeFragment = "";

  if ( ! $self->{IS_SERVICE}
       && exists $methodCodeHashRef->{$methodNameKey} ) {
    foreach my $line (@{$methodCodeHashRef->{$methodNameKey}}) {
      if ($line !~ m/^\#/ ) {
        $codeFragment .= $indent;
      }
      $codeFragment .= $line . "\n"; 
    }
  }
  return $codeFragment;
}

# Returns code required after END EDITABLE SECTION
# get reference count related code for the interface and method
# arg1 indent
# arg2 interfacename
# arg3 method
# returns string which is the code to insert after END EDITABLE SECTION
sub _getPostEditableCode
{
  my $self       = shift;
  my $indent     = shift;
  my $interface  = shift;
  my $methodName = shift;

  my $methodNameKey = $interface . "." . $methodName;
  my $methodCodeHashRef =
    \%Codegen::CppBaseDelegate::postEditableSectionRefcountCode;

  my $codeFragment = "";

  if ( ! $self->{IS_SERVICE}
       && exists $methodCodeHashRef->{$methodNameKey} ) {
    foreach my $line (@{$methodCodeHashRef->{$methodNameKey}}) {
      if ($line !~ m/^\#/ ) {
        $codeFragment .= $indent;
      }
      $codeFragment .= $line . "\n"; 
    }
  }
  return $codeFragment;
}

# End of package, needed for module load
1;
