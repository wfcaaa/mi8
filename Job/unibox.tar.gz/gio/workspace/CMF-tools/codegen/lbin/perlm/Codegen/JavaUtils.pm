# Perl package with utility methods supporting Java code
# from uno types

package Codegen::JavaUtils;

use lib "..";
use RegviewUtils;
use Codegen::Utils;

require Exporter;
@ISA    = qw(Exporter);
@EXPORT = qw(unoToJavaType getJavaShortName getJavaMethodCall);


# arg1 RegviewTypesDb reference
# arg2 =1, output methods use short names, 0, use full names
sub new
{
  my ($class)     = shift;
  my ($typeDefDb) = shift;
  my $useShortNames = 1;
  $useShortNames = shift if @_;

  return bless {
    TYPE_DEF_DB      => $typeDefDb,
    USE_SHORT_NAMES  => $useShortNames,
    }, $class ;

}

# Java types table, see http://udk.openoffice.org/java/man/map_idl_to_java.html
%Codegen::JavaUtils::lookupJavaType =
    ("unsigned short" => "short",
     "long"           => "int",
     "unsigned long"  => "int",
     "hyper"          => "long",
     "unsigned hyper" => "long",
     "string"         => "String",
     "any"            => "java.lang.Object",
     "type"           => "com.sun.star.uno.Type",
     "com.sun.star.uno.XInterface" => "java.lang.Object"
     );

%Codegen::JavaUtils::lookupJavaInitStrings =
  ("byte"           => " = 0",
   "short"          => " = 0",
   "unsigned short" => " = 0",
   "long"           => " = 0",
   "unsigned long"  => " = 0",
   "hyper"          => " = 0",
   "unsigned hyper" => " = 0",
   "float"          => " = (float)0.0",
   "double"         => " = 0.0",
   "boolean"        => " = false",
   "char"           => " = 0",
   "string"         => " = \"\"",
   "type "          => " = null",
   "any"            => " = null"
   );

# Converts UNO type name to Java type name
# 1. IDL simple types: lookup in table
# 2. IDL interface: object
# 3. UNO struct: object
# 4. Other: object
# 5. arrays: arrays to same depth
# arg 1 is UNO type
# arg 2 optional shortname flag, true to output short name.
sub unoToJavaType
{
    my $unoType = shift;
    my $useShortName = 0;
    if ( @_ > 0 ) {
        $useShortName = shift;
    }


    my $basicUnoType = &removeArraysFromType($unoType);
    my $numberOfArrays = &getNumberOfArraysFromType($unoType);
    my $javaType = "";

    if ( exists $Codegen::JavaUtils::lookupJavaType{$basicUnoType} ) {
        $javaType = $Codegen::JavaUtils::lookupJavaType{$basicUnoType} ;
    }
    else {
        # Convert everything else to Java class
        $javaType = $basicUnoType;
    }
    if ( $useShortName ) {
        $javaType = &getJavaShortName($javaType);
    }
    for ( my $i = 0; $i < $numberOfArrays; $i++) {
        $javaType .= "[]";
    }
    
    return $javaType;
} # ! unoToJavaType

# Get short name from Java type
sub getJavaShortName
{
    my $javaType = shift;
    my $shortName = $javaType;

    $javaType =~ m/.*\..+/
        and $shortName =~ s/(.*\.)(.+)/$2/ ;

    return $shortName;
}

# Return string which is a call to the method woth arg names as its definition
# arg 1 is reference to RegviewMethodDef
sub getJavaMethodCall
{
  my $methodDefRef = shift;

  my $methodCall = "";

  $methodCall .= $methodDefRef->{NAME} . "(";
  my $paramsRef = $methodDefRef->{PARAMETERS};
  my $i = 0;
  for ( $i = 0; $i < @$paramsRef; $i++ ) {
    my $paramTypeRef = $paramsRef->[$i];
    $methodCall .= $paramTypeRef->{ARG_NAME};
    if ( $i < $#{$paramsRef} ) {
      $methodCall .= "," ;
    }
  }
  $methodCall .= ")";

  return $methodCall;
} # ! getJavaMethodCall

# Object methods

# Return string that is the return type for a method
# arg 1 name of UNO type
sub getJavaReturnType
{
  my $self = shift;
  my $unoType = shift;

  my $returnTypeName =
    $self->{TYPE_DEF_DB}->getResolvedTypeName($unoType);
  my $javaReturnType = 
    &unoToJavaType($returnTypeName, $self->{USE_SHORT_NAMES});

  return $javaReturnType;
} # ! getJavaReturnType

# getJava init code for UNO type
# 1. simple types as in table
# 2. enum value of first enum entry
# 3. struct, arrays, references return null
# arg 1 is UNO type name
sub getJavaInitCode
{
  my $self        = shift;
  my $unoTypeName = shift;

  my $initCode    = " = null"; # unknown types are become objects

  # map UNO types to Java initcode
  if ( exists $Codegen::JavaUtils::lookupJavaInitStrings{ $unoTypeName } ) {
    $initCode = $Codegen::JavaUtils::lookupJavaInitStrings{ $unoTypeName } ;
  }
  elsif ( $self->{TYPE_DEF_DB}->isTypeAnEnum($unoTypeName) ) {
    $initCode = " = " 
      . &unoToJavaType($unoTypeName, $self->{USE_SHORT_NAMES})
      . "." . $self->{TYPE_DEF_DB}->getTypeFieldName($unoTypeName, 0);
  }
    # else maps to object, init is null reference

  return $initCode;
} # ! getJavaInitCode

# Needed for module load
1;

