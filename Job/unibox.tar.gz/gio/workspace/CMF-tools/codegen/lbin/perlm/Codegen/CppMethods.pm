# Perl package to support generating C++ code from
# type date in RegviewTypesDb
#

package Codegen::CppMethods;

use strict;
use lib "..";
use RegviewTypesDb;

use Codegen::Utils;
use Codegen::CppUtils;
use Codegen::CppDefault;
use Codegen::CppBaseDelegate;

sub new
{
  my ($class)   = shift;
  my $typeDefDb = shift;
  my $className = "";
  my $baseClassName = "UnknownBase";

  @_ and $className = shift;
  @_ and $baseClassName = shift;
  my $name = shift;
  my $cdef = shift;
  
  return bless {
    IS_SERVICE       => 1,
    USE_SHORT_NAMES  => 1,
    CLASS_NAME       => $className,
    BASE_CLASS_NAME  => $baseClassName,
    CATEGORY         => "default",
    INDENT           => "  ",
    SEEN_METHODS_REF => 0,
    TYPE_DEF_DB      => $typeDefDb,
    NAME             => $name,
    CDEF             => $cdef,
    }, $class ;

}

# arg 1: 1 if generating for service, 0 for weakObject
sub setIsService
{
  my $self              = shift;
  ($self->{IS_SERVICE}) = @_;
}

# arg 1: 1 to use short names, 0 to use long names (with namespace path)
sub setUseShortNames
{
  my $self                   = shift;
  ($self->{USE_SHORT_NAMES}) = @_;
}

# arg 1:  service or weakObject category attribute
sub setCategory
{
  my $self            = shift;
  ($self->{CATEGORY}) = @_;
}

# arg 1:  Indent string (default is "  " when created)
sub setIndent
{
  my $self          = shift;
  ($self->{INDENT}) = @_;
}

# arg 1: Reference to seen methods hash, 0 clears
sub setSeenMethodsHashRef
{
  my $self          = shift;
  ($self->{SEEN_METHODS_REF}) = @_;
}


# Return string with stubs for all implemented methods
# for the interface with all ancestor interfaces
#
# arg1 interface name
sub getMethodImplementations
{
  my $self   = shift;
  my $interfaceName      = shift;

  my $methodStubs = "";
  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};  
 
  my @nextInterface = $interfaceName;
  while ( @nextInterface > 0 ) {
    my $interfaceTypeDef = $rdbTypeDefDb->getTypeDefinition( $nextInterface[0] )
      or die "Interface \"$nextInterface[0]\" not defined in rdbs";
    $interfaceTypeDef->isInterface
      or die "Type \"$nextInterface[0]\" is not an interface";

    $methodStubs .= $self->_getSingleInterfaceMethodStubs($interfaceName,
                                                          $interfaceTypeDef);    

    my @parent = $interfaceTypeDef->getParentTypeNames;
    shift @nextInterface; # remove already handled interface
    unshift @nextInterface, @parent; # add parents because they must be handled, too    
  }
 
  return $methodStubs;
}

# Return string with declarations for all implemented methods
# for the interface with all ancestor interfaces
#
# arg1 interface name
# arg2 1 if virtual, 0 if not
sub getMethodDeclarations
{
  my $self          = shift;
  my $interfaceName = shift;
  my $isVirtual     = shift;

  my $methodStubs = "";
  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};  
  
  my @nextInterface = $interfaceName;
    
  while ( @nextInterface > 0 ) {
    my $interfaceTypeDef = $rdbTypeDefDb->getTypeDefinition( $nextInterface[0] )
      or die "Interface \"$nextInterface[0]\" not defined in rdbs";
    $interfaceTypeDef->isInterface
      or die "Type \"$nextInterface[0]\" is not an interface";

    $methodStubs .=
      $self->_getSingleInterfaceMethodDeclarations($interfaceName,
                                                   $interfaceTypeDef,
                                                   $isVirtual);    

    my @parent = $interfaceTypeDef->getParentTypeNames;
    shift @nextInterface; # remove already handled interface
    unshift @nextInterface, @parent; # add parents because they must be handled, too    
  }
  
  return $methodStubs;
}


# getRuntimeException, if required
# All methods except XInterface acquire and release throw RuntimeException
# arg 1 method definition
sub getRuntimeException
{
  my $self         = shift;
  my $methodDefRef = shift;
  my $typeDef      = $methodDefRef->{PARENT_TYPE};
  my $runtimeException = &unoToCppType("com.sun.star.uno.RuntimeException",
                                       0,
                                       $self->{USE_SHORT_NAMES});
  if ( $typeDef ) {
    my $typeName   = $typeDef->{TYPE_NAME};


    my $methodName = $methodDefRef->{NAME};
    if ( "$typeName" =~ m/^com\.sun\.star\.uno\.XInterface$/
         && "$methodName" =~ m/^(acquire|release)$/ ) {
      $runtimeException = "";
    }
  }

  return $runtimeException;
} # ! getRuntimeException

# Internal methods

# Return string with stubs for all implemented methods
# for the interface
# 
# arg 1 interface name
# arg 2 interface type def reference for interface or its am=ncestor
sub _getSingleInterfaceMethodStubs
{
  my $self   = shift;
  my $interfaceName = shift;
  my $interfaceTypeDefRef = shift;

  my $methodStubs = "";
  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};

  # Attribute methods
  my $fieldDefRefs = $interfaceTypeDefRef->{FIELDS};
  for (my  $aa = 0; $aa < @$fieldDefRefs; $aa++ ) {
    my $fieldName = $interfaceTypeDefRef->getFieldName($aa);

    my $fieldDefRef = $fieldDefRefs->[$aa];
    my $attrGetMethodRef =  RegviewMethodDef->new;
    $attrGetMethodRef->setGetMethodFromFieldDef($fieldDefRef);
    my $attrComment = "// Get method for "
      .$fieldDefRef->{FLAGS}." attribute "
      .$fieldDefRef->{NAME} ." of ".$interfaceName ."\n";
    $methodStubs .= $self->_getMethodStub($interfaceName,$attrGetMethodRef,
                                          $attrComment);
    if ( $fieldDefRef->isReadwrite ) {
      my $attrSetMethodRef =  RegviewMethodDef->new;
      $attrSetMethodRef->setSetMethodFromFieldDef($fieldDefRef);
      $attrComment = "// Set method for "
        .$fieldDefRef->{FLAGS}." attribute "
        .$fieldDefRef->{NAME} ." of ".$interfaceName."\n";
      $methodStubs .= $self->_getMethodStub($interfaceName,$attrSetMethodRef,
                                            $attrComment);
    }
  }

  # Methods
  for (my  $mm = 0; $mm < @{$interfaceTypeDefRef->{METHODS}}; $mm++ ) {
    my $methodDefRef = $interfaceTypeDefRef->{METHODS}[$mm];
    $methodStubs .= $self->_getMethodStub($interfaceName,$methodDefRef);
  }

  return $methodStubs;
} # getInterfaceMethodStubs

# Get method stub
# arg1 interface name
# arg2 RegviewDb method definition reference
# arg3 optional method header comment
sub _getMethodStub
{
  my $self              = shift;
  my $ifName            = shift;
  my $methodDefRef      = shift;
  my $methodComment     = "// Method of ".$ifName."\n";
  $methodComment        = shift if @_;

  my $seenMethodsRef = $self->{SEEN_METHODS_REF};
  my $indent         = $self->{INDENT};
  my $methodName     = $methodDefRef->{NAME};

  my $methodStub     = "\n";
  $methodStub       .= $indent . $methodComment;

  my $signature = $methodDefRef->getUnoSignature;
  my $priorInterface = "";
  $priorInterface = $seenMethodsRef->{$signature} if $seenMethodsRef;
  if ( $priorInterface ) {
    $methodStub .=
      $indent ."// ".$self->{CLASS_NAME}."::".$methodName
      ." already implemented for interface "
      .$priorInterface."\n";
  }
  else {
    my $cppUtils = new Codegen::CppUtils($self->{TYPE_DEF_DB},
                                         $self->{USE_SHORT_NAMES});
    
    $seenMethodsRef->{$signature} = $ifName if $seenMethodsRef;

    $methodStub .= $self->_getMethodDeclaration($methodDefRef,
                                                $indent);
    $methodStub .= "\n";
    $methodStub .= $indent . "{\n";
    my $implModule;

    if ( &isImplementedInBase($ifName, $self->{IS_SERVICE}) ) {

      $implModule = new Codegen::CppBaseDelegate($self->{TYPE_DEF_DB},
                                                 $ifName,
                                                 $self->{CLASS_NAME},
                                                 $self->{BASE_CLASS_NAME});
      $implModule->{IS_SERVICE} = $self->{IS_SERVICE};
      $implModule->{CATEGORY}   = $self->{CATEGORY};
    }

    else {
      $implModule = new Codegen::CppDefault($self->{TYPE_DEF_DB},
                                            $ifName,
                                            $self,
                                            $self->{CLASS_NAME});
    }
    $methodStub .= $implModule->getMethodCode($methodDefRef,
                                              $indent . "  ");
    $methodStub .= $indent . "}\n";
  }
  return $methodStub;
} # _getMethodStub


# Return string with declarations for all implemented methods
# for the interface
# 
# arg 1 interface name
# arg 2 interface type def reference for interface or its ancestor
# arg 3 1 if virtual, 0 if not
sub _getSingleInterfaceMethodDeclarations
{
  my $self                = shift;
  my $interfaceName       = shift;
  my $interfaceTypeDefRef = shift;
  my $isVirtual           = shift;

  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};
  my $indent       = $self->{INDENT};
  my $methodDecls  = "";

  # Attribute methods
  my $fieldDefRefs = $interfaceTypeDefRef->{FIELDS};
  for (my  $aa = 0; $aa < @$fieldDefRefs; $aa++ ) {
    my $fieldName = $interfaceTypeDefRef->getFieldName($aa);

    my $fieldDefRef = $fieldDefRefs->[$aa];
    my $attrGetMethodRef =  RegviewMethodDef->new;
    $attrGetMethodRef->setGetMethodFromFieldDef($fieldDefRef);
    $methodDecls .=
      $self->_getHeaderMethodDeclaration($attrGetMethodRef,
                                         $interfaceName,
                                         $indent,
                                         $isVirtual);
    if ( $fieldDefRef->isReadwrite ) {
      my $attrSetMethodRef =  RegviewMethodDef->new;
      $attrSetMethodRef->setSetMethodFromFieldDef($fieldDefRef);
      $methodDecls .=
      $self->_getHeaderMethodDeclaration($attrSetMethodRef,
                                         $interfaceName,
                                         $indent,
                                         $isVirtual);
    }
  }

  # Methods
  for (my  $mm = 0; $mm < @{$interfaceTypeDefRef->{METHODS}}; $mm++ ) {
    my $methodDefRef = $interfaceTypeDefRef->{METHODS}[$mm];
    $methodDecls .=
      $self->_getHeaderMethodDeclaration($methodDefRef,
                                         $interfaceName,
                                         $indent,
                                         $isVirtual);
  }

  return $methodDecls;
} # _getSingleInterfaceMethodDeclarations

# Return string which is the method declaration statement in the header
# protecting against duplicate declarations
# Method is always declared as virtual
# arg 1 is reference to RegviewMethodDef
# arg 2 interface name
# arg 3 indent string
# arg 4 optional virtual if true (default is virtual)
sub _getHeaderMethodDeclaration
{
  my $self         = shift;
  my $methodDefRef = shift;
  my $interfaceName= shift;
  my $indent       = shift;
  my $isVirtual    = 1;
  $isVirtual       = shift if @_;

  my $methodDecl = "";
  my $seenMethodsRef = $self->{SEEN_METHODS_REF};

  my $signature = $methodDefRef->getUnoSignature;
  my $priorInterface = "";
  $priorInterface = $seenMethodsRef->{$signature} if $seenMethodsRef;
  $methodDecl .= "\n".$indent."// Method of ".$interfaceName ."\n";
  if ( $priorInterface ) {
    $methodDecl .= $indent . "// " . $methodDefRef->{NAME}
    ." already implemented for interface "
      .$priorInterface."\n";
  }
  else {
    $seenMethodsRef->{$signature} = $interfaceName if $seenMethodsRef;
    $methodDecl .= $self->_getMethodDeclaration($methodDefRef,
                                                $indent,
                                                $isVirtual);
    $methodDecl .= ";\n";
  }

  return $methodDecl;
} # ! _getHeaderMethodDeclaration

# Return string which is the method declaration
# arg 1 is reference to RegviewMethodDef
# arg 2 indent string
# arg 3 optional 1 if virtual, 0 if not
sub _getMethodDeclaration
{
  my $self         = shift;
  my $methodDefRef = shift;
  my $indentString = shift;
  my $isVirtual    = 0;
  $isVirtual       = shift if @_;

  my $methodDeclaration = "";

  my $className    = $self->{CLASS_NAME};
  my $cppUtils     = new Codegen::CppUtils($self->{TYPE_DEF_DB},
                                           $self->{USE_SHORT_NAMES});
  
  my $cppReturnType =
    $cppUtils->getCppReturnType($methodDefRef->{RETURN_TYPE_NAME});
  $methodDeclaration .= $indentString;
  $methodDeclaration .= "virtual " if $isVirtual;
  $methodDeclaration .= $cppReturnType . " SAL_CALL";
  $methodDeclaration .= "\n".$indentString;

  $methodDeclaration .= $className . "::" if $className;
  $methodDeclaration .= $methodDefRef->{NAME} ;
  $methodDeclaration .= "(";

  my $paramsRef = $methodDefRef->{PARAMETERS};
  
  $methodDeclaration .= "\n" if ( @$paramsRef > 0 ) ;
  my $i = 0;
  my $paramIndent = $indentString . "  ";
  for ( $i = 0; $i < @$paramsRef; $i++ ) {
    my $paramTypeRef = $paramsRef->[$i];
    my $unoTypeName =
      $self->{TYPE_DEF_DB}->getResolvedTypeName($paramTypeRef->{TYPE_NAME});
    my $argName = $paramTypeRef->{ARG_NAME};
    $methodDeclaration .= $paramIndent;
    if ( $cppUtils->isTypeCppObject($unoTypeName) 
         && $paramTypeRef->isInParam ) {
      $methodDeclaration .= "const ";
    }
    $methodDeclaration .= &unoToCppType($unoTypeName,
                                        $cppUtils->isCppReference($unoTypeName),
                                        $self->{USE_SHORT_NAMES});
    $methodDeclaration .= "&" if $cppUtils->isCppPassedByRef($paramTypeRef);
    $methodDeclaration .= " " . $argName;
    if ( $i < $#{$paramsRef} ) {
      $methodDeclaration .= ",\n";
    }
    else {
      $methodDeclaration .= " " ;
    }
  }

  $methodDeclaration .= ")\n" ;
  my $exceptionsNamesRef = $methodDefRef->{EXCEPTION_NAMES};
  my $runtimeExceptionName = $self->getRuntimeException($methodDefRef);
  $methodDeclaration .= $indentString . "  throw (" ;
  if (@$exceptionsNamesRef > 0) {
    $methodDeclaration .= "\n";
    my $exceptionsIndent = $indentString . "    ";
    for ( $i = 0; $i < @$exceptionsNamesRef; $i++ ) {
      my $exceptionName = $exceptionsNamesRef->[$i];
      $methodDeclaration .= $exceptionsIndent;
      $methodDeclaration .= &unoToCppType($exceptionName, 0,
                                          $self->{USE_SHORT_NAMES});
      $methodDeclaration .= ",\n";
    }
    $methodDeclaration .= $exceptionsIndent .  $runtimeExceptionName .  " )";
  }
  else {
    $methodDeclaration .= " " .$runtimeExceptionName .  " )";
  }
  return $methodDeclaration;
} # ! _getMethodDeclaration

sub needsRegistration
{
  my $self = shift;
  
  return $self->{CDEF}->needsRegistration($self->{NAME});
}

sub dump
{
  my $self = shift;

  print "Codegen::CppMethods IS_SERVICE=".$self->{IS_SERVICE}."\n";;
  print "Codegen::CppMethods USE_SHORT_NAMES="
    .$self->{USE_SHORT_NAMES}."\n";;
  print "Codegen::CppMethods CLASS_NAME=".$self->{CLASS_NAME}."\n";;
  print "Codegen::CppMethods BASE_CLASS_NAME="
    .$self->{BASE_CLASS_NAME}."\n";;
  print "Codegen::CppMethods CATEGORY=".$self->{CATEGORY}."\n";;
  print "Codegen::CppMethods TYPE_DEF_DB=".$self->{TYPE_DEF_DB}."\n";;

}

# End of package, needed for module load
1;
