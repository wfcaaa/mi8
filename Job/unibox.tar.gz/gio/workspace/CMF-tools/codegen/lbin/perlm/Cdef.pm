# Perl package with utility methods useful when processing
# regview output.


# Contains the hash table with all types
# and access methods
package Cdef;

use strict;
use XML::LibXML;
use XML::LibXML::XPathContext;

# arg 1 cdefFile
sub new
{
  my ($class) = shift;
  @_ or die "Cdef->new: Missing cdefFile";
  my $cdefFile = shift;

  my $parser  = XML::LibXML->new();
  $parser->expand_xinclude(1);
  $parser->line_numbers();
  my $cdefDoc = $parser->parse_file($cdefFile);
  
  my $xpathContext = XML::LibXML::XPathContext->new($cdefDoc);

  return bless{
    file         => $cdefFile,
    parser       => $parser,
    cdef         => $cdefDoc,
    xpathContext => $xpathContext,
  }, $class;
}

# return component name
sub getComponentName()
{
  my $self = shift;
  my $name = "";

  my $nodes = $self->{xpathContext}->
    findnodes("/component/modelGenerated/name");

  if ( $nodes->size > 0 ) {
    my $node = $nodes->get_node(1);
    $name = $node->textContent;
  }

  return $name;
} # getComponentName

# Return list of all implemented services
sub getServiceNames
{
  my $self = shift;

  return $self->
    xpathText("/component/modelGenerated/serviceImplementation/service/name");
} # getServiceNames

# Return list of all implemented weakObjects
sub getWeakObjectNames
{
  my $self = shift;

  return $self->
    xpathText("/component/modelGenerated/weakObjectImplementation/weakObject/name");
} # getWeakObjectNames

# Return implementation class name for service or weakObject
# arg1 full service or weakObject name
sub getImplementationClassName()
{
  my $self = shift;
  my $name = shift;

  # default name to short service name
  my $className = $name;
  $className =~ s/.*\.//;

  my $elementXPath = "/component/modelGenerated//name[.='$name']";
  my $elementNode =
    $self->{xpathContext}->findnodes($elementXPath)->get_node(1);


  my $classXPath ="../../class";
  my @cdefClasses = $self->xpathText($classXPath,$elementNode);

  @cdefClasses and
    $className = shift @cdefClasses;
 
  return $className;
} # getImplementationClassName

# Return category for service or weakObject
# arg1 full service or weakObject name
sub getImplementationCategory
{
  my $self = shift;
  my $name = shift;

  my $category = "";

  my $elementXPath = "/component/modelGenerated//name[.='$name']";
  my $elementNode =
    $self->{xpathContext}->findnodes($elementXPath)->get_node(1);
  my $xpath = "(ancestor-or-self::*/\@category)[last()]";

  $category = ($self->xpathText($xpath, $elementNode))[0];

  return $category;
} # getImplementationCategory

# Return provides list for service or weakObject
# arg1 name of service or weakObject
sub getProvidesForName()
{
  my $self = shift;
  my $name = shift;

  my @provides = ();

  my $elementXPath = "/component/modelGenerated//name[.='$name']";
  my $elementNode =
    $self->{xpathContext}->findnodes($elementXPath)->get_node(1);

  if ( $elementNode ) {
    @provides = $self->xpathText("../provides",$elementNode);
  }
  return @provides;
} # getProvidesForName

# Return uses list for service or weakObject
# arg1 name of service or weakObject
sub getUsesForName()
{
  my $self = shift;
  my $name = shift;

  my @uses = ();

  my $elementXPath = "/component/modelGenerated//name[.='$name']";
  my $elementNode =
    $self->{xpathContext}->findnodes($elementXPath)->get_node(1);
  
  if ( $elementNode ) {
    @uses = $self->xpathText("../../uses",$elementNode);
  }
  return @uses;
} # getUsesForName

# Return implementation class name for service or weakObject
#  (with package prefix)
# arg1 full service or weakObject name
sub getFullImplementationClassName()
{
  my $self = shift;
  my $name = shift;

  # default name to short service name
  my $className = $self->getImplementationClassName($name);

  my $elementXPath = "/component/modelGenerated//name[.='$name']";
  my $elementNode =
    $self->{xpathContext}->findnodes($elementXPath)->get_node(1);

  my $packageName = $self->getNodePackage($elementNode);

  my $fullClassName = $packageName. "." . $className;

  return $fullClassName;
} # getFullImplementationClassName

# Return implementation class name for service or weakObject
#  (with package prefix)
# arg1 service or weakObject base class name
sub getBaseClassName()
{
  my $self = shift;
  my $name = shift;

  # default name to short service name
  my $baseClassName = $self->getImplementationClassName($name);
  if ( $self->isService($name) ) {
    $baseClassName .= "Base";
  }
  else {
    $baseClassName .= "ImplHelper";
  }

  return $baseClassName;
} # getFullImplementationClassName

# Return implementation class name for service or weakObject
#  (with package prefix)
# arg1 full service or weakObject base class name
sub getFullBaseClassName()
{
  my $self = shift;
  my $name = shift;

  my $baseClassName = $self->getFullImplementationClassName($name);
  if ( $self->isService($name) ) {
    $baseClassName .= "Base";
  }
  else {
    $baseClassName .= "ImplHelper";
  }

  return $baseClassName;
} # getFullImplementationClassName


# Return list of text content for matching nodes
# arg1 $xpath
# arg2 optional context node, default is root
sub xpathText()
{
  my $self  = shift;
  my $xpath = shift;
  my $context = $self->{xpathContext};
  if ( @_ ) {
    $context = shift;
  }

  my @results = ();

  my $nodes = $context->findnodes($xpath);

  foreach my $node ($nodes->get_nodelist) {
    push @results, $node->textContent;
  }

  return (@results);
} # xpathText

# Returns true (1) if implementation name is a service
# 
# arg1 service or weakObjectName
sub isService
{
  my $self = shift;
  my $name = shift;

  my $elementXPath = "/component/modelGenerated//service/name[.='$name']";
  my $elementNodes =
    $self->{xpathContext}->findnodes($elementXPath);

  return $elementNodes->size;
} # isService

# Return name of package for cdef node
# arg1 context node for element
sub getNodePackage
{
  my $self    = shift;
  my $elementNode = shift;

  my $xpath = "(ancestor-or-self::*/package)[last()]";
  my $packageName = ($self->xpathText($xpath, $elementNode))[0];

  return $packageName;
} # getNodePackage

sub needsRegistration
{
  my $self = shift;
  my $serviceName = shift;

  my $xpath = '/component/modelGenerated//service' .
     '[@singleton="true" and' .
     ' name="' . $serviceName . '" and' .
     ' not(provides="xoc.svc.session.ZSessionLifecycle")' .
     ']' ;
  my $context = $self->{xpathContext};
  my $nodes = $context->findnodes($xpath);
  my $needsReg = "false";  

  if ( $nodes->size > 0 ) {
       $needsReg = "true";
  }  
  
  return  $needsReg;
}

sub printList
{
  my $self = shift;

  print "(";
  foreach my $ll (@_) {
    print $ll . ",";
  }
  print ")";

}
# Needed for module load
1;

