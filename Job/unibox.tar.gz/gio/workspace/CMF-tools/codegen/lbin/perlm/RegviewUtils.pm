# Perl package with utility methods for Uno types in RegviewTypedb


package RegviewUtils;

require Exporter;
@ISA    = qw(Exporter);
@EXPORT = qw(toDotPath            toSlashPath
             removeArraysFromType getNumberOfArraysFromType
             );



# Converts '/' to '.' separated path 
sub toDotPath
{
    my $path = shift;
    $path =~ s%/%.%g ;
    return $path;
}

# Converts '.' to '/' separated path 
sub toSlashPath
{
    my $path = shift;
    $path =~ s%\.%/%g ;
    return $path;
}

# Remove arrays from type
sub removeArraysFromType
{
    my $arraylessType = shift;
    $arraylessType =~ s/(\[|\])//g ;
    return $arraylessType;
}

# Returns the number of arrays for the type
sub getNumberOfArraysFromType
{
    my $type = shift;
    my $arrayBrackets = "";
    if ( $type =~ m/\[/ ) {
        ( $arrayBrackets ) = ( $type =~ m/((\[\])*)/ );
    }
    my $numArrays = (length $arrayBrackets)/2;
    return $numArrays;
}

# Needed for module load
1;

