# Perl package with utility methods for generating code methods
# (not languge specific)

package Codegen::Utils;

use strict;
use FileHandle;

require Exporter;
@Codegen::Utils::ISA    = qw(Exporter);
@Codegen::Utils::EXPORT = qw(getBeginEditableSection getEndEditableSection
                             getEditableSectionContent
                             getNSpaces
                             );

# arg 1 is key (normally method name)
# arg 2 is optional comment code (default "//")
sub getBeginEditableSection
{
  my $key = shift;
  my $commentCode = "//";
  @_ > 0 and $commentCode = shift;

  return $commentCode .
    " ---- BEGIN EDITABLE SECTION " . $key . " ----\n";
} # ! getBeginEditableSection

# arg 1 is key (normally method name)
# arg 2 is optional comment code (default "//")
sub getEndEditableSection
{
  my $key = shift;
  my $commentCode = "//";
  @_ > 0 and $commentCode = shift;

  return $commentCode .
    " ---- END EDITABLE SECTION " . $key . " ----\n";
} # ! getEndEditableSection

# return content of editable section (if file and section exists)
# arg1 filename
# arg2 editable section key
sub getEditableSectionContent
{
  my $filename = shift;
  my $key      = shift;
  my $content  = "";

  my $fh = new FileHandle;
  if ( $fh->open($filename, "r") ) {
    my $inES = 0;
    while ( <$fh> ) {
      if ( m/ ---- BEGIN EDITABLE SECTION +$key +----( *$| )/ ) {
        $inES = 1;
        next;
      }
      elsif ( m/ ---- END EDITABLE SECTION +$key +----( *$| )/ ) {
        $inES = 0;
        last;
      }
      elsif ( $inES ) {
        $content .= $_;
      }
    }
    $fh->close;
  }
  return $content;
}

# Returns a string of n spaces
# $1 n the number of spaces
sub getNSpaces
{
    my $n = shift;
    my $spaceString = "";
    for ( my $i = 0; $i < $n ; $i++ ) {
        $spaceString .= " ";
    }

    return $spaceString;
}

# End of package, needed for module load
1;
