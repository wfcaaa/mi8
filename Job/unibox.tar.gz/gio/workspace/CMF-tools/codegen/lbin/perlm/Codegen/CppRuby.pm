# Perl package with utility methods etc.
# supporting C++ code generation from uno types

#

package Codegen::CppRuby;


use strict;
use lib "..";
use RegviewTypesDb;
use Codegen::Utils;
use Codegen::CppUtils;

sub new
{
  my $class     = shift;
  my $typeDefDb = shift;  # RegviewTypesDb reference
  my $interface = shift;  # UNO interface name
  my $className = "";     # C++ class name (short)
  @_ and $className = shift;

  return bless {
    
    TYPE_DEF_DB    => $typeDefDb,
    INTERFACE_NAME => $interface,
    INTERFACE_REF  => $typeDefDb->getTypeDefinition($interface ),
    CLASS_NAME     => $className,
    INDENT         => "  ",
    }, $class ;

}

# returns a string containing the implementation code to
# bridge a C++ method to its equivalent Ruby implementation method
# arg1 reference to RegviewMethodDef for the method to generate
# arg2 indent string
sub getMethodCode
{
  my $self             = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;
  my $code = "";

  my $methodName = $methodDefRef->{NAME};

  my $cppUtils  = new Codegen::CppUtils($self->{TYPE_DEF_DB});
  my $className  = $self->{CLASS_NAME};

  $code .= $methodCodeIndent .
    &getBeginEditableSection($methodName);

  if ($methodName eq "initialize"
      && $self->{INTERFACE_NAME} eq "com.sun.star.lang.XInitialization") {
    $code .= $self->_getInitializeCode($methodCodeIndent);
  }
  else {
    $code .= $self->_getCodeCallingRubyMethod($methodDefRef,
                                              $methodCodeIndent);
  }
  $code .= $methodCodeIndent . &getEndEditableSection($methodName);
  return $code;
} # ! getMethodCode

# get code delegating C++ method to its Ruby implementation
# arg1 methodDef reference
# arg2 indent string, method code level
sub _getCodeCallingRubyMethod
{
  my $self             = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;

  my $cppUtils   = new Codegen::CppUtils($self->{TYPE_DEF_DB});
  my $paramsRef  = $methodDefRef->{PARAMETERS};
  my $methodName = $methodDefRef->{NAME};
  my $code = "";

  my $cppReturnType =
    $cppUtils->getCppReturnType($methodDefRef->{RETURN_TYPE_NAME});
  my $fragment .= $methodCodeIndent;
  $fragment .= "return " if $cppReturnType !~ m/^void$/ ;
  $fragment .= "pRubyStub" .
    $self->{TYPE_DEF_DB}->getShortTypeName($self->{INTERFACE_NAME}).
    "->" .
    $methodName .
    "(" ;

  $code .= $fragment;
  my $argIndent = &getNSpaces(length $fragment);
  for ( my $i = 0; $i < @$paramsRef; $i++ ) {
    $code .= $paramsRef->[$i]{ARG_NAME};
    if ( $i < $#{$paramsRef} ) {
      $code .= ",\n$argIndent" ;
    }
  }
  $code .= ");\n";
} # ! _getCodeCallingRubyMethod

# get code for com.sun.star.lang.XInitialization.initialize method
# arg1 indent string
sub _getInitializeCode
{
  my $self             = shift;
  my $methodCodeIndent = shift;

  my $mappedMethodName = "unoInitialize";

  my $code = $methodCodeIndent .
    "::xoc::threads::Guard< ::xoc::threads::Mutex > guard(mInitializedMutex);\n";
  $code .= $methodCodeIndent .
    "if ( mInitialized == sal_False ) {\n";
  $code .= $methodCodeIndent .
    "  mInitialized = sal_True;\n";
  $code .= "#ifdef " .
    "ENABLE_RUBY_UNO_XINITIALIZATION_FOR_" . uc $self->{CLASS_NAME} . "\n";
  $code .= $methodCodeIndent . "  " .
    "pRubyStubXInitialization->" . $mappedMethodName ."(aArguments);" . "\n";
  $code .= "#endif\n";

  $code .= $methodCodeIndent . "}\n";
} # ! _getInitializeCode

# End of package, needed for module load
1;
