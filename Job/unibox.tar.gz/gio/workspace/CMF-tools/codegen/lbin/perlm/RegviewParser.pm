# Perl package which provides simple parsing of review output

# Example input:
# Registry "file:///vobs/zenith/common/IDL/zenith.rdb":
#
# /
#  / UCR
#    / xoc
#      / svc
#        / session
#          / ZSessionLifecycle
#            Value: Type = RG_VALUETYPE_BINARY
#                   Size = 204
#                   Data = version: 0
# 
#                          documentation: ""
#                          file name: ""
#                          type class: interface
#                          type name: "xoc/svc/session/ZSessionLifecycle"
#                          super type count: 1
#                          super type name 0: "com/sun/star/uno/XInterface"
#                          field count: 0
#                          method count: 2
#                          method 0:
#                              documentation: ""
#                              flags: synchronous
#                              name: "sbsInitialize"
#                              return type name: "void"
#                              parameter count: 0
#                              exception count: 0
#                          method 1:
#                              documentation: ""
#                              flags: synchronous
#                              name: "sbsShutdown"
#                              return type name: "void"
#                              parameter count: 0
#                              exception count: 0
#                          reference count: 0

package RegviewParser;

use strict;
use FileHandle;


# Constructor
# arg 1 is registry Key
# arg 2... =  filename list
sub new
{
    my ($class) = shift;
    my $registryKey = shift;
    my @rdbFiles = @_;

    if (  @rdbFiles > 0 ) {
        return bless {
            "REGISTRY_KEY"     => $registryKey,
            "RDB_FILES_REF"    => \@rdbFiles,
            "CURRENT_FILE"     => "",
            "FILE_SPEC"        => 0,
            "FILE_HANDLE"      => 0,
            "LINE_NUMBER"      => 0,
            "LINE"             => "",
            "RDB_INDENT_STACK" => [],
            "RDB_KEY_STACK"    => [],
            "RDB_VALUE_STACK"  => [],
        }, $class ;
    }
    else {
        print STDERR "Warning: No Rdb files\n";
        my ($packge, $filename, $line) = caller;
        return 0;
    }

} # ! new

# Open next rdb file from list with regview
# Returns true if file open, false if not
sub _openNextRdb
{
    my $self  = shift;
    my $opened = 0;
    my $fileHandle = $self->{FILE_HANDLE};
    if ( $fileHandle == 0 ) {
        $fileHandle = new FileHandle;
    }
    else {
        $self->closeRdb;
    }

    my $fileName = "";
    if ( @{$self->{RDB_FILES_REF}} ) {
        $fileName = shift @{$self->{RDB_FILES_REF}};
    }
    if ( $fileName ) {
        my $fileSpec = $ENV{OO_SDK_URE_BIN_DIR} . "/regview ";
        $fileSpec .= $fileName;
        $fileSpec .= " " . $self->{REGISTRY_KEY};
        $fileSpec .= " 2>/dev/null |";
        if (open ($fileHandle, $fileSpec) ) {
            $self->{CURRENT_FILE} = $fileName;
            $self->{FILE_HANDLE}  = $fileHandle;
            $self->{LINE_NUMBER}  = 0;
            $opened = 1;
        }
    }
    return $opened;
} # ! _openNextRdb

# Close rdb file
sub closeRdb
{
    my $self  = shift;
    my $fileHandle = $self->{FILE_HANDLE};
    if ( $self->{CURRENT_FILE}
         && $fileHandle ) {
        close $fileHandle ;
        $self->{CURRENT_FILE} = "";
    }
}

# Read one line from the input, stepping through rdb files until exhausted
# returns the line, false if end of file.
sub readLine
{
    my $self        = shift;
    my $currentFile = $self->{CURRENT_FILE};
    my $line        = "";

    my $haveRdb = 1;
    if ( ! $currentFile ) {
        $haveRdb = $self->_openNextRdb;
    }

    if ( $haveRdb ) {
        my $fileHandle = $self->{FILE_HANDLE};
        $line = <$fileHandle>;
        if ( ! $line ) {
            $haveRdb = $self->_openNextRdb;
            if ( $haveRdb ) {
                $fileHandle = $self->{FILE_HANDLE};
                $line = <$fileHandle>;
            }
        }
    }

    $self->{LINE_NUMBER} += 1;
    $self->{LINE} = $line;
    return $line;
} # ! readLine


# parseNextLine, reads one line, and puts its key into rdbKeyStack
# with the key value
#   rdb key entries start with / and are nested
#   minor key entries have : to separate key and value
# other lines are ignored
# All items are trimmed before storing, any spaces in a key are converted to
# underscore before storing
# returns true if OK, false if end of file
sub parseNextLine
{
    my $self  = shift;

    $_ = $self->readLine;

    $_ or return 0;  # EOF
    
    my $indentSize = $self->_getIndentSize($_);

    if ( $self->_hasMajorKey($_) ) {
        my $majorKey = $self->_getMajorKey($_);
        $self->_putKeyInStack($indentSize,  $majorKey, "");
    }
    elsif ( $self->_hasMinorKey($_) ) {
        $self->_putKeyInStack($indentSize,
                              $self->_getMinorKey($_),
                              $self->_getMinorKeyValue($_));
    }
    return 1;
} # ! parseNextLine

# Goes to next matching key in the file
# arg 1 class
# arg 2 regex pattern to match key
#  returns key if found, "" if not
sub findNext
{
    my $self  = shift;
    my $pattern = shift;
    my $returnKey = "";

    while ( $self->parseNextLine() ) {
        if ($self->matchCurrentKey($pattern) ) {
            $returnKey = $self->getCurrentKey;
            last;
        }
    }
    return $returnKey;
} # ! findNext

# Match current key to regex pattern
# Returns true if current key matches the regex pattern
# arg 2 regex pattern to match
sub matchCurrentKey
{
    my $self = shift;
    my $pattern = shift;
    my $isMatch = 0;

    my $matchExpression = "m%" . $pattern . "%";

    my $currentKey = $self->getCurrentKey;

    if ( $currentKey =~ m%${pattern}% ) {
        $isMatch = 1;
    }
    return $isMatch;
}

# Match current key to regex pattern
# Returns true if current key matches the regex pattern
# arg 2 regex pattern to match
sub matchCurrentValue
{
    my $self = shift;
    my $pattern = shift;
    my $isMatch = 0;

    my $matchExpression = "m%" . $pattern . "%";

    my $currentValue = $self->getCurrentValue;

    if ( $currentValue =~ m%${pattern}% ) {
        $isMatch = 1;
    }
    return $isMatch;
}


# Get current key value in regview file
#
sub getCurrentKey
{
    my $self  = shift;
    my $currentKey = "";
    my $keyStackRef = $self->{RDB_KEY_STACK};

    if ( $#{$keyStackRef} >= 0 ) {
        $currentKey = $keyStackRef->[$#{$keyStackRef}];
    }
    return $currentKey;
}

# Get UNO type at current position
# Returns UNO type, "" if none
sub getCurrentUnoTypeName
{
    my $self  = shift;
    my $unoTypeName = "";

    my $currentKey = $self->getCurrentKey;
    if ( $currentKey =~ m%(\/UCR\/)(.+)(\/Value.*)% ) {
        $currentKey =~ s%(\/UCR\/)(.+)(\/Value.*)%$2% ;
        $unoTypeName = RegviewUtils::toDotPath($currentKey);
    }
    return $unoTypeName;
}

# Get parent key of current key value in regview file
#
sub getParentKey
{
    my $self  = shift;
    my ($parentKey) = $self->getCurrentKey =~ m%(.+)/.*%;

    return $parentKey;
}

# Get value mapped to current key value in regview file
#
sub getCurrentValue
{
    my $self  = shift;
    my $currentValue = "";
    my $valueStackRef = $self->{RDB_VALUE_STACK};

    if ( $#{$valueStackRef} >= 0 ) {
        $currentValue = $valueStackRef->[$#{$valueStackRef}];
    }
    return $currentValue;
}

# Get value mapped to current key value in regview file
# with any enclosing double quotes removed
#
sub getUnquotedValue
{
    my $self  = shift;
    my $value = $self->getCurrentValue;
    $value =~ s/\"?([^\"]*)\"?$/$1/ ;
    return $value ;
}

# Dump parser state to STDERR
#
sub debugDumpParser
{
    my $self = shift;

    print STDERR "debugDumpParser: REGISTRY_KEY=" . $self->{REGISTRY_KEY} . "\n";
    print STDERR "debugDumpParser: ". @{$self->{RDB_FILES_REF}}." RDB_FILES=";
    foreach my $rf ( @{$self->{RDB_FILES_REF}} ) {
        print STDERR "$rf" . " ";
    }
    print STDERR "\n";
    print STDERR "debugDumpParser: CURRENT_FILE=" . $self->{CURRENT_FILE} . "\n";
    print STDERR "debugDumpParser: FILE_SPEC=" . $self->{FILE_SPEC} . "\n";
    print STDERR "debugDumpParser: FILE_HANDLE=" . $self->{FILE_HANDLE} . "\n";
    print STDERR "debugDumpParser: LINE_NUMBER=" . $self->{LINE_NUMBER} . "\n";
    print STDERR "debugDumpParser: LINE=" . $self->{LINE} . "\n";
    print STDERR "debugDumpParser: RDB_INDENT_STACK length="
        . @{$self->{RDB_INDENT_STACK}} . "\n";
    if ( $#{$self->{RDB_KEY_STACK}} >= 0 ) {
        print STDERR "debugDumpParser: RDB_KEY_STACK top="
            . $self->{RDB_KEY_STACK}[$#{$self->{RDB_KEY_STACK}}] . "\n";
    }
    if ( $#{$self->{RDB_VALUE_STACK}} >= 0 ) {
        print STDERR "debugDumpParser: RDB_VALUE_STACK top="
            . $self->{RDB_VALUE_STACK}[$#{$self->{RDB_VALUE_STACK}}] . "\n";
    }
} # ! debugDumpParser

# Local  methods
#
# Set key in key stack, places key on 
# arg 1 self
# arg 2 indent size
# arg 3 key name
# arg 4 value ( for minor keys only, major keys set to 0 (false) )
sub _putKeyInStack
{
    my $self  = shift;
    my $indentSize = shift;
    my $key   = shift;
    my $value = shift;

    my $indentStackRef = $self->{RDB_INDENT_STACK};
    my $keyStackRef    = $self->{RDB_KEY_STACK};
    my $valueStackRef  = $self->{RDB_VALUE_STACK};

    # if larger size stack, reduce until smaller than
    while ( $#{$indentStackRef} >= 0
            && $indentSize <= $indentStackRef->[$#{$indentStackRef}] ) {
        pop @$indentStackRef;
        pop @$keyStackRef;
        pop @$valueStackRef;
    }

    push @$indentStackRef, $indentSize;
    push @$valueStackRef,  $value ;
    if ( $#{$keyStackRef} < 0 ) {
        # Empty stack case
        push @$keyStackRef, "/" . $key ;
    }
    else {
        # Create full key here
        push @$keyStackRef, $keyStackRef->[$#{$keyStackRef}] . "/" . $key ;
    }
} # ! _putKeyInStack

# Returns number of whitespace characters at start of line
sub _getIndentSize
{
    my $self = shift;
    my $indent = shift;
    chomp $indent;
    my $indentSize = 0;
    if ( $indent =~ m/^(\s+)/ ) {
        $indent =~ s/^(\s+).*$/$1/ ;
        $indentSize = length $indent;
    }
    return $indentSize;
}

# Checks if line contains a major key
# line with spaces t "/" followed by keyname
sub _hasMajorKey
{
    my $self = shift;
    my $line = shift;
    return $line =~ m%^(\s*)/(\s*)[^\s]+% ;
}

# Returns major key value (string after "/" )
sub _getMajorKey
{
    my $self = shift;
    my $majorKey = shift;
    chomp $majorKey;
    $majorKey =~ s/^.*\/// ; # Remove upto "/"

    $majorKey =~ s/^\s+//;  # trim before
    $majorKey =~ s/\s+$//;  # trim after

    return $majorKey;
}

# Checks if line contains a minor key
# line containing  minot keyname ":" followed by value
sub _hasMinorKey
{
    my $self = shift;
    my $line = shift;
    return $line =~ m%^(\s+)(\b[^:]+)(: ?)% ;
}

# Returns (trimmed) string after ":" in input line
sub _getMinorKey
{
    my $self = shift;
    my $minorKey = shift;
    chomp $minorKey;
    $minorKey =~ s/^\s+//;  # trim indent
    $minorKey =~ s/\s*:.*$//;  # remove ':" and after

    return $minorKey;
}

# Returns (trimmed) string after ":" in input line
sub _getMinorKeyValue
{
    my $self = shift;
    my $minorKeyValue = shift;
    chomp $minorKeyValue;
    $minorKeyValue =~ s/^.*:// ; # Remove upto colon
    $minorKeyValue =~ s/^\s+//;  # trim
    $minorKeyValue =~ s/\s+$//;

    return $minorKeyValue;
}

END {
    if ($#_ > 0) {
        print STDERR "END: first" . shift ;
    }
}

# Needed to load as package
1;

