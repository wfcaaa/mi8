# Perl package for generating method implementations for
# methods that are delegated to the base class method.
#

package Codegen::JavaBaseDelegate;


use strict;
use lib "..";
use RegviewTypesDb;
use Codegen::Utils;
use Codegen::JavaUtils;

sub new
{
  my $class     = shift;
  my $typeDefDb = shift;  # RegviewTypesDb reference
  my $interface = shift;  # UNO interface name
  my $className = shift;  # Java class name (short)

  return bless {
    
    TYPE_DEF_DB    => $typeDefDb,
    INTERFACE_NAME => $interface,
    INTERFACE_REF  => $typeDefDb->getTypeDefinition($interface ),
    CLASS_NAME     => $className,
    INDENT         => "  ",
    CATEGORY       => "default",
    }, $class ;
}

# returns a string containing the implementation code to
# delegate a method call to the base class method.
# arg1 reference to RegviewMethodDef for the method to generate
# arg2 indent string
sub getMethodCode
{
  my $self             = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;

  my $code = "";
  my $methodName = $methodDefRef->{NAME};

  my $className = $self->{CLASS_NAME};

  $code .= $methodCodeIndent . &getBeginEditableSection($methodName);

  $code .=  $self->_getEditableCode($methodCodeIndent, $methodDefRef);

  $code .= $methodCodeIndent . &getEndEditableSection($methodName);

  return $code;
} # ! getMethodCode

# Returns the editable code for the delegated call.
# $1 indent string
# $2 methodDefRef method definition
sub _getEditableCode
{
  my $self = shift;
  my $methodCodeIndent = shift;
  my $methodDefRef     = shift;

  my $methodImpl = "";

  $methodImpl .= $methodCodeIndent
    . "// WARNING:"
    . " removing the base class method call may break the component\n";

  if ( $methodDefRef->{RETURN_TYPE_NAME} =~ m/^void$/ ) {
    $methodImpl .= $methodCodeIndent
      . "super."
      . &getJavaMethodCall($methodDefRef)
      . ";\n";
  }
  else {
    $methodImpl .= $methodCodeIndent
      . "return super."
      . &getJavaMethodCall($methodDefRef)
      . ";\n";
  }

  return $methodImpl;
} # ! _getEditableCode


# End of package, needed for module load
1;
