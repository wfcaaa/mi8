# Perl package with utility methods for Ruby conversions
# regview output.

package Codegen::RubyUtils;

use RegviewUtils;
use Codegen::Utils;

require Exporter;
@ISA    = qw(Exporter);
@EXPORT = qw(unoToRubyType unoToRubyEnumType
             getRubyShortName);

## Ruby utils
# Ruby types table, see http://udk.openoffice.org/java/man/map_idl_to_java.html
%Codegen::RubyUtils::lookupRubyType =
    ("boolean"        => "?Fixnum?",
     "short"          => "Bignum",
     "unsigned short" => "Bignum",
     "long"           => "Bignum",
     "unsigned long"  => "Bignum",
     "hyper"          => "Bignum",
     "unsigned hyper" => "Bignum",
     "float"          => "Float",
     "double"         => "Float",
     "char"           => "?char?",
     "byte"           => "?byte?",
     "string"         => "String",
     "any"            => "?C_com_sun_star_uno_Any?",
     "type"           => "?C_com_sun_star_uno_Type?",
     "com.sun.star.uno.XInterface" => "?C_com_sun_star_uno_Xinterface?"
     );

# Init code for each UNO type in Ruby
%Codegen::RubyUtils::lookupRubyInitStrings =
    ("byte"           => " = 0",
     "short"          => " = 0",
     "unsigned short" => " = 0",
     "long"           => " = 0",
     "unsigned long"  => " = 0",
     "hyper"          => " = 0",
     "unsigned hyper" => " = 0",
     "float"          => " = 0.0",
     "double"         => " = 0.0",
     "boolean"        => " = false",
     "char"           => " = 0",
     "string"         => " = \"\"",
     "type "          => " = nil",
     "any"            => " = nil"
     );
# arg1 regview type definition database reference
# arg2 =1, output mthods use short names, 0, use full names
# (long names not supported for ruby yet)
sub new
{
  my ($class)     = shift;
  my ($typeDefDb) = shift;
  my $useShortNames = 1;
  $useShortNames = shift if @_;

  return bless {
    TYPE_DEF_DB      => $typeDefDb,
    USE_SHORT_NAMES  => $useShortNames,
    }, $class ;

}

# Converts UNO type name to Ruby type name
# 1. IDL simple types: lookup in table
# 2. IDL interface: object
# 3. UNO struct: object
# 4. Other: object
# 5. arrays: arrays to same depth
# arg 1 is UNO type
# arg 2 optional shortname flag, true to output short name.
sub junk_unoToRubyType
{
    my $unoType = shift;
    my $useShortName = 0;
    if ( @_ > 0 ) {
        $useShortName = shift;
    }

    my $basicUnoType   = &removeArraysFromType($unoType);
    my $numberOfArrays = &getNumberOfArraysFromType($unoType);
    my $rubyType = "";

    if ( exists $Codegen::RubyUtils::lookupRubyType{$basicUnoType} ) {
        $rubyType = $Codegen::RubyUtils::lookupRubyType{$basicUnoType} ;
    }
    else {
        
        # Convert everything else to Ruby class name
        $rubyType = "C_" . $basicUnoType =~ s/\./_/g ;
    }
    for ( my $i = 0; $i < $numberOfArrays; $i++) {
        $rubyType .= "??array??";
    }
    
    return $rubyType;
} # ! unoToRubyType

# Converts UNO enum type name to Ruby type name
# arg 1 is UNO type
sub unoToRubyEnumType
{
    my $unoType = shift;

    $rubyEnumType = "E_" . $unoType =~ s/\./_/g ;
    
    return $rubyEnumType;
} # ! unoToRubyEnumType

# Get short name from Ruby type
sub getRubyShortName
{
    my $rubyType = shift;
    my $shortName = $rubyType;

    $rubyType =~ m/.*\..+/
        and $shortName =~ s/(.*\.)(.+)/$2/ ;

    return $shortName;
} # ! getRubyShortName

# Return string that is return value declaration for ruby method,
# empty if void return type
# arg 1 name of UNO type
# arg 2 indent string
sub getRubyReturnValueDecl
{
  my $self         = shift;
  my $unoType      = shift;
  my $indentString = shift;

  my $decl = "";
  if ( $unoType ne "void" ) {
    my $resolvedTypeName = $self->{TYPE_DEF_DB}->getResolvedTypeName($unoType);

    $decl .= $indentString;
    $decl .= "returnValue";
    $decl .= $self->getRubyInitCode($resolvedTypeName);
    $decl .= "\n";

  }
  return $decl;
} # ! getRubyReturnValueDecl

# get Ruby init code for UNO type
# 1. simple types as in table
# 2. enum value of first enum entry
# 3. struct, arrays, references return default constructor value
# arg 1 reference to UNO type name
sub getRubyInitCode
{
  my $self        = shift;
  my $unoTypeName = shift;

  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};
  my $initCode = " = nil"; # unknown types are treated as objects

  # map UNO types to Ruby initcode
  if ( exists $Codegen::RubyUtils::lookupRubyInitStrings{ $unoTypeName } ) {
    $initCode = $Codegen::RubyUtils::lookupRubyInitStrings{ $unoTypeName } ;
  }
  elsif ( $rdbTypeDefDb->isTypeAnEnum($unoTypeName) ) {
    $initCode = " = " 
      . &unoToRubyEnumType($unoTypeName)
      . "_" . $rdbTypeDefDb->getTypeFieldName($unoTypeName, 0);
  }
  elsif ( &getNumberOfArraysFromType($unoTypeName) > 0 ){
    $initCode = " = []";
  }
  # else maps to object, init is nil
  
  return $initCode;
} # ! getRubyInitCode

# Return string that is return stamement for a method
# with returnValue, if needed.
# arg 1 name of UNO type
# arg 2 indent string
sub getRubyReturnStatement
{
  my $self = shift;
  my $unoType = shift;
  my $indentString = shift;
  my $retStatement = "";

  if ( $unoType ne "void"  ) {
    $retStatement .= $indentString . "return returnValue\n" ;
  }

  return $retStatement;
} # ! getRubyReturnStatement


