# Perl package with utility methods etc.
# supporting C++ code generation from uno types

#

package Codegen::CppUtils;

#use strict;

use lib "..";
use RegviewUtils;
use Codegen::Utils;

require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(toCppPath     isCppFundamentalType
             unoToCppType  getCppShortName getCppNamespace
             );

# arg1 regview type definition databse reference
# arg2 =1, output mthods use short names, 0, use full names
sub new
{
  my ($class)     = shift;
  my ($typeDefDb) = shift;
  my $useShortNames = 1;
  $useShortNames = shift if @_;

  return bless {
    TYPE_DEF_DB      => $typeDefDb,
    USE_SHORT_NAMES  => $useShortNames,
    }, $class ;

}


# C++ utils
# Cpp types table, see http://udk.openoffice.org/cpp/man/spec/cpp_spec.html
%Codegen::CppUtils::lookupCppType =
    ("void"           => "void",
     "byte"           => "::sal_Int8",
     "short"          => "::sal_Int16",
     "unsigned short" => "::sal_uInt16",
     "long"           => "::sal_Int32",
     "unsigned long"  => "::sal_uInt32",
     "hyper"          => "::sal_Int64",
     "unsigned hyper" => "::sal_uInt64",
     "float"          => "float",
     "double"         => "double",
     "boolean"        => "::sal_Bool",
     "char"           => "::sal_Unicode",
     "string"         => "::rtl::OUString",
     "type"           => "::com::sun::star::uno::Type",
     "any"            => "::com::sun::star::uno::Any",
     );

# Cpp fundamental types table
%Codegen::CppUtils::lookupCppFundamentals =
    ("void"           => 1,
     "byte"           => 1,
     "short"          => 1,
     "unsigned short" => 1,
     "long"           => 1,
     "unsigned long"  => 1,
     "hyper"          => 1,
     "unsigned hyper" => 1,
     "float"          => 1,
     "double"         => 1,
     "boolean"        => 1,
     "char"           => 1,
     );

# Init code for each UNO type in Cpp
%Codegen::CppUtils::lookupCppInitStrings =
    ("byte"           => " = 0",
     "short"          => " = 0",
     "unsigned short" => " = 0",
     "long"           => " = 0",
     "unsigned long"  => " = 0",
     "hyper"          => " = 0",
     "unsigned hyper" => " = 0",
     "float"          => " = 0.0",
     "double"         => " = 0.0",
     "boolean"        => " = sal_False",
     "char"           => " = 0",
     "string"         => "",
     "type"           => "",
     "any"            => ""
     );

$Codegen::CppUtils::cppSequenceType = "::com::sun::star::uno::Sequence";

# Static methods
#

# Converts '.' to '::' separated path 
sub toCppPath
{
    my $path = shift;
    $path =~ s%\.%::%g ;
    return $path;
}

# Get short name from Cpp type
sub getCppShortName
{
    my $cppType = shift;
    my $shortName = $cppType;

    $cppType =~ m/.*::.+/
        and $shortName =~ s/(.*::)(.+)/$2/ ;

    return $shortName;
}

# Get namespace from Cpp type
sub getCppNamespace
{
    my $cppType = shift;
    my $namespace = "";

    if ( $cppType =~ m/::/ ) {
      if ( $cppType =~ m/</ ) {
        # type includes C++ template e.g. a::b::c::Sequence < ::sal_int32 i >
        ($namespace) = $cppType =~ m/(.*)::.*</;
      }
      else {
        ($namespace) = $cppType =~ m/(.*)::.*/;
      }
    }
    return $namespace;
}

# Returns true if UNO type is maps to a fundamental Cpp type
#
sub isCppFundamentalType
{
    my $unoType = shift;
    my $isFundType = 0;
    exists $Codegen::CppUtils::lookupCppFundamentals{$unoType}
    and  $isFundType = 1;
    return $isFundType;
}

# Converts type to C++ type
# Converts UNO type name to Cpp type name
# 1. IDL simple types: lookup in table
# 2. IDL interface: Reference
# 3. UNO struct: Cpp class
# 4. Other: warn?
# 5. arrays: nested Sequences of the converted basic type
# arg 1 is UNO type
# arg 2 optional isReference flag, true if type is wrapped with Reference class
#    (i.e. IDL interfaces)
# arg 3 optional shortname flag, true to output short name.
sub unoToCppType
{
    my $unoType = shift;
    my $isReference = 0;
    if ( @_ > 0 ) {
        $isReference = shift;
    }
    my $shortName = 0;
    if ( @_ > 0 ) {
        $shortName = shift;
    }

    my $basicUnoType = &removeArraysFromType($unoType);
    my $numberOfArrays = &getNumberOfArraysFromType($unoType);
    my $cppType = "";

    if ( exists $Codegen::CppUtils::lookupCppType{$basicUnoType} ) {
        $cppType = $Codegen::CppUtils::lookupCppType{$basicUnoType} ;
    }
    else {
        # Convert everything else to Cpp class
        $cppType = "::" . &toCppPath($basicUnoType);
    }
    if ( $shortName ) {
        $cppType = &getCppShortName($cppType);
        if ( $isReference ) {
            $cppType = "Reference< " .  $cppType .  " >" ;
        }
    }
    elsif ( $isReference ) {
        $cppType = "::com::sun::star::uno::Reference< " .  $cppType .  " >" ;
    }
    if ( $numberOfArrays ) {
        $cppType = &wrapCppTypeInSequences($numberOfArrays,
                                           $cppType,
                                           $shortName);
    }
    return $cppType;
} # ! unoToCppType

# Wrap type in Sequence 
# arg 1 depth of sequences
# arg 2 cppType
sub wrapCppTypeInSequences
{
    my $depthSeq = shift;
    my $cppType  = shift;
    my $useShortName = 0;
    if ( @_ > 0 ) {
        $useShortName = shift;
    }
    my $sequenceType = $Codegen::CppUtils::cppSequenceType;
    $useShortName
        and $sequenceType = &getCppShortName($sequenceType);

    if ( $depthSeq > 0 ) {
        &wrapCppTypeInSequences($depthSeq - 1,
                                $sequenceType . "< " . $cppType . " >",
                                $useShortName);
    }
    else {
        return $cppType;
    }
} # ! wrapCppTypeInSequences


# Object methods
#
# Get C++ namespace from UNO Type (resolved)
#
# arg1 UNO type name
sub getCppNamespaceForUno
{
  my $self        = shift;
  my $unoTypeName = shift;

  my $resolvedTypeName = $self->{TYPE_DEF_DB}->
    getResolvedTypeName(&removeArraysFromType($unoTypeName));
  my $cppType          = &unoToCppType($resolvedTypeName,
                                       0,
                                       0);

  my $cppNamespace     = &getCppNamespace($cppType);

  return $cppNamespace;
} # ! getCppNamespaceForUno

# Get namespaces for dependent types
#
# arg1 UNO type name
# returns sorted unique list of namespaces
sub getDependentCppNamespacesForUno
{
  my $self           = shift;
  my $unoTypeName    = shift;
  my %namespacesHash = ();

  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};  

  my @typeName     = $unoTypeName;
  
  while (@typeName > 0) {
    my @dependentTypesList =
      $rdbTypeDefDb->getDependentTypes($typeName[0]);
  
    foreach my $dependentTypeName (@dependentTypesList) {
      my $cppNamespace = $self->getCppNamespaceForUno($dependentTypeName);
  
      $cppNamespace and $namespacesHash{$cppNamespace} = 1;
    }    
  
    if ( $rdbTypeDefDb->isTypeAnInterface($typeName[0]) ) {  
      my @parent = $rdbTypeDefDb->getParentTypeNames($typeName[0]);
      shift @typeName; # remove already handled interface
      unshift @typeName, @parent; # add parents because they must be handled, too    
    }
    else {
      shift @typeName; # remove already handled interface
    }
  }

  return  (sort keys %namespacesHash);
} # ! getDependentNamespacesForUno

# Return string that is the return type for a method
# arg 1 name of UNO type
sub getCppReturnType
{
  my $self = shift;
  my $unoType = shift;

  my $returnTypeName =
    $self->{TYPE_DEF_DB}->getResolvedTypeName($unoType);
  my $cppReturnType = &unoToCppType($returnTypeName,
                                    $self->isCppReference($returnTypeName),
                                    $self->{USE_SHORT_NAMES});
  return $cppReturnType;
} # ! getCppReturnType

# Return true if the UNO type is a Reference in Cpp
# arg 1 name of UNO type
sub isCppReference
{
  my $self = shift;
  my $unoType = shift;
  my $isReference = 0;
  my $basicUnoType = &removeArraysFromType($unoType);
  $isReference = $self->{TYPE_DEF_DB}->isTypeAnInterface($basicUnoType);

  return $isReference;
} # ! isCppReference

# Returns true if unoType is passed by reference in Cpp
# Out and inout params are always passed by reference
# otherwise fundemental Cpp types and enums passed by value,
#  the rest (objects and arrays) by reference
# arg 1 reference to RegviewParameterTypeDef
sub isCppPassedByRef
{
  my $self = shift;
  my $unoTypeDefRef = shift;
  my $isPassedByRef = 0;
  my $unoTypeName   =
    $self->{TYPE_DEF_DB}->getResolvedTypeName($unoTypeDefRef->{TYPE_NAME});

  if ( $unoTypeDefRef->isOutOrInoutParam
       || ( ! $self->{TYPE_DEF_DB}->isTypeAnEnum($unoTypeName)
            && ! &isCppFundamentalType($unoTypeName) ) ) {
    $isPassedByRef = 1;
  }
    return $isPassedByRef;
}
# Returns true if unoType is maps to a Cpp object
# (Arrays are mapped to Sequence objects)
# arg 1 UNO type name
sub isTypeCppObject
{
  my $self = shift;
  my $unoTypeName = shift;
  my $isObject = 0;

  if ( ! $self->{TYPE_DEF_DB}->isTypeAnEnum($unoTypeName)
       && ! &isCppFundamentalType($unoTypeName) ) {
    $isObject = 1;
  }
  return $isObject;
} # ! isTypeCppObject

# Return string that is return declaration
# arg 1 name of UNO type
# arg 2 indent string
sub getCppReturnValueDecl
{
  my $self = shift;
  my $unoType = shift;
  my $indentString = shift;
  my $decl = "";

  my $cppReturnType = $self->getCppReturnType($unoType);
  if ( $cppReturnType !~ m/^void$/  ) {
    $decl .= $indentString;
    $decl .= $cppReturnType . " returnValue";
    $decl .=
      $self->getCppInitCode($self->{TYPE_DEF_DB}
                            ->getResolvedTypeName($unoType));
    $decl .= ";\n";
  }

  return $decl;
} # ! getCppReturnValueDecl

# get Cpp init code for UNO type
# 1. simple types as in table
# 2. enum value of first enum entry
# 3. struct, arrays, references return default constructor value
# arg 1 reference to UNO type name
sub getCppInitCode
{
  my $self = shift;
  my $unoTypeName = shift;
  my $initCode = ""; # unknown types are become objects with default constructors

  # map UNO types to Cpp initcode
  if ( exists $lookupCppInitStrings{$unoTypeName} ) {
    $initCode = $lookupCppInitStrings{$unoTypeName} ;
  }
  elsif ( $self->{TYPE_DEF_DB}->isTypeAnEnum($unoTypeName)) {
    my $cppEnumType =  &toCppPath($unoTypeName);
    $cppEnumType = &getCppShortName($cppEnumType);
    $initCode = " = " . $cppEnumType . "_"
      . $self->{TYPE_DEF_DB}->getTypeFieldName($unoTypeName);
  }
  # else maps to object, use default constructor
  
  return $initCode;
} # ! getCppInitCode

# Return string that is return statement for a method
# with returnValue, if needed.
# arg 1 name of UNO type
# arg 2 indent string
sub getCppReturnStatement
{
  my $self = shift;
  my $unoType = shift;
  my $indentString = shift;
  my $retStatement = "";

  my $cppReturnType = $self->getCppReturnType($unoType);
  if ( $cppReturnType !~ m/^void$/  ) {
    $retStatement .= $indentString . "return returnValue;\n" ;
  }

  return $retStatement;
} # ! getCppReturnStatement

# Return string which is the method call with param names as its definition
# arg 1 is reference to RegviewMethodDef
sub getCppMethodCall
{
  my $self         = shift;
  my $methodDefRef = shift;

  my $methodCall = "";

  $methodCall .= $methodDefRef->{NAME} . "(";
  my $paramsRef = $methodDefRef->{PARAMETERS};
  my $i = 0;
  for ( $i = 0; $i < @$paramsRef; $i++ ) {
    my $paramTypeRef = $paramsRef->[$i];
    $methodCall .= $paramTypeRef->{ARG_NAME};
    if ( $i < $#{$paramsRef} ) {
      $methodCall .= "," ;
    }
  }
  $methodCall .= ")";

  return $methodCall;
} # ! getCppMethodCall

# End of package, needed for module load
1;
