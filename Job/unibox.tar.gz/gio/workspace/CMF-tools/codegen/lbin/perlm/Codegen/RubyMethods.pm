# Perl package to support generating C++ code from
# type date in RegviewTypesDb
#

package Codegen::RubyMethods;

use strict;
use lib "..";
use RegviewTypesDb;

use Codegen::Utils;
use Codegen::RubyUtils;

sub new
{
  my ($class)   = shift;
  my $typeDefDb = shift;
  my $className = "";
  my $baseClassName = "UnknownBase";

  @_ and $className     = shift;
  @_ and $baseClassName = shift;
  
  return bless {
    IS_SERVICE       => 1,
    USE_SHORT_NAMES  => 1,
    CLASS_NAME       => $className,
    BASE_CLASS_NAME  => $baseClassName,
    CATEGORY         => "ruby",
    INDENT           => "  ",
    SEEN_METHODS_REF => 0,
    TYPE_DEF_DB      => $typeDefDb,
    }, $class ;

}

# arg 1: 1 if generating for service, 0 for weakObject
sub setIsService
{
  my $self              = shift;
  ($self->{IS_SERVICE}) = @_;
}

# arg 1: 1 to use short names, 0 to use long names (with namespace path)
sub setUseShortNames
{
  my $self                   = shift;
  ($self->{USE_SHORT_NAMES}) = @_;
}

# arg 1:  service or weakObject category attribute
sub setCategory
{
  my $self            = shift;
  ($self->{CATEGORY}) = @_;
}

# arg 1:  Indent string (default is "  " when created)
sub setIndent
{
  my $self          = shift;
  ($self->{INDENT}) = @_;
}

# arg 1: Reference to seen methods hash, 0 clears
sub setSeenMethodsHashRef
{
  my $self          = shift;
  ($self->{SEEN_METHODS_REF}) = @_;
}


# Return string with stubs for all implemented methods
# for the interface with all ancestor interfaces
#
# arg1 interface name
sub getMethodImplementations
{
  my $self   = shift;
  my $interfaceName      = shift;

  my $methodStubs = "";
  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};

  my @nextInterface = $interfaceName;
  while ( @nextInterface > 0 ) {
    my $interfaceTypeDef = $rdbTypeDefDb->getTypeDefinition( $nextInterface[0] )
      or die "Interface \"$nextInterface[0]\" not defined in rdbs";
    $interfaceTypeDef->isInterface
      or die "Type \"$nextInterface[0]\" is not an interface";

    $methodStubs .= $self->_getSingleInterfaceMethodStubs($interfaceName,
                                                          $interfaceTypeDef);

    my @parent = $interfaceTypeDef->getParentTypeNames;
    shift @nextInterface; # remove already handled interface
    unshift @nextInterface, @parent; # add parents because they must be handled, too    
  }
    
  return $methodStubs;
}

# Internal methods

# Return string with stubs for all implemented methods
# for the interface
# 
# arg 1 interface name
# arg 2 interface type def reference for interface or its ancestor
sub _getSingleInterfaceMethodStubs
{
  my $self   = shift;
  my $interfaceName = shift;
  my $interfaceTypeDefRef = shift;

  my $methodStubs = "";
  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};

  # Attribute methods
  my $fieldDefRefs = $interfaceTypeDefRef->{FIELDS};
  for (my  $aa = 0; $aa < @$fieldDefRefs; $aa++ ) {
    my $fieldName = $interfaceTypeDefRef->getFieldName($aa);

    my $fieldDefRef = $fieldDefRefs->[$aa];
    my $attrGetMethodRef =  RegviewMethodDef->new;
    $attrGetMethodRef->setGetMethodFromFieldDef($fieldDefRef);
    my $attrComment = "# Get method for "
      .$fieldDefRef->{FLAGS}." attribute "
      .$fieldDefRef->{NAME} ." of ".$interfaceName ."\n";
    $methodStubs .= $self->_getMethodStub($interfaceName,$attrGetMethodRef,
                                          $attrComment);
    if ( $fieldDefRef->isReadwrite ) {
      my $attrSetMethodRef =  RegviewMethodDef->new;
      $attrSetMethodRef->setSetMethodFromFieldDef($fieldDefRef);
      $attrComment = "# Set method for "
        .$fieldDefRef->{FLAGS}." attribute "
        .$fieldDefRef->{NAME} ." of ".$interfaceName."\n";
      $methodStubs .= $self->_getMethodStub($interfaceName,$attrSetMethodRef,
                                            $attrComment);
    }
  }

  # Methods
  for (my  $mm = 0; $mm < @{$interfaceTypeDefRef->{METHODS}}; $mm++ ) {
    my $methodDefRef = $interfaceTypeDefRef->{METHODS}[$mm];
    my $methodKey = $interfaceName . '.' . $methodDefRef->{NAME};
    if ( $interfaceName eq "com.sun.star.lang.XInitialization"
         && $methodDefRef->{NAME} eq "initialize") {
      # Special case as conflicts with Ruby initialize method
      $methodStubs .= $self->_getInitializeMethodStub($interfaceName);
    }
    else {
      $methodStubs .= $self->_getMethodStub($interfaceName,$methodDefRef);
    }
  }

  return $methodStubs;
} # getInterfaceMethodStubs

# Output Ruby method stub for XInitialization.initialize
# arg 1 is interface name
sub _getInitializeMethodStub
{
  my $self         = shift;
  my $ifName       = shift;
  my $methodIndent = $self->{INDENT};

  my $methodStub     = "";
  my $methodComment = "# Method of $ifName";

  my $methodName = "unoInitialize";
  $methodStub .= "\n" ;
  $methodStub .= $methodIndent . $methodComment . "\n" ;
  
  $methodStub .= $methodIndent  .
    "# initialize method name mapped to $methodName\n";
  $methodStub .= $methodIndent .
    "def unoInitialize(aArguments)\n";

  my $methodCodeIndent = $methodIndent . "  ";
  $methodStub .= $methodCodeIndent . &getBeginEditableSection($methodName,'#');
  $methodStub .= $methodCodeIndent .
    "# // \@todo TODO_AUTO_GENERATED\n";
  $methodStub .= $methodCodeIndent . &getEndEditableSection($methodName,'#');

  $methodStub .= $methodIndent . "end\n" ;

} # ! _getInitializeMethodStub

# Get method stub
# arg1 interface name
# arg2 RegviewDb method definition reference
# arg3 optional method header comment
sub _getMethodStub
{
  my $self              = shift;
  my $ifName            = shift;
  my $methodDefRef      = shift;
  my $methodComment     = "# Method of ".$ifName."\n";
  $methodComment        = shift if @_;

  my $seenMethodsRef = $self->{SEEN_METHODS_REF};
  my $indent         = $self->{INDENT};
  my $methodName     = $methodDefRef->{NAME};

  my $methodStub     = "\n";
  $methodStub       .= $indent . $methodComment;

  my $signature = $methodDefRef->getUnoSignature;
  my $priorInterface = "";
  $priorInterface = $seenMethodsRef->{$signature} if $seenMethodsRef;
  if ( $priorInterface ) {
    $methodStub .=
      $indent ."# ".$methodName
      ." already implemented for interface "
      .$priorInterface."\n";
  }
  else {
    $seenMethodsRef->{$signature} = $ifName if $seenMethodsRef;

    $methodStub .= $self->_getMethodDeclaration($methodDefRef,
                                                $indent);
    $methodStub .= "\n";
    $methodStub .= $self->_getMethodCode($ifName,
                                         $methodDefRef,
                                         $indent . "  ");
    $methodStub .= $indent . "end\n";
  }
  return $methodStub;
} # _getMethodStub

sub _getMethodCode
{
  my $self             = shift;
  my $interfaceName    = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;
  my $code = "";

  my $methodName = $methodDefRef->{NAME};

  $code .= $methodCodeIndent .
    &getBeginEditableSection($methodName, "#");

  my $defaultImplementationCode =
    _getDefaultCode($interfaceName, $methodName, $self->{CLASS_NAME});
  $code .= $defaultImplementationCode;
  if ( ! $defaultImplementationCode )  {
    $code .= $self->_getNotImplementedCode($methodDefRef,
                                           $methodCodeIndent);
  }

  $code .= $methodCodeIndent . &getEndEditableSection($methodName, "#");

  return $code;
} # ! _getMethodCode

sub _getNotImplementedCode
{
  my $self             = shift;
  my $methodDefRef     = shift;
  my $methodCodeIndent = shift;

  my $unoReturnType = $methodDefRef->{RETURN_TYPE_NAME};
  my $rubyUtils = new Codegen::RubyUtils($self->{TYPE_DEF_DB},
                                         $self->{USE_SHORT_NAMES});
  my $code = "";
  $code .= $rubyUtils->getRubyReturnValueDecl($unoReturnType,
                                              $methodCodeIndent);
  $code .= $methodCodeIndent .
    "# // \@todo TODO_AUTO_GENERATED\n";

  $code .= $rubyUtils->getRubyReturnStatement($unoReturnType,
                                              $methodCodeIndent);
  return $code;

} # ! _getNotImplementedCode

# Return string which is the method declaration
# arg 1 is reference to RegviewMethodDef
# arg 2 indent string
# arg 3 optional 1 if virtual, 0 if not
sub _getMethodDeclaration
{
  my $self         = shift;
  my $methodDefRef = shift;
  my $indentString = shift;

  my $methodDeclaration = "";

  my $returnTypeName =
    $self->{TYPE_DEF_DB}->getResolvedTypeName($methodDefRef->{RETURN_TYPE_NAME});
  my $methodHead = $indentString . "def " . $methodDefRef->{NAME} . "(" ;
  my $paramsRef = $methodDefRef->{PARAMETERS};
  $methodDeclaration .= $methodHead;
  for ( my $i = 0; $i < @$paramsRef; $i++ ) {
    my $paramTypeRef = $paramsRef->[$i];
    my $argName     = $paramTypeRef->{ARG_NAME};
    $methodDeclaration .= $argName;
    $methodDeclaration .= ", " if  $i < $#{$paramsRef};
  }
  $methodDeclaration .= ")" ;
} # ! _getMethodDeclaration

# Return implementation code from default interface implementation file,
# if any
# arg1 interfaceName
# arg2 method name
# arg3 class name
sub _getDefaultCode
{
  my $interfaceName    = shift;
  my $methodName       = shift;
  my $class            = shift;

  my $workspace = $ENV{"WORKSPACE"};
  my $interfacePath = $interfaceName;
  $interfacePath =~ tr%.%/%;
  my $implFileName = $workspace .
    "/CMF-tools/codegen/lbin/defaultImplementations/" .
     $interfacePath . ".rb";

  my $code = getEditableSectionContent($implFileName,$methodName);
  $code =~ s/__CLASS_NAME__/$class/g;
  return $code;
} # ! getDefaultCode

sub dump
{
  my $self = shift;

  print "Codegen::RubyMethods IS_SERVICE=".$self->{IS_SERVICE}."\n";;
  print "Codegen::RubyMethods USE_SHORT_NAMES="
    .$self->{USE_SHORT_NAMES}."\n";;
  print "Codegen::RubyMethods CLASS_NAME=".$self->{CLASS_NAME}."\n";;
  print "Codegen::RubyMethods BASE_CLASS_NAME="
    .$self->{BASE_CLASS_NAME}."\n";;
  print "Codegen::RubyMethods CATEGORY=".$self->{CATEGORY}."\n";;
  print "Codegen::RubyMethods TYPE_DEF_DB=".$self->{TYPE_DEF_DB}."\n";;

}

# End of package, needed for module load
1;
