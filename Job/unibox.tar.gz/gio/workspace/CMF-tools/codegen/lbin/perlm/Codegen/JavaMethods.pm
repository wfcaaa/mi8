# Perl package to support generating Java code from
# type date in RegviewTypesDb
#

package Codegen::JavaMethods;

use strict;
use lib "..";
use RegviewTypesDb;

use Codegen::Utils;
use Codegen::JavaUtils;
use Codegen::JavaDefault;
use Codegen::JavaBaseDelegate;

# Interfaces implemented in service base class
%Codegen::JavaMethods::serviceBaseInterfaces =
  ( "com.sun.star.lang.XComponent" => "",
    "com.sun.star.lang.XServiceInfo" => "",
    "com.sun.star.lang.XTypeProvider" => "",
    "com.sun.star.uno.XWeak"      => "",
    "com.sun.star.uno.XInterface" => "",
    );

# Interfaces implemented in weakObject base class
%Codegen::JavaMethods::weakObjectBaseInterfaces =
  ( "com.sun.star.lang.XComponent" => "",
    "com.sun.star.lang.XTypeProvider" => "",
    "com.sun.star.uno.XWeak"      => "",
    "com.sun.star.uno.XInterface" => "",
    );

sub new
{
  my ($class)   = shift;
  my $typeDefDb = shift;
  my $className = "";
  my $baseClassName = "UnknownBase";

  @_ and $className = shift;
  @_ and $baseClassName = shift;
  
  return bless {
    IS_SERVICE       => 1,
    USE_SHORT_NAMES  => 1,
    CLASS_NAME       => $className,
    BASE_CLASS_NAME  => $baseClassName,
    CATEGORY         => "default",
    INDENT           => "  ",
    SEEN_METHODS_REF => 0,
    TYPE_DEF_DB      => $typeDefDb,
    }, $class ;

}

# arg 1: 1 if generating for service, 0 for weakObject
sub setIsService
{
  my $self              = shift;
  ($self->{IS_SERVICE}) = @_;
}

# arg 1: 1 to use short names, 0 to use long names (with namespace path)
sub setUseShortNames
{
  my $self                   = shift;
  ($self->{USE_SHORT_NAMES}) = @_;
}

# arg 1:  service or weakObject category attribute
sub setCategory
{
  my $self            = shift;
  ($self->{CATEGORY}) = @_;
}

# arg 1:  Indent string (default is "  " when created)
sub setIndent
{
  my $self          = shift;
  ($self->{INDENT}) = @_;
}

# arg 1: Reference to seen methods hash, 0 clears
sub setSeenMethodsHashRef
{
  my $self          = shift;
  ($self->{SEEN_METHODS_REF}) = @_;
}


# Return string with stubs for all implemented methods
# for the interface with all ancestor interfaces
# NOTE: com.sun.star.uno.XInterface has no methods in Java implementation
#
# arg1 interface name
sub getMethodImplementations
{
  my $self   = shift;
  my $interfaceName      = shift;

  my $methodStubs = "";
  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};

  my @nextInterface = $interfaceName;
  while ( @nextInterface > 0
          && $nextInterface[0] ne "com.sun.star.uno.XInterface" ) {
    my $interfaceTypeDef = $rdbTypeDefDb->getTypeDefinition( $nextInterface[0] )
      or die "Interface \"$nextInterface[0]\" not defined in rdbs";
    $interfaceTypeDef->isInterface
      or die "Type \"$nextInterface[0]\" is not an interface";

    $methodStubs .= $self->_getSingleInterfaceMethodStubs($interfaceName,
                                                          $interfaceTypeDef);

     my @parent = $interfaceTypeDef->getParentTypeNames;
    shift @nextInterface; # remove already handled interface
    unshift @nextInterface, @parent; # add parents because they must be handled, too    
    
  }
  return $methodStubs;
}



# Internal methods

# Return string with stubs for all implemented methods
# for the interface
# 
# arg 1 interface name
# arg 2 interface type def reference for interface or its am=ncestor
sub _getSingleInterfaceMethodStubs
{
  my $self   = shift;
  my $interfaceName = shift;
  my $interfaceTypeDefRef = shift;

  my $methodStubs = "";
  my $rdbTypeDefDb = $self->{TYPE_DEF_DB};

  # Attribute methods
  my $fieldDefRefs = $interfaceTypeDefRef->{FIELDS};
  for (my  $aa = 0; $aa < @$fieldDefRefs; $aa++ ) {
    my $fieldName = $interfaceTypeDefRef->getFieldName($aa);

    my $fieldDefRef = $fieldDefRefs->[$aa];
    my $attrGetMethodRef =  RegviewMethodDef->new;
    $attrGetMethodRef->setGetMethodFromFieldDef($fieldDefRef);
    my $attrComment = "// Get method for "
      .$fieldDefRef->{FLAGS}." attribute "
      .$fieldDefRef->{NAME} ." of ".$interfaceName ."\n";
    $methodStubs .= $self->_getMethodStub($interfaceName,$attrGetMethodRef,
                                          $attrComment);
    if ( $fieldDefRef->isReadwrite ) {
      my $attrSetMethodRef =  RegviewMethodDef->new;
      $attrSetMethodRef->setSetMethodFromFieldDef($fieldDefRef);
      $attrComment = "// Set method for "
        .$fieldDefRef->{FLAGS}." attribute "
        .$fieldDefRef->{NAME} ." of ".$interfaceName."\n";
      $methodStubs .= $self->_getMethodStub($interfaceName,$attrSetMethodRef,
                                            $attrComment);
    }
  }

  # Methods
  for (my  $mm = 0; $mm < @{$interfaceTypeDefRef->{METHODS}}; $mm++ ) {
    my $methodDefRef = $interfaceTypeDefRef->{METHODS}[$mm];
    $methodStubs .= $self->_getMethodStub($interfaceName,$methodDefRef);
  }

  return $methodStubs;
} # _getSingleInterfaceMethodStubs

# Get method stub
# arg1 interface name
# arg2 RegviewDb method definition reference
# arg3 optional method header comment
sub _getMethodStub
{
  my $self              = shift;
  my $ifName            = shift;
  my $methodDefRef      = shift;
  my $methodComment     = "// Method of ".$ifName."\n";
  $methodComment        = shift if @_;

  my $seenMethodsRef = $self->{SEEN_METHODS_REF};
  my $indent         = $self->{INDENT};
  my $methodName     = $methodDefRef->{NAME};

  my $methodStub     = "\n";
  $methodStub       .= $indent . $methodComment;
  my $signature = $methodDefRef->getUnoSignature;
  my $priorInterface = "";
  $priorInterface = $seenMethodsRef->{$signature} if $seenMethodsRef;
  if ( $priorInterface ) {
    $methodStub .=
      $indent ."// ".$self->{CLASS_NAME}."::".$methodName
      ." already implemented for interface "
      .$priorInterface."\n";
  }
  else {
    $seenMethodsRef->{$signature} = $ifName if $seenMethodsRef;
    $methodStub .= $self->_getMethodDeclaration($methodDefRef,
                                                $indent);
    $methodStub .= "\n";
    $methodStub .= $indent . "{\n";

    # Implementation
    my $implModule;
    if ( $self->_isImplementedInBase($ifName) ) {
      $implModule = new Codegen::JavaBaseDelegate($self->{TYPE_DEF_DB},
                                                  $ifName,
                                                  $self->{CLASS_NAME});
    }
    else {
      $implModule = new Codegen::JavaDefault($self->{TYPE_DEF_DB},
                                             $ifName,
                                             $self->{CLASS_NAME});
    }
    $methodStub .= $implModule->getMethodCode($methodDefRef,
                                              $indent . "  ");
    $methodStub .= $indent . "}\n";

  }
  return $methodStub;
} # ! _getMethodStub


# Return string which is the method declaration
# arg 1 is reference to RegviewMethodDef
# arg 2 indent string
sub _getMethodDeclaration
{
  my $self         = shift;
  my $methodDefRef = shift;
  my $indentString = shift;

  my $methodDeclaration = "";
  my $javaUtils = new Codegen::JavaUtils($self->{TYPE_DEF_DB},
                                         $self->{USE_SHORT_NAMES});

  my $javaReturnType =
    $javaUtils->getJavaReturnType($methodDefRef->{RETURN_TYPE_NAME});
  
  my $methodHead.= $indentString
    . "public " 
    . $javaReturnType . " " . $methodDefRef->{NAME}
  . "(" ;
  $methodDeclaration .= $methodHead;

  my $paramIndent = $methodHead;
  $paramIndent =~ s/./ /g;
  my $paramsRef = $methodDefRef->{PARAMETERS};
  for ( my $i = 0; $i < @$paramsRef; $i++ ) {
    my $paramTypeRef = $paramsRef->[$i];
    my $unoTypeName = $self->{TYPE_DEF_DB}->
      getResolvedTypeName($paramTypeRef->{TYPE_NAME});
    my $argName     = $paramTypeRef->{ARG_NAME};
    
    $methodDeclaration .= $paramIndent if $i > 0;
    $methodDeclaration .= &unoToJavaType($unoTypeName,
                                         $self->{USE_SHORT_NAMES});
    if ( $paramTypeRef->isOutOrInoutParam ) {
      # inout or out parameters are passed in array[0]
      $methodDeclaration .= "[]" ;
    }
    $methodDeclaration .= " " ;
    $methodDeclaration .= $argName;
    $methodDeclaration .= ",\n" if  $i < $#{$paramsRef};
  }
  $methodDeclaration .= ")";

# Exceptions
  my $exceptionsNamesRef = $methodDefRef->{EXCEPTION_NAMES};
  if ( @$exceptionsNamesRef > 0 ) {
    $methodDeclaration .= "\n" . $indentString . "  throws" ;
    if ( @$exceptionsNamesRef == 1 ) {
      $methodDeclaration .= " "
        . &unoToJavaType($exceptionsNamesRef->[0],$self->{USE_SHORT_NAMES});
    }
    else {
      $methodDeclaration .= "\n";
      my $exceptionIndent =  $indentString . "    ";
      for ( my $i = 0; $i < @$exceptionsNamesRef; $i++) {
        my $exception = &unoToJavaType($exceptionsNamesRef->[$i],
                                       $self->{USE_SHORT_NAMES});
        $methodDeclaration .= $exceptionIndent . $exception;
        $methodDeclaration .= ",\n" if $i < $#{@$exceptionsNamesRef};
      }
    }
  }
  return $methodDeclaration;

} # ! _getMethodDeclaration

# Returns true if interface is implemented in base class
#
# arg1 interface name
sub _isImplementedInBase
{
  my $self = shift;
  my $interfaceName = shift;

  if ( $self->{IS_SERVICE} ) {
    return
      exists $Codegen::JavaMethods::serviceBaseInterfaces{$interfaceName};
  }
  else {
    return
      exists $Codegen::JavaMethods::weakObjectBaseInterfaces{$interfaceName};
  }

} # ! _isImplementedInBase

sub dump
{
  my $self = shift;

  print "Codegen::JavaMethods IS_SERVICE=".$self->{IS_SERVICE}."\n";;
  print "Codegen::JavaMethods USE_SHORT_NAMES="
    .$self->{USE_SHORT_NAMES}."\n";;
  print "Codegen::JavaMethods CLASS_NAME=".$self->{CLASS_NAME}."\n";;
  print "Codegen::JavaMethods BASE_CLASS_NAME="
    .$self->{BASE_CLASS_NAME}."\n";;
  print "Codegen::JavaMethods CATEGORY=".$self->{CATEGORY}."\n";;
  print "Codegen::JavaMethods TYPE_DEF_DB=".$self->{TYPE_DEF_DB}."\n";;

}

# End of package, needed for module load
1;
