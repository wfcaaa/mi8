#!/usr/bin/perl

# Detects if file is marked to disable automatic merge
# returns 0, if disable key line found, otherwise 1

use strict;
use Getopt::Long;

my $disableAutoMergeKey = "FORCE_INTERACTIVE_MERGE";

my $optQuiet = 0;
&getArgs;

my $exitValue = 1;  # asume we don't find the key
my $foundKey  = 0;
while ( <> ) {
  m%\s*//\s*$disableAutoMergeKey\s*%
    and $foundKey = 1;
  if ( $foundKey ) {
    if ( !$optQuiet
         && m%\s*//% ) {
      print STDOUT "$_";
    }
    else {
      $exitValue = 0;
      last;
    }
  }
}

exit $exitValue;

sub usage
{
  print STDERR 
    "Usage:\n"
    . "$0 [-help] [-quiet] infile\n"
    . "  -help displays this\n"
    . "  -quiet suppress output of explanation lines from file\n"
    . "Exits with 0 value if the file contains a // comment with containing\n"
    . " only the keyword $disableAutoMergeKey and whitespace\n"
    . " If found any following contiguous // comment lines are output to\n"
    . "  stdout as an explanation\n"
    . "Exits with non-0 code key line is not found\n"
    ;
}

# Get command line args,
# tool exits with non-zero value, if any error found
sub getArgs
{

  my $optHelp    = 0;
  my $optUnknown = 0;

  &GetOptions("-quiet"  => \$optQuiet,
              "-help!"  => \$optHelp)
    or $optUnknown = 1;

  if ( $optUnknown 
       ||  $optHelp ) {
    &usage;
    exit 1;
  }

  if ( @ARGV == 0 ) {
    print STDERR "Missing file\n";
    &usage ;
    exit 1;
  }
}



