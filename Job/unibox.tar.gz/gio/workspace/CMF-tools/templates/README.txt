Template files
==============

These directory contains templates of files that are used frequently
and may be used for auto-generation using the tools in CMF-tools/bin
as follows:

To create a simple test to run a C++ component
------------------------------------------------

  1. After creating the component, create a directory at the
     same level for the tests e.g.
       mkdir ../Test
  2. cd to created directory
  3. Run CMF-tools/bin/generateCppComponentPackageTests.ksh, with same
     -service and -impl options as the component, for example:
    createCppComponentTest.ksh -name MyComponent -service com.agilent.soc.MyService  .
  4. The directory should now contain:
       Makefile
       z_comp_test.ksh
  5. Add test methods:
     The test suite will contain already the method testinstantiation() performing
     an instantiation of the component. You may add other test methods to call the
     components methods.
  6. Run the component with the run ksh script:
       z_comp_test.ksh

To create a simple test to run the Java component
-------------------------------------------------

Follow the procedure for a Cpp component test but using the
  createJavaComponentTest.ksh:
 
  createJavaComponentTest.ksh -name MyComponent -service com.agilent.soc.MyService  .

Then
  make all
  ./z_comp_test.ksh

Note:
  Loading Java components can be problematic, however,
  the Makefile has the required environment register a Java component.
  The runMyServiceImpl.ksh script creates the environment to load
  a Java component from a C++ client, in this case 'starter'.
