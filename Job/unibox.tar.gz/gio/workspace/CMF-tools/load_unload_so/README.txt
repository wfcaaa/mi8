Horst Perner, March 1, 2010
This directory contains some very primitive utilities.
The load_unload_so* executables, available in 32/64 optimized/debug variants
do exactly what the name says: they load a shared library with dlopen
and close it again with dlclose.

What are they for?

some component libraries show nasty behaviour. some of them simply crash
when an attempt to 'dlopen' them is made.
the ability to do so is mandatory for component libraries - regcomp
does exactly that!

at some point in time open/closing a component library will become
part of the build process!

The utilities are made with the script buildit.sh - calling gcc on a
one-file program does not warrant a make file.

they should rarely change, if the do:
- co and modify load_unload_so.c
- co all the executables load_unload_so(32|64)[dbg]
- call ./buildit.sh
- ci all of the stuff.