#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>

int main(int argc, char **argv) {
    void *handle;
    char *error;
    
    if ( argc != 2 ) {
      char *msg =
      "usage: %s shared_library\n"
      "open (dlopen) a shared library and close it again.\n"
      "print errors happening to stderr\n"
      "return: 0 if no issues, non-0 in case of trouble\n" ;
      fprintf (stderr, msg, argv[0]) ;
      exit(1) ;
    }

    fprintf (stderr,"calling handle = dlopen(\"%s\", RTLD_LAZY)\n", argv[1]);
    fflush(stderr) ;
    handle = dlopen (argv[1], RTLD_LAZY);
    fprintf (stderr,"dlopen returned\n");
    fflush(stderr) ;
    if (!handle) {
      fprintf (stderr, "%s\n", dlerror());
      fprintf (stderr, "Error: dlopen of %s failed\n", argv[1]) ;
      fflush(stderr) ;
      exit(1) ;
    }


    dlerror();    /* Clear any existing error */
    fprintf (stderr,"calling dlclose(handle)\n");
    fflush(stderr) ;
    dlclose(handle);
    fprintf (stderr,"dlclose returned\n");
    fflush(stderr) ;
#if 0
    if ((error = dlerror()) != NULL)  {
      fprintf (stderr, "%s\n", error);
      fprintf (stderr, "Error: dlclose on %s failed\n", argv[1]) ;
      fflush(stderr) ;
      exit(1) ;
    }
#endif

    return 0 ;
}
