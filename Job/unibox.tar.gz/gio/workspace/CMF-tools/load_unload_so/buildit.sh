#!/bin/bash
set -x

gcc -m32 -rdynamic -o load_unload_so32 load_unload_so.c -ldl
gcc -m64 -rdynamic -o load_unload_so64 load_unload_so.c -ldl
gcc -g -m32 -rdynamic -o load_unload_so32dbg load_unload_so.c -ldl
gcc -g -m64 -rdynamic -o load_unload_so64dbg load_unload_so.c -ldl