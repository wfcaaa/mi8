# Welcome to the Generic IO (GIO) project repository

The GIO library provides a generic interface to external instrument hardware.
