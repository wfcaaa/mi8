package com.advantest.test.gpio;
import com.pi4j.wiringpi.Gpio;

public class GPIBreceive
{
    //public String ab;
    //GPIBreceive(String A){
    //ab=A;
    //}
    public static int receivemessage() throws InterruptedException{
        if(Gpio.digitalRead(27)==1)
        {
            Gpio.digitalWrite(28,1);
            //Thread.sleep(10);
            while(Gpio.digitalRead(27)==1); //used as synchronizing
            Gpio.digitalWrite(28,0);
            //Thread.sleep(10);
            int a=255-(Gpio.digitalRead(0)+2*Gpio.digitalRead(1)+4*Gpio.digitalRead(2)
                    +8*Gpio.digitalRead(3)+16*Gpio.digitalRead(4)+32*Gpio.digitalRead(5)
                    +64*Gpio.digitalRead(6)+128*Gpio.digitalRead(7));
            Gpio.digitalWrite(29,1);
            while(Gpio.digitalRead(27)==0);//used as synchronizing
            Gpio.digitalWrite(29,0);
            return a;
            //Gpio.digitalWrite(28,1);
        }
        else return -1;

    }
}
