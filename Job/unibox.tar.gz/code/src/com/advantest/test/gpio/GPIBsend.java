package com.advantest.test.gpio;

import com.pi4j.wiringpi.Gpio;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
public class GPIBsend {
    public static void sendmessage(char c)  throws InterruptedException
    {

        if(GPIBcontrol.getATN()==1)  //0是命令 1是信息
        {
            if (Gpio.digitalRead(29) == 0&&Gpio.digitalRead(28) == 1)
            // if(GPIBhandshake.getNDAC()==0&&GPIBhandshake.getNRFD()==1)
            {
                //List<String> a= new ArrayList<String>();
                //a = Collections.synchronizedList(a);
                //GPIBhandshake handshake=new GPIBhandshake(a);
                Gpio.digitalWriteByte(c);
                GPIBhandshake.setDAV(0);
                while (Gpio.digitalRead(28) == 1);//used as synchronizing
                // ;

                //while((a.get(0).equals("close the switch"))==false);
                while (Gpio.digitalRead(29)== 0);//used as synchronizing
                // ;
                //while((a.get(1).equals("finish listening"))==false);
                GPIBhandshake.setDAV(1);
                while (Gpio.digitalRead(29) == 1);//used as synchronizing
                // ;
                //while((a.get(2).equals("prepare next cycle"))==false);
                while (Gpio.digitalRead(28) == 0&&Gpio.digitalRead(25)==1 );//used as synchronizing
                //  ;//有可能是while
                //while((a.get(3).equals("finish preparing"))==false);
                //Thread.sleep(10);
            }

        }
        else System.out.println("发的不是消息");
    }
    public static void sendcommand(char c) throws InterruptedException
    {
        //初始状态
        //GPIBcontrol.setATN(Gpio.digitalRead(21));
        if(GPIBcontrol.getATN()==0)
        {
            if (Gpio.digitalRead(29) == 0&&Gpio.digitalRead(28) == 1)
            // if(GPIBhandshake.getNDAC()==0&&GPIBhandshake.getNRFD()==1)
            {
                //List<String> a= new ArrayList<String>();
                //a = Collections.synchronizedList(a);
                //GPIBhandshake handshake=new GPIBhandshake(a);
                Gpio.digitalWriteByte(c);
                GPIBhandshake.setDAV(0);
                while (Gpio.digitalRead(28) == 1);//used as synchronizing
                // ;

                //while((a.get(0).equals("close the switch"))==false);
                while (Gpio.digitalRead(29)== 0);//used as synchronizing
                // ;
                //while((a.get(1).equals("finish listening"))==false);
                GPIBhandshake.setDAV(1);
                while (Gpio.digitalRead(29) == 1);//used as synchronizing
                // ;
                //while((a.get(2).equals("prepare next cycle"))==false);
                while (Gpio.digitalRead(28) == 0);//used as synchronizing
                //while((a.get(3).equals("finish preparing"))==false);
                //Thread.sleep(10);
            }

        }
        else System.out.println("发的不是命令");
    }
}



