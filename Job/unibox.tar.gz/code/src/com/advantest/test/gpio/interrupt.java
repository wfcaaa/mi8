package com.advantest.test.gpio;

import com.pi4j.wiringpi.Gpio;
import com.pi4j.wiringpi.GpioInterruptCallback;
import jdk.internal.util.xml.impl.Input;
// this class is used as debugging the callback function
public class interrupt {
    static{
        System.out.println("说明听者准备好了");
    }
     public static void main(String[] args) throws InterruptedException
    {
        if (Gpio.wiringPiSetup() == -1) {
            System.out.println(" ==>> GPIO SETUP FAILED");
            return;
        }

        Gpio.pinMode(1, Gpio.INPUT) ;
        Gpio.pinMode(26, Gpio.OUTPUT);
        Gpio.pinMode(27, Gpio.OUTPUT);
        Gpio.wiringPiISR(1, Gpio.INT_EDGE_FALLING, new GpioInterruptCallback() {
            @Override
            public void callback(int pin) {
               Gpio.digitalWrite(27,(1==Gpio.digitalRead(27))?0:1);
            }
        });
        //while(true)
        //{
            Gpio.digitalWrite(26, 1);
            try {
                Thread.sleep(3000);
            }
            catch(InterruptedException e)
            {}
            //Gpio.digitalWrite(26, 0);
            //Thread.sleep(3000);
        //}

    }

}
