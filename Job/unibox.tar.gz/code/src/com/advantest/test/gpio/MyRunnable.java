package com.advantest.test.gpio;

import com.pi4j.wiringpi.Gpio;
import java.util.concurrent.BlockingQueue;
import java.util.LinkedList;
import java.util.Queue;

public class MyRunnable implements Runnable {
    BlockingQueue<Integer>  queue;
    SRQlist srqlist=new SRQlist();
    MyRunnable(BlockingQueue<Integer> abc){
        queue=abc;
    }
    public void run ()
    {
        // this thread is used as handling SRQ
        Gpio.wiringPiISR(24, Gpio.INT_EDGE_FALLING, new GpioInterruptCallbacknew24(queue) );
        int len=0;
        synchronized (queue) {
            while (true) {
                try {
                    Thread.sleep(5000);
                } catch (Exception e) {
                    System.out.println("not support");
                }

                if (queue.size() > len) {
                    srqlist.onSRQ(queue);
                    len = queue.size();
                }

            }
        }
    }
}