package com.advantest.test.gpio;


import java.util.Arrays;
import com.pi4j.wiringpi.Gpio;

public class GPIBdrive  {
    public static void  send(String mess, int addresslis, int addresstalk) throws InterruptedException
    {

        GPIBcontrol.setlinsenertalker(addresslis, addresstalk);

        GPIBcontrol.setATN(1);
        Thread.sleep(100);

        //System.out.println(Gpio.digitalRead(21));
        //GPIBhandshake.setDAV(0);
        //GPIBhandshake.setDAV(1);

        char [] str=mess.toCharArray();
        for(char c:str)
        {
            GPIBsend.sendmessage((char)(255-c));
        }
        //GPIBsend.sendmessage((char)(13));
        GPIBcontrol.setEOI(0);
        GPIBsend.sendmessage((char)(10));
        GPIBcontrol.setEOI(1); //representing end
        GPIBcontrol.setATN(0);
    };
    public static void receive(int addresslis,int addresstalk) throws InterruptedException
    {
        GPIBcontrol.setlinsenertalker(addresslis, addresstalk);
        GPIBcontrol.setATN(1);
        // changing pinmode
        Gpio.pinMode(27, Gpio.INPUT);
        Gpio.pinMode(28, Gpio.OUTPUT);
        Gpio.digitalWrite(28,0);
        Gpio.pinMode(29, Gpio.OUTPUT);
        Gpio.digitalWrite(29,0);
        Gpio.pinMode(0, Gpio.INPUT);
        Gpio.pinMode(1, Gpio.INPUT);
        Gpio.pinMode(2, Gpio.INPUT);
        Gpio.pinMode(3, Gpio.INPUT);
        Gpio.pinMode(4, Gpio.INPUT);
        Gpio.pinMode(5, Gpio.INPUT);
        Gpio.pinMode(6, Gpio.INPUT);
        Gpio.pinMode(7, Gpio.INPUT);
        int[] intArray = new int[50];
        int a,b,c,i=0;
        //GPIBreceive receiver=new GPIBreceive(a);
        if((c=GPIBreceive.receivemessage())!=-1)
        {
            intArray[i]=c;
            i++;
        }
        while((c=GPIBreceive.receivemessage())!=-1) {
            intArray[i]=c;
            if(Gpio.digitalRead(25) == 1||c!=(10))
            {
                i++;
            }
            else

                break;

        }
        //char[] chararray=(char)intArray;
        //String string=Arrays.toString(intArray);
        //recovering pinmode
        Gpio.pinMode(27, Gpio.OUTPUT);
        Gpio.pinMode(28, Gpio.INPUT);
        Gpio.digitalWrite(28,0);
        Gpio.pinMode(29, Gpio.INPUT);
        Gpio.digitalWrite(29,0);
        Gpio.pinMode(0, Gpio.OUTPUT);
        Gpio.pinMode(1, Gpio.OUTPUT);
        Gpio.pinMode(2, Gpio.OUTPUT);
        Gpio.pinMode(3, Gpio.OUTPUT);
        Gpio.pinMode(4, Gpio.OUTPUT);
        Gpio.pinMode(5, Gpio.OUTPUT);
        Gpio.pinMode(6, Gpio.OUTPUT);
        Gpio.pinMode(7, Gpio.OUTPUT);
        StringBuilder strb=new StringBuilder();
        for(int index=0;index<i;index++)
            strb.append((char)intArray[index]);
        String string=strb.toString();
        System.out.println(string);
    };


}