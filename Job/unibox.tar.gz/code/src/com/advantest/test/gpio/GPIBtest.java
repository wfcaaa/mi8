package com.advantest.test.gpio;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.BlockingQueue;
import com.pi4j.wiringpi.Gpio;
import java.util.concurrent.ArrayBlockingQueue;
public class GPIBtest {
    public static void main(String[] args) throws InterruptedException {
        if (Gpio.wiringPiSetup() == -1) {
            System.out.println(" ==>> GPIO SETUP FAILED");
            return;
        }
        BlockingQueue<Integer> queue = new ArrayBlockingQueue<Integer>(10000);
        SRQlist srqlist=new SRQlist();

        int len=0;
        Gpio.pinMode(26, Gpio.OUTPUT);
        Gpio.pinMode(22, Gpio.OUTPUT);
        Gpio.pinMode(23, Gpio.OUTPUT);
        Gpio.pinMode(24, Gpio.INPUT);

        Gpio.pinMode(28, Gpio.INPUT);
        Gpio.pinMode(29, Gpio.INPUT);
        Gpio.pinMode(25, Gpio.OUTPUT);
        Gpio.pinMode(27, Gpio.OUTPUT);

        GPIBcontrol.setup();
        Gpio.wiringPiISR(24, Gpio.INT_EDGE_FALLING, new GpioInterruptCallbacknew24(queue) );
        // sometimes SRQ=0 and callback function can not detect the change,so this code detects the first SRQ
        synchronized (queue){
            if (Gpio.digitalRead(24) == 0) {
                try {
                    Gpio.digitalWrite(26, 0);
                    GPIBsend.sendcommand((char) 160);
                    GPIBsend.sendcommand((char) (255 - 24)); //SPE
                    GPIBsend.sendcommand((char) (255 - (5 + 64)));  //find talker
                    //GPIBsend.sendcommand((char) (255 - (0 + 32)));//  判断一下地址范围
                    GPIBcontrol.setATN(1);
                    // changing pinmode
                    Gpio.pinMode(0, Gpio.INPUT);
                    Gpio.pinMode(1, Gpio.INPUT);
                    Gpio.pinMode(2, Gpio.INPUT);
                    Gpio.pinMode(3, Gpio.INPUT);
                    Gpio.pinMode(4, Gpio.INPUT);
                    Gpio.pinMode(5, Gpio.INPUT);
                    Gpio.pinMode(6, Gpio.INPUT);
                    Gpio.pinMode(7, Gpio.INPUT);
                    int a = 255 - (Gpio.digitalRead(0) + 2 * Gpio.digitalRead(1) + 4 * Gpio.digitalRead(2)
                            + 8 * Gpio.digitalRead(3) + 16 * Gpio.digitalRead(4) + 32 * Gpio.digitalRead(5)
                            + 64 * Gpio.digitalRead(6) + 128 * Gpio.digitalRead(7));
                    queue.offer(a);
                    // changing pinmode
                    Gpio.pinMode(0, Gpio.OUTPUT);
                    Gpio.pinMode(1, Gpio.OUTPUT);
                    Gpio.pinMode(2, Gpio.OUTPUT);
                    Gpio.pinMode(3, Gpio.OUTPUT);
                    Gpio.pinMode(4, Gpio.OUTPUT);
                    Gpio.pinMode(5, Gpio.OUTPUT);
                    Gpio.pinMode(6, Gpio.OUTPUT);
                    Gpio.pinMode(7, Gpio.OUTPUT);
                    GPIBcontrol.setATN(0);
                    GPIBsend.sendcommand((char) (255 - 25)); //SPD
                    GPIBsend.sendcommand((char) (255 - 63));  //set untalk
                } catch (Exception e) {
                    System.out.println("meizhe");
                }
            }
        }

        while(true)
        {
            try {
                Thread.sleep(5000);
            }
            catch (Exception e)
            {
                System.out.println("not support");
            }

            //  if(queue.size()>len)
            //{
            //    srqlist.onSRQ(queue);
            //  len=queue.size();
            // }

            //}
            //Gpio.wiringPiISR(24, Gpio.INT_EDGE_BOTH, new GpioInterruptCallbacknew24(abc) );
            //Gpio.pinMode(26, Gpio.OUTPUT);
            //Gpio.pinMode(22, Gpio.OUTPUT);
            //Gpio.pinMode(23, Gpio.OUTPUT);
            //Gpio.pinMode(24, Gpio.INPUT);
            //Gpio.pinMode(28, Gpio.INPUT);
            //Gpio.pinMode(29, Gpio.INPUT);
            //Gpio.pinMode(25, Gpio.OUTPUT);
            //Gpio.pinMode(27, Gpio.OUTPUT);
            //System.out.println(GPIBhandshake.getNDAC());
            //System.out.println(Gpio.digitalRead(29));
            //System.out.println(Gpio.digitalRead(24));
            //System.out.println(Gpio.digitalRead(29));
            //GPIBcontrol.setATN(1);
            //System.out.println(Gpio.digitalRead(24));
            //System.out.println(Gpio.digitalRead(29));
            //System.out.println(GPIBhandshake.getNDAC());
            //System.out.println(Gpio.digitalRead(29));
            //GPIBcontrol.setup();
            //System.out.println(GPIBhandshake.getNDAC());



            //GPIBdrive.send("45634JKSDAHJKLHASHL;56UOIQWUEOU789758732078HJKLdfghGJHRET",5,0);
            //GPIBdrive.send("HL;56UOIQWUEOU789758732078HJKLd",5,0);
            //GPIBdrive.receive(0,5);



        }


    }
}
