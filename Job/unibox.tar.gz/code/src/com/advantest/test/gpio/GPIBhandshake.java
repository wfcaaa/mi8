package com.advantest.test.gpio;

import com.pi4j.wiringpi.Gpio;

import java.util.ArrayList;
import java.util.List;

public class GPIBhandshake {
    private static volatile int DAV=1;
    private static volatile int NRFD=1;
    private static volatile int NDAC=0;
    private List<String> ab;
    //GPIBhandshake(List<String> abc)
    //{
      //  ab=abc;
        //Gpio.wiringPiISR(28, Gpio.INT_EDGE_BOTH, new GpioInterruptCallbacknew28(abc)) ;
        /*{
            public void callback(int pin) {
                if (Gpio.digitalRead(28) == 1) {
                    abcd.add("说明听者准备好了");
                    //NRFD = 1;
                } else {
                    abcd.add("关掉开关");
                    //NRFD = 0;
                }
            }
        });*/
        //Gpio.wiringPiISR(29, Gpio.INT_EDGE_BOTH, new GpioInterruptCallbacknew29(abc) );
        /*{
            public void callback(int pin) {
                if (Gpio.digitalRead(29) == 1) {
                    abcd.add("听者接收完成");
                    //NDAC = 1;
                } else {
                    abcd.add("准备下一循环");
                    //NDAC = 0;
                }
            }
        });*/
    //}

    /*static { //是个小程序

        Gpio.wiringPiISR(28, Gpio.INT_EDGE_RISING, new GpioInterruptCallbacknew28(arrayl));
 /*       Gpio.wiringPiISR(28, Gpio.INT_EDGE_RISING, new GpioInterruptCallback() {
            public void callback(int pin, ArrayList<String> abc) {
                a.get(1);
                if(Gpio.digitalRead(28)==1) {
                    System.out.println("说明听者准备好了");
                    NRFD = 1;
                }
                else{
                    System.out.println("关掉开关");
                    NRFD = 0;;
                }
            }
        });
        Gpio.wiringPiISR(29, Gpio.INT_EDGE_BOTH, new GpioInterruptCallback() {
            public void callback(int pin) {
                if(Gpio.digitalRead(29)==1) {
                    System.out.println("听者接收完成");
                    NDAC = 1;
                }
                else{
                    System.out.println("准备下一循环");
                    NDAC = 0;
                }

            }
        });
    }
*/





    public  static void setDAV(int i)
    {
         DAV=i;
        Gpio.digitalWrite(27,i);
    };
    public  static void setNRFD(int i)
    {
         NRFD=i;
    };
    public  static void setNDAC(int i)
    {
         NDAC=i;
    };  //enum
    public  static int getDAV()
    {
        return DAV;
    };
    public  static int getNRFD()
    {
        return NRFD;
    };
    public  static int getNDAC()
    {
        return NDAC;
    };

}
