package com.advantest.test.gpio;

import java.util.concurrent.BlockingQueue;
import java.util.ArrayList;
import java.util.Queue;

public class SRQlist {
    public static void onSRQ(BlockingQueue<Integer> abc ){
        synchronized (abc) {
            while(abc.size()>0){
                int a=abc.poll();
                // in each case, some resolutions must be used on each specific case
                switch (a) {
                    case 65:
                        System.out.println(65);// this code must be replaced
                        break;
                    case 66:
                        System.out.println(66);// this code must be replaced
                        break;
                    case 67:
                        System.out.println(67);// this code must be replaced
                        break;
                    case 68:
                        System.out.println(68);// this code must be replaced
                        break;
                    case 69:
                        System.out.println(69);// this code must be replaced
                        break;
                    default:
                        System.out.println("out of boundary");// this code must be replaced
                        break;
                }

            }
        }
    }

}


