package com.advantest.test.gpio;

import com.pi4j.wiringpi.Gpio;
import com.pi4j.wiringpi.GpioInterruptCallback;

import java.util.ArrayList;
import java.util.List;
// this function is used as handshaking,however now is not realized
public class GpioInterruptCallbacknew29 implements GpioInterruptCallback {
    public List<String> abcd;

    GpioInterruptCallbacknew29(List<String> abc) {
        abcd = abc;
    }

    public void callback(int pin)
    {
        if (Gpio.digitalRead(29) == 1) {
            abcd.add("finish listening");
            //NDAC = 1;
        } else {
            abcd.add("prepare next cycle");
            //NDAC = 0;
        }
    }
    }