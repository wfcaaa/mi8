package com.advantest.test.gpio;

import com.pi4j.wiringpi.Gpio;
import com.pi4j.wiringpi.GpioInterruptCallback;

import java.util.ArrayList;
import java.util.List;
// this function is used as handshaking,however now is not realized
public class GpioInterruptCallbacknew28 implements GpioInterruptCallback {
    public List<String> abcd;

    GpioInterruptCallbacknew28(List<String> abc) {
        abcd = abc;
    }

    public void callback(int pin)
    {
        if(Gpio.digitalRead(28)==1) {
            abcd.add("finish preparing");
              //  NRFD = 1;
            }
        else{
            abcd.add("close the switch");
              //  NRFD = 0;
            }
    }
}


//    void callback(int pin, ArrayList<String> abc)
//    {
//        callback(pin);
//        abc.add();
//
//    }
