package com.advantest.test.gpio;


import com.pi4j.wiringpi.Gpio;
public class GPIBcontrol {
    private static volatile int ATN;
    private static volatile int REN;
    private static volatile int IFC;
    private static volatile int SRQ;
    private static volatile int EOI;
    GPIBcontrol()
    {
        ATN=0;
        REN=1;
        IFC=1;
        SRQ=1;
        EOI=1;
    }

    public static  void setATN(int i)     //enum  lei
    {
        ATN=i;
        Gpio.digitalWrite(26,i);
        //System.out.println(GPIBhandshake.getNDAC());
        //System.out.println(Gpio.digitalRead(29));/
        //Gpio.digitalWrite(21,0);
        //System.out.println(GPIBhandshake.getNDAC());
        //System.out.println(Gpio.digitalRead(29));
    };
    public  static void setREN(int i)
    {
        REN=i;
        Gpio.digitalWrite(23,i);
    };
    public  static void setIFC(int i)
    {
        IFC=i;
        Gpio.digitalWrite(22,i);
    };
    //public  static void setSRQ(int i)
   // {
     //   SRQ=i;
      //  Gpio.digitalWrite(24,i);
    //};
    public  static void setEOI(int i)
    {
        EOI=i;
        Gpio.digitalWrite(25,i);
    };
    public  static int getATN()
    {
        return ATN;
    };
    public  static int getREN()
    {
        return REN;
    };
    public  static int getIFC()
    {
        return IFC;
    };
    public  static int getSRQ()
    {
        return SRQ;
    };
    public  static int getEOI()
    {
        return EOI;
    };
    public static void setlinsenertalker(int addresslis, int addresstalk) throws InterruptedException
    {

        GPIBcontrol.setATN(0);

        GPIBsend.sendcommand((char)160); //set unlisten
        GPIBsend.sendcommand((char)(255-63));//set untalk
        GPIBsend.sendcommand((char)(255-(addresslis+32)));//  判断一下地址范围 //set listener
        GPIBsend.sendcommand((char)(255-(addresstalk+64))); //set talker

    }

    public static void setup() throws InterruptedException
    {
        //this function is used as initializing
        GPIBcontrol.setREN(0);
        GPIBcontrol.setIFC(0);
        Thread.sleep(1000);
        GPIBcontrol.setIFC(1);
        GPIBcontrol.setATN(0);
        GPIBcontrol.setEOI(1);
        //GPIBcontrol.setSRQ(1);
        GPIBhandshake.setDAV(1);
        Gpio.pinMode(0, Gpio.OUTPUT);
        Gpio.pinMode(1, Gpio.OUTPUT);
        Gpio.pinMode(2, Gpio.OUTPUT);
        Gpio.pinMode(3, Gpio.OUTPUT);
        Gpio.pinMode(4, Gpio.OUTPUT);
        Gpio.pinMode(5, Gpio.OUTPUT);
        Gpio.pinMode(6, Gpio.OUTPUT);
        Gpio.pinMode(7, Gpio.OUTPUT);
        Gpio.pinMode(27, Gpio.OUTPUT);
        Gpio.pinMode(28, Gpio.INPUT);
        Gpio.pinMode(29, Gpio.INPUT);

        //Gpio.pullUpDnControl(28, Gpio.PUD_DOWN);
        //Gpio.pullUpDnControl(29, Gpio.PUD_DOWN);
    }

}



