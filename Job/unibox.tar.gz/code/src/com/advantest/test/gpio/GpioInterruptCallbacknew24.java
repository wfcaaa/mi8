package com.advantest.test.gpio;
import com.pi4j.wiringpi.Gpio;
import com.pi4j.wiringpi.GpioInterruptCallback;



import java.util.List;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class GpioInterruptCallbacknew24  implements GpioInterruptCallback
{
    public BlockingQueue<Integer> queue;

    GpioInterruptCallbacknew24(BlockingQueue<Integer> abc) {
        queue = abc;
    }

    public  void  callback(int pin) {
        synchronized (queue) {
            if (Gpio.digitalRead(24) == 0) {
                try {
                    Gpio.digitalWrite(26, 0);
                    GPIBsend.sendcommand((char) 160);
                    GPIBsend.sendcommand((char) (255 - 24)); //SPE
                    GPIBsend.sendcommand((char) (255 - (5 + 64)));  //find talker
                    //GPIBsend.sendcommand((char) (255 - (0 + 32)));//  判断一下地址范围
                    GPIBcontrol.setATN(1);
                    // changing pinmode
                    Gpio.pinMode(0, Gpio.INPUT);
                    Gpio.pinMode(1, Gpio.INPUT);
                    Gpio.pinMode(2, Gpio.INPUT);
                    Gpio.pinMode(3, Gpio.INPUT);
                    Gpio.pinMode(4, Gpio.INPUT);
                    Gpio.pinMode(5, Gpio.INPUT);
                    Gpio.pinMode(6, Gpio.INPUT);
                    Gpio.pinMode(7, Gpio.INPUT);
                    int a = 255 - (Gpio.digitalRead(0) + 2 * Gpio.digitalRead(1) + 4 * Gpio.digitalRead(2)
                            + 8 * Gpio.digitalRead(3) + 16 * Gpio.digitalRead(4) + 32 * Gpio.digitalRead(5)
                            + 64 * Gpio.digitalRead(6) + 128 * Gpio.digitalRead(7));
                    queue.offer(a);
                    // changing pinmode
                    Gpio.pinMode(0, Gpio.OUTPUT);
                    Gpio.pinMode(1, Gpio.OUTPUT);
                    Gpio.pinMode(2, Gpio.OUTPUT);
                    Gpio.pinMode(3, Gpio.OUTPUT);
                    Gpio.pinMode(4, Gpio.OUTPUT);
                    Gpio.pinMode(5, Gpio.OUTPUT);
                    Gpio.pinMode(6, Gpio.OUTPUT);
                    Gpio.pinMode(7, Gpio.OUTPUT);
                    GPIBcontrol.setATN(0);
                    GPIBsend.sendcommand((char) (255 - 25)); //SPD
                    GPIBsend.sendcommand((char) (255 - 63));  //set untalk
                } catch (Exception e) {
                    System.out.println("meizhe");
                }
            } else ;
        }
    }

}




