package com.advantest.test.gpio;

//this interface now is not used
public interface callback {
    public void onSRQ(char[] ab);
}
