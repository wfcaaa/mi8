1. GPIO GPIB
YOU CAN USE GPIO READALL COMMANDS ON RASPIBERRY TO LOOK FOR THE PIN NUMBERS
GPIB 1-8   GPIO 0-7
ATN        GPIO 26
DAV        GPIO 27
NRFD       GPIO 28
NDAC       GPIO 29
IFC        GPIO 22
REN        GPIO 23
SRQ        GPIO 24
EOI        GPIO 25

2. all the data bus are negative logic, for example, if you want to send 0, please set voltage 1 and vice versa.
3. if you want to check command sequences, please look for them on the book IEEE488.1 PAGE 113 and etc.
4. now the code is using while to synchronize, however it should be replaced by callback function.
5. some codes need to revised and the framework needs to refactor.
