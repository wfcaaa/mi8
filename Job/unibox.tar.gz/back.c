#include<wiringPi.h>
#include<stdio.h>
#include<unistd.h>

#define EOI     26
#define ATN     23


#define DAV     27
#define NRFD    28
#define NDAC    29


void initHandShakePinMode()
{
    pinMode(DAV,OUTPUT);
    pinMode(NRFD,INPUT);
    digitalWrite(NRFD,1);
    pinMode(NDAC,INPUT);
    digitalWrite(NDAC,0);
}

int isConditionOccur(const int pin,const int value,const int timeout)
{
    int i = 0,isSuccess = 0;
    printf("step in isConditionOccur, timeout:%d\n",timeout);
    for(i=0;i<timeout;++i)
    {
        if(digitalRead(pin) == value)
        {
          isSuccess = 1;
          break;
        }
    }
    printf("isConditionOccur return:%d\n",isSuccess);
    return isSuccess;
}
int sendByteForMessageType(const char ch,const int timeout)
{
    
    // if the lasest byte data has been accepted and listener has not been read for data yet, 
  if(digitalRead(NRFD) == 1 && digitalRead(NDAC) == 0)
  {
     printf("NRFD=%d , NDAC=%d\n",digitalRead(NRFD),digitalRead(NDAC));
    digitalWriteByte(ch);
    printf("set DAV to 0\n");
    digitalWrite(DAV,0);

    if(isConditionOccur(NRFD,1,timeout)!= 1)
    {
        printf("timout when wait NRFD=1\n");
        return -1;
    }
    
    if(isConditionOccur(NDAC,0,timeout)!= 1)
    {
        printf("timout when wait NDAC=0\n");
        return -1;
    }
    
    printf("try to set DAV to 1\n");
    digitalWrite(DAV,1);
    printf("set DAV to 1\n");

    while(digitalRead(NDAC)==1);
     printf("NDAC = 1,continue ....\n");


    printf("try to detect if listener is ready for data----ATN=1\n");
    while(digitalRead(NRFD)==0);


    
    printf(" listener is ready for data\n");

#if 0
    printf("try to detect if have receive EOI  ---ATN=1\n");
    while(digitalRead(EOI) == 1);
    printf("have detect EOI\n");
#endif

  }
  else
  {
    printf("NRFD=%d , NDAC=%d\n",digitalRead(NRFD),digitalRead(NDAC));
    return -1;
  }
  return 0;
   
}

void initDataline(int flag)
{
    int i = 0 ;
    for(i=0;i<8;++i)
    {
      if(flag == 1)
        pinMode(i,OUTPUT);
      else if(flag == 0)
        pinMode(i,INPUT);
      else
        printf("flag:%d is invalid.plesae input:0(input mode) or 1(output mode)\n",flag);
    }
}
int main()
{
    printf("will initial gpibo setup ...\n");
    if(wiringPiSetup() < 0)
      printf("pigpio initialisation failed\n");
    else
      printf(" pigpio initialised okay.\n");

    initHandShakePinMode();
    
    initDataline(1); // 0--> input mode, 1--> output mode
    pinMode(ATN,OUTPUT);
    pinMode(EOI,OUTPUT);
    digitalWrite(ATN,1);

    char ch = 'a';
 
    if(sendByteForMessageType(ch,10) == -1)
    {
        printf("sendByteForMessageType failed\n");
        return 0;
    }
    
  //  digitalWrite(EOI,1);
    digitalWrite(ATN,0);
    return 0;
}
