#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x4766f3ab, "module_layout" },
	{ 0xd3f748d2, "tms9914_request_system_control" },
	{ 0x85bd1608, "__request_region" },
	{ 0x3351716f, "kmalloc_caches" },
	{ 0x77358855, "iomem_resource" },
	{ 0x3c1786aa, "tms9914_disable_eos" },
	{ 0xb96ee748, "tms9914_online" },
	{ 0x6859ed39, "tms9914_enable_eos" },
	{ 0xfe7eecac, "tms9914_read" },
	{ 0x66520fda, "tms9914_primary_address" },
	{ 0x53744b80, "tms9914_parallel_poll_response" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
	{ 0xc37060e0, "gpib_unregister_driver" },
	{ 0x168fef9, "tms9914_t1_delay" },
	{ 0x32d016cf, "tms9914_parallel_poll" },
	{ 0x350d469e, "tms9914_iomem_read_byte" },
	{ 0x5f754e5a, "memset" },
	{ 0xc73c5096, "tms9914_parallel_poll_configure" },
	{ 0x67732736, "tms9914_write" },
	{ 0xa06d161c, "tms9914_update_status" },
	{ 0xf3d0b495, "_raw_spin_unlock_irqrestore" },
	{ 0xc5850110, "printk" },
	{ 0xf45dccb5, "tms9914_serial_poll_status" },
	{ 0x1d37eeed, "ioremap" },
	{ 0x9fef51c3, "tms9914_board_reset" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0xac5fe686, "tms9914_secondary_address" },
	{ 0xbf429c6d, "tms9914_remote_enable" },
	{ 0x3e1ce7db, "tms9914_serial_poll_response" },
	{ 0x7b5af827, "tms9914_command" },
	{ 0x42cfb7af, "gpib_register_driver" },
	{ 0xca646aa3, "tms9914_interface_clear" },
	{ 0xfa5b5153, "tms9914_take_control" },
	{ 0x1035c7c2, "__release_region" },
	{ 0x81f8ac7e, "kmem_cache_alloc_trace" },
	{ 0xde55e795, "_raw_spin_lock_irqsave" },
	{ 0xdd1cd147, "tms9914_go_to_standby" },
	{ 0x37a0cba, "kfree" },
	{ 0xedc03953, "iounmap" },
	{ 0xc50a883c, "tms9914_interrupt_have_status" },
	{ 0xa1490ce8, "tms9914_return_to_local" },
	{ 0xec119222, "tms9914_iomem_write_byte" },
	{ 0xf220ae5a, "tms9914_line_status" },
	{ 0xc1514a3b, "free_irq" },
};

MODULE_INFO(depends, "tms9914,gpib_common");


MODULE_INFO(srcversion, "26EE023F46A35C627CD79C1");
