#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x4766f3ab, "module_layout" },
	{ 0x97e5f278, "platform_driver_unregister" },
	{ 0xc37060e0, "gpib_unregister_driver" },
	{ 0x42cfb7af, "gpib_register_driver" },
	{ 0x13f8c478, "__platform_driver_register" },
	{ 0xeff892d4, "dma_request_chan" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0xc146ded0, "platform_get_irq" },
	{ 0xffeaebe8, "_dev_info" },
	{ 0x1d37eeed, "ioremap" },
	{ 0x85bd1608, "__request_region" },
	{ 0xcb203f2e, "platform_get_resource_byname" },
	{ 0x350aa546, "driver_find_device" },
	{ 0x47103e07, "nec7210_board_online" },
	{ 0x50d5c7ad, "nec7210_set_handshake_mode" },
	{ 0xc1514a3b, "free_irq" },
	{ 0x1035c7c2, "__release_region" },
	{ 0x77358855, "iomem_resource" },
	{ 0xfaa64eda, "nec7210_board_reset" },
	{ 0x58d28d0c, "dma_release_channel" },
	{ 0x37a0cba, "kfree" },
	{ 0x5f754e5a, "memset" },
	{ 0x81f8ac7e, "kmem_cache_alloc_trace" },
	{ 0x3351716f, "kmalloc_caches" },
	{ 0x56755c4a, "_dev_err" },
	{ 0x2cfde9a2, "warn_slowpath_fmt" },
	{ 0x30011784, "dev_driver_string" },
	{ 0xc5850110, "printk" },
	{ 0x50b03c47, "sg_init_table" },
	{ 0xb8ec81d, "dma_unmap_page_attrs" },
	{ 0x15d315d0, "dma_map_page_attrs" },
	{ 0xe45b9834, "mem_map" },
	{ 0xc31db0ce, "is_vmalloc_addr" },
	{ 0x9d669763, "memcpy" },
	{ 0x41d3cb6d, "nec7210_set_reg_bits" },
	{ 0x16b769a1, "push_gpib_event" },
	{ 0x3dcf1ffa, "__wake_up" },
	{ 0x676bbc0f, "_set_bit" },
	{ 0xda72a368, "nec7210_interrupt_have_status" },
	{ 0x1a46e5e, "_dev_notice" },
	{ 0xfab9e811, "gpib_match_device_path" },
	{ 0x49970de8, "finish_wait" },
	{ 0x647af474, "prepare_to_wait_event" },
	{ 0x1000e51, "schedule" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x2a3aa678, "_test_and_clear_bit" },
	{ 0xa1c76e0a, "_cond_resched" },
	{ 0xd2d2d267, "nec7210_t1_delay" },
	{ 0x71e32aa1, "nec7210_serial_poll_status" },
	{ 0x49ebacbd, "_clear_bit" },
	{ 0xcc8398a5, "nec7210_parallel_poll_response" },
	{ 0xa0727970, "nec7210_parallel_poll_configure" },
	{ 0xc038da87, "nec7210_parallel_poll" },
	{ 0xa7ad7165, "nec7210_secondary_address" },
	{ 0x6f9e0772, "nec7210_primary_address" },
	{ 0xb66e09be, "nec7210_update_status" },
	{ 0x99f8257, "nec7210_disable_eos" },
	{ 0xdacacbf3, "nec7210_enable_eos" },
	{ 0x7a4ac585, "nec7210_remote_enable" },
	{ 0xab716a68, "nec7210_interface_clear" },
	{ 0x8bfb318c, "nec7210_request_system_control" },
	{ 0x94013af7, "nec7210_go_to_standby" },
	{ 0xb9a6b888, "nec7210_take_control" },
	{ 0x2f987480, "nec7210_command" },
	{ 0x67744005, "nec7210_write" },
	{ 0xa1b5ded6, "nec7210_read" },
	{ 0x86332725, "__stack_chk_fail" },
	{ 0x8f678b07, "__stack_chk_guard" },
	{ 0xf3d0b495, "_raw_spin_unlock_irqrestore" },
	{ 0xde55e795, "_raw_spin_lock_irqsave" },
	{ 0x8e865d3c, "arm_delay_ops" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
};

MODULE_INFO(depends, "gpib_common,nec7210");

MODULE_ALIAS("of:N*T*Cfmhess,fmh_gpib_core");
MODULE_ALIAS("of:N*T*Cfmhess,fmh_gpib_coreC*");

MODULE_INFO(srcversion, "4EE5BBA2A0B6E722C7F1BD8");
