#include <iostream>

using namespace std;

int main()
{
  cout << "I think I'm a simulator :-)" << endl;

  return 0;
}
