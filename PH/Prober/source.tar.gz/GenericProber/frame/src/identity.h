#define PHFRAME_IDENT "General Handler Driver"
#define PHFRAME_DATE "Fri Mar 4 15:36:08 CST 2022"
#define PHFRAME_REVISION "8.99.99_DEBUG_verify-issue-jaxwu_20220304"
#undef PHFRAME_LOCAL
