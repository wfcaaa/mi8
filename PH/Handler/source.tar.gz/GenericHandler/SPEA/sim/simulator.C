#include    <iostream>
using namespace std;


int main()
{
    cout << "I think I need to be implemented..." << endl;
}
