#define PHFUNC_IDENT "Advantest Handler Driver Plugin"
#define PHFUNC_DATE "Fri Mar 4 15:35:48 CST 2022"
#define PHFUNC_REVISION "8.99.99_DEBUG_verify-issue-jaxwu_20220304"
#undef PHFUNC_LOCAL
